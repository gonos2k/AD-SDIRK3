# Tiny MPI lifecycle smoke report

Local timestamp: 2026-10-23 19:30:13 JST

## Result

The bounded smoke did **not reproduce a nonzero launcher return or timeout in the 30 properly built MPI lifecycle launches**. It ran ten repetitions each of a C probe, an F77 `mpif.h` probe, and the existing F77 PMPI finalizer observer linked to the probe. All 30 returned RC=0 within the 5-second per-launch timeout. Each requested `MPI_THREAD_SINGLE` first and received `MPI_THREAD_SINGLE`; all logged rank 0, size 1, `MPI_Finalize` entry, return, and `ierr=0`.

Two earlier runner bootstrap invocations count toward the 32-launch cap. Their numeric return codes and individual elapsed times were not serialized before the first runner version raised. The C log shows that finalization returned; the F77 invocation used a missing executable and is a setup failure, not lifecycle evidence. Both are retained with `return_code: null` and excluded from the proper 30-launch result. The first runner process window was under 1.9 seconds including compile and both setup invocations; the corrected batch including builds took 5.60 seconds, with 4.61 seconds summed across its 30 captured `mpirun` elapsed fields. All 32 actual `mpirun` invocations remain within the 32-launch cap and the bounded execution windows remain below 60 seconds.

The initial direct `mpifort` link failed with `ld: library 'System' not found`. The F77 probes then linked successfully with the explicit `/usr/bin/g++` plus Homebrew GNU Fortran and Open MPI libraries used by the archived smoke receipt. This was a build invocation issue; no lifecycle result was inferred from it.

## Measurements

The recorded per-call `MPI_Finalize` wall-clock durations were:

- C base: 0.784–1.092 ms; median 0.896 ms.
- F77 base: 0.895–1.066 ms; median 0.981 ms.
- F77 with PMPI observer: 1.039–1.366 ms; median 1.298 ms.

All ten PMPI traces show `forward ierr_ptr=present` and return with `ierr=0`, initialized=1, finalized=1. These tiny probes are not comparable to the WRF process workload. The separate WRF timing ledger records 39 RC=0 cases finishing 0.140–0.534 seconds after their last NetCDF output, while the failed 192-step case ended 18.052 seconds after its last NetCDF output. This timing places attention in post-output shutdown but does not identify the cause. The smoke result does not explain that WRF RC=1 and does not prove universal MPI shutdown reliability.

No WRF, Torch, PDE, or model executable was built or launched. No MPI error suppression, exit-code normalization, timeout changes, or runtime-policy changes were made. The prior native idealized-twin evidence tree was read only.

## Provenance

- Target worktree `/private/tmp/mpi-exit-investigation-20261023`: HEAD `0816c32393c7a0b12081e1d4c4e5f8b0ad46c9b3`, tree `0de07ff435a2621447d8b5f5cf4ee8426533aef2`, clean.
- Open MPI: 5.0.9. `mpicc`: Homebrew clang 22.1.4. `mpifort`: GNU Fortran 15.2.0.
- Launch command: `/opt/homebrew/bin/mpirun -np 1 --bind-to none <executable>`.
- The C, F77, common logger, and copied PMPI observer source hashes, all compiler/linker commands, executable hashes, per-attempt return codes, logs, and timing records are in `green_smoke/green_smoke_receipt.json`.
- Current source orientation receipt: `graph_orientation.json`, SHA256 `2d318ea78d51ec0985d7e92e099525ae139bbc8f7090bf9efb0887baf93e0adc`. It binds the clean target worktree to the reused source graphs and a bounded eight-file C++ MPI/halo AST; Fortran extraction gaps and manual source checks are recorded there.
- Smoke receipt SHA256: `5c9e2440ae6f0781d080f8fa6dddcc98bb5cb53d4661e842fae1951b781b7793`.
