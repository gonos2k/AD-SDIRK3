#!/usr/bin/env python3
"""One-shot PMIx_Init/Finalize ack-delay probe with owned-PGID fault injection."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shlex
import signal
import subprocess
import time


ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT.parent
BUILD = ROOT / 'build'
ATTEMPTS = ROOT / 'attempts'
SOURCE = ROOT / 'pmix_ack_delay_probe.c'
EXE = BUILD / 'pmix_ack_delay_probe.exe'
MPIRUN = '/opt/homebrew/bin/mpirun'
MPICC = '/opt/homebrew/bin/mpicc'
PKG_CONFIG = '/opt/homebrew/bin/pkg-config'
PMIX_INFO = '/opt/homebrew/bin/pmix_info'
PKG_CONFIG_PATH = '/opt/homebrew/opt/pmix/lib/pkgconfig'
EXPECTED_PMIX_VERSION = '5.0.9'
DEFAULT_FINALIZE_TIMEOUT_S = 10
READY_WAIT_S = 30.0
POST_RESUME_WAIT_S = 20.0
MAX_LAUNCHES = 4
MAX_NEW_LAUNCHES = 2
PRIOR_RECEIPT = EVIDENCE / 'green_ack_delay_v2/fault_probe_receipt.json'
PRIOR_RECEIPT_SHA256 = 'a92f6ca0c244ccdb55447c80f7117293fcb46e1b35ee55e32a867f63ce095579'
TOTAL_WALL_CAP_S = 75.0
SCENARIOS = (('baseline_hold_1s', 1.0), ('delayed_hold_12p5s', 12.5))


class ProbeInterrupted(Exception):
    pass


def stop_handler(signum, _frame):
    raise ProbeInterrupted(f'driver received signal {signum}')


def stamp() -> dict[str, int]:
    return {'wall_ns': time.time_ns(), 'monotonic_ns': time.monotonic_ns()}


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def write_json(path: Path, obj: dict, *, exclusive: bool = False) -> None:
    with path.open('x' if exclusive else 'w') as stream:
        stream.write(json.dumps(obj, sort_keys=True, separators=(',', ':')) + '\n')
        stream.flush()
        os.fsync(stream.fileno())


def capture(command: list[str], *, env: dict[str, str] | None = None,
            timeout: float = 10.0, deadline: float | None = None) -> dict:
    started = time.monotonic()
    if deadline is not None:
        remaining = deadline - started
        if remaining <= 0:
            return {'command': command, 'return_code': None, 'stdout': '',
                    'stderr': 'cumulative preflight deadline exhausted',
                    'elapsed_seconds': 0.0, 'timed_out': True}
        timeout = min(timeout, remaining)
    try:
        proc = subprocess.run(command, text=True, capture_output=True,
                              check=False, env=env, timeout=timeout)
        return {'command': command, 'return_code': proc.returncode,
                'stdout': proc.stdout, 'stderr': proc.stderr,
                'elapsed_seconds': time.monotonic()-started, 'timed_out': False}
    except subprocess.TimeoutExpired as exc:
        out = exc.stdout or ''
        err = exc.stderr or ''
        if isinstance(out, bytes): out = out.decode(errors='replace')
        if isinstance(err, bytes): err = err.decode(errors='replace')
        return {'command': command, 'return_code': None, 'stdout': out,
                'stderr': err, 'elapsed_seconds': time.monotonic()-started,
                'timed_out': True}


def relevant_env(env: dict[str, str]) -> dict[str, str]:
    prefixes = ('PMIX_', 'PRTE_', 'OMPI_', 'OPAL_')
    return {k:v for k,v in sorted(env.items())
            if k.startswith(prefixes) or k in ('PATH','DYLD_LIBRARY_PATH')}


def mca_overrides(env: dict[str, str]) -> dict[str, str]:
    prefixes = ('PMIX_MCA_', 'PRTE_MCA_', 'OMPI_MCA_', 'OPAL_MCA_')
    return {k:v for k,v in sorted(env.items()) if k.startswith(prefixes)}


def inherited_pmix_identity(env: dict[str,str]) -> dict[str,str]:
    exact={'PMIX_NAMESPACE','PMIX_RANK','PMIX_SERVER_NSPACE','PMIX_SERVER_RANK','PMIX_ID'}
    prefixes=('PMIX_SERVER_URI','PMIX_SERVER_URI2')
    return {k:v for k,v in sorted(env.items()) if k in exact or k.startswith(prefixes)}


def preflight_and_build(start_time: float, deadline: float | None = None) -> dict:
    BUILD.mkdir(parents=True, exist_ok=True)
    pkg_env = os.environ.copy()
    pkg_env['PKG_CONFIG_PATH'] = PKG_CONFIG_PATH
    pmix_info = capture([PMIX_INFO, '--param', 'pmix', 'base', '--level', '9'], deadline=deadline)
    version = capture([PKG_CONFIG, '--modversion', 'pmix'], env=pkg_env, deadline=deadline)
    cflags = capture([PKG_CONFIG, '--cflags', 'pmix'], env=pkg_env, deadline=deadline)
    libs = capture([PKG_CONFIG, '--libs', 'pmix'], env=pkg_env, deadline=deadline)
    mpirun_version = capture([MPIRUN, '--version'], deadline=deadline)
    mpicc_version = capture([MPICC, '--version'], deadline=deadline)
    env_overrides = mca_overrides(os.environ)
    identity_env = inherited_pmix_identity(os.environ)
    info_text = pmix_info.get('stdout', '')
    default_proven = (pmix_info['return_code'] == 0 and
        'pmix_finalize_timeout' in info_text and
        'current value: "10"' in info_text and 'data source: default' in info_text)
    preflight = {'pmix_info':pmix_info,'pkg_config_version':version,
        'pkg_config_cflags':cflags,'pkg_config_libs':libs,
        'mpirun_version':mpirun_version,'mpicc_version':mpicc_version,
        'effective_mpi_environment':relevant_env(os.environ),
        'MCA_overrides':env_overrides,
        'inherited_PMIX_identity_environment':identity_env,
        'pmix_finalize_timeout_environment_value':os.environ.get('PMIX_MCA_pmix_finalize_timeout'),
        'pmix_default_10_verified':default_proven,
        'runtime_environment_modified':False}
    failures=[]
    if version['return_code'] != 0 or version['stdout'].strip() != EXPECTED_PMIX_VERSION:
        failures.append('pkg-config did not resolve PMIx 5.0.9')
    if cflags['return_code'] != 0 or libs['return_code'] != 0:
        failures.append('PMIx pkg-config cflags/libs unavailable')
    if mpirun_version['return_code'] != 0 or 'Open MPI) 5.0.9' not in mpirun_version['stdout']:
        failures.append('mpirun is not Open MPI 5.0.9')
    if not default_proven:
        failures.append('PMIx default finalize timeout10 not established')
    if env_overrides:
        failures.append('preexisting PMIX/PRTE/OMPI/OPAL MCA environment override present; refusing to alter or run')
    if identity_env:
        failures.append('inherited PMIX_SERVER_URI/namespace/rank identity present; refusing attachment to an outer PMIx server')
    if failures:
        return {'status':'blocked_preflight','preflight':preflight,'failures':failures,'build':None}
    compile_command=[MPICC,'-std=c11','-O2','-Wall','-Wextra','-Werror',
        *shlex.split(cflags['stdout']),str(SOURCE),*shlex.split(libs['stdout']),'-o',str(EXE)]
    build=capture(compile_command,timeout=15.0,deadline=deadline)
    pc=Path('/opt/homebrew/opt/pmix/lib/pkgconfig/pmix.pc')
    build.update({'source':str(SOURCE),'source_sha256':sha(SOURCE),
        'pkg_config_file':str(pc),'pkg_config_sha256':sha(pc),
        'pkg_config_path_for_compile_only':PKG_CONFIG_PATH,
        'environment_overrides_for_compile_only':{'PKG_CONFIG_PATH':PKG_CONFIG_PATH},
        'executable':{'path':str(EXE),'bytes':EXE.stat().st_size,'sha256':sha(EXE)} if EXE.is_file() else None,
        'elapsed_from_driver_start_s':time.monotonic()-start_time})
    if build['return_code'] != 0 or build['timed_out'] or not EXE.is_file():
        return {'status':'blocked_build','preflight':preflight,
            'failures':['PMIx client build failed; no launcher invoked'],'build':build}
    return {'status':'ready','preflight':preflight,'failures':[],'build':build}


def baseline_clean_gate(attempt: dict) -> dict:
    final_tree=attempt.get('final_process_tree') or {}
    markers=attempt.get('markers') or {}
    init=(markers.get('init_return.json') or {}).get('record') or {}
    finalize=(markers.get('finalize_return.json') or {}).get('record') or {}
    app_exit=(markers.get('app_exit.json') or {}).get('record') or {}
    resumes=attempt.get('resume_results') or []
    conditions={
        'probe_completed':attempt.get('status')=='hold_elapsed',
        'launcher_return_code_zero':attempt.get('return_code')==0,
        'launcher_return_code_captured':attempt.get('return_code_capture_status')=='captured',
        'PMIx_Init_success':init.get('pmix_status')==0,
        'PMIx_Finalize_return_recorded':bool(finalize),
        'PMIx_Finalize_success':finalize.get('pmix_status')==0,
        'app_exit_zero':app_exit.get('app_exit_code')==0,
        'no_ready_or_return_timeout':not attempt.get('timed_out',False) and
            attempt.get('post_resume_wait_timeout') is not True,
        'all_stopped_runtime_ancestors_resumed_by_pid':len(resumes)==len(attempt.get('sigstop_targets') or []) and
            bool(resumes) and all(x.get('resume_method')=='pid' and x.get('resume_confirmed') for x in resumes),
        'no_safety_or_cleanup_error':not attempt.get('resume_safety_error') and
            not attempt.get('timeout_cleanup') and not attempt.get('own_group_cleanup') and
            not attempt.get('control_marker_error') and
            not (markers.get('setup_cleanup_finalize_return.json') or {}).get('record'),
        'final_process_tree_snapshot_valid':not attempt.get('final_process_tree_error') and
            final_tree.get('ps_return_code')==0 and isinstance(final_tree.get('process_group_rows'),list),
        'owned_launch_process_group_empty':final_tree.get('process_group_rows')==[]}
    return {'conditions':conditions,'passed':all(conditions.values()),
            'failure_reasons':[k for k,v in conditions.items() if not v]}


def ps_table() -> tuple[dict[int,dict],dict]:
    command=['/bin/ps','-axo','pid=,ppid=,pgid=,stat=,comm=,args=']
    proc=subprocess.run(command,text=True,capture_output=True,check=False,timeout=2.0)
    rows={}
    for line in proc.stdout.splitlines():
        f=line.strip().split(None,5)
        if len(f)<5: continue
        try: pid,ppid,pgid=map(int,f[:3])
        except ValueError: continue
        comm=f[4];args=f[5] if len(f)>5 else ''
        try: hint=Path(shlex.split(args)[0]).name.lower()
        except (ValueError, IndexError): hint=''
        identity_query=None
        if hint in {'mpirun','prterun','prted',EXE.name.lower()}:
            full=subprocess.run(['/bin/ps','-p',str(pid),'-o','comm='],
                text=True,capture_output=True,check=False,timeout=2.0)
            identity_query={'return_code':full.returncode,'stderr':full.stderr,
                            'full_comm':full.stdout.strip()}
            # A failed identity query cannot authorize a signal.
            comm=full.stdout.strip() if full.returncode==0 else ''
        rows[pid]={'pid':pid,'ppid':ppid,'pgid':pgid,'stat':f[3],
                   'comm':comm,'name':Path(comm).name.lower(),'args':args,'comm_identity_query':identity_query}
    return rows,{'command':command,'return_code':proc.returncode,'stderr':proc.stderr}


def ancestor_chain(client_pid: int, rows: dict[int,dict]) -> list[dict]:
    chain=[];seen=set();current=client_pid
    while current in rows and current not in seen:
        seen.add(current);entry=rows[current];chain.append(entry)
        if entry['ppid']<=1: break
        current=entry['ppid']
    return chain


def group_rows(rows: dict[int,dict], pgid: int) -> list[dict]:
    return [rows[pid] for pid in sorted(rows) if rows[pid]['pgid']==pgid]


OPENMPI_PREFIXES=(Path('/opt/homebrew/opt/open-mpi').resolve(),
                  Path('/opt/homebrew/Cellar/open-mpi/5.0.9').resolve())
RUNTIME_NAMES={'mpirun','prterun','prted'}


def executable_path(pid: int, expected_name: str) -> tuple[str|None,dict]:
    command=['/usr/sbin/lsof','-a','-p',str(pid),'-d','txt','-Fn']
    try:
        proc=subprocess.run(command,text=True,capture_output=True,check=False,timeout=2.0)
        paths=[line[1:] for line in proc.stdout.splitlines()
               if line.startswith('n') and line[1:].startswith('/')]
        selected=None
        aliases={'prterun':{'prterun','prte'}}
        accepted_basenames=aliases.get(expected_name,{expected_name})
        for path in paths:
            resolved=Path(path).resolve()
            if Path(path).name in accepted_basenames and any(resolved.is_relative_to(prefix) for prefix in OPENMPI_PREFIXES):
                selected=str(resolved);break
        return selected,{'command':command,'return_code':proc.returncode,'stderr':proc.stderr,
                         'candidate_text_paths':paths,'selected_path':selected}
    except Exception as exc:
        return None,{'command':command,'error':repr(exc),'candidate_text_paths':[],'selected_path':None}


def process_birth(pid: int) -> tuple[str|None,dict]:
    command=['/bin/ps','-p',str(pid),'-o','lstart=']
    try:
        proc=subprocess.run(command,text=True,capture_output=True,check=False,timeout=2.0)
        value=proc.stdout.strip() or None
        return value,{'command':command,'return_code':proc.returncode,'value':value,'stderr':proc.stderr}
    except Exception as exc:
        return None,{'command':command,'error':repr(exc),'value':None}


def select_server(client_pid: int, driver_pid: int, launcher_pid: int,
                  pgid: int, rows: dict[int,dict]) -> dict:
    chain=ancestor_chain(client_pid,rows);ancestors=chain[1:]
    runtime=[x for x in ancestors if x['name'] in RUNTIME_NAMES]
    client=rows.get(client_pid);launcher=rows.get(launcher_pid)
    group=group_rows(rows,pgid)
    candidates=[];identity_reviews=[]
    for item in runtime:
        exe,exe_review=executable_path(item['pid'],item['name'])
        birth,birth_review=process_birth(item['pid'])
        enriched={**item,'executable_path':exe,'executable_path_review':exe_review,
                  'birth_time':birth,'birth_time_review':birth_review}
        identity_reviews.append({'pid':item['pid'],'exe':exe_review,'birth':birth_review})
        if item['pgid']==pgid and exe is not None and birth is not None:
            candidates.append(enriched)
    safe=(client is not None and client['pgid']==pgid and
          launcher is not None and launcher['pgid']==pgid and pgid==launcher_pid and
          driver_pid not in {x['pid'] for x in group} and bool(runtime) and
          len(candidates)==len(runtime) and
          all(x['pid'] not in (driver_pid,client_pid) for x in candidates))
    return {'safe_to_signal':safe,
        'reason':'all recognized runtime ancestors are in the isolated PGID with verified Open MPI executable paths' if safe else
          'unsafe/ambiguous process tree: need mpirun/prterun/prted ancestors in the launch PGID with installed executable paths',
        'client':client,'launcher':launcher,'ancestor_chain':chain,
        'runtime_ancestors':runtime,'owned_runtime_ancestors':candidates,
        'runtime_identity_reviews':identity_reviews,
        'launch_process_group':group,'excluded_driver_pid':driver_pid}


def revalidate_owned_target(target: dict, client_pid: int, driver_pid: int,
                            pgid: int) -> tuple[bool,dict|None,str]:
    try:
        rows,_=ps_table();now=rows.get(target['pid'])
    except Exception as exc:
        return False,None,f'process snapshot failed: {exc!r}'
    if now is None: return False,None,'selected PID disappeared'
    try: os_pgid=os.getpgid(now['pid'])
    except OSError as exc: return False,now,f'getpgid failed: {exc!r}'
    if (now['pid'] in (client_pid,driver_pid) or now['name']!=target['name'] or
        now['pgid']!=pgid or os_pgid!=pgid or now['ppid']!=target['ppid']):
        return False,now,'PID/comm/PPID/PGID changed; refusing signal'
    exe,review=executable_path(now['pid'],now['name'])
    if exe is None or exe!=target.get('executable_path'):
        return False,{**now,'executable_review':review},'runtime executable path changed or is not under installed Open MPI prefix'
    birth,_=process_birth(now['pid'])
    if birth is None or birth!=target.get('birth_time'):
        return False,{**now,'birth_time_now':birth},'process birth time changed; refusing possible PID reuse'
    return True,{**now,'executable_path':exe,'birth_time':birth},'same owned runtime PID/comm/PPID/PGID/executable/birth time confirmed'


def signal_cont_owned(target: dict, client_pid: int, driver_pid: int, pgid: int) -> dict:
    try: safe,current,reason=revalidate_owned_target(target,client_pid,driver_pid,pgid)
    except Exception as exc: safe,current,reason=False,None,f'revalidation exception {exc!r}'
    out={'timestamp':stamp(),'pid':target['pid'],'signal':'SIGCONT',
         'ownership_check':reason,'process':current,'sent':False,'error':None}
    if not safe: return out
    try: os.kill(target['pid'],signal.SIGCONT);out['sent']=True
    except OSError as exc: out['error']=repr(exc)
    return out


def wait_target_resumed(target: dict, pgid: int, timeout_s: float=2.0) -> dict:
    deadline=time.monotonic()+timeout_s;last=None
    while time.monotonic()<deadline:
        rows,_=ps_table();last=rows.get(target['pid'])
        if last is None:
            return {'resumed_or_exited':True,'state':'server_process_exited','process':None}
        exe,_=executable_path(last['pid'],last['name'])
        birth,_=process_birth(last['pid'])
        if (last['pgid']!=pgid or last['name']!=target['name'] or
                exe!=target.get('executable_path') or birth!=target.get('birth_time')):
            return {'resumed_or_exited':False,'state':'server_identity_or_PGID_changed','process':last}
        if 'T' not in last['stat']:
            return {'resumed_or_exited':True,'state':'server_not_stopped','process':last}
        time.sleep(0.05)
    return {'resumed_or_exited':False,'state':'server_still_stopped_after_wait','process':last}


def resume_stopped_server(proc: subprocess.Popen, target: dict,
                          client_pid: int, driver_pid: int, pgid: int) -> dict:
    result={'timestamp':stamp(),'target_pid':target['pid'],'fallback_used':False,
            'resume_confirmed':False,'group_cleanup':None}
    direct=signal_cont_owned(target,client_pid,driver_pid,pgid)
    result['pid_sigcont']=direct
    state=wait_target_resumed(target,pgid,2.0) if direct.get('sent') else None
    if state and state['resumed_or_exited']:
        result.update({'resume_confirmed':True,'resume_method':'pid','target_state_after':state})
        return result
    try:
        rows,_=ps_table();current=rows.get(target['pid'])
    except Exception as exc:
        current=None;result['target_state_recheck_error']=repr(exc)
    result['target_process_rechecked']=current
    if current is None:
        result.update({'resume_confirmed':True,'resume_method':'server_process_exited'})
        return result
    if current['pgid']!=pgid or current['name']!=target['name']:
        result['target_outside_owned_group']=True
        result['group_cleanup']=cleanup_owned_group(proc,pgid)
        empty=result['group_cleanup'].get('process_group_empty_after_cleanup') is True
        result.update({'resume_confirmed':False,'group_terminated_and_reaped':bool(empty and proc.poll() is not None),
            'resume_method':'target_identity_left_launch_group'})
        return result
    if 'T' not in current['stat']:
        result.update({'resume_confirmed':True,'resume_method':'server_already_running',
                       'target_state_after':current})
        return result
    # SIGCONT the exact isolated launch PGID only after proving Popen created it:
    # Popen start_new_session=True, leader PID equals PGID, and all group members
    # still match this launcher/PRTE/client job.
    owned,members,reason=verify_owned_launch_group(proc,pgid)
    result['pgid_fallback_ownership']={'ok':owned,'reason':reason,'members':members,
        'start_new_session':True,'popen_pid':proc.pid,'pgid':pgid}
    if owned and target['pgid']==pgid:
        try:
            os.killpg(pgid,signal.SIGCONT)
            result['fallback_used']=True
            result['pgid_sigcont']={'timestamp':stamp(),'sent':True,'pgid':pgid}
            state=wait_target_resumed(target,pgid,2.0)
            result['target_state_after_pgid_cont']=state
            if state['resumed_or_exited']:
                result.update({'resume_confirmed':True,'resume_method':'owned_launch_pgid'})
                return result
        except OSError as exc:
            result['pgid_sigcont']={'timestamp':stamp(),'sent':False,'error':repr(exc),'pgid':pgid}
    # No safe continuation path remains. Terminate only the verified isolated group,
    # then verify it is empty and the mpirun child has been reaped.
    result['group_cleanup']=cleanup_owned_group(proc,pgid)
    empty=result['group_cleanup'].get('process_group_empty_after_cleanup') is True
    reaped=proc.poll() is not None
    result.update({'group_terminated_and_reaped':bool(empty and reaped),
                   'resume_confirmed':bool(empty and reaped),
                   'resume_method':'owned_group_terminated' if empty and reaped else 'unresolved_owned_group'})
    return result


def verify_owned_launch_group(proc: subprocess.Popen, pgid: int) -> tuple[bool,list[dict],str]:
    # Popen(start_new_session=True) makes its PID the isolated PGID. While that
    # group has members, its ID cannot be reused by an unrelated process group.
    if pgid<=1 or proc.pid!=pgid:
        return False,[],'PGID is not the isolated Popen leader PID'
    rows,_=ps_table();members=group_rows(rows,pgid)
    if not members: return False,[],'owned launcher process group is empty'
    if os.getpid() in {x['pid'] for x in members}:
        return False,members,'driver is unexpectedly inside the launcher PGID'
    try:
        if proc.poll() is None and os.getpgid(proc.pid)!=pgid:
            return False,members,'Popen leader no longer owns the recorded PGID'
    except OSError as exc:
        if proc.poll() is None: return False,members,f'Popen leader PGID check failed: {exc!r}'
    return True,members,'isolated Popen PGID and member names verified'


def cleanup_owned_group(proc: subprocess.Popen, pgid: int) -> dict:
    out={'owned_pgid':pgid,'signals':[],'return_code_before':proc.poll(),
         'stdout':'','stderr':''}
    owned,members,reason=verify_owned_launch_group(proc,pgid)
    out['ownership_check']=reason;out['owned_group_members_before']=members
    if owned:
        try: os.killpg(pgid,signal.SIGTERM);out['signals'].append('SIGTERM')
        except OSError as exc: out['SIGTERM_error']=repr(exc)
    if proc.poll() is None:
        try: out['stdout'],out['stderr']=proc.communicate(timeout=1.0)
        except subprocess.TimeoutExpired: pass
    deadline=time.monotonic()+1.0
    while time.monotonic()<deadline:
        rows,_=ps_table()
        if not group_rows(rows,pgid): break
        time.sleep(0.05)
    rows,_=ps_table();remaining=group_rows(rows,pgid)
    if remaining:
        owned,members,reason=verify_owned_launch_group(proc,pgid)
        out['ownership_check_before_sigkill']=reason
        out['owned_group_members_before_sigkill']=members
        if owned:
            try: os.killpg(pgid,signal.SIGKILL);out['signals'].append('SIGKILL')
            except OSError as exc: out['SIGKILL_error']=repr(exc)
        else:
            out['SIGKILL_refused_not_owned']=True
    if proc.poll() is None:
        try: out['stdout'],out['stderr']=proc.communicate(timeout=2.0)
        except subprocess.TimeoutExpired: out['reap_timeout']=True
    deadline=time.monotonic()+1.0
    while time.monotonic()<deadline:
        rows,_=ps_table()
        if not group_rows(rows,pgid): break
        time.sleep(0.05)
    out['return_code_after']=proc.poll()
    try:
        rows,_=ps_table();out['remaining_group_rows']=group_rows(rows,pgid)
        out['process_group_empty_after_cleanup']=not out['remaining_group_rows']
    except Exception as exc:
        out['remaining_group_check_error']=repr(exc)
    return out


def file_stamp(path: Path) -> dict|None:
    if not path.is_file(): return None
    try:
        obj=json.loads(path.read_text());st=path.stat()
        return {'path':str(path),'record':obj,'bytes':st.st_size,'sha256':sha(path),'observed_at':stamp()}
    except Exception as exc: return {'path':str(path),'error':repr(exc),'observed_at':stamp()}


def write_control(path: Path, event: str, details: dict) -> dict:
    obj={'event':event,'timestamp':stamp(),**details}
    write_json(path,obj,exclusive=True)
    return obj


def wait_for_marker(path: Path, proc: subprocess.Popen, deadline: float,
                    overall_deadline: float) -> tuple[bool, str | None]:
    """Accept a complete ready record; early exit and partial JSON are not readiness."""
    end = min(deadline, overall_deadline)
    last_error = None
    while time.monotonic() < end:
        record = file_stamp(path)
        if record is not None:
            data = record.get('record')
            if isinstance(data, dict) and isinstance(data.get('pid'), int) and data['pid'] > 1:
                return True, None
            last_error = record.get('error', 'ready marker has no valid PID')
        if proc.poll() is not None:
            return False, f'launcher exited with {proc.returncode} before a complete ready marker'
        time.sleep(0.02)
    return False, last_error or 'ready marker deadline expired'


def run_case(label: str, hold_s: float, overall_deadline: float) -> dict:
    case_dir=ATTEMPTS/label;case_dir.mkdir(parents=True,exist_ok=False)
    ready=case_dir/'ready.json';go=case_dir/'GO';abort=case_dir/'ABORT';resumed=case_dir/'RESUMED'
    entry=case_dir/'finalize_entry.json';ret=case_dir/'finalize_return.json'
    env=os.environ.copy()  # no MCA changes or run-specific environment overrides
    command=[MPIRUN,'-np','1','--bind-to','none',str(EXE),str(case_dir)]
    rec={'label':label,'planned_server_hold_seconds':hold_s,'command':command,
        'environment_overrides':{},'runtime_env':relevant_env(env),
        'owned_process_group_provenance':{'subprocess_start_new_session':True,
            'expected_pgid_equals_popen_pid':True,'driver_outside_launch_group':True},
        'executable':{'path':str(EXE),'bytes':EXE.stat().st_size,'sha256':sha(EXE)},
        'source_sha256':{SOURCE.name:sha(SOURCE)},'launch_succeeded':False,
        'return_code':None,'return_code_capture_status':'not launched yet',
        'timed_out':False,'process_tree_snapshots':[],'broker_signals':[],
        'markers':{},'driver_pid':os.getpid()}
    attempt_start=time.monotonic();proc=None;pgid=None;ready_record=None
    stopped_targets=[];resumed_written=False;go_created=False;safe_resume=True
    stdout=stderr='';cleanup_called=False;normal_hold=False
    rec['launch_start']=stamp()
    try:
        if time.monotonic()>=overall_deadline:
            rec['status']='75s_budget_exhausted_before_launch';return rec
        proc=subprocess.Popen(command,cwd=ROOT,env=env,text=True,stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,start_new_session=True)
        rec['launch_succeeded']=True;rec['mpirun_pid']=proc.pid;pgid=proc.pid;rec['launch_pgid']=pgid
        try: rec['launcher_os_pgid']=os.getpgid(proc.pid)
        except OSError as exc: rec['launcher_pgid_error']=repr(exc)
        marker_ok,marker_error=wait_for_marker(ready,proc,min(time.monotonic()+READY_WAIT_S,overall_deadline),overall_deadline)
        if not marker_ok:
            rec['status']='pmix_init_or_ready_timeout';rec['ready_wait_error']=marker_error
            if proc.poll() is None:
                cleanup_called=True;rec['cleanup']=cleanup_owned_group(proc,pgid)
                stdout=rec['cleanup'].get('stdout','');stderr=rec['cleanup'].get('stderr','')
            return rec
        ready_record=json.loads(ready.read_text());rec['markers']['ready']=file_stamp(ready)
        client_pid=int(ready_record['pid']);rec['client_pid']=client_pid
        rows,psrec=ps_table();rec['process_tree_snapshots'].append({'phase':'after_ready',
            'timestamp':stamp(),'ps_command':psrec['command'],'ps_return_code':psrec['return_code'],
            'process_group_rows':group_rows(rows,pgid)})
        selection=select_server(client_pid,os.getpid(),proc.pid,pgid,rows);rec['server_selection']=selection
        if not selection['safe_to_signal']:
            rec['status']='safety_blocked_no_broker_signal';rec['blocked_reason']=selection['reason']
            rec['cleanup']=cleanup_owned_group(proc,pgid);cleanup_called=True
            stdout=rec['cleanup'].get('stdout','');stderr=rec['cleanup'].get('stderr','')
            return rec
        targets=selection['owned_runtime_ancestors']
        pre_stop_checks=[]
        for candidate in targets:
            owned,current,reason=revalidate_owned_target(candidate,client_pid,os.getpid(),pgid)
            pre_stop_checks.append({'pid':candidate['pid'],'ok':owned,'reason':reason,'process':current})
        rec['pre_stop_ownership']={'checks':pre_stop_checks,'timestamp':stamp(),
            'all_owned':all(x['ok'] for x in pre_stop_checks)}
        if not all(x['ok'] for x in pre_stop_checks):
            rec['status']='safety_blocked_target_identity_changed';rec['blocked_reason']=pre_stop_checks
            rec['cleanup']=cleanup_owned_group(proc,pgid);cleanup_called=True
            stdout=rec['cleanup'].get('stdout','');stderr=rec['cleanup'].get('stderr','')
            return rec

        sigstop_reports=[]
        for target in targets:
            sigstop_at=stamp()
            try:
                os.kill(target['pid'],signal.SIGSTOP)
                stopped_targets.append(target)
                rec['broker_signals'].append({'signal':'SIGSTOP','timestamp':sigstop_at,
                    'pid':target['pid'],'pgid':pgid,'comm':target['comm'],
                    'executable_path':target['executable_path'],'sent':True})
            except OSError as exc:
                sigstop_reports.append({'pid':target['pid'],'confirmed':False,'error':repr(exc)})
                break
            stop_deadline=min(time.monotonic()+2.0,overall_deadline);snapshots=[];confirmed=False
            while time.monotonic()<stop_deadline:
                snap,_=ps_table();item=snap.get(target['pid'])
                if item is not None:
                    snapshots.append(item)
                    if item['pgid']==pgid and 'T' in item['stat']:
                        confirmed=True;break
                time.sleep(0.02)
            sigstop_reports.append({'pid':target['pid'],'confirmed':confirmed,
                'requested_at':sigstop_at,'confirmed_at':stamp(),'snapshots':snapshots})
            if not confirmed:break
        rec['sigstop_targets']=targets;rec['sigstop_reports']=sigstop_reports
        if len(sigstop_reports)!=len(targets) or not all(x.get('confirmed') for x in sigstop_reports):
            rec['status']='safety_blocked_sigstop_not_confirmed'
            return rec

        write_control(go,'GO',{'scenario':label,'target_pids':[x['pid'] for x in targets]});go_created=True
        rec['markers']['GO']=file_stamp(go);hold_start=time.monotonic();hold_deadline=min(hold_start+hold_s,overall_deadline)
        rec['broker_hold_start']=stamp();rec['hold_deadline_monotonic_ns']=time.monotonic_ns()+int((hold_deadline-time.monotonic())*1e9)
        return_seen=client_exit=launcher_exit=None
        while time.monotonic()<hold_deadline:
            if return_seen is None and ret.is_file():return_seen=file_stamp(ret)
            if client_exit is None:
                snap,_=ps_table();c=snap.get(client_pid)
                if c is None or any(mark in c['stat'] for mark in ('Z','X')):
                    client_exit={'timestamp':stamp(),'process':c}
            if launcher_exit is None and proc.poll() is not None:
                launcher_exit={'timestamp':stamp(),'return_code':proc.returncode}
            time.sleep(min(0.1,max(0.0,hold_deadline-time.monotonic())))
        rec['broker_hold_end']=stamp();rec['actual_hold_seconds']=time.monotonic()-hold_start
        rec['return_marker_observed_during_hold']=return_seen
        rec['client_exit_observed_during_hold']=client_exit
        rec['launcher_exit_observed_during_hold']=launcher_exit
        rec['markers']['finalize_entry_before_resume']=file_stamp(entry)
        rec['markers']['finalize_return_before_resume']=file_stamp(ret)
        rows,psrec=ps_table();rec['process_tree_snapshots'].append({'phase':'end_hold_before_resume',
            'timestamp':stamp(),'ps_command':psrec['command'],'ps_return_code':psrec['return_code'],
            'process_group_rows':group_rows(rows,pgid)})
        if not entry.is_file():
            rec['status']='setup_error_finalize_entry_marker_missing'
        else:
            rec['status']='hold_elapsed'
        normal_hold=(time.monotonic()<overall_deadline)
    except ProbeInterrupted as exc:
        rec['status']='driver_interrupted';rec['driver_interruption']=str(exc)
        raise
    except Exception as exc:
        rec['status']='driver_error';rec['driver_error']=repr(exc)
    finally:
        if proc is not None and pgid is not None:
            if stopped_targets:
                resume_results=[]
                for stopped_target in reversed(stopped_targets):
                    try:
                        resume=resume_stopped_server(proc,stopped_target,
                            rec.get('client_pid',-1),os.getpid(),pgid)
                    except Exception as exc:
                        resume={'timestamp':stamp(),'target_pid':stopped_target['pid'],
                            'resume_confirmed':False,'resume_method':'resume_exception','error':repr(exc)}
                    resume_results.append(resume)
                    if resume.get('resume_method')=='pid':
                        rec['broker_signals'].append(resume.get('pid_sigcont'))
                    elif resume.get('resume_method')=='owned_launch_pgid':
                        rec['broker_signals'].append(resume.get('pgid_sigcont'))
                    if not resume.get('resume_confirmed'):
                        break
                rec['resume_results']=resume_results
                all_resumed=(len(resume_results)==len(stopped_targets) and all(
                    x.get('resume_method') in ('pid','owned_launch_pgid') and x.get('resume_confirmed')
                    for x in resume_results))
                pid_only=(all_resumed and all(x.get('resume_method')=='pid' for x in resume_results))
                if all_resumed:
                    if not pid_only:
                        rec['resume_safety_error']='PGID-wide SIGCONT fallback used; preserve result but do not advance phase 2'
                        rec['status']='resume_fallback_inconclusive'
                    stopped_targets.clear();safe_resume=True
                else:
                    safe_resume=False
                    rec['resume_safety_error']='not all stopped MPI runtime ancestors resumed by verified PID-level SIGCONT'
                    cleanup=next((x.get('group_cleanup') for x in resume_results if x.get('group_cleanup')),None)
                    if cleanup is None:
                        cleanup=cleanup_owned_group(proc,pgid)
                    rec['own_group_cleanup']=cleanup;cleanup_called=True
                    stdout=cleanup.get('stdout','');stderr=cleanup.get('stderr','')
                    if cleanup.get('process_group_empty_after_cleanup'):
                        rec['status']='resume_safety_cleanup_terminated_group'
                    else:
                        rec['status']='resume_safety_cleanup_unresolved_group'
            abnormal=(not go_created or not normal_hold or rec.get('status')!='hold_elapsed' or
                      bool(rec.get('resume_safety_error')))
            if safe_resume and ready_record is not None:
                try:
                    if not resumed_written:
                        write_control(resumed,'RESUMED',{'server_pids':[x['pid'] for x in rec.get('sigstop_targets',[])],
                            'signal_sent':bool(rec.get('broker_signals'))})
                        resumed_written=True;rec['markers']['RESUMED']=file_stamp(resumed)
                    if abnormal and not abort.exists():
                        write_control(abort,'ABORT',{'reason':rec.get('status','setup_abort')})
                        rec['markers']['ABORT']=file_stamp(abort)
                except Exception as exc:rec['control_marker_error']=repr(exc)
            if proc.poll() is None and not cleanup_called:
                wait_s=min(POST_RESUME_WAIT_S,max(0.1,overall_deadline-time.monotonic()))
                try:stdout,stderr=proc.communicate(timeout=wait_s);rec['post_resume_wait_timeout']=False
                except subprocess.TimeoutExpired:
                    rec['post_resume_wait_timeout']=True
                    rec['own_group_cleanup']=cleanup_owned_group(proc,pgid);cleanup_called=True
                    stdout=rec['own_group_cleanup'].get('stdout','');stderr=rec['own_group_cleanup'].get('stderr','')
            elif proc.poll() is not None:
                try:stdout,stderr=proc.communicate(timeout=0.5)
                except subprocess.TimeoutExpired:stdout=stderr=''
                rec['post_resume_wait_timeout']=False
            rec['return_code']=proc.poll()
            rec['return_code_capture_status']='captured' if proc.poll() is not None else 'not reaped after own-PGID cleanup'
        rec['launch_end']=stamp();rec['elapsed_seconds']=time.monotonic()-attempt_start
        rec['stdout']=stdout;rec['stderr']=stderr
        out_path=case_dir/'mpirun.stdout.txt';err_path=case_dir/'mpirun.stderr.txt'
        out_path.write_text(stdout);err_path.write_text(stderr)
        rec['stdout_path']=str(out_path);rec['stderr_path']=str(err_path)
        rec['stdout_sha256']=sha(out_path);rec['stderr_sha256']=sha(err_path)
        rec['markers'].update({name:file_stamp(case_dir/name) for name in (
            'app_exit.json','init_entry.json','init_return.json','ready.json',
            'finalize_entry.json','finalize_return.json','setup_cleanup_finalize_entry.json',
            'setup_cleanup_finalize_return.json','go_timeout.json')})
        app_exit=(rec['markers'].get('app_exit.json') or {}).get('record',{})
        rec['app_exit_code_from_marker']=app_exit.get('app_exit_code')
        init=(rec['markers'].get('init_return.json') or {}).get('record',{})
        fin=(rec['markers'].get('finalize_return.json') or {}).get('record',{})
        rec['pmix_init_status']=init.get('pmix_status')
        rec['pmix_namespace']=init.get('namespace')
        rec['pmix_rank']=init.get('rank')
        rec['pmix_finalize_status']=fin.get('pmix_status')
        rec['pmix_finalize_elapsed_ns']=None
        ent=(rec['markers'].get('finalize_entry.json') or {}).get('record',{})
        if ent.get('monotonic_ns') is not None and fin.get('monotonic_ns') is not None:
            rec['pmix_finalize_elapsed_ns']=fin['monotonic_ns']-ent['monotonic_ns']
        try:
            rows,psrec=ps_table();rec['final_process_tree']={'timestamp':stamp(),
                'ps_command':psrec['command'],'ps_return_code':psrec['return_code'],
                'process_group_rows':group_rows(rows,pgid or -1)}
        except Exception as exc:rec['final_process_tree_error']=repr(exc)
        write_json(case_dir/'attempt.json',rec)
    return rec


def main() -> None:
    signal.signal(signal.SIGTERM,stop_handler)
    signal.signal(signal.SIGINT,stop_handler)
    receipt_path=ROOT/'fault_probe_receipt.json'
    if receipt_path.exists() or any(ATTEMPTS.glob('*/attempt.json')):
        raise RuntimeError('one-shot evidence root already contains a partial/completed run; no additional launch allowed')
    ATTEMPTS.mkdir(parents=True,exist_ok=True)
    if sha(PRIOR_RECEIPT) != PRIOR_RECEIPT_SHA256:
        raise RuntimeError('preserved setup attempt receipt changed')
    prior = json.loads(PRIOR_RECEIPT.read_text())
    if prior['launch_count'] != 2 or prior['status'] != 'blocked_safe_server_selection':
        raise RuntimeError('unexpected prior setup attempt accounting')
    prior_seconds = float(prior['elapsed_seconds'])
    started=time.monotonic();deadline=started+TOTAL_WALL_CAP_S-prior_seconds
    built=preflight_and_build(started,deadline)
    result={'schema':'pmix_finalize_ack_controlled_delay_probe_v3',
        'scope':'Direct PMIx_Init and PMIx_Finalize only. No MPI API or MPI_Finalized claim; no WRF/PDE/Torch/model executable.',
        'build_and_preflight':built,'attempts':[],'skipped_scenarios':[],
        'prior_setup_attempt':{'path':str(PRIOR_RECEIPT),'sha256':PRIOR_RECEIPT_SHA256,'launch_count':2,'elapsed_seconds':prior_seconds,'interpretation':'Two pre-injection setup stops: missing ready helper, then macOS ps comm truncation. Both counted/preserved; no finalize-delay measurement.'},
        'launch_cap':{'max_invocations':MAX_LAUNCHES,'max_new_invocations':MAX_NEW_LAUNCHES,'total_wall_seconds':TOTAL_WALL_CAP_S,
            'default_pmix_finalize_timeout_seconds':DEFAULT_FINALIZE_TIMEOUT_S,
            'per_launcher_timeout_unchanged':True},
        'status':built['status'],'historical_Wrf_cause_established':False,
        'phase_interpretation':'PMIx status, app exit marker, and launcher RC are distinct. Direct PMIx_Finalize excludes MPI_Finalize pre-fence; forced broker hold is still only a mechanism demonstration, not historical WRF causation.'}
    if built['status']=='ready':
        for index,(name,hold) in enumerate(SCENARIOS):
            if len(result['attempts'])>=MAX_NEW_LAUNCHES or time.monotonic()>=deadline:
                result['skipped_scenarios']=[x[0] for x in SCENARIOS[index:]]
                result['status']='stopped_at_two_launch_or_75s_cap';break
            try:attempt=run_case(name,hold,deadline)
            except ProbeInterrupted as exc:
                result['status']='driver_interrupted_after_own_group_cleanup';result['interruption']=str(exc);break
            result['attempts'].append(attempt)
            if str(attempt.get('status','')).startswith('safety_blocked'):
                result['status']='blocked_safe_server_selection';result['skipped_scenarios']=[x[0] for x in SCENARIOS[index+1:]];break
            if attempt.get('status') in ('pmix_init_or_ready_timeout','driver_error'):
                result['status']='stopped_after_setup_error';result['skipped_scenarios']=[x[0] for x in SCENARIOS[index+1:]];break
            if index==0:
                gate=baseline_clean_gate(attempt);result['phase1_baseline_clean_gate']=gate
                if not gate['passed']:
                    result['status']='baseline_inconclusive_phase2_skipped'
                    result['baseline_gate_failure_reasons']=gate['failure_reasons']
                    result['skipped_scenarios']=[x[0] for x in SCENARIOS[1:]]
                    break
            else:
                markers=attempt.get('markers') or {}
                final_tree=attempt.get('final_process_tree') or {}
                measurement_complete=(attempt.get('status')=='hold_elapsed' and
                    attempt.get('return_code_capture_status')=='captured' and
                    attempt.get('post_resume_wait_timeout') is not True and
                    not attempt.get('resume_safety_error') and
                    not attempt.get('own_group_cleanup') and
                    not attempt.get('final_process_tree_error') and
                    final_tree.get('ps_return_code')==0 and
                    final_tree.get('process_group_rows')==[] and
                    (markers.get('init_return.json') or {}).get('record',{}).get('pmix_status') is not None and
                    (markers.get('finalize_entry.json') or {}).get('record') is not None and
                    (markers.get('finalize_return.json') or {}).get('record',{}).get('pmix_status') is not None and
                    (markers.get('app_exit.json') or {}).get('record',{}).get('app_exit_code') is not None)
                result['phase2_measurement_complete']=measurement_complete
                result['status']='completed_two_launch_measurement' if measurement_complete else 'phase2_inconclusive_no_retry'
                if not measurement_complete:
                    break
        else:
            result['status']='completed_two_launch_measurement'
    else:
        result['status']='blocked_preflight_or_build'
    result['new_launch_count']=sum(bool(x.get('launch_succeeded')) for x in result['attempts'])
    result['launch_count']=prior['launch_count']+result['new_launch_count']
    result['new_elapsed_seconds']=time.monotonic()-started
    result['elapsed_seconds']=prior_seconds+result['new_elapsed_seconds']
    result['within_budget']=result['launch_count']<=MAX_LAUNCHES and result['elapsed_seconds']<=TOTAL_WALL_CAP_S
    result['summary']={'launcher_return_codes':[x.get('return_code') for x in result['attempts']],
        'app_exit_codes':[x.get('app_exit_code_from_marker') for x in result['attempts']],
        'pmix_init_statuses':[x.get('pmix_init_status') for x in result['attempts']],
        'pmix_finalize_statuses':[x.get('pmix_finalize_status') for x in result['attempts']],
        'pmix_finalize_elapsed_ns':[x.get('pmix_finalize_elapsed_ns') for x in result['attempts']],
        'suspended_runtime_ancestor_pids_by_attempt':[[t['pid'] for t in x.get('sigstop_targets',[])] for x in result['attempts']],
        'broker_hold_seconds':[x.get('actual_hold_seconds') for x in result['attempts']]}
    write_json(receipt_path,result)
    print(json.dumps({'status':result['status'],'receipt':str(receipt_path),
        'launch_count':result['launch_count'],'elapsed_seconds':result['elapsed_seconds'],
        'launcher_return_codes':result['summary']['launcher_return_codes'],
        'pmix_finalize_statuses':result['summary']['pmix_finalize_statuses'],
        'within_budget':result['within_budget']},indent=2))


if __name__=='__main__':
    main()
