program mpi_lifecycle_f77
  use iso_c_binding, only: c_int
  implicit none
  include 'mpif.h'
  integer requested, provided, ierr, init_ierr, rank, size

  interface
    subroutine logger_record(phase, requested, provided, rank, size, ierr) &
        bind(C, name='logger_record')
      use iso_c_binding, only: c_int
      integer(c_int), value :: phase, requested, provided, rank, size, ierr
    end subroutine logger_record
  end interface

  requested = MPI_THREAD_SINGLE
  provided = -1
  rank = -1
  size = -1
  call logger_record(0, requested, provided, rank, size, -999)
  call MPI_Init_thread(requested, provided, ierr)
  init_ierr = ierr
  if (ierr == MPI_SUCCESS) then
    call MPI_Comm_rank(MPI_COMM_WORLD, rank, ierr)
    call MPI_Comm_size(MPI_COMM_WORLD, size, ierr)
  end if
  call logger_record(1, requested, provided, rank, size, init_ierr)
  if (init_ierr /= MPI_SUCCESS) stop 10

  call logger_record(2, requested, provided, rank, size, -999)
  call MPI_Finalize(ierr)
  call logger_record(3, requested, provided, rank, size, ierr)
  if (ierr /= MPI_SUCCESS) stop 11
end program mpi_lifecycle_f77
