#include <mpi.h>

void logger_record(int phase, int requested, int provided, int rank, int size,
                   int ierr);

int main(int argc, char **argv) {
  int rank = -1;
  int size = -1;
  int provided = -1;
  const int requested = MPI_THREAD_SINGLE;
  (void)argc;
  (void)argv;

  logger_record(0, requested, provided, rank, size, -999);
  int init_ierr = MPI_Init_thread(NULL, NULL, requested, &provided);
  if (init_ierr == MPI_SUCCESS) {
    (void)MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    (void)MPI_Comm_size(MPI_COMM_WORLD, &size);
  }
  logger_record(1, requested, provided, rank, size, init_ierr);
  if (init_ierr != MPI_SUCCESS) return 10;

  logger_record(2, requested, provided, rank, size, -999);
  const int finalize_ierr = MPI_Finalize();
  logger_record(3, requested, provided, rank, size, finalize_ierr);
  return finalize_ierr == MPI_SUCCESS ? 0 : 11;
}
