#!/usr/bin/env python3
"""Build and sequentially run a bounded, tiny Open MPI finalize batch."""
from __future__ import annotations

import hashlib
import csv
import json
import os
from pathlib import Path
import signal
import subprocess
import time


ROOT = Path(__file__).resolve().parent
BUILD = ROOT / 'build'
ATTEMPTS = ROOT / 'batch2_attempts'
MPIRUN = '/opt/homebrew/bin/mpirun'
MPICC = '/opt/homebrew/bin/mpicc'
MPIFORT = '/opt/homebrew/bin/mpifort'
GXX = '/usr/bin/g++'
GFORTRAN_LIB = '/opt/homebrew/opt/gcc/lib/gcc/current'
MPI_LIB = '/opt/homebrew/opt/open-mpi/lib'
MAX_LAUNCHES = 32
TOTAL_WALL_CAP_S = 60.0
PER_LAUNCH_TIMEOUT_S = 5.0
REPEATS_PER_VARIANT = 10
WORKTREE = Path('/private/tmp/mpi-exit-investigation-20261023')
EVIDENCE_ROOT = Path('/Users/yhlee/AD-SDIRK3-review-evidence/mpi-exit-20261023')
OLD_EVIDENCE_ROOT = Path('/Users/yhlee/AD-SDIRK3-review-evidence/native-idealized-twin-20261022')


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def capture(command: list[str], cwd: Path = ROOT) -> dict:
    started = time.monotonic()
    proc = subprocess.run(command, cwd=cwd, text=True, capture_output=True, check=False)
    return {'command': command, 'return_code': proc.returncode,
            'stdout': proc.stdout, 'stderr': proc.stderr,
            'elapsed_seconds': time.monotonic() - started}


def build_one(command: list[str], label: str, outputs: list[Path]) -> dict:
    rec = capture(command)
    rec['label'] = label
    rec['outputs'] = [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)}
                      for p in outputs if p.is_file()]
    rec['output_missing'] = [str(p) for p in outputs if not p.is_file()]
    return rec


def compile_smokes() -> dict:
    BUILD.mkdir(parents=True, exist_ok=True)
    c_exe = BUILD / 'mpi_lifecycle_c.exe'
    f_obj = BUILD / 'mpi_lifecycle_f77.o'
    logger_obj = BUILD / 'mpi_lifecycle_logger.o'
    trace_obj = BUILD / 'mpi_finalize_pmpi_observer.o'
    f_exe = BUILD / 'mpi_lifecycle_f77.exe'
    ft_exe = BUILD / 'mpi_lifecycle_f77_pmpi.exe'
    commands = [
        build_one([MPICC, '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
                   str(ROOT/'mpi_lifecycle_c.c'), str(ROOT/'mpi_lifecycle_logger.c'),
                   '-o', str(c_exe)], 'compile_link_C_base', [c_exe]),
        build_one([MPIFORT, '-c', '-O2', '-ffree-form',
                   str(ROOT/'mpi_lifecycle_f77.f90'), '-o', str(f_obj)],
                  'compile_F77_object', [f_obj]),
        build_one([MPICC, '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
                   '-c', str(ROOT/'mpi_lifecycle_logger.c'), '-o', str(logger_obj)],
                  'compile_C_logger', [logger_obj]),
        build_one([GXX, str(f_obj), str(logger_obj),
                   '-L'+GFORTRAN_LIB, '-lgfortran', '-lquadmath',
                   '-Wl,-rpath,'+GFORTRAN_LIB, '-L'+MPI_LIB,
                   '-lmpi_usempif08', '-lmpi_usempi_ignore_tkr', '-lmpi_mpifh', '-lmpi',
                   '-Wl,-rpath,'+MPI_LIB, '-o', str(f_exe)],
                  'link_F77_base', [f_exe]),
        build_one([MPICC, '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
                   '-c', str(ROOT/'mpi_finalize_pmpi_observer.c'), '-o', str(trace_obj)],
                  'compile_existing_PMPI_observer_source', [trace_obj]),
        build_one([GXX, str(trace_obj), str(f_obj), str(logger_obj),
                   '-L'+GFORTRAN_LIB, '-lgfortran', '-lquadmath',
                   '-Wl,-rpath,'+GFORTRAN_LIB, '-L'+MPI_LIB,
                   '-lmpi_usempif08', '-lmpi_usempi_ignore_tkr', '-lmpi_mpifh', '-lmpi',
                   '-Wl,-rpath,'+MPI_LIB, '-o', str(ft_exe)],
                  'link_F77_with_PMPI_observer', [ft_exe]),
    ]
    versions = {name: capture([exe, '--version']) for name, exe in
                (('mpirun', MPIRUN), ('mpicc', MPICC), ('mpifort', MPIFORT))}
    wrappers = {name: capture([exe, flag]) for name, exe, flag in
                (('mpicc_showme_command', MPICC, '--showme:command'),
                 ('mpicc_showme_link', MPICC, '--showme:link'),
                 ('mpifort_showme_command', MPIFORT, '--showme:command'),
                 ('mpifort_showme_link', MPIFORT, '--showme:link'))}
    return {'commands': commands, 'versions': versions, 'wrapper_configuration': wrappers,
            'binaries': {'C_base': str(c_exe), 'F77_base': str(f_exe),
                         'F77_PMPI_observer': str(ft_exe)},
            'sources': {p.name: {'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)}
                        for p in (ROOT/'mpi_lifecycle_c.c', ROOT/'mpi_lifecycle_f77.f90',
                                  ROOT/'mpi_lifecycle_logger.c', ROOT/'mpi_finalize_pmpi_observer.c')}}


def relevant_environment(env: dict[str, str]) -> dict[str, str]:
    names = ('PATH', 'DYLD_LIBRARY_PATH')
    return {k: v for k, v in env.items()
            if k in names or k.startswith(('OMPI_', 'PMIX_', 'PRTE_', 'OPAL_', 'UCX_', 'MPI_'))}


def parse_lifecycle(stdout: str) -> list[dict]:
    events = []
    for line in stdout.splitlines():
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(obj, dict) and 'event' in obj:
            events.append(obj)
    return events


def source_context() -> dict:
    head = capture(['git','-C',str(WORKTREE),'rev-parse','HEAD'])
    tree = capture(['git','-C',str(WORKTREE),'rev-parse','HEAD^{tree}'])
    status = capture(['git','-C',str(WORKTREE),'status','--short'])
    graph = EVIDENCE_ROOT/'graph_orientation.json'
    timings = EVIDENCE_ROOT/'post_payload_timing.csv'
    old_smokes = [OLD_EVIDENCE_ROOT/f'build/mpi_finalize_smoke{suffix}_receipt.json'
                  for suffix in ('','_v2','_v3')]
    old_orientation = OLD_EVIDENCE_ROOT/'green_graph/mpi_shutdown_orientation.json'
    timing_summary = {'source_file':str(timings),'source_sha256':sha(timings) if timings.is_file() else None}
    if timings.is_file():
        with timings.open(newline='') as stream:
            rows=list(csv.DictReader(stream))
        success=[float(r['last_netcdf_to_process_end_s']) for r in rows if r['return_code']=='0']
        timing_summary.update({'successful_rows':len(success),'successful_last_netcdf_to_process_end_s':
            {'min':min(success),'max':max(success)},
            'failed_rows':[{'label':r['label'],'return_code':int(r['return_code']),
                'last_netcdf_to_process_end_s':float(r['last_netcdf_to_process_end_s'])}
                for r in rows if r['return_code']!='0']})
    return {'worktree':str(WORKTREE),'head':head['stdout'].strip(),
        'tree':tree['stdout'].strip(),'status_short':status['stdout'],
        'worktree_clean':not bool(status['stdout'].strip()),
        'current_graph_orientation':{'path':str(graph),'sha256':sha(graph) if graph.is_file() else None,
            'scope':'bounded MPI shutdown source orientation; separate from this tiny runtime experiment'},
        'old_graph_orientation':{'path':str(old_orientation),
            'sha256':sha(old_orientation) if old_orientation.is_file() else None,
            'worktree_revision':'e111d2bea3a2c3fa34eb117b131cb03cf89eda5f',
            'use':'navigation only; stale for target W'},
        'closed_case_timing_context':{**timing_summary,
            'scope':'prior WRF timing only; no model/native launch in this task'},
        'prior_tiny_smoke_receipts':[{'path':str(p),'sha256':sha(p) if p.is_file() else None}
            for p in old_smokes],
        'no_W_source_edit_by_this_harness':True}


def run_one(label: str, variant: str, executable: Path, index: int,
            batch_start: float) -> dict:
    attempt_dir = ATTEMPTS / label
    attempt_dir.mkdir(parents=True, exist_ok=True)
    trace = attempt_dir / 'pmpi_trace.log'
    env = os.environ.copy()
    overrides = {}
    if variant == 'F77_PMPI_observer':
        env['NATIVE_MPI_FINALIZE_TRACE'] = str(trace)
        overrides['NATIVE_MPI_FINALIZE_TRACE'] = str(trace)
    command = [MPIRUN, '-np', '1', '--bind-to', 'none', str(executable)]
    record = {'label': label, 'variant': variant, 'command': command,
        'executable': {'path': str(executable),
                       'bytes': executable.stat().st_size if executable.is_file() else None,
                       'sha256': sha(executable) if executable.is_file() else None},
        'source_sha256': {p.name: sha(p) for p in
            (ROOT/'mpi_lifecycle_c.c', ROOT/'mpi_lifecycle_f77.f90',
             ROOT/'mpi_lifecycle_logger.c', ROOT/'mpi_finalize_pmpi_observer.c')},
        'environment_overrides': overrides,
        'observed_MPI_environment': relevant_environment(env),
        'timeout_seconds': PER_LAUNCH_TIMEOUT_S, 'timed_out': False,
        'return_code': None, 'stdout': '', 'stderr': '',
        'stdout_path': str(attempt_dir/'stdout.txt'), 'stderr_path': str(attempt_dir/'stderr.txt'),
        'trace_path': str(trace) if variant == 'F77_PMPI_observer' else None}
    if not executable.is_file():
        record.update({'launch_status':'precondition_failed_missing_executable',
                       'mpirun_invoked':False,'return_code_capture_status':'not launched'})
        (attempt_dir/'attempt.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
        return record
    started_wall = time.time_ns()
    started = time.monotonic()
    try:
        proc = subprocess.Popen(command, cwd=ROOT, env=env, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                start_new_session=True)
        record['mpirun_invoked'] = True
        record['pid'] = proc.pid
        try:
            stdout, stderr = proc.communicate(timeout=PER_LAUNCH_TIMEOUT_S)
        except subprocess.TimeoutExpired:
            record['timed_out'] = True
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            stdout, stderr = proc.communicate()
        record.update({'return_code':proc.returncode, 'return_code_capture_status':'captured',
            'launch_status':'completed_or_timed_out', 'stdout':stdout, 'stderr':stderr})
    except Exception as exc:
        record.update({'launch_status':'runner_launch_error','launch_error':repr(exc),
                       'mpirun_invoked':False,'return_code_capture_status':'not available; process did not start'})
    finally:
        elapsed = time.monotonic() - started
        ended_wall = time.time_ns()
        stdout = record.get('stdout',''); stderr = record.get('stderr','')
        (attempt_dir/'stdout.txt').write_text(stdout)
        (attempt_dir/'stderr.txt').write_text(stderr)
        events = parse_lifecycle(stdout)
        by_phase = {x['event']: x for x in events}
        finalize_elapsed_ns = None
        finalize_wall_elapsed_ns = None
        if 'finalize_entry' in by_phase and 'finalize_return' in by_phase:
            finalize_elapsed_ns = by_phase['finalize_return']['monotonic_ns'] - by_phase['finalize_entry']['monotonic_ns']
            finalize_wall_elapsed_ns = by_phase['finalize_return']['wall_ns'] - by_phase['finalize_entry']['wall_ns']
        record.update({'started_wall_ns':started_wall,'ended_wall_ns':ended_wall,
            'elapsed_seconds':elapsed,'lifecycle_events':events,
            'finalize_elapsed_ns_monotonic':finalize_elapsed_ns,
            'finalize_elapsed_ns_wall':finalize_wall_elapsed_ns,
            'stdout_sha256':sha(attempt_dir/'stdout.txt'),'stderr_sha256':sha(attempt_dir/'stderr.txt'),
            'trace_sha256':sha(trace) if trace.is_file() else None,
            'trace_text':trace.read_text() if trace.is_file() else None,
            'batch_elapsed_seconds_after':time.monotonic()-batch_start})
        (attempt_dir/'attempt.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    return record


def main() -> None:
    if ((ROOT/'green_smoke_receipt.json').exists() or any(ATTEMPTS.glob('*/attempt.json')) or
            any((ROOT/'attempts').glob('*/stdout.txt'))):
        raise RuntimeError('this evidence root already contains a completed or partial smoke batch; copy green_smoke to a new evidence root before another authorized batch')
    ATTEMPTS.mkdir(parents=True, exist_ok=True)
    batch_start = time.monotonic()
    build = compile_smokes()
    build_failures = [x for x in build['commands']
                      if x['return_code'] != 0 or x['output_missing']]
    if build_failures:
        (ROOT/'green_smoke_build_failure.json').write_text(
            json.dumps(build,indent=2,sort_keys=True)+'\n')
        raise RuntimeError(f'smoke compilation/link failed; see green_smoke_build_failure.json: {build_failures}')
    mpirun_version = build['versions']['mpirun']['stdout']
    if 'Open MPI) 5.0.9' not in mpirun_version:
        raise RuntimeError(f'expected installed Open MPI 5.0.9, observed {mpirun_version!r}')
    binary = {key: Path(path) for key, path in build['binaries'].items()}
    launch_plan = []
    for rep in range(1, REPEATS_PER_VARIANT + 1):
        launch_plan.extend([
            (f'c_{rep:02d}', 'C_base', binary['C_base']),
            (f'f77_{rep:02d}', 'F77_base', binary['F77_base']),
            (f'f77_pmpi_{rep:02d}', 'F77_PMPI_observer', binary['F77_PMPI_observer']),
        ])
    launch_plan = launch_plan[:MAX_LAUNCHES]
    attempts = []
    skipped = []
    for label, variant, exe in launch_plan:
        elapsed = time.monotonic() - batch_start
        if elapsed + PER_LAUNCH_TIMEOUT_S > TOTAL_WALL_CAP_S:
            skipped.extend({'label': l, 'variant': v, 'executable': str(p),
                            'reason': '60-second batch wall cap reserves full per-launch timeout'}
                           for l, v, p in launch_plan[len(attempts):])
            break
        attempts.append(run_one(label, variant, exe, len(attempts), batch_start))
    successful = [x for x in attempts if x['return_code'] == 0 and not x['timed_out']]
    nonzero_or_timeout = [x for x in attempts if x['return_code'] != 0 or x['timed_out']]
    trace_observer = {'source': str(ROOT/'mpi_finalize_pmpi_observer.c'),
        'source_sha256': sha(ROOT/'mpi_finalize_pmpi_observer.c'),
        'original_source': '/Users/yhlee/AD-SDIRK3-review-evidence/native-idealized-twin-20261022/build/mpi_shutdown_trace_v3.c',
        'contract': 'Existing F77 mpi_finalize_ observer forwards the same ierr pointer once to pmpi_finalize_; no ierr synthesis or error suppression.'}
    result = {'schema':'mpi_exit_tiny_lifecycle_smoke_v1',
        'scope':'Tiny MPI_Init_thread(MPI_THREAD_SINGLE)/MPI_Finalize C and F77 programs only; no WRF, Torch, PDE, or model executable.',
        'mpi':{'mpirun':MPIRUN,'expected_version':'Open MPI 5.0.9',
               'observed_version':mpirun_version.strip(),
               'launch_argv_template':[MPIRUN,'-np','1','--bind-to','none','<executable>']},
        'limits':{'max_MPI_launches':MAX_LAUNCHES,'launches_attempted':len(attempts),
            'launch_timeout_seconds':PER_LAUNCH_TIMEOUT_S,'batch_wall_cap_seconds':TOTAL_WALL_CAP_S,
            'preflight_launches_before_receipt_failure':2,
            'all_actual_mpirun_invocations_including_preflight':len(attempts)+2,
            'cumulative_captured_mpirun_elapsed_seconds':sum(x.get('elapsed_seconds',0.0) for x in attempts),
            'batch_elapsed_seconds':time.monotonic()-batch_start,'unattempted_due_to_wall_cap':skipped},
        'build':build,'PMPI_observer':trace_observer,
        'source_context':source_context(),
        'setup_history':[{
            'event':'initial F77 direct mpifort link failed; historical explicit g++ recipe used',
            'observed_error':'ld: library System not found',
            'classification':'build setup failure; no MPI lifecycle conclusion',
            'final_link_recipe':'/usr/bin/g++ with explicit Homebrew gfortran/Open MPI libraries and rpaths'},
            {'event':'first runner version launched C_01 and F77_01 before raising during missing-executable bookkeeping',
             'classification':'two setup invocations counted against the 32-launch cap; one C lifecycle completed, F77 executable was missing',
             'return_codes':'not serialized before runner error; retained as null/unknown, not inferred'}],
        'preflight_bootstrap_incidents':[{
            'label':'preflight_C_01','variant':'C_base',
            'stdout_path':str(ROOT/'attempts/c_01/stdout.txt'),
            'stderr_path':str(ROOT/'attempts/c_01/stderr.txt'),
            'stdout_sha256':sha(ROOT/'attempts/c_01/stdout.txt'),
            'stderr_sha256':sha(ROOT/'attempts/c_01/stderr.txt'),
            'return_code':None,'return_code_capture_status':'runner raised during next launch before serializing this process status'},
            {'label':'preflight_F77_01','variant':'F77_base_missing_executable',
            'stdout_path':str(ROOT/'attempts/f77_01/stdout.txt'),
            'stderr_path':str(ROOT/'attempts/f77_01/stderr.txt'),
            'stdout_sha256':sha(ROOT/'attempts/f77_01/stdout.txt'),
            'stderr_sha256':sha(ROOT/'attempts/f77_01/stderr.txt'),
            'return_code':None,'return_code_capture_status':'runner raised after communicate before serializing status; stderr records missing executable'}],
        'attempts':attempts,
        'summary':{'return_code_counts':{str(rc):sum(x['return_code']==rc for x in attempts)
                                          for rc in sorted({x['return_code'] for x in attempts})},
            'timeouts':sum(x['timed_out'] for x in attempts),
            'nonzero_or_timeout_labels':[x['label'] for x in nonzero_or_timeout],
            'successful_rc0_count':len(successful),
            'all_actual_mpirun_invocations_including_preflight':len(attempts)+2,
            'reproduced_nonzero_or_timeout':bool(nonzero_or_timeout),
            'claim_limit':'A clean batch does not prove universal MPI finalization reliability or explain the earlier WRF launcher RC=1.'}}
    receipt = ROOT/'green_smoke_receipt.json'
    receipt.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'receipt':str(receipt),'launches':len(attempts),
        'elapsed_seconds':result['limits']['batch_elapsed_seconds'],
        'return_code_counts':result['summary']['return_code_counts'],
        'timeouts':result['summary']['timeouts'],
        'reproduced_nonzero_or_timeout':result['summary']['reproduced_nonzero_or_timeout']},indent=2))


if __name__ == '__main__':
    main()
