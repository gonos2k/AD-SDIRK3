#define _POSIX_C_SOURCE 200809L
#include <mpi.h>
#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>

enum {
  PHASE_BEFORE_INIT = 0,
  PHASE_INIT_RETURN = 1,
  PHASE_FINALIZE_ENTRY = 2,
  PHASE_FINALIZE_RETURN = 3
};

static const char *phase_name(int phase) {
  switch (phase) {
  case PHASE_BEFORE_INIT: return "before_init_thread";
  case PHASE_INIT_RETURN: return "init_thread_return";
  case PHASE_FINALIZE_ENTRY: return "finalize_entry";
  case PHASE_FINALIZE_RETURN: return "finalize_return";
  default: return "unknown";
  }
}

static int64_t clock_ns(clockid_t clock_id) {
  struct timespec ts;
  if (clock_gettime(clock_id, &ts) != 0) return -1;
  return (int64_t)ts.tv_sec * 1000000000LL + ts.tv_nsec;
}

void logger_record(int phase, int requested, int provided, int rank, int size,
                   int ierr) {
  const int64_t wall_ns = clock_ns(CLOCK_REALTIME);
  const int64_t monotonic_ns = clock_ns(CLOCK_MONOTONIC);
  printf("{\"event\":\"%s\",\"wall_ns\":%lld,\"monotonic_ns\":%lld,"
         "\"pid\":%ld,\"rank\":%d,\"size\":%d,\"requested_thread\":%d,"
         "\"provided_thread\":%d,\"ierr\":%d}\n",
         phase_name(phase), (long long)wall_ns, (long long)monotonic_ns,
         (long)getpid(), rank, size, requested, provided, ierr);
  fflush(stdout);
}
