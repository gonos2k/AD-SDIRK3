# Tiny MPI lifecycle smoke

`run_smokes.py` builds a C lifecycle probe, an F77 `mpif.h` probe, and an F77 probe linked with the existing PMPI finalizer observer. Each requests `MPI_THREAD_SINGLE` through `MPI_Init_thread`, records wall/monotonic timestamps plus PID/rank/size and requested/provided levels, then records entry/return around `MPI_Finalize`. The observer forwards the original F77 `ierr` once to `PMPI_Finalize`.

The saved proper batch has ten launches per variant. It uses `/opt/homebrew/bin/mpirun -np 1 --bind-to none`, Open MPI 5.0.9, a 5-second timeout per launch, a 32-invocation cap, and a 60-second wall cap. Build commands, versions, source/executable hashes, per-attempt return codes, stdout/stderr, timing, and PMPI trace are in `green_smoke_receipt.json` and `batch2_attempts/`.

Two earlier runner bootstrap invocations are preserved under `attempts/` and count toward the 32-invocation cap. The runner failed before serializing their numeric return codes: the C output shows a complete finalize return; the F77 invocation used a missing executable. They are explicitly marked unknown and excluded from the 30 valid lifecycle attempts. The corrected runner now has a one-shot guard; copy this directory to a new evidence root before any separately authorized batch.

No WRF, Torch, PDE, or model executable was built or launched. A clean tiny batch cannot establish universal MPI reliability or explain a WRF launcher return code.
