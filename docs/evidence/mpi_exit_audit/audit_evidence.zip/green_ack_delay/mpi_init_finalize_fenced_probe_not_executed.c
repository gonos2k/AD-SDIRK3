#define _POSIX_C_SOURCE 200809L
#include <mpi.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

static int64_t clock_ns(clockid_t id) {
  struct timespec ts;
  if (clock_gettime(id, &ts) != 0) return -1;
  return (int64_t)ts.tv_sec * 1000000000LL + ts.tv_nsec;
}

static int write_record(const char *path, const char *json) {
  int fd = open(path, O_WRONLY | O_CREAT | O_EXCL, 0600);
  if (fd < 0) return errno ? errno : 1;
  FILE *f = fdopen(fd, "w");
  if (f == NULL) { close(fd); return errno ? errno : 1; }
  int failed = fprintf(f, "%s\n", json) < 0 || fflush(f) != 0 || fsync(fd) != 0;
  if (fclose(f) != 0) failed = 1;
  return failed ? 1 : 0;
}

static void marker_path(char *out, size_t size, const char *dir, const char *name) {
  (void)snprintf(out, size, "%s/%s", dir, name);
}

static int file_exists(const char *path) {
  struct stat st;
  return stat(path, &st) == 0 && S_ISREG(st.st_mode);
}

static const char *threadlevel_name(int level) {
  if (level == MPI_THREAD_SINGLE) return "MPI_THREAD_SINGLE";
  if (level == MPI_THREAD_FUNNELED) return "MPI_THREAD_FUNNELED";
  if (level == MPI_THREAD_SERIALIZED) return "MPI_THREAD_SERIALIZED";
  if (level == MPI_THREAD_MULTIPLE) return "MPI_THREAD_MULTIPLE";
  return "unknown";
}

static void event_stdout(const char *event, int rank, int size, int threadlevel,
                         int ierr) {
  printf("event=%s wall_ns=%" PRId64 " monotonic_ns=%" PRId64
         " pid=%ld ppid=%ld pgid=%ld rank=%d size=%d threadlevel=%d ierr=%d\n",
         event, clock_ns(CLOCK_REALTIME), clock_ns(CLOCK_MONOTONIC),
         (long)getpid(), (long)getppid(), (long)getpgrp(), rank, size,
         threadlevel, ierr);
  fflush(stdout);
}

int main(int argc, char **argv) {
  if (argc != 2) {
    fprintf(stderr, "usage: %s <attempt-directory>\n", argv[0]);
    return 2;
  }
  const char *dir = argv[1];
  char ready_path[4096], go_path[4096], entry_path[4096], return_path[4096];
  char timeout_path[4096], record[2048];
  marker_path(ready_path, sizeof(ready_path), dir, "ready.json");
  marker_path(go_path, sizeof(go_path), dir, "GO");
  marker_path(entry_path, sizeof(entry_path), dir, "finalize_entry.json");
  marker_path(return_path, sizeof(return_path), dir, "finalize_return.json");
  marker_path(timeout_path, sizeof(timeout_path), dir, "go_timeout.json");

  const int init_ierr = MPI_Init(&argc, &argv); /* MPI_Init has SINGLE-thread semantics. */
  if (init_ierr != MPI_SUCCESS) {
    event_stdout("mpi_init_error", -1, -1, -1, init_ierr);
    return 10;
  }
  int rank = -1, size = -1, threadlevel = -1;
  int rank_ierr = MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  int size_ierr = MPI_Comm_size(MPI_COMM_WORLD, &size);
  int query_ierr = MPI_Query_thread(&threadlevel);
  if (rank_ierr != MPI_SUCCESS || size_ierr != MPI_SUCCESS || query_ierr != MPI_SUCCESS) {
    event_stdout("mpi_query_error", rank, size, threadlevel,
                 rank_ierr != MPI_SUCCESS ? rank_ierr :
                 (size_ierr != MPI_SUCCESS ? size_ierr : query_ierr));
    return 11;
  }

  int64_t wall = clock_ns(CLOCK_REALTIME), mono = clock_ns(CLOCK_MONOTONIC);
  (void)snprintf(record, sizeof(record),
      "{\"event\":\"ready\",\"wall_ns\":%" PRId64 ",\"monotonic_ns\":%" PRId64
      ",\"pid\":%ld,\"ppid\":%ld,\"pgid\":%ld,\"rank\":%d,\"size\":%d"
      ",\"threadlevel\":%d,\"threadlevel_name\":\"%s\","
      "\"requested_threadlevel_name\":\"MPI_THREAD_SINGLE via MPI_Init\",\"init_ierr\":%d}",
      wall, mono, (long)getpid(), (long)getppid(), (long)getpgrp(), rank, size,
      threadlevel, threadlevel_name(threadlevel), init_ierr);
  event_stdout("ready", rank, size, threadlevel, init_ierr);
  if (write_record(ready_path, record) != 0) {
    fprintf(stderr, "failed to write ready marker %s: %s\n", ready_path, strerror(errno));
    fflush(stderr);
    return 12;
  }

  const int64_t go_deadline = clock_ns(CLOCK_MONOTONIC) + 30000000000LL;
  const struct timespec pause = {.tv_sec = 0, .tv_nsec = 10000000L};
  while (!file_exists(go_path) && clock_ns(CLOCK_MONOTONIC) < go_deadline)
    (void)nanosleep(&pause, NULL);
  if (!file_exists(go_path)) {
    wall = clock_ns(CLOCK_REALTIME); mono = clock_ns(CLOCK_MONOTONIC);
    (void)snprintf(record, sizeof(record),
        "{\"event\":\"go_wait_timeout\",\"wall_ns\":%" PRId64
        ",\"monotonic_ns\":%" PRId64 ",\"pid\":%ld,\"rank\":%d,\"size\":%d}",
        wall, mono, (long)getpid(), rank, size);
    (void)write_record(timeout_path, record);
    event_stdout("go_wait_timeout", rank, size, threadlevel, 20);
    return 20;
  }

  wall = clock_ns(CLOCK_REALTIME); mono = clock_ns(CLOCK_MONOTONIC);
  (void)snprintf(record, sizeof(record),
      "{\"event\":\"finalize_entry\",\"wall_ns\":%" PRId64
      ",\"monotonic_ns\":%" PRId64 ",\"pid\":%ld,\"ppid\":%ld,\"pgid\":%ld"
      ",\"rank\":%d,\"size\":%d,\"threadlevel\":%d}",
      wall, mono, (long)getpid(), (long)getppid(), (long)getpgrp(), rank, size, threadlevel);
  event_stdout("finalize_entry", rank, size, threadlevel, -999);
  if (write_record(entry_path, record) != 0) {
    fprintf(stderr, "failed to write finalize-entry marker %s: %s\n", entry_path, strerror(errno));
    fflush(stderr);
    return 21;
  }

  const int finalize_ierr = MPI_Finalize();
  int finalized = -1;
  const int finalized_ierr = MPI_Finalized(&finalized);
  wall = clock_ns(CLOCK_REALTIME); mono = clock_ns(CLOCK_MONOTONIC);
  (void)snprintf(record, sizeof(record),
      "{\"event\":\"finalize_return\",\"wall_ns\":%" PRId64
      ",\"monotonic_ns\":%" PRId64 ",\"pid\":%ld,\"ppid\":%ld,\"pgid\":%ld"
      ",\"rank\":%d,\"size\":%d,\"threadlevel\":%d,\"finalize_ierr\":%d"
      ",\"finalized_ierr\":%d,\"finalized\":%d}",
      wall, mono, (long)getpid(), (long)getppid(), (long)getpgrp(), rank, size,
      threadlevel, finalize_ierr, finalized_ierr, finalized);
  event_stdout("finalize_return", rank, size, threadlevel, finalize_ierr);
  if (write_record(return_path, record) != 0) {
    fprintf(stderr, "failed to write finalize-return marker %s: %s\n", return_path, strerror(errno));
    fflush(stderr);
    return 22;
  }
  return (finalize_ierr == MPI_SUCCESS && finalized_ierr == MPI_SUCCESS && finalized == 1) ? 0 : 30;
}
