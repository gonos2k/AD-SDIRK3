#define _POSIX_C_SOURCE 200809L
#include <pmix.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

static int64_t clock_ns(clockid_t id) {
  struct timespec ts;
  if (clock_gettime(id, &ts) != 0) return -1;
  return (int64_t)ts.tv_sec * 1000000000LL + ts.tv_nsec;
}

static int write_record(const char *path, const char *json) {
  int fd = open(path, O_WRONLY | O_CREAT | O_EXCL, 0600);
  if (fd < 0) return errno ? errno : 1;
  FILE *f = fdopen(fd, "w");
  if (f == NULL) { close(fd); return errno ? errno : 1; }
  int failed = fprintf(f, "%s\n", json) < 0 || fflush(f) != 0 || fsync(fd) != 0;
  if (fclose(f) != 0) failed = 1;
  return failed ? 1 : 0;
}

static void marker_path(char *out, size_t size, const char *dir, const char *name) {
  (void)snprintf(out, size, "%s/%s", dir, name);
}

static int file_exists(const char *path) {
  struct stat st;
  return stat(path, &st) == 0 && S_ISREG(st.st_mode);
}

static pmix_status_t cleanup_finalize_after_abort(const char *dir,
                                                  const char *nspace,
                                                  uint32_t rank) {
  char path[4096], record[2048];
  marker_path(path, sizeof(path), dir, "setup_cleanup_finalize_entry.json");
  (void)snprintf(record, sizeof(record),
      "{\"event\":\"setup_cleanup_finalize_entry\",\"wall_ns\":%" PRId64
      ",\"monotonic_ns\":%" PRId64 ",\"pid\":%ld,\"namespace\":\"%s\",\"rank\":%" PRIu32 "}",
      clock_ns(CLOCK_REALTIME), clock_ns(CLOCK_MONOTONIC), (long)getpid(), nspace, rank);
  (void)write_record(path, record);
  const pmix_status_t status = PMIx_Finalize(NULL, 0);
  marker_path(path, sizeof(path), dir, "setup_cleanup_finalize_return.json");
  (void)snprintf(record, sizeof(record),
      "{\"event\":\"setup_cleanup_finalize_return\",\"wall_ns\":%" PRId64
      ",\"monotonic_ns\":%" PRId64 ",\"pid\":%ld,\"namespace\":\"%s\",\"rank\":%" PRIu32 ""
      ",\"pmix_status\":%d}",
      clock_ns(CLOCK_REALTIME), clock_ns(CLOCK_MONOTONIC), (long)getpid(), nspace, rank,
      (int)status);
  (void)write_record(path, record);
  return status;
}

static void event_stdout(const char *event, const char *nspace, uint32_t rank,
                         int status_valid, pmix_status_t status) {
  printf("event=%s wall_ns=%" PRId64 " monotonic_ns=%" PRId64
         " pid=%ld ppid=%ld pgid=%ld nspace=%s rank=%" PRIu32,
         event, clock_ns(CLOCK_REALTIME), clock_ns(CLOCK_MONOTONIC),
         (long)getpid(), (long)getppid(), (long)getpgrp(), nspace, rank);
  if (status_valid) printf(" pmix_status=%d", (int)status);
  putchar('\n');
  fflush(stdout);
}

static int exit_app(const char *dir, int code, const char *reason) {
  char path[4096], record[1024];
  marker_path(path, sizeof(path), dir, "app_exit.json");
  (void)snprintf(record, sizeof(record),
      "{\"event\":\"app_exit\",\"wall_ns\":%" PRId64
      ",\"monotonic_ns\":%" PRId64 ",\"pid\":%ld,\"app_exit_code\":%d,\"reason\":\"%s\"}",
      clock_ns(CLOCK_REALTIME), clock_ns(CLOCK_MONOTONIC), (long)getpid(), code, reason);
  (void)write_record(path, record);
  printf("event=app_exit wall_ns=%" PRId64 " monotonic_ns=%" PRId64
         " pid=%ld app_exit_code=%d reason=%s\n",
         clock_ns(CLOCK_REALTIME), clock_ns(CLOCK_MONOTONIC), (long)getpid(), code, reason);
  fflush(stdout);
  return code;
}

int main(int argc, char **argv) {
  if (argc != 2) {
    fprintf(stderr, "usage: %s <attempt-directory>\n", argv[0]);
    return 2;
  }
  const char *dir = argv[1];
  char ready_path[4096], go_path[4096], entry_path[4096], return_path[4096];
  char timeout_path[4096], abort_path[4096], resumed_path[4096], record[2048];
  marker_path(ready_path, sizeof(ready_path), dir, "ready.json");
  marker_path(go_path, sizeof(go_path), dir, "GO");
  marker_path(entry_path, sizeof(entry_path), dir, "finalize_entry.json");
  marker_path(return_path, sizeof(return_path), dir, "finalize_return.json");
  marker_path(timeout_path, sizeof(timeout_path), dir, "go_timeout.json");
  marker_path(abort_path, sizeof(abort_path), dir, "ABORT");
  marker_path(resumed_path, sizeof(resumed_path), dir, "RESUMED");

  pmix_proc_t self;
  memset(&self, 0, sizeof(self));
  int64_t wall = clock_ns(CLOCK_REALTIME), mono = clock_ns(CLOCK_MONOTONIC);
  (void)snprintf(record, sizeof(record),
      "{\"event\":\"init_entry\",\"wall_ns\":%" PRId64
      ",\"monotonic_ns\":%" PRId64 ",\"pid\":%ld,\"ppid\":%ld,\"pgid\":%ld}",
      wall, mono, (long)getpid(), (long)getppid(), (long)getpgrp());
  char init_entry_path[4096];
  marker_path(init_entry_path, sizeof(init_entry_path), dir, "init_entry.json");
  if (write_record(init_entry_path, record) != 0)
    return exit_app(dir, 9, "init_entry_marker_error_before_init");

  const pmix_status_t init_status = PMIx_Init(&self, NULL, 0);
  char init_return_path[4096];
  marker_path(init_return_path, sizeof(init_return_path), dir, "init_return.json");
  if (init_status != PMIX_SUCCESS) {
    wall = clock_ns(CLOCK_REALTIME); mono = clock_ns(CLOCK_MONOTONIC);
    (void)snprintf(record, sizeof(record),
        "{\"event\":\"init_return\",\"wall_ns\":%" PRId64
        ",\"monotonic_ns\":%" PRId64 ",\"pid\":%ld,\"namespace\":null,\"rank\":null"
        ",\"pmix_status\":%d}", wall, mono, (long)getpid(), (int)init_status);
    event_stdout("init_return", "unavailable", UINT32_MAX, 1, init_status);
    (void)write_record(init_return_path, record);
    return exit_app(dir, 11, "pmix_init_non_success");
  }
  char nspace[PMIX_MAX_NSLEN + 1];
  memcpy(nspace, self.nspace, PMIX_MAX_NSLEN);
  nspace[PMIX_MAX_NSLEN] = '\0';
  wall = clock_ns(CLOCK_REALTIME); mono = clock_ns(CLOCK_MONOTONIC);
  (void)snprintf(record, sizeof(record),
      "{\"event\":\"init_return\",\"wall_ns\":%" PRId64
      ",\"monotonic_ns\":%" PRId64 ",\"pid\":%ld,\"ppid\":%ld,\"pgid\":%ld"
      ",\"namespace\":\"%s\",\"rank\":%" PRIu32 ",\"pmix_status\":%d}",
      wall, mono, (long)getpid(), (long)getppid(), (long)getpgrp(), nspace,
      self.rank, (int)init_status);
  event_stdout("init_return", nspace, self.rank, 1, init_status);
  if (write_record(init_return_path, record) != 0) {
    (void)cleanup_finalize_after_abort(dir, nspace, self.rank);
    return exit_app(dir, 10, "init_return_marker_error_after_cleanup_finalize");
  }
  (void)snprintf(record, sizeof(record),
      "{\"event\":\"ready\",\"wall_ns\":%" PRId64
      ",\"monotonic_ns\":%" PRId64 ",\"pid\":%ld,\"ppid\":%ld,\"pgid\":%ld"
      ",\"namespace\":\"%s\",\"rank\":%" PRIu32 ",\"pmix_status\":%d}",
      wall, mono, (long)getpid(), (long)getppid(), (long)getpgrp(), nspace,
      self.rank, (int)init_status);
  event_stdout("ready", nspace, self.rank, 1, init_status);
  if (write_record(ready_path, record) != 0) {
    (void)cleanup_finalize_after_abort(dir, nspace, self.rank);
    return exit_app(dir, 12, "ready_marker_error_after_cleanup_finalize");
  }

  const int64_t go_deadline = clock_ns(CLOCK_MONOTONIC) + 30000000000LL;
  const struct timespec pause = {.tv_sec = 0, .tv_nsec = 10000000L};
  while (!file_exists(go_path) && !file_exists(abort_path) &&
         clock_ns(CLOCK_MONOTONIC) < go_deadline)
    (void)nanosleep(&pause, NULL);
  if (!file_exists(go_path)) {
    wall = clock_ns(CLOCK_REALTIME); mono = clock_ns(CLOCK_MONOTONIC);
    (void)snprintf(record, sizeof(record),
        "{\"event\":\"go_wait_timeout\",\"wall_ns\":%" PRId64
        ",\"monotonic_ns\":%" PRId64 ",\"pid\":%ld,\"namespace\":\"%s\",\"rank\":%" PRIu32 "}",
        wall, mono, (long)getpid(), nspace, self.rank);
    (void)write_record(timeout_path, record);
    event_stdout("go_wait_timeout", nspace, self.rank, 0, PMIX_SUCCESS);
    if (file_exists(abort_path)) {
      const int64_t cleanup_deadline = clock_ns(CLOCK_MONOTONIC) + 20000000000LL;
      while (!file_exists(resumed_path) && clock_ns(CLOCK_MONOTONIC) < cleanup_deadline)
        (void)nanosleep(&pause, NULL);
      if (file_exists(resumed_path)) {
        const pmix_status_t cleanup_status = cleanup_finalize_after_abort(dir, nspace, self.rank);
        return exit_app(dir, cleanup_status == PMIX_SUCCESS ? 23 : 24,
                        cleanup_status == PMIX_SUCCESS ? "aborted_setup_cleaned_up" :
                        "aborted_setup_cleanup_finalize_error");
      }
    }
    /* Without GO or ABORT+RESUMED, server state is unknown; do not finalize. */
    return exit_app(dir, 20, "go_wait_timeout_without_resumed_abort");
  }

  wall = clock_ns(CLOCK_REALTIME); mono = clock_ns(CLOCK_MONOTONIC);
  (void)snprintf(record, sizeof(record),
      "{\"event\":\"finalize_entry\",\"wall_ns\":%" PRId64
      ",\"monotonic_ns\":%" PRId64 ",\"pid\":%ld,\"ppid\":%ld,\"pgid\":%ld"
      ",\"namespace\":\"%s\",\"rank\":%" PRIu32 "}",
      wall, mono, (long)getpid(), (long)getppid(), (long)getpgrp(), nspace, self.rank);
  event_stdout("finalize_entry", nspace, self.rank, 0, PMIX_SUCCESS);
  if (write_record(entry_path, record) != 0) {
    event_stdout("finalize_entry_marker_error", nspace, self.rank, 0, PMIX_SUCCESS);
    /* The driver resumes its owned server and writes RESUMED before this cleanup path. */
    const int64_t cleanup_deadline = clock_ns(CLOCK_MONOTONIC) + 20000000000LL;
    while (!file_exists(resumed_path) && clock_ns(CLOCK_MONOTONIC) < cleanup_deadline)
      (void)nanosleep(&pause, NULL);
    if (!file_exists(resumed_path))
      return exit_app(dir, 21, "finalize_entry_marker_error_without_resumed_server");
    const pmix_status_t cleanup_status = cleanup_finalize_after_abort(dir, nspace, self.rank);
    return exit_app(dir, cleanup_status == PMIX_SUCCESS ? 25 : 26,
                    cleanup_status == PMIX_SUCCESS ? "finalize_entry_marker_error_cleaned_up" :
                    "finalize_entry_marker_error_cleanup_failed");
  }

  /* No PMIX_EMBED_BARRIER request: isolate PMIX_FINALIZE_CMD acknowledgement. */
  const pmix_status_t finalize_status = PMIx_Finalize(NULL, 0);
  wall = clock_ns(CLOCK_REALTIME); mono = clock_ns(CLOCK_MONOTONIC);
  (void)snprintf(record, sizeof(record),
      "{\"event\":\"finalize_return\",\"wall_ns\":%" PRId64
      ",\"monotonic_ns\":%" PRId64 ",\"pid\":%ld,\"ppid\":%ld,\"pgid\":%ld"
      ",\"namespace\":\"%s\",\"rank\":%" PRIu32 ",\"pmix_status\":%d"
      ",\"pmix_success\":%s}",
      wall, mono, (long)getpid(), (long)getppid(), (long)getpgrp(), nspace,
      self.rank, (int)finalize_status, finalize_status == PMIX_SUCCESS ? "true" : "false");
  event_stdout("finalize_return", nspace, self.rank, 1, finalize_status);
  if (write_record(return_path, record) != 0)
    return exit_app(dir, 22, "finalize_return_marker_error");
  return exit_app(dir, finalize_status == PMIX_SUCCESS ? 0 : 30,
                  finalize_status == PMIX_SUCCESS ? "pmix_finalize_success" :
                  "pmix_finalize_non_success");
}
