#!/usr/bin/env python3
"""Render the frozen RK3 postprocess JSON as two static review figures."""
from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D

ROOT = Path(__file__).resolve().parent
DATA = json.loads((ROOT / "rk3_analysis.json").read_text())
START = datetime.strptime(DATA["reference_start_timestamp"], "%Y-%m-%d_%H:%M:%S")
END = DATA["reference_endpoint_timestamp"]
RUNS = ("rk3_h600", "rk3_h300", "rk3_h150")
STYLES = {"rk3_h600": "-", "rk3_h300": "--", "rk3_h150": ":"}
FIELDS = ("U", "V", "W", "PH", "T", "MU", "P_total")
COLORS = dict(zip(FIELDS, plt.cm.tab10(np.linspace(0, 1, len(FIELDS))), strict=True))


def day(timestamp: str) -> float:
    t = datetime.strptime(timestamp, "%Y-%m-%d_%H:%M:%S")
    return (t - START).total_seconds() / 86400.0


def save_figure(fig, name: str) -> None:
    target = ROOT / name
    fd, temporary = tempfile.mkstemp(prefix=".plot_", suffix=".png", dir=ROOT)
    os.close(fd)
    fig.savefig(temporary, dpi=160)
    os.replace(temporary, target)
    plt.close(fig)


def accuracy_panels() -> None:
    fig, axes = plt.subplots(2, 2, figsize=(16, 11), constrained_layout=True)
    fig.suptitle("Official em_b_wave RK3 timestep comparison — h150 is a comparator, not exact truth")

    ax = axes[0, 0]
    for field in FIELDS:
        for label in ("rk3_h600", "rk3_h300"):
            times = sorted(DATA["comparisons"][label])
            xs, ys = [], []
            for timestamp in times:
                value = DATA["comparisons"][label][timestamp][field]["relative_rms_to_reference_signal"]
                if value is not None:
                    xs.append(day(timestamp))
                    ys.append(value)
            ax.plot(xs, ys, color=COLORS[field], linestyle=STYLES[label], linewidth=1.35)
    ax.set_yscale("log")
    ax.set_xlabel("Forecast day")
    ax.set_ylabel("RMS / h150 initial-signal RMS")
    ax.set_title("Common-time field differences; t0 denominator is undefined")
    ax.grid(True, alpha=0.25)
    legend = ax.legend(handles=[Line2D([0], [0], color=COLORS[f], label=f) for f in FIELDS],
                       fontsize=7, ncol=2, loc="upper left", title="Field")
    ax.add_artist(legend)
    ax.legend(handles=[Line2D([0], [0], color="black", linestyle=STYLES[label],
                              label=label.replace("rk3_", "h="))
                       for label in ("rk3_h600", "rk3_h300")],
              fontsize=7, loc="lower right", title="Timestep")

    ax = axes[0, 1]
    for field in ("U", "V", "W", "PH", "T", "P_total"):
        for label in ("rk3_h600", "rk3_h300"):
            profile = DATA["comparisons"][label][END][field].get("per_z")
            if profile:
                ax.plot([v["rms"] for v in profile], [v["z_index"] for v in profile],
                        color=COLORS[field], linestyle=STYLES[label], linewidth=1.25)
    ax.set_xscale("symlog", linthresh=1.0e-8)
    ax.set_xlabel("Day-5 RMS difference (field units; symlog includes zero)")
    ax.set_ylabel("Owned vertical index")
    ax.set_title("Day-5 profiles; W/PH retain top and exclude lower fixed face")
    ax.grid(True, alpha=0.25)
    legend = ax.legend(handles=[Line2D([0], [0], color=COLORS[f], label=f)
                                for f in ("U", "V", "W", "PH", "T", "P_total")],
                       fontsize=7, ncol=2, loc="lower right", title="Field")
    ax.add_artist(legend)
    ax.legend(handles=[Line2D([0], [0], color="black", linestyle=STYLES[label],
                              label=label.replace("rk3_", "h="))
                       for label in ("rk3_h600", "rk3_h300")],
              fontsize=7, loc="upper left", title="Timestep")

    ax = axes[1, 0]
    wave = DATA["wave_mode1_diagnostics"]
    wave_colors = {"T": "tab:blue", "W": "tab:orange", "P": "tab:green"}
    for field, color in wave_colors.items():
        # Normalize all three methods by the same h150 maximum for this field.
        reference_max = max(wave["rk3_h150"][t][field]["coefficient_rms_amplitude"]
                            for t in wave["rk3_h150"])
        for label in RUNS:
            times = sorted(wave[label])
            amps = [wave[label][t][field]["coefficient_rms_amplitude"] for t in times]
            ax.plot([day(t) for t in times],
                    [v / reference_max if reference_max > 0.0 else 0.0 for v in amps],
                    color=color, linestyle=STYLES[label], linewidth=1.3)
    ax.set_xlabel("Forecast day")
    ax.set_ylabel("Mode-1 RMS amplitude / h150 maximum for field")
    ax.set_title("Zonal m=1 amplitude; common h150 normalization per field")
    ax.grid(True, alpha=0.25)
    legend = ax.legend(handles=[Line2D([0], [0], color=c, label=f) for f, c in wave_colors.items()],
                       fontsize=8, loc="upper left", title="Field")
    ax.add_artist(legend)
    ax.legend(handles=[Line2D([0], [0], color="black", linestyle=STYLES[label],
                              label=label.replace("rk3_", "h=")) for label in RUNS],
              fontsize=7, loc="lower right", title="Timestep")

    ax = axes[1, 1]
    theta_ax = ax.twinx()
    budgets = DATA["budgets"]
    budget_colors = {"rk3_h600": "tab:blue", "rk3_h300": "tab:orange", "rk3_h150": "tab:green"}
    for label in RUNS:
        times = sorted(budgets[label])
        xs = [day(t) for t in times]
        ax.plot(xs, [budgets[label][t]["dry_mass_relative_change"] for t in times],
                color=budget_colors[label], linestyle="-", linewidth=1.3)
        theta_ax.plot(xs, [budgets[label][t]["mass_weighted_theta_change_K"] for t in times],
                      color=budget_colors[label], linestyle="--", linewidth=1.3)
    ax.set_xlabel("Forecast day")
    ax.set_ylabel("Dry column mass relative change")
    theta_ax.set_ylabel("Mass-weighted theta change (K)")
    ax.set_title("Dry mass and mass-weighted theta; diagnostics, not acceptance gates")
    ax.grid(True, alpha=0.25)
    ax.legend(handles=[Line2D([0], [0], color=budget_colors[label], label=label.replace("rk3_", "h="))
                       for label in RUNS], fontsize=7, loc="upper left", title="Timestep")
    save_figure(fig, "rk3_accuracy_summary_4panel.png")


def wave_phase_panels() -> None:
    pairs = DATA["wave_pairwise_diagnostics"]
    pair_styles = {"rk3_600_vs_300": "-", "rk3_300_vs_150": "--"}
    field_colors = {"T": "tab:blue", "W": "tab:orange", "P": "tab:green"}
    fig, axes = plt.subplots(1, 2, figsize=(15, 5.5), constrained_layout=True)
    fig.suptitle("RK3 mode-1 pairwise cross-phase and coherence (native-coordinate fields; no alignment)")
    coherence_values = []
    for pair, times in pairs.items():
        ordered = sorted(times)
        xs = [day(t) for t in ordered]
        for field, color in field_colors.items():
            axes[0].plot(xs, [times[t][field]["cross_phase_right_minus_left_rad"] for t in ordered],
                         color=color, linestyle=pair_styles[pair], linewidth=1.3)
            ys = [times[t][field]["coherence"] for t in ordered]
            coherence_values.extend(v for v in ys if v is not None)
            axes[1].plot(xs, ys, color=color, linestyle=pair_styles[pair], linewidth=1.3)
    axes[0].set_xlabel("Forecast day")
    axes[0].set_ylabel("Cross-phase (rad)")
    axes[0].set_title("arg(sum(Cright × conj(Cleft)))")
    axes[0].grid(True, alpha=0.25)
    axes[0].legend(handles=[Line2D([0], [0], color="black", linestyle=pair_styles[p],
                                   label=p.replace("rk3_", "")) for p in pair_styles],
                   fontsize=8, loc="upper right", title="Pair")
    axes[1].set_xlabel("Forecast day")
    axes[1].set_ylabel("Coherence")
    if coherence_values:
        lo = max(0.0, min(coherence_values) - max(1.0e-5, (max(coherence_values) - min(coherence_values)) * 0.02))
        axes[1].set_ylim(lo, max(coherence_values) + 1.0e-5)
    axes[1].set_title("Mode-1 coefficient coherence (full data range)")
    axes[1].grid(True, alpha=0.25)
    legend = axes[1].legend(handles=[Line2D([0], [0], color=c, label=f)
                                    for f, c in field_colors.items()],
                            fontsize=8, loc="lower right", title="Field")
    axes[1].add_artist(legend)
    save_figure(fig, "rk3_mode1_phase_coherence_2panel.png")


if __name__ == "__main__":
    accuracy_panels()
    wave_phase_panels()
