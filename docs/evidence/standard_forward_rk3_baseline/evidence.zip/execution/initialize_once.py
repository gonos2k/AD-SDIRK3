#!/usr/bin/env python3
"""One reviewed initial-data writer invocation; no forecast or retry."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
PLAN = ROOT / 'initializer_prelaunch_plan.json'
PLAN_SHA = 'aadaf082d34edb7d2b9bdea46037558ae3f1773990193979ac3f870bc93c585c'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()


def processes():
    r = subprocess.run(['/bin/ps', '-axo', 'pid=,ppid=,rss=,stat=,lstart='],
                       capture_output=True, text=True, check=True, timeout=3)
    rows = {}
    for line in r.stdout.splitlines():
        p = line.split(None, 4)
        if len(p) == 5:
            rows[int(p[0])] = {'ppid': int(p[1]), 'rss': int(p[2])*1024,
                               'state': p[3], 'birth': p[4]}
    return rows


def family(rows, root):
    found = {root}
    for _ in range(8):
        found.update(pid for pid, r in rows.items() if r['ppid'] in found)
    return {p: rows[p] for p in found if p in rows}


def main():
    assert sys.argv[1:] == ['--go'], 'explicit one-shot GO required'
    assert sha(PLAN) == PLAN_SHA
    plan = json.loads(PLAN.read_text())
    launch = plan['initializer_launch_plan']; cwd = Path(launch['cwd'])
    exe = plan['binaries']['ideal_exe']; nml = plan['official_input']['staged_namelist']
    jet = plan['official_input']['staged_input_jet']
    for p in (exe, nml, jet):
        assert sha(p['path']) == p['sha256']
    assert sha(plan['build_receipt']['path']) == plan['build_receipt']['sha256']
    assert sha(plan['binaries']['shared_exit_observer_receipt']['path']) == plan['binaries']['shared_exit_observer_receipt']['sha256']
    assert not any((cwd/p).exists() for p in ('wrfinput_d01','rsl.error.0000','launcher.stdout.log','root_initializer_intent.json'))
    assert shutil.disk_usage(ROOT).free >= 20*1024**3
    bad = [k for k in os.environ if k.startswith(('PMIX_', 'OMPI_COMM_WORLD_', 'PRTE_RANK', 'OMPI_MCA_', 'PRTE_MCA_', 'OPAL_MCA_'))]
    assert not bad, f'foreign runtime environment: {bad}'
    env = {k:v for k,v in os.environ.items() if not k.startswith(('WRF_SDIRK3_', 'WRF_PARITY_'))}
    env.update(launch['environment_overrides'])
    record = {'command': launch['argv'], 'cwd': str(cwd), 'plan_sha256': PLAN_SHA,
              'environment_overrides': launch['environment_overrides'], 'model_steps': 0,
              'scope': 'ideal.exe input generation only; not forecast cost evidence',
              'feasibility_note': {'pinned': plan['build_feasibility']['sha256'],
                                  'live': sha(plan['build_feasibility']['path']),
                                  'operative_inputs_and_build_verified_independently': True}}
    (cwd/'root_initializer_intent.json').write_text(json.dumps(record, indent=2)+'\n')
    start = time.monotonic(); epoch = time.time_ns(); proc = None; reason = None; tracked = {}; peak = 0
    with (cwd/'launcher.stdout.log').open('xb') as out, (cwd/'launcher.stderr.log').open('xb') as err:
        try:
            proc = subprocess.Popen(launch['argv'], cwd=cwd, env=env, stdout=out,
                                    stderr=err, start_new_session=True)
            while proc.poll() is None:
                rows = processes()
                if proc.poll() is not None:
                    break
                own = family(rows, proc.pid); tracked.update(own)
                peak = max(peak, sum(x['rss'] for x in own.values()))
                if time.monotonic()-start > 300 or peak > 32*1024**3 or shutil.disk_usage(ROOT).free < 20*1024**3:
                    reason = 'resource_or_wall_cap'; break
                time.sleep(.2)
        except BaseException as exc:
            reason = repr(exc)
        finally:
            oldmask = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGINT,signal.SIGTERM})
            try:
                if proc is not None and proc.poll() is None:
                    proc.terminate()
                    try:
                        proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        proc.kill(); proc.wait(timeout=5)
                if proc is not None:
                    proc.wait(timeout=5)
                rows = processes()
                remaining = {p:r for p,r in rows.items() if p in tracked and
                             r['birth']==tracked[p]['birth'] and not r['state'].startswith('Z')}
                if remaining:
                    reason = reason or 'owned_descendant_remaining_after_launcher_exit'
                for p,r in remaining.items():
                    if proc is not None and p == proc.pid:
                        continue
                    mapped = subprocess.run(['/usr/sbin/lsof','-a','-p',str(p),'-d','txt','-Fn'],
                                            capture_output=True,text=True,timeout=3)
                    if 'n'+str(Path(exe['path']).resolve()) in mapped.stdout.splitlines():
                        os.kill(p, signal.SIGKILL)
                        reason = reason or 'owned_rank_remaining_after_launcher_exit'
                record['remaining_owned_before_cleanup'] = remaining
            finally:
                signal.pthread_sigmask(signal.SIG_SETMASK, oldmask)
    record.update(return_code=proc.returncode if proc else None, stop_reason=reason,
                  elapsed_seconds=time.monotonic()-start, start_wall_ns=epoch,
                  end_wall_ns=time.time_ns(), peak_sampled_tree_rss_bytes=peak)
    if record['elapsed_seconds'] > 300:
        record['stop_reason'] = record['stop_reason'] or 'late_wall_cap'
    try:
        sys.path.insert(0, '/private/tmp/standard-forward-comparison-20261024/tools')
        import benchmark_wrf_accuracy_cost as helper
        import numpy as np
        state = helper.load_initial_state(cwd, {'nx':40,'ny':80,'nz':64},
                                          dry_case_no_qv=True,use_theta_m=1,source='wrfinput')
        f=state['fields']
        minima={'theta_K':float(np.min(f['T']+300)),
                'mu_Pa':float(np.min(f['MU']+f['MUB'])),
                'pressure_Pa':float(np.min(f['P']+f['PB'])),
                'layer_depth_m':float(np.min(np.diff(f['PH']+f['PHB'],axis=0)/9.81))}
        assert all(v>0 for v in minima.values())
        record['input']={'sha256':state['input_sha256'],'grid':state['grid'],
                         'timestamp':state['timestamp'],'minima':minima,'QVAPOR_max':state['qvapor_max_abs']}
    except Exception as exc:
        record['input_validation_error']=repr(exc)
    record['status']='completed' if record['return_code']==0 and not record['stop_reason'] and 'input_validation_error' not in record else 'failed'
    (cwd/'root_initializer_receipt.json').write_text(json.dumps(record,indent=2)+'\n')
    (cwd/'time.log').write_text(json.dumps({'source':'Python own-child wall samples; not BSD time or forecast timing',
                                        'wall_ns':record['end_wall_ns']-epoch,'monotonic_seconds':record['elapsed_seconds']},indent=2)+'\n')
    print(json.dumps(record,indent=2))
    return 0 if record['status']=='completed' else 2


if __name__ == '__main__':
    raise SystemExit(main())
