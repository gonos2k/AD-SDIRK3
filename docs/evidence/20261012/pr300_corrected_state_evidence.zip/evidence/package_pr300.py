#!/usr/bin/env python3
"""Freeze the completed PR300 evidence; no model evaluation or build."""
from pathlib import Path
import hashlib,json,shutil,subprocess,tempfile,zipfile,zlib
E=Path(__file__).resolve().parent
W=Path('/private/tmp/pr300-corrected-state-20261012')
OUT=W/'docs/evidence/20261012'
OUT.mkdir(parents=True,exist_ok=True)
B=Path(tempfile.mkdtemp(prefix='pr300-evidence-freeze-'))
def copy(src,rel):
 dst=B/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
for src in sorted(E.rglob('*')):
 if src.is_file() and not src.is_symlink() and '__pycache__' not in src.parts and src.suffix not in ('.pyc','.exe','.a','.o','.mod'):
  copy(src,Path('evidence')/src.relative_to(E))
copy(Path('/Users/yhlee/AD-SDIRK3-review-evidence/pressure-lineage-20261012/actual_t60_corrected_time0_wrfinput_d01_qvguard'),'inputs/corrected_wrfinput_d01.nc')
copy(Path('/Users/yhlee/AD-SDIRK3-review-evidence/same-state-rhs-20261011/wrf_validation/reference_snapshots/pr292_rk3_h3p75/wrfout_d01_0001-01-01_00:00:00'),'inputs/source60_wrfout_d01.nc')
for src in (E/'portable_dependencies').glob('*.py'):copy(src,Path('dependencies')/src.name)
copy(E/'verify_pr300_bundle.py','verify_pr300_bundle.py')
copy(W/'docs/(202610121600)_pr300_input_w_and_actual_rhs.md','final_report.md')
copy(E/'portable_dependencies/dependency_receipt.json','dependencies/dependency_receipt.json')
bind=json.loads((E/'red_provenance/final_code_binding.json').read_text())
for rel,pin in bind['native_source_pins']['pins'].items():
 blob=subprocess.check_output(['git','show','c26a0f9:'+rel],cwd=W)
 assert hashlib.sha256(blob).hexdigest()==pin['recorded_sha256']
 dst=B/'source'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(blob)
copy(W/'configure.wrf','source/configure.wrf')
(B/'source/start_em.patch').write_bytes(subprocess.check_output(['git','show','--format=','c26a0f9','--','dyn_em/start_em.F'],cwd=W))
G=Path('/private/tmp/pr299-pressure-lineage-graph-20261012')
copy(G/'source-bindings.json','graph/source-bindings.json')
for graph in sorted(G.rglob('graph.json')):
 if hashlib.sha256(graph.read_bytes()).hexdigest()=='6ac0649af173999996678af6f69c30409e411eac95099ff2441dc163c80bfe72':
  copy(graph,'graph/graph.json');break
else:raise ValueError('frozen graph bytes missing')
paths={
 'corrected_input':'inputs/corrected_wrfinput_d01.nc','source60_wrfout':'inputs/source60_wrfout_d01.nc',
 'corrected_runs':'evidence/green_execution/corrected_runs.json',
 'preserve_w_runs':'evidence/green_execution/preserve_w/preserve_w_runs.json',
 'corrected_state_gate':'evidence/green_rhs/corrected_state_gate.json',
 'preserve_w_state_gate':'evidence/green_execution/preserve_w/preserve_w_state_gate.json',
 'corrected_full_rhs':'evidence/green_execution/corrected_full_rhs_analysis.json',
 'corrected_pgf_context':'evidence/green_execution/corrected_pgf_context_gate.json',
 'default_off_runs':'evidence/green_execution/preserve_w/off_regression_runs.json',
 'default_off_acceptance':'evidence/green_execution/preserve_w/off_regression_physical_acceptance.json',
 'corrected_hv_npz':'evidence/green_transport/corrected_state_hv_physical_arrays.npz',
 'corrected_residual_npz':'evidence/green_pressure/corrected_actual_full_hv_pgf_residual_arrays.npz',
 'preserve_w_hv_npz':'evidence/green_transport/preserve_w_hv_physical_arrays.npz',
 'preserve_w_residual_npz':'evidence/green_pressure/preserve_w/preserve_w_full_hv_pgf_residual_arrays.npz',
 'preserve_w_full_npz':'evidence/green_metric/preserve_w/physical_rhs_arrays.npz',
 'preserve_w_pgf_npz':'evidence/green_pressure/preserve_w/preserve_w_pgf_physical_arrays.npz',
 'full_parser':'dependencies/analyze_snapshots.py','pgf_parser':'dependencies/analyze_pgf_capture_context.py'}
runs={
 'corrected_fortran_rk3_h15':'evidence/green_execution/captures/corrected/corrected_fortran_rk3_h15',
 'corrected_cpp_ark3_h15':'evidence/green_execution/captures/corrected/corrected_cpp_ark3_h15',
 'default_off_newexe_fortran_rk3_h15':'evidence/green_execution/preserve_w/captures/off_regression/newexe_default_off_fortran_rk3_h15',
 'preserve_w_fortran_rk3_h15':'evidence/green_execution/preserve_w/captures/preserve_w/preserve_w_fortran_rk3_h15',
 'preserve_w_cpp_ark3_h15':'evidence/green_execution/preserve_w/captures/preserve_w/preserve_w_cpp_ark3_h15'}
for rel in paths.values():assert (B/rel).is_file(),rel
for rel in runs.values():assert (B/rel).is_dir(),rel
(B/'README.md').write_text("PR300 evidence: minimal existing use_input_w initialization fix and five bounded native calls. Run python3 verify_pr300_bundle.py --root BUNDLE_ROOT --out RESULT.json (numpy/netCDF4 required). All scientific payloads use relative manifest paths. Auxiliary original scripts retain historical paths and receipts; the verifier is the relocation entrypoint. Exe/library bytes are excluded; hashes are recorded runtime observations. Baseline two calls had W=0. The third/default-off physical contract passes but strict whole-file parity fails only on 109 off-owner mu_tend ghost values. The final two opted-in calls preserve all six source60 fields. No warm restart or qualified forecast accuracy is asserted.\n")
entries=[]
for f in sorted(B.rglob('*')):
 if f.is_file():
  b=f.read_bytes();entries.append({'path':str(f.relative_to(B)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'crc32':f'0x{zlib.crc32(b)&0xffffffff:08x}'})
manifest={'schema':'pr300-portable-bundle-v1','paths':paths,'run_dirs':runs,'manifest_files':entries,'native_calls':5,'source_fix_commit':'c26a0f9a86d4ca83642d2cf82326399f8c79fe8a','scope':'cold-call state preservation and U/V/MU diagnostics; no new forecast acceptance'}
(B/'bundle_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
zip_path=OUT/'pr300_corrected_state_evidence.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted(B.rglob('*')):
  if f.is_file():z.write(f,f.relative_to(B))
with zipfile.ZipFile(zip_path) as z:assert z.testzip() is None
sha=hashlib.sha256(zip_path.read_bytes()).hexdigest()
(OUT/'pr300_corrected_state_evidence.zip.sha256').write_text(sha+'  '+zip_path.name+'\n')
print(json.dumps({'bundle_root':str(B),'zip':str(zip_path),'sha256':sha,'payload_files':len(entries),'zip_bytes':zip_path.stat().st_size}))
