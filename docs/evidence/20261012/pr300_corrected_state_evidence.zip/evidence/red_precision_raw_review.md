# Red precision: corrected-state raw-array and units check

Local time: 2026-10-12 15:10:28 JST. Independent, read-only binary parsing of the two completed 15 s corrected-state captures; no model run, build, source edit, EOS replay, or compiler/FMA analysis. The shared input SHA is `fc37c8c0c8be8053a16e0d3424609d496f4a023c6c17ee3a06371970639d14df`; both runs used executable SHA `4201790d…e22ec3`. Green’s exact six-state/periodic face gate passes. My parser and raw-file SHA receipts are in [`red_precision_raw_check.py`](red_precision_raw_check.py) and [`red_precision_raw_check.json`](red_precision_raw_check.json).

I independently parsed the FT/CPP Full snapshots, FT/CPP PGF snapshots, and both horizontal/vertical U-diffusion captures. The physical U mask is `[j=0:16,k=0:16,i=0:16]`: 4,096 unique owners; periodic seam face `i=0` is included and duplicated closing face `i=16` is excluded. Every cross-language difference was formed in float64 after widening raw FP32 values; isolated FT before/after increments were also widened before subtracting.

The Full U conversion from coupled Fortran tendency includes the mass product rule:

`u_dot = (RU_tend*MSFUY - U*C1H*mu_u_dot)/(C1H*Muu+C2H)`.

I reconstructed `mu_dot` from the raw captured RU/RV flux divergence and MU_TEND, then averaged it to U faces with periodic wrap. The resulting `mu_dot` RMS is `3.77238e-3 Pa/s`; `mu_u_dot` RMS is `3.79925e-3 Pa/s`. Its physical U product-rule term has RMS `6.82061e-8` and max `2.57364e-7 m/s²`. This term belongs in Full conversion. The isolated PGF and diffusion increments have no MU-dot product-rule term: FT partial contributions use `increment*MSFUY/L`; CPP partial contributions use the captured coupled increment divided by its captured velocity mass.

The raw Full RHS CPP−FT U delta is `8.39973e-8 m/s²` RMS, max `3.74252e-7`; seam face 0 RMS/max are `8.06269e-8` / `2.24776e-7`. The independently normalized PGF CPP−FT delta is `8.39315e-8` RMS, max `3.74262e-7`; face 0 RMS/max are `8.05158e-8` / `2.24771e-7`. The H-diffusion delta is `6.52201e-10` RMS (max `7.41318e-9`); V-diffusion delta is `1.53018e-12` RMS (max `1.39871e-11`). Subtracting these three measured components from the Full delta leaves `3.06866e-9` RMS, max `3.43791e-8 m/s²`. Thus PGF explains almost all of the corrected Full-RHS mismatch; the measured H/V diffusion deltas are much smaller.

The C++ H/V captures use identical mass arrays to their C++ PGF mass (zero measured difference). C++ PGF mass versus FT’s FP32 layer mass differs by only `0.003013 Pa` RMS / `0.008361 Pa` max on this approximately `89 kPa` layer scale. This confirms the conversion used each implementation’s captured mass basis rather than mixing coupled RU and physical acceleration units.

The Full delta values independently reproduce Green’s `corrected_full_rhs_analysis.json` U RMS and max exactly. The component decomposition is a new calculation directly from capture binaries; it is not a callback to Green’s result-producing function. Scope is limited to these two corrected-state first-call captures and U momentum; no V-PGF isolation is claimed.
