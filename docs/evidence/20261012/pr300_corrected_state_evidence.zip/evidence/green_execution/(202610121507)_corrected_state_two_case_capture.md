# Corrected-state two-case capture

Local timestamp: 2026-10-12 15:07 JST. Target worktree `/private/tmp/pr300-corrected-state-20261012`, HEAD `303fd8e22dc6908a0493ca87b49b2b6b2b3e9456`.

The corrected time-zero input was [`actual_t60_corrected_time0_wrfinput_d01_qvguard`](</Users/yhlee/AD-SDIRK3-review-evidence/pressure-lineage-20261012/actual_t60_corrected_time0_wrfinput_d01_qvguard>), SHA-256 `fc37c8c0c8be8053a16e0d3424609d496f4a023c6c17ee3a06371970639d14df`. Its fixture receipt verifies the t=60 RK3 state fields including THM and a zero-QVAPOR guard.

The PR298 executable was reused without rebuilding: executable SHA-256 `4201790d363fb9bdc1e49bf9a83fd3a506b91147c1b34b8a8fbbc0ff77e22ec3`, C++ archive SHA-256 `21f7bc79a131f4608f506259b7c0434f2350749486774f14aea260cc69910565`, configure SHA-256 `8cdf647666634cdb8cc2624d5d627c6bdd79472b3ed99481831f2a3e27873289`. The historical build receipt remains pinned to its actual PR298 HEAD `51527694a3cb139ae43c20532b138e4a65dd6153`; it was not relabeled as a PR300 build. The current target was clean, all seven primary and seven startup source hashes match the reused tree, and the 1,701 tracked native source files present in both trees had no byte mismatches. Three MYNN source files absent from the reuse tree are recorded as unavailable rather than treated as equal. Preflight is in [`preflight_source_binary_input.json`](preflight_source_binary_input.json).

Exactly two native calls ran, each at h=15 s for one step with debug level 2, one MPI rank, one OMP thread, and `WRF_PARITY_RK_TEND_DUMP=1`: Fortran RK3 and C++ ARK3. Both returned 0 and reached `SUCCESS COMPLETE`. Their full RHS, PGF, operand, and existing H/V snapshot files are under [`captures/corrected`](captures/corrected); each artifact's SHA-256 and schema/length receipt is in [`corrected_runs.json`](corrected_runs.json). No build or other native call was launched.

The Full RHS analysis [`corrected_full_rhs_analysis.json`](corrected_full_rhs_analysis.json) passes exact six-field state and periodic-U closure gates. The direct-call audit [`corrected_pgf_context_gate.json`](corrected_pgf_context_gate.json) also ties each captured PGF input to its same-run Full RHS input and passes the cross-method physical state/seam checks. Pressure operands are recorded for downstream analysis; this capture report makes no operator-parity or causal claim.

Next: GreenPressure, GreenMetric, and GreenTransport can analyze the pinned arrays. No further model run is authorized by this receipt.
