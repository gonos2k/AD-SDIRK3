#!/usr/bin/env python3
"""Analyze the two corrected-state capture files without launching WRF."""
from __future__ import annotations
import hashlib, importlib.util, json
from pathlib import Path

HERE=Path(__file__).parent
RUNS=HERE/'corrected_runs.json'
OUT=HERE/'corrected_pgf_context_gate.json'
CONTEXT_ANALYZER=Path('/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012/green_build/analyze_pgf_capture_context.py')

def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()

def main()->int:
    runs=json.loads(RUNS.read_text())
    if runs.get('status')!='completed' or len(runs.get('runs',[]))!=2:
        raise ValueError('expected exactly two completed corrected-state capture runs')
    ft=next(r for r in runs['runs'] if r['method']=='RK3')
    cpp=next(r for r in runs['runs'] if r['method']=='ARK3')
    if ft['input_sha256']!=cpp['input_sha256']:
        raise ValueError('Fortran/CPP capture inputs differ')
    spec=importlib.util.spec_from_file_location('context_audit',CONTEXT_ANALYZER)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    mod.DEFAULT_RUNS=RUNS
    case=mod.audit_case(cpp)
    out={'schema':'pr300-corrected-state-pgf-context-gate-v1','run_receipt':str(RUNS),
         'run_receipt_sha256':sha(RUNS),'input_sha256':ft['input_sha256'],
         'target_head':runs['target_head'],'reused_executable_sha256':ft['executable_sha256'],
         'case':case,'all_same_call_state_gates_pass':case['state_gates']['all_same_call_state_gates_pass'],
         'native_calls':2,'offline_analysis_only':True}
    OUT.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':case['status'],'out':str(OUT),'state_gate':out['all_same_call_state_gates_pass']},sort_keys=True))
    return 0 if out['all_same_call_state_gates_pass'] else 2

if __name__=='__main__':
    raise SystemExit(main())
