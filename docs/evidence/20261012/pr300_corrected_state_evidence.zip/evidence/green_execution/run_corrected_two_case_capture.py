#!/usr/bin/env python3
"""Run only the corrected-input Fortran RK3 and C++ ARK one-step captures."""
from __future__ import annotations
import hashlib, importlib.util, json, os, re, struct, subprocess, sys, time
from pathlib import Path

ROOT=Path('/private/tmp/pr300-corrected-state-20261012')
E=Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012/green_execution')
P298=Path('/private/tmp/pr298-u-pgf-20261012')
INPUT=Path('/Users/yhlee/AD-SDIRK3-review-evidence/pressure-lineage-20261012/actual_t60_corrected_time0_wrfinput_d01_qvguard')
FIXTURE=Path('/Users/yhlee/AD-SDIRK3-review-evidence/pressure-lineage-20261012/actual_t60_corrected_fixture_final_receipt.json')
BUILD_RECEIPT=Path('/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012/build_completed_receipt.json')
COMPAT=E/'preflight_source_binary_input.json'
EXE=P298/'main/wrf.exe'
LIB=P298/'external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a'
CONFIG=P298/'configure.wrf'
NML=Path('/Users/yhlee/Documents/AD-SDIRK3-worktree-archive/20261005/native_wave_refinement/wrf_runs/signfix_fp64_carry_on15_240/namelist.input')
DIAG=NML.parent/'diagnostics.txt'
EXPECTED_HEAD='303fd8e22dc6908a0493ca87b49b2b6b2b3e9456'
EXPECTED_INPUT_SHA='fc37c8c0c8be8053a16e0d3424609d496f4a023c6c17ee3a06371970639d14df'
EXPECTED_EXE_SHA='4201790d363fb9bdc1e49bf9a83fd3a506b91147c1b34b8a8fbbc0ff77e22ec3'
EXPECTED_LIB_SHA='21f7bc79a131f4608f506259b7c0434f2350749486774f14aea260cc69910565'
EXPECTED_CONFIG_SHA='8cdf647666634cdb8cc2624d5d627c6bdd79472b3ed99481831f2a3e27873289'
EXPECTED_COMPAT_SHA='3b8bdb0afdb362c0984c0c49ba78aa15b6e907b5c7689f9c3d870d1bcd46eaa9'
EXPECTED_NAMELIST_SHA='6258b997543f95b6cdde538aa37e14084f17862210e94c02dd23fb7fd91a8e06'
EXPECTED_DIAGNOSTICS_SHA='bc5c198d7f033fa8cd5d5b9bcbe2a46a2eae7d69ea8dd414d18f0cc5dc62b224'
CAPROOT=E/'captures'/'corrected'
RUNS=E/'corrected_runs.json'
BASE_RUNNER=Path('/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012/green_build/run_u_pgf_capture.py')

def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()
def load_base():
 spec=importlib.util.spec_from_file_location('pgf_base_runner',BASE_RUNNER)
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def expected_artifacts(method):
 if method=='RK3':
  return ('wrf_rk_tend_dump.bin','wrf_full_rhs_snapshot.bin','wrf_u_pgf_snapshot.bin',
          'wrf_u_hdiff_snapshot.bin','wrf_u_vdiff_before.bin')
 return ('port_full_rhs_snapshot.bin','port_u_pgf_snapshot.bin','port_u_pgf_operands_snapshot.bin',
         'port_hdiff_u_snapshot.bin','port_vdiff_u_snapshot.bin')

def h_v_schema(path,method,name):
 data=path.read_bytes()
 if name=='wrf_u_hdiff_snapshot.bin':
  if len(data)<60:raise ValueError('Fortran H-diff header truncated')
  ver,=struct.unpack_from('<I',data,0);b=struct.unpack_from('<12i',data,4)
  _,_,_,_,_,_,ims,ime,jms,jme,kms,kme=b
  n3=(ime-ims+1)*(jme-jms+1)*(kme-kms+1);expected=60+4*10*n3
  if ver!=1 or len(data)!=expected:raise ValueError(f'Fortran H-diff schema mismatch {len(data)} != {expected}')
  return {'version':ver,'bounds':list(b),'bytes_expected':expected,'fields_float32':10}
 if name=='wrf_u_vdiff_before.bin':
  if len(data)<60:raise ValueError('Fortran V-diff header truncated')
  ver,=struct.unpack_from('<I',data,0);b=struct.unpack_from('<12i',data,4)
  _,_,_,_,_,_,ims,ime,jms,jme,kms,kme=b
  n3=(ime-ims+1)*(jme-jms+1)*(kme-kms+1);expected=60+4*5*n3
  if ver!=1 or len(data)!=expected:raise ValueError(f'Fortran V-diff schema mismatch {len(data)} != {expected}')
  return {'version':ver,'bounds':list(b),'bytes_expected':expected,'fields_float32':5}
 if name in ('port_hdiff_u_snapshot.bin','port_vdiff_u_snapshot.bin'):
  if len(data)<16:raise ValueError(f'C++ {name} header truncated')
  ver,ny,nz,nxu=struct.unpack_from('<4i',data,0);expected=16+16*ny*nz*nxu
  if ver!=1 or min(ny,nz,nxu)<=0 or len(data)!=expected:raise ValueError(f'C++ {name} schema mismatch {len(data)} != {expected}')
  return {'version':ver,'shape_jki':[ny,nz,nxu],'bytes_expected':expected,'blocks_float64':2}
 raise ValueError(f'unknown H/V artifact: {name}')

def artifact_receipt(base,folder,method):
 base.EXPECTED_OUTPUTS[method]=expected_artifacts(method)
 result=base.artifact_receipt(folder,method)
 for n in ('wrf_u_hdiff_snapshot.bin','wrf_u_vdiff_before.bin','port_hdiff_u_snapshot.bin','port_vdiff_u_snapshot.bin'):
  if n in result:result[n]['schema']=h_v_schema(folder/n,method,n)
 return result

def verify_preflight(base):
 head=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()
 status=subprocess.check_output(['git','-C',str(ROOT),'status','--short'],text=True)
 if head!=EXPECTED_HEAD or status:raise RuntimeError(f'PR300 target changed: head={head}; status={status!r}')
 comp=json.loads(COMPAT.read_text())
 if comp['target_head']!=head or not comp['target_worktree_clean']:raise RuntimeError('source/binary preflight target HEAD/status mismatch')
 if not comp.get('seven_primary_sources_match_binary_tree') or not comp.get('startup_source_pins_match_binary_tree'):
  raise RuntimeError('primary or startup source byte-equivalence gate is false')
 for rel,h in comp['target_direct_source_pins'].items():
  if sha(ROOT/rel)!=h:raise RuntimeError(f'target source changed since preflight: {rel}')
 if comp['all_tracked_native_source_comparison']['byte_mismatches']:
  raise RuntimeError('current native sources differ from reused PR298 source tree')
 if sha(INPUT)!=EXPECTED_INPUT_SHA or sha(INPUT)!=json.loads(FIXTURE.read_text())['output_sha256']:
  raise RuntimeError('corrected input changed or fixture receipt mismatch')
 if sha(EXE)!=EXPECTED_EXE_SHA or sha(LIB)!=EXPECTED_LIB_SHA or sha(CONFIG)!=EXPECTED_CONFIG_SHA:
  raise RuntimeError('reused PR298 executable/library/config pin mismatch')
 historical_head=comp['historical_binary_origin']['receipt_head']
 if historical_head!='51527694a3cb139ae43c20532b138e4a65dd6153':raise RuntimeError('historical build receipt HEAD changed')
 old_build=base.verify_completed_build_receipt(P298,historical_head)
 if old_build['executable_sha256']!=EXPECTED_EXE_SHA or old_build['library_sha256']!=EXPECTED_LIB_SHA:
  raise RuntimeError('historical build receipt does not match reused binary')
 if sha(COMPAT)!=EXPECTED_COMPAT_SHA:raise RuntimeError('source/binary preflight manifest changed')
 if sha(NML)!=EXPECTED_NAMELIST_SHA or sha(DIAG)!=EXPECTED_DIAGNOSTICS_SHA:raise RuntimeError('source namelist/diagnostics changed')
 return {'target_head':head,'target_worktree_clean':True,'compatibility_manifest':str(COMPAT),
         'compatibility_manifest_sha256':sha(COMPAT),'historical_build_head':historical_head,
         'historical_build_receipt':str(BUILD_RECEIPT),'historical_build_receipt_sha256':sha(BUILD_RECEIPT),
         'historical_build_validation':old_build,'reused_executable_path':str(EXE),
         'reused_executable_sha256':sha(EXE),'reused_library_path':str(LIB),'reused_library_sha256':sha(LIB),
         'reused_config_path':str(CONFIG),'reused_config_sha256':sha(CONFIG),
         'corrected_input_path':str(INPUT),'corrected_input_sha256':sha(INPUT),
         'namelist_source':str(NML),'namelist_source_sha256':sha(NML),
         'diagnostics_source':str(DIAG),'diagnostics_sha256':sha(DIAG)}

def set_int(text,key,value):
 import re
 t,n=re.subn(r'(\b'+re.escape(key)+r'\s*=\s*)[-+0-9]+',lambda m:m.group(1)+str(value),text,count=1,flags=re.I)
 if n!=1:raise ValueError(f'missing namelist key {key}')
 return t

def stage(root,label,method,plan):
 folder=CAPROOT/label
 if folder.exists():raise FileExistsError(f'refusing to overwrite {folder}')
 folder.mkdir(parents=True)
 import shutil
 shutil.copy2(INPUT,folder/'wrfinput_d01');shutil.copy2(DIAG,folder/'diagnostics.txt')
 text=NML.read_text()
 for key,value in (('time_step',15),('time_step_fract_num',0),('time_step_fract_den',1),('run_seconds',15),
                   ('rk_ord',3),('time_integration_scheme',0 if method=='RK3' else 6),('sdirk3_debug_level',2)):
  text=set_int(text,key,value)
 (folder/'namelist.input').write_text(text)
 if sha(folder/'wrfinput_d01')!=EXPECTED_INPUT_SHA:raise RuntimeError('staged corrected input SHA mismatch')
 row={'label':label,'method':method,'time_step_seconds':15,'run_seconds':15,'reinitialized_from_corrected_t60_state':True,
      'input_origin':str(INPUT),'input_sha256':sha(folder/'wrfinput_d01'),'namelist_sha256':sha(folder/'namelist.input'),
      'diagnostics_sha256':sha(folder/'diagnostics.txt'),'executable_path':str(EXE),'executable_sha256':sha(EXE),
      'library_sha256':sha(LIB),'target_source_sha256':plan['target_source_sha256'],'workdir':str(folder),'status':'staged'}
 plan['runs'].append(row)
 return row, ['/usr/bin/time','-l','-o',str(folder/'time.log'),'/opt/homebrew/bin/mpirun','-np','1','--bind-to','none',str(EXE)]

def main():
 import argparse
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--timeout',type=int,default=1200);args=ap.parse_args()
 base=load_base();
 if RUNS.exists() or CAPROOT.exists():raise FileExistsError('refusing to overwrite existing corrected run plan/output')
 for p in (INPUT,FIXTURE,NML,DIAG,EXE,LIB,CONFIG,BUILD_RECEIPT,base.BUILD_COMPILE_LOG,base.BUILD_REUSE_RECEIPT,COMPAT):
  if not p.is_file():raise FileNotFoundError(p)
 pre=verify_preflight(base)
 source_before=base.source_hashes(ROOT)
 if source_before!=base.EXPECTED_SOURCE_SHA256:raise RuntimeError('seven current target source pins differ from PR298 capture pins')
 CAPROOT.mkdir(parents=True)
 plan={'schema':'pr300-corrected-state-u-pgf-two-case-v1','status':'running','target_root':str(ROOT),
       'target_head':EXPECTED_HEAD,'target_source_sha256':source_before,'preflight':pre,
       'reused_binary_historical_head':'51527694a3cb139ae43c20532b138e4a65dd6153',
       'run_policy':'exactly two one-step captures; no build or other native calls; clear inherited WRF_SDIRK3_* and WRF_PARITY_* then set only WRF_PARITY_RK_TEND_DUMP=1',
       'requested_cases':['corrected_fortran_rk3_h15','corrected_cpp_ark3_h15'],
       'step_seconds':15,'duration_seconds':15,'mpi_ranks':1,'omp_threads':1,'debug_level':2,
       'corrected_input_sha256':EXPECTED_INPUT_SHA,'runs':[]}
 RUNS.write_text(json.dumps(plan,indent=2)+'\n')
 clean={k:v for k,v in os.environ.items() if not k.startswith(('WRF_SDIRK3_','WRF_PARITY_'))}
 clean.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
 cases=(('corrected_fortran_rk3_h15','RK3'),('corrected_cpp_ark3_h15','ARK3'))
 try:
  for label,method in cases:
   row,cmd=stage(ROOT,label,method,plan);row['command']=cmd;row['status']='running';RUNS.write_text(json.dumps(plan,indent=2)+'\n')
   runenv=dict(clean,WRF_PARITY_RK_TEND_DUMP='1');t0=time.monotonic()
   with (Path(row['workdir'])/'run.log').open('wb') as log:
    proc=subprocess.run(cmd,cwd=row['workdir'],env=runenv,stdout=log,stderr=subprocess.STDOUT,timeout=args.timeout,check=False)
   folder=Path(row['workdir']);out=(folder/'rsl.out.0000').read_text(errors='replace') if (folder/'rsl.out.0000').is_file() else ''
   err=(folder/'rsl.error.0000').read_text(errors='replace') if (folder/'rsl.error.0000').is_file() else ''
   row.update({'return_code':proc.returncode,'wall_seconds':time.monotonic()-t0,
       'rsl_out_sha256':sha(folder/'rsl.out.0000') if (folder/'rsl.out.0000').is_file() else None,
       'rsl_error_sha256':sha(folder/'rsl.error.0000') if (folder/'rsl.error.0000').is_file() else None,
       'namelist_output_sha256':sha(folder/'namelist.output') if (folder/'namelist.output').is_file() else None,
       'time_log_sha256':sha(folder/'time.log') if (folder/'time.log').is_file() else None,
       'completion_marker':'SUCCESS COMPLETE' in (out+err),
       'effective_runtime_config':base.capture_runtime_config(folder,method),
       'artifacts':artifact_receipt(base,folder,method)})
   row['status']='completed' if proc.returncode==0 and row['completion_marker'] else 'failed'
   RUNS.write_text(json.dumps(plan,indent=2)+'\n')
   if row['status']!='completed':raise RuntimeError(f'capture failed: {label}')
   if sha(EXE)!=EXPECTED_EXE_SHA or sha(LIB)!=EXPECTED_LIB_SHA:raise RuntimeError('reused binary changed during run')
  after=base.source_hashes(ROOT)
  if after!=source_before:raise RuntimeError('target sources changed during native calls')
  plan['source_sha256_after']=after;plan['status']='completed';plan['native_calls']=2
  plan['completion_note']='Only the two requested corrected-input 15 s calls ran; outputs include PGF, Full RHS, and existing H/V snapshots.'
  RUNS.write_text(json.dumps(plan,indent=2)+'\n')
  print(json.dumps({'status':'completed','plan':str(RUNS),'runs':[{'label':r['label'],'return_code':r['return_code'],'status':r['status'],'artifacts':list(r['artifacts'])} for r in plan['runs']]},sort_keys=True))
 except Exception as exc:
  plan['status']='failed';plan['failure']=f'{type(exc).__name__}: {exc}';plan['source_sha256_after']=base.source_hashes(ROOT);RUNS.write_text(json.dumps(plan,indent=2)+'\n');raise

if __name__=='__main__':main()
