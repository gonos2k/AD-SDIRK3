#!/usr/bin/env python3
"""One new-executable default-off RK3 call, compared bytewise to retained baseline."""
from __future__ import annotations
import hashlib, importlib.util, json, os, re, shutil, subprocess, time
from pathlib import Path

HERE=Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012/green_execution/preserve_w')
BASE=Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261011/unused')
# Exact retained corrected-input Fortran baseline from the two-call PR300 capture.
BASE=Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012/green_execution/captures/corrected/corrected_fortran_rk3_h15')
RUNS=HERE/'off_regression_runs.json'; CAPROOT=HERE/'captures'/'off_regression'
PRESERVE=HERE/'run_preserve_w_two_case_capture.py'
INPUT=Path('/Users/yhlee/AD-SDIRK3-review-evidence/pressure-lineage-20261012/actual_t60_corrected_time0_wrfinput_d01_qvguard')
NML=Path('/Users/yhlee/Documents/AD-SDIRK3-worktree-archive/20261005/native_wave_refinement/wrf_runs/signfix_fp64_carry_on15_240/namelist.input')
DIAG=NML.parent/'diagnostics.txt'
ARTIFACTS=('wrf_rk_tend_dump.bin','wrf_full_rhs_snapshot.bin','wrf_u_pgf_snapshot.bin','wrf_u_hdiff_snapshot.bin','wrf_u_vdiff_before.bin')
EXPECTED_NML_SHA='6258b997543f95b6cdde538aa37e14084f17862210e94c02dd23fb7fd91a8e06'
EXPECTED_BASE_INPUT_SHA='fc37c8c0c8be8053a16e0d3424609d496f4a023c6c17ee3a06371970639d14df'
BASE_RUNS=Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012/green_execution/corrected_runs.json')
BASE_LABEL='corrected_fortran_rk3_h15'

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load_preserve():
 spec=importlib.util.spec_from_file_location('preserve_runner',PRESERVE)
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--timeout',type=int,default=1200);args=ap.parse_args()
 m=load_preserve(); corrected=m.load_base(); base=corrected.load_base()
 if RUNS.exists() or CAPROOT.exists(): raise FileExistsError('refusing to overwrite off-regression outputs')
 build=m.verify_build_and_sources(base)
 baseline=json.loads(BASE_RUNS.read_text())
 br=next(r for r in baseline['runs'] if r['label']==BASE_LABEL)
 if baseline.get('status')!='completed' or br.get('status')!='completed' or br.get('return_code')!=0:
  raise RuntimeError('retained baseline run receipt is not complete')
 for name in ('wrfinput_d01','namelist.input','diagnostics.txt',*ARTIFACTS):
  if not (BASE/name).is_file(): raise FileNotFoundError(BASE/name)
 if sha(BASE/'wrfinput_d01')!=EXPECTED_BASE_INPUT_SHA:
  raise RuntimeError('baseline input does not match requested corrected case')
 # Baseline confirms the default-off setting in the effective runtime namelist.
 if not re.search(r'(?im)^\s*USE_INPUT_W\s*=\s*F\s*,?',(BASE/'namelist.output').read_text()):
  raise RuntimeError('baseline does not report USE_INPUT_W=F')
 source_before=base.source_hashes(m.ROOT)
 if RUNS.exists(): raise FileExistsError(RUNS)
 CAPROOT.mkdir(parents=True)
 label='newexe_default_off_fortran_rk3_h15'; folder=CAPROOT/label;folder.mkdir()
 shutil.copy2(INPUT,folder/'wrfinput_d01');shutil.copy2(DIAG,folder/'diagnostics.txt')
 text=NML.read_text()
 if re.search(r'(?im)^\s*use_input_w\s*=',re.sub(r'(?m)!.*$','',text)):
  raise RuntimeError('source namelist unexpectedly contains use_input_w; refusing implicit override')
 for key,value in (('time_step',15),('time_step_fract_num',0),('time_step_fract_den',1),('run_seconds',15),('rk_ord',3),('time_integration_scheme',0),('sdirk3_debug_level',2)):
  text=m.set_namelist_int(text,key,value)
 (folder/'namelist.input').write_text(text)
 if sha(folder/'namelist.input')!=sha(BASE/'namelist.input'): raise RuntimeError('staged default-off namelist differs from retained baseline')
 if sha(folder/'wrfinput_d01')!=EXPECTED_BASE_INPUT_SHA: raise RuntimeError('staged corrected input hash mismatch')
 plan={'schema':'pr300-newexe-default-off-regression-v1','status':'running','build_lineage':build,
  'baseline_plan':str(BASE_RUNS),'baseline_plan_sha256':sha(BASE_RUNS),'baseline_label':BASE_LABEL,
  'baseline_workdir':str(BASE),'baseline_artifacts':{n:sha(BASE/n) for n in ARTIFACTS},
  'target_workdir':str(folder),'target_executable_sha256':sha(m.EXE),'target_start_em_sha256':m.EXPECTED_START_EM_SHA,
  'input_sha256':sha(folder/'wrfinput_d01'),'namelist_sha256':sha(folder/'namelist.input'),
  'use_input_w':'false (key absent; runtime must report F)','method':'Fortran RK3','time_step_seconds':15,'run_seconds':15,
  'native_calls':1,'runs':[{'label':label,'status':'running','input_sha256':sha(folder/'wrfinput_d01'),
  'namelist_sha256':sha(folder/'namelist.input'),'workdir':str(folder)}]}
 RUNS.write_text(json.dumps(plan,indent=2)+'\n')
 clean={k:v for k,v in os.environ.items() if not k.startswith(('WRF_SDIRK3_','WRF_PARITY_'))}
 clean.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',WRF_PARITY_RK_TEND_DUMP='1')
 cmd=['/usr/bin/time','-l','-o',str(folder/'time.log'),'/opt/homebrew/bin/mpirun','-np','1','--bind-to','none',str(m.EXE)]
 plan['runs'][0]['command']=cmd;RUNS.write_text(json.dumps(plan,indent=2)+'\n');t0=time.monotonic()
 try:
  with (folder/'run.log').open('wb') as log: proc=subprocess.run(cmd,cwd=folder,env=clean,stdout=log,stderr=subprocess.STDOUT,timeout=args.timeout,check=False)
  out=(folder/'rsl.out.0000').read_text(errors='replace') if (folder/'rsl.out.0000').is_file() else ''
  err=(folder/'rsl.error.0000').read_text(errors='replace') if (folder/'rsl.error.0000').is_file() else ''
  if not re.search(r'(?im)^\s*USE_INPUT_W\s*=\s*F\s*,?',(folder/'namelist.output').read_text()):
   raise RuntimeError('new executable did not report USE_INPUT_W=F')
  artifacts={}
  for n in ARTIFACTS:
   p=folder/n
   if not p.is_file(): raise FileNotFoundError(p)
   artifacts[n]={'sha256':sha(p),'bytes':p.stat().st_size,'baseline_sha256':sha(BASE/n),'byte_identical_to_baseline':p.read_bytes()==(BASE/n).read_bytes()}
  run=plan['runs'][0];run.update({'return_code':proc.returncode,'wall_seconds':time.monotonic()-t0,
   'completion_marker':'SUCCESS COMPLETE' in out+err,'effective_use_input_w':'F','runtime_route':base.capture_runtime_config(folder,'RK3'),
   'artifacts':artifacts,'namelist_output_sha256':sha(folder/'namelist.output'),'rsl_out_sha256':sha(folder/'rsl.out.0000'),
   'rsl_error_sha256':sha(folder/'rsl.error.0000'),'time_log_sha256':sha(folder/'time.log')})
  if proc.returncode!=0 or not run['completion_marker']: raise RuntimeError('default-off native call did not complete')
  if not all(x['byte_identical_to_baseline'] for x in artifacts.values()):
   raise RuntimeError('new default-off outputs differ from retained baseline; preserve receipt and stop before opt-in calls')
  if sha(m.EXE)!=m.EXPECTED_EXE_SHA or sha(m.LIB)!=m.EXPECTED_LIB_SHA: raise RuntimeError('binary changed during call')
  if base.source_hashes(m.ROOT)!=source_before or sha(m.ROOT/'dyn_em/start_em.F')!=m.EXPECTED_START_EM_SHA:
   raise RuntimeError('authoritative source changed during default-off run')
  run['status']='completed';plan.update({'status':'completed','source_sha256_after':base.source_hashes(m.ROOT),
    'parity':'all five captured Fortran artifacts byte-identical to retained corrected-input baseline','gate':'PASS'})
  RUNS.write_text(json.dumps(plan,indent=2)+'\n')
  print(json.dumps({'status':'completed','plan':str(RUNS),'artifacts':artifacts},sort_keys=True))
 except Exception as exc:
  plan['status']='failed';plan['failure']=f'{type(exc).__name__}: {exc}';RUNS.write_text(json.dumps(plan,indent=2)+'\n');raise
if __name__=='__main__':main()
