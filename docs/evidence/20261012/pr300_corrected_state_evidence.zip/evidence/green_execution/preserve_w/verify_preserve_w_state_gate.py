#!/usr/bin/env python3
"""Fail-closed comparison of corrected cold-call state against archived WRFOUT frame.

Offline only: parses the two already completed PR300 captures, checks their
paired state contract, and compares the six actual prognostic call fields with
the unique archived 60 s source frame. NetCDF T/P diagnostics are reported
separately from prognostic THM/call-time derived pressure.
"""
from __future__ import annotations
import hashlib, importlib.util, json, sys
from pathlib import Path
import numpy as np
from netCDF4 import Dataset

E = Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012')
HERE = Path(__file__).resolve().parent
RUNS = E/'green_execution/preserve_w/preserve_w_runs.json'
FULL_JSON = HERE/'preserve_w_full_rhs_analysis.json'
PGF_JSON = HERE/'preserve_w_pgf_context_gate.json'
FIXTURE = Path('/Users/yhlee/AD-SDIRK3-review-evidence/pressure-lineage-20261012/actual_t60_corrected_fixture_final_receipt.json')
SOURCE_ROOT = Path('/private/tmp/pr300-corrected-state-20261012')
SEAM_EVID = Path('/Users/yhlee/AD-SDIRK3-review-evidence/seam-cause-acceptance-20261012')
PGF_PARSER = Path('/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012/green_build/analyze_pgf_capture_context.py')
AS_SPEC = importlib.util.spec_from_file_location('full_rhs_contract', SEAM_EVID/'analyze_snapshots.py')
AS = importlib.util.module_from_spec(AS_SPEC); AS_SPEC.loader.exec_module(AS)
CAP_SPEC = importlib.util.spec_from_file_location('pgf_context_contract', PGF_PARSER)
CAP = importlib.util.module_from_spec(CAP_SPEC); CAP_SPEC.loader.exec_module(CAP)

STATE_MAP = {'u':'U','v':'V','w':'W','ph':'PH','t':'THM','mu':'MU'}
EXPECTED_DIMS = {
 'U':('Time','bottom_top','south_north','west_east_stag'),
 'V':('Time','bottom_top','south_north_stag','west_east'),
 'W':('Time','bottom_top_stag','south_north','west_east'),
 'PH':('Time','bottom_top_stag','south_north','west_east'),
 'THM':('Time','bottom_top','south_north','west_east'),
 'MU':('Time','south_north','west_east'),
 'T':('Time','bottom_top','south_north','west_east'),
 'P':('Time','bottom_top','south_north','west_east'),
}
EXPECTED_UNITS={'U':'m s-1','V':'m s-1','W':'m s-1','PH':'m2 s-2','THM':'K','MU':'Pa','T':'K','P':'Pa'}
EXPECTED_STAGGER={'U':'X','V':'Y','W':'Z','PH':'Z','THM':'','MU':'','T':'','P':''}


def sha(path:Path)->str:
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()

def receipt(path:Path): return {'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path)}

def decode_times(ds):
 if 'Times' not in ds.variables: return None
 arr=ds.variables['Times'][:]
 out=[]
 for row in arr:
  vals=[]
  for x in row:
   if isinstance(x,(bytes,np.bytes_)): vals.append(x.decode('ascii'))
   else: vals.append(str(x))
  out.append(''.join(vals).rstrip('\x00 '))
 return out

def stat_delta(a,b):
 x=np.asarray(a); y=np.asarray(b)
 if x.shape!=y.shape: return {'shape_equal':False,'shape_a':list(x.shape),'shape_b':list(y.shape)}
 if not (np.isfinite(x).all() and np.isfinite(y).all()):
  return {'shape_equal':True,'finite':False,'count':int(x.size),'nonfinite_a':int(np.count_nonzero(~np.isfinite(x))),'nonfinite_b':int(np.count_nonzero(~np.isfinite(y)))}
 d=x.astype(np.float64)-y.astype(np.float64)
 return {'shape_equal':True,'finite':True,'count':int(d.size),'exact':bool(np.array_equal(x,y)),
         'mismatch_count':int(np.count_nonzero(x!=y)),'rms_delta':float(np.sqrt(np.mean(d*d))),
         'max_abs_delta':float(np.max(np.abs(d))) if d.size else 0.0,
         'max_index':list(map(int,np.unravel_index(np.argmax(np.abs(d)),d.shape))) if d.size else [],
         'a_sha256':hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest(),
         'b_sha256':hashlib.sha256(np.ascontiguousarray(y).tobytes()).hexdigest()}

def compact_delta(a,b):
 x=np.asarray(a); y=np.asarray(b)
 if x.shape!=y.shape: return {'shape_equal':False,'shape_a':list(x.shape),'shape_b':list(y.shape)}
 if not (np.isfinite(x).all() and np.isfinite(y).all()): return {'shape_equal':True,'finite':False}
 d=x.astype(np.float64)-y.astype(np.float64)
 return {'shape_equal':True,'finite':True,'count':int(d.size),'exact':bool(np.array_equal(x,y)),
         'mismatch_count':int(np.count_nonzero(x!=y)),'rms_delta':float(np.sqrt(np.mean(d*d))),
         'max_abs_delta':float(np.max(np.abs(d))) if d.size else 0.0}

def gate_summary(gates):
 return {name:{field:bool(item.get('equal',False)) for field,item in fields.items()} for name,fields in gates.items()}

def source_array(ds,name,time_index):
 var=ds.variables[name]
 x=np.ma.asarray(var[time_index])
 if np.ma.getmaskarray(x).any(): raise ValueError(f'{name}: masked source values')
 x=np.asarray(x)
 if x.ndim==3: x=x.transpose(1,0,2) # NetCDF [k,j,i] -> canonical [j,k,i]
 elif x.ndim!=2: raise ValueError(f'{name}: unsupported rank {x.ndim}')
 return x

def read_state_inputs():
 runs_doc=json.loads(RUNS.read_text()); fixture=json.loads(FIXTURE.read_text())
 if runs_doc.get('status')!='completed' or runs_doc.get('native_calls')!=2 or len(runs_doc.get('runs',[]))!=2:
  raise ValueError('run receipt must represent exactly two completed native calls')
 if runs_doc['target_head']!='303fd8e22dc6908a0493ca87b49b2b6b2b3e9456': raise ValueError('unexpected target HEAD')
 if runs_doc.get('corrected_input_sha256') != fixture.get('output_sha256'): raise ValueError('corrected input hash does not match fixture receipt')
 if sha(Path(fixture['output'])) != fixture['output_sha256']: raise ValueError('corrected input bytes differ from fixture receipt')
 if sha(Path(fixture['source_wrfout'])) != fixture['source_sha256']: raise ValueError('archived source frame file SHA differs from fixture receipt')
 source_path=Path(fixture['source_wrfout']); input_path=Path(fixture['output'])
 labels={r['label']:r for r in runs_doc['runs']}
 expected_labels={'preserve_w_fortran_rk3_h15','preserve_w_cpp_ark3_h15'}
 if set(labels)!=expected_labels: raise ValueError(f'unexpected preserve-W labels: {sorted(labels)}')
 for label,r in labels.items():
  if r.get('status')!='completed' or r.get('input_sha256')!=fixture['output_sha256'] or r.get('input_origin')!=str(input_path):
   raise ValueError(f'{label}: run receipt/input mismatch')
  if not r.get('use_input_w') or not r.get('effective_use_input_w',{}).get('namelist_output_use_input_w_true'):
   raise ValueError(f'{label}: USE_INPUT_W is not true in run receipt')
  if sha(Path(r['workdir'])/'wrfinput_d01')!=fixture['output_sha256']:
   raise ValueError(f'{label}: actual workdir wrfinput bytes differ')
 source_ds=Dataset(source_path,'r'); input_ds=Dataset(input_path,'r')
 source_times=decode_times(source_ds); input_times=decode_times(input_ds)
 if source_times is None or input_times is None: raise ValueError('missing Times metadata')
 if source_times.count(fixture['source_timestamp'])!=1: raise ValueError('source timestamp is missing or nonunique')
 source_ti=source_times.index(fixture['source_timestamp'])
 if source_ti!=fixture['source_time_index']: raise ValueError('source timestamp index differs from fixture receipt')
 if input_times!=[fixture['output_time']]: raise ValueError(f'corrected input Times is not the expected time zero: {input_times}')
 missing=[]; meta={}
 for name in (*STATE_MAP.values(),'T','P'):
  if name not in source_ds.variables: missing.append(f'source:{name}'); continue
  var=source_ds.variables[name]
  dims=tuple(var.dimensions); units=str(getattr(var,'units',''))
  stagger=str(getattr(var,'stagger',''))
  meta[name]={'dimensions':list(dims),'shape':list(var.shape),'dtype':str(var.dtype),'units':units,'stagger':stagger}
  if dims!=EXPECTED_DIMS[name]: missing.append(f'source:{name}:dimensions')
  if units!=EXPECTED_UNITS[name]: missing.append(f'source:{name}:units')
  if stagger!=EXPECTED_STAGGER[name]: missing.append(f'source:{name}:stagger')
  if name not in input_ds.variables: missing.append(f'input:{name}')
  elif tuple(input_ds.variables[name].dimensions)!=EXPECTED_DIMS[name]: missing.append(f'input:{name}:dimensions')
 if missing:
  source_ds.close();input_ds.close()
  raise ValueError('fail-closed missing/incompatible state metadata before array comparison: '+','.join(missing))
 src={name:source_array(source_ds,name,source_ti) for name in (*STATE_MAP.values(),'T','P')}
 inp={name:source_array(input_ds,name,0) for name in (*STATE_MAP.values(),'T','P')}
 for name in (*STATE_MAP.values(),'T','P'):
  if not (np.isfinite(src[name]).all() and np.isfinite(inp[name]).all()):
   source_ds.close();input_ds.close();raise ValueError(f'{name}: nonfinite source/input values before comparison')
 stmeta={'source_path':str(source_path),'source_file':receipt(source_path),'source_times':source_times,
         'source_timestamp':fixture['source_timestamp'],'source_index':source_ti,
         'input_path':str(input_path),'input_file':receipt(input_path),'input_times':input_times,
         'variables':meta,'input_state_vs_source':{name:stat_delta(inp[name],src[name]) for name in (*STATE_MAP.values(),'T','P')}}
 source_ds.close();input_ds.close()
 return runs_doc,fixture,labels,src,inp,stmeta

def main():
 report={'schema':'pr300-actual-prognostic-state-vs-source60-preserve-w-v1','target_root':str(SOURCE_ROOT),
         'scope':'Offline call-state verification only; no production P equivalence assumption and no RHS/PGF arithmetic attribution.'}
 try:
  runs,fixture,labels,src,inp,smeta=read_state_inputs()
 except Exception as e:
  report.update({'status':'blocked_missing_or_invalid_state_metadata','comparison_performed':False,'reason':str(e)})
  (HERE/'preserve_w_state_gate.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
  print(json.dumps({'status':report['status'],'reason':report['reason']})); return 2
 report['source_and_input_metadata']=smeta
 report['source_selection']={'fixture_receipt':str(FIXTURE),'fixture_receipt_sha256':sha(FIXTURE),
   'source_timestamp_unique':True,'source_time_index':smeta['source_index'],'input_metadata_time_zero':True,
   'diagnostic_T_is_not_prognostic_state':True,'prognostic_theta_binding':'call-local t maps to NetCDF THM via Registry; NetCDF T is diagnostic th_phy_m_t0'}
 # Required state fields must exist and pass finite/shape checks before any RHS arithmetic.
 source_required=tuple(STATE_MAP.values())
 for name in source_required:
  if not np.isfinite(src[name]).all():
   report.update({'status':'blocked_nonfinite_archived_state','comparison_performed':False,'missing_or_bad_field':name})
   (HERE/'preserve_w_state_gate.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n'); return 2
 report['input_state_gate']={name:smeta['input_state_vs_source'][name] for name in source_required}
 report['input_diagnostic_fields_not_in_call_state_gate']={name:smeta['input_state_vs_source'][name] for name in ('T','P')}
 if not all(x.get('shape_equal') and x.get('exact') and x.get('finite') for x in report['input_state_gate'].values()):
  report.update({'status':'input_state_not_exact_to_source60','comparison_performed':False})
  (HERE/'preserve_w_state_gate.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n'); return 2
 # Parse actual calls and replay the established full-RHS + PGF state contracts.
 capmod=CAP
 capmod.DEFAULT_RUNS=RUNS
 case_gate=capmod.audit_case(labels['preserve_w_cpp_ark3_h15'])
 PGF_JSON.write_text(json.dumps({'schema':'pr300-preserve-w-pgf-context-gate-v1','run_receipt':str(RUNS),
  'run_receipt_sha256':sha(RUNS),'case':case_gate,
  'all_same_call_state_gates_pass':case_gate['state_gates']['all_same_call_state_gates_pass']},indent=2,sort_keys=True)+'\n')
 if case_gate['status']!='state_gates_pass':
  report.update({'status':'paired_same_call_gate_failed','comparison_performed':False,'same_call_gate':case_gate})
  (HERE/'preserve_w_state_gate.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n'); return 2
 ft_dir=Path(labels['preserve_w_fortran_rk3_h15']['workdir']); cpp_dir=Path(labels['preserve_w_cpp_ark3_h15']['workdir'])
 ft_full_path=ft_dir/'wrf_full_rhs_snapshot.bin'; cpp_full_path=cpp_dir/'port_full_rhs_snapshot.bin'
 ft_pgf_path=ft_dir/'wrf_u_pgf_snapshot.bin'; cpp_pgf_path=cpp_dir/'port_u_pgf_snapshot.bin'
 full_contract=AS.analyze(ft_full_path,cpp_full_path,SOURCE_ROOT)
 if not full_contract.get('comparison_available') or not full_contract.get('state_gate',{}).get('passed'):
  report.update({'status':'full_rhs_state_gate_failed','comparison_performed':False,'full_rhs_analysis':full_contract})
  (HERE/'preserve_w_state_gate.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n'); return 2
 FULL_JSON.write_text(json.dumps(full_contract,indent=2,sort_keys=True)+'\n')
 ft_full_meta,ftfull=AS.read_fortran(ft_full_path); cpp_full_meta,cpp_full_state,_=AS.read_cpp(cpp_full_path)
 dims=tuple(cpp_full_meta['dims_nx_ny_nz_nxu_nyv_nzw'])
 ft_full_state=AS.logical_fortran_state(ft_full_meta,ftfull,dims)
 ft_pgf_meta,ftp=CAP.read_ft_pgf(ft_pgf_path)
 cpp_pgf_meta,cpp_pgf_state,_=CAP.read_cpp_pgf(cpp_pgf_path)
 ft_call_logical=AS.logical_fortran_state({'bounds':ft_pgf_meta['bounds_dict']},
  {'u2':ftp['u'],'v2':ftp['v'],'w2':ftp['w'],'ph2':ftp['ph'],'t2':ftp['t'],'mu2':ftp['mu']},dims)
 # Fail closed on same-run call/full equality and paired physical state before source comparisons.
 call_gates={'fortran_pgf_vs_full':AS.state_audit(ft_call_logical,ft_full_state),
             'cpp_pgf_vs_full':AS.state_audit(cpp_pgf_state,cpp_full_state)}
 ft_phys=AS.physical_state(ft_call_logical,dims); cpp_phys=AS.physical_state(cpp_pgf_state,dims)
 paired=AS.state_audit(ft_phys,cpp_phys)
 periodic=AS.periodic_u_seam_audit(ft_call_logical,cpp_pgf_state,dims)
 call_ok=(all(x['equal'] for g in call_gates.values() for x in g.values()) and
          all(x['equal'] for x in paired.values()) and
          all(periodic[k] for k in ('fortran_first_equals_closing_face','cpp_first_equals_closing_face','fortran_cpp_closing_face_equal')))
 if not call_ok:
  report.update({'status':'same_call_state_gate_failed','comparison_performed':False,
   'call_state_gate_summary':gate_summary(call_gates),'paired_physical_state_equal':{k:bool(v.get('equal',False)) for k,v in paired.items()},
   'periodic_u_seam':periodic})
  (HERE/'preserve_w_state_gate.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n'); return 2
 # State metrics now compare each live call snapshot against archived 60-s source arrays.
 actual={'fortran':ft_phys,'cpp':cpp_phys}; state_results={}
 for mode,fields in actual.items():
  state_results[mode]={}
  for state_name,nc_name in STATE_MAP.items():
   actual_array=fields[state_name][:,0,:] if state_name=='mu' else fields[state_name]
   state_results[mode][state_name]={'source_variable':nc_name,'call_vs_archived_source60':stat_delta(actual_array,src[nc_name])}
 report['same_call_state_gates']={'passed':True,'per_field_equal':gate_summary(call_gates),
  'fortran_vs_cpp_physical_owned_equal':{k:bool(v.get('equal',False)) for k,v in paired.items()},'periodic_u_seam':periodic}
 report['actual_prognostic_state_vs_source60']=state_results
 all_source_exact=all(v['call_vs_archived_source60']['shape_equal'] and v['call_vs_archived_source60']['exact'] and v['call_vs_archived_source60']['finite']
  for by_field in state_results.values() for v in by_field.values())
 report['W_vertical_level_differences']={'axes':'for each zero-based k, compare [j,i] owner plane',
  'by_mode':{mode:{str(k):compact_delta(fields['w'][:,k,:],src['W'][:,k,:]) for k in range(fields['w'].shape[1])} for mode,fields in actual.items()}}
 report['diagnostic_T_alias_audit']={
  'input_T_vs_source_T':smeta['input_state_vs_source']['T'],
  'input_THM_vs_source_THM':smeta['input_state_vs_source']['THM'],
  'fortran_call_t_vs_source_THM':stat_delta(ft_phys['t'],src['THM']),
  'cpp_call_t_vs_source_THM':stat_delta(cpp_phys['t'],src['THM']),
  'fortran_call_t_vs_diagnostic_T_not_a_state_gate':stat_delta(ft_phys['t'],src['T']),
  'cpp_call_t_vs_diagnostic_T_not_a_state_gate':stat_delta(cpp_phys['t'],src['T']),
  'binding_note':'Actual prognostic t is compared to source THM. NetCDF T is th_phy_m_t0 diagnostic and is never substituted for THM in the six-field state gate.'}
 # P is a startup-derived diagnostic input to PGF, not one of the six prognostic state fields.
 b=ft_pgf_meta['bounds_dict']; i0=b['ids']-b['ims']; j0=b['jds']-b['jms']; k0=b['kds']-b['kms']; py,nz,px=src['P'].shape
 ft_call_p=ftp['p'][j0:j0+py,k0:k0+nz,i0:i0+px]
 cpp_oper_meta,cpp_oper=CAP.read_cpp_operands(cpp_dir/'port_u_pgf_operands_snapshot.bin')
 cpp_call_p=cpp_oper['p_prime'][:py,:,:px]
 report['derived_pressure_context_not_state_gate']={
  'call_time_fortran_P_vs_source60_P':stat_delta(ft_call_p,src['P']),
  'call_time_cpp_Pprime_vs_source60_P':stat_delta(cpp_call_p,src['P']),
  'input_P_vs_source60_P':smeta['input_state_vs_source']['P'],
  'interpretation':'File P is copied from source as cold-input data, but start_em recomputes pressure before the first PGF call. Report call-time pressure separately; do not require call-time P to equal source P or use it in the six prognostic-state gate.'}
 ft_log=(ft_dir/'rsl.out.0000').read_text(errors='replace')
 ft_nml=(ft_dir/'namelist.output').read_text(errors='replace')
 pgf_log_at=ft_log.find('[PARITY PGF] wrote wrf_u_pgf_snapshot.bin')
 setw_log_at=ft_log.lower().find('call set_w_surface')
 report['startup_w_update']={'namelist_use_input_w_true':'USE_INPUT_W=T' in ft_nml,
  'run_receipt_use_input_w_true_all_cases':all(bool(r.get('use_input_w')) and bool(r.get('effective_use_input_w',{}).get('namelist_output_use_input_w_true')) for r in labels.values()),
  'actual_call_W_exact_source60':all_source_exact,
  'input_and_source_W_surface_max_abs':float(max(np.max(np.abs(inp['W'][:,0,:])),np.max(np.abs(src['W'][:,0,:])))),
  'input_and_source_W_full_column_nonzero':bool(np.any(inp['W'][:,1:,:] != 0.0) and np.any(src['W'][:,1:,:] != 0.0)),
  'later_solve_em_set_w_surface_logged':setw_log_at >= 0,
  'later_solve_em_set_w_surface_after_first_pgf_capture':pgf_log_at >= 0 and setw_log_at > pgf_log_at,
  'source_locations':'dyn_em/start_em.F:1495-1552 scans k=1:min(kte,kde) when use_input_w=true; dyn_em/solve_em.F:5297-5314 later calls set_w_surface with fill_w_flag=false after small-step work.',
  'interpretation':'The start_em full-column scan sees nonzero interior W despite the zero surface plane, so its missing-W fallback does not run and the first PGF-call W matches source60. The later logged solve_em call is after the first PGF capture and uses fill_w_flag=false, so it only reapplies the already-zero surface condition.',
  'full_rhs_gate_path':str(FULL_JSON),'full_rhs_gate_passed':bool(full_contract['state_gate']['passed']),
  'pgf_gate_path':str(PGF_JSON),'pgf_same_call_gate_passed':bool(case_gate['state_gates']['all_same_call_state_gates_pass'])}
 report['source_scope']={'source_frame_path':fixture['source_wrfout'],'source_file_sha256':fixture['source_sha256'],
  'source_timestamp':fixture['source_timestamp'],'source_time_index':fixture['source_time_index'],
  'corrected_input_path':fixture['output'],'corrected_input_sha256':fixture['output_sha256'],
  'call_state_records':{'fortran_full':receipt(ft_full_path),'cpp_full':receipt(cpp_full_path),
                        'fortran_pgf':receipt(ft_pgf_path),'cpp_pgf':receipt(cpp_pgf_path)},
  'run_receipt_path':str(RUNS),'run_receipt_sha256':sha(RUNS),'full_analysis_json':str(FULL_JSON),'pgf_gate_json':str(PGF_JSON)}
 report['status']='all_six_actual_call_fields_exact_to_source60' if all_source_exact else 'actual_call_state_differs_from_source60'
 report['comparison_performed']=True
 report['all_six_actual_call_fields_exact_to_source60']=all_source_exact
 np.savez_compressed(HERE/'preserve_w_state_comparison_arrays.npz',
  source_U=src['U'],source_V=src['V'],source_W=src['W'],source_PH=src['PH'],source_THM=src['THM'],source_MU=src['MU'],
  fortran_U=ft_phys['u'],fortran_V=ft_phys['v'],fortran_W=ft_phys['w'],fortran_PH=ft_phys['ph'],fortran_THM=ft_phys['t'],fortran_MU=ft_phys['mu'][:,0,:],
  cpp_U=cpp_phys['u'],cpp_V=cpp_phys['v'],cpp_W=cpp_phys['w'],cpp_PH=cpp_phys['ph'],cpp_THM=cpp_phys['t'],cpp_MU=cpp_phys['mu'][:,0,:],
  source_P=src['P'],input_P=inp['P'],fortran_call_P=ft_call_p,cpp_call_Pprime=cpp_call_p,source_T_diagnostic=src['T'])
 report['artifacts']={'comparison_arrays_npz':receipt(HERE/'preserve_w_state_comparison_arrays.npz'),
                      'analysis_script_sha256':sha(Path(__file__))}
 (HERE/'preserve_w_state_gate.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'status':report['status'],'output':str(HERE/'preserve_w_state_gate.json'),
  'state_exact':{mode:{key:val['call_vs_archived_source60'].get('exact') for key,val in fields.items()} for mode,fields in state_results.items()},
  'fortran_call_P_vs_source_P':report['derived_pressure_context_not_state_gate']['call_time_fortran_P_vs_source60_P']['exact'],
  'cpp_call_P_vs_source_P':report['derived_pressure_context_not_state_gate']['call_time_cpp_Pprime_vs_source60_P']['exact']},indent=2))
 return 0 if all_source_exact else 2

if __name__=='__main__': raise SystemExit(main())
