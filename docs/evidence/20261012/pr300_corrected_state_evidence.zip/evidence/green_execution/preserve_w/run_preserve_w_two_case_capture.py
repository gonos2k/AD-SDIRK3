#!/usr/bin/env python3
"""Run exactly two h=15 corrected-state calls with use_input_w enabled."""
from __future__ import annotations
import hashlib, importlib.util, json, os, re, shutil, struct, subprocess, sys, time
from pathlib import Path

ROOT=Path('/private/tmp/pr300-corrected-state-20261012')
HERE=Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012/green_execution/preserve_w')
E=Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012/green_execution')
P298=Path('/private/tmp/pr298-u-pgf-20261012')
INPUT=Path('/Users/yhlee/AD-SDIRK3-review-evidence/pressure-lineage-20261012/actual_t60_corrected_time0_wrfinput_d01_qvguard')
FIXTURE=Path('/Users/yhlee/AD-SDIRK3-review-evidence/pressure-lineage-20261012/actual_t60_corrected_fixture_final_receipt.json')
REBUILD=Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012/start_em_rebuild_receipt.json')
PREFLIGHT=HERE/'preserve_w_preflight.json'
EXE=ROOT/'main/wrf.exe';LIB=ROOT/'external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a';CONFIG=ROOT/'configure.wrf'
NML=Path('/Users/yhlee/Documents/AD-SDIRK3-worktree-archive/20261005/native_wave_refinement/wrf_runs/signfix_fp64_carry_on15_240/namelist.input')
DIAG=NML.parent/'diagnostics.txt'
EXPECTED_HEAD='303fd8e22dc6908a0493ca87b49b2b6b2b3e9456'
EXPECTED_INPUT_SHA='fc37c8c0c8be8053a16e0d3424609d496f4a023c6c17ee3a06371970639d14df'
EXPECTED_START_EM_SHA='f3cf233cb8223601629a5779625a421bdd92cad639d9f7f7eef2502fdc5d8fd6'
EXPECTED_EXE_SHA='5589c1a02f491bfc4e14c9e0f9bef32dea562e8e99bf59132bf22fa13b557338'
EXPECTED_LIB_SHA='21f7bc79a131f4608f506259b7c0434f2350749486774f14aea260cc69910565'
EXPECTED_CONFIG_SHA='8cdf647666634cdb8cc2624d5d627c6bdd79472b3ed99481831f2a3e27873289'
EXPECTED_NML_SHA='6258b997543f95b6cdde538aa37e14084f17862210e94c02dd23fb7fd91a8e06'
EXPECTED_DIAG_SHA='bc5c198d7f033fa8cd5d5b9bcbe2a46a2eae7d69ea8dd414d18f0cc5dc62b224'
RUNS=HERE/'preserve_w_runs.json';CAPROOT=HERE/'captures'/'preserve_w'
BASE_RUNNER=Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012/green_execution/run_corrected_two_case_capture.py')

def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()
def load_base():
 spec=importlib.util.spec_from_file_location('corrected_base_runner',BASE_RUNNER)
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def set_namelist_int(text,key,value):
 t,n=re.subn(r'(\b'+re.escape(key)+r'\s*=\s*)[-+0-9]+',lambda m:m.group(1)+str(value),text,count=1,flags=re.I)
 if n!=1:raise ValueError(f'missing namelist key {key}')
 return t

def set_use_input_w(text):
 matches=list(re.finditer(r'(?ims)^\s*&dynamics\b(.*?)(^\s*/)',text))
 if len(matches)!=1:raise ValueError(f'expected exactly one &dynamics group, found {len(matches)}')
 m=matches[0];body=m.group(1)
 rows=body.splitlines(keepends=True); found=0
 for idx,line in enumerate(rows):
  uncommented=line.split('!')[0]
  if re.match(r'^\s*use_input_w\s*=',uncommented,re.I):
   rows[idx]=re.sub(r'(\buse_input_w\s*=\s*)(\.true\.|\.false\.|true|false)',r'\1.true.',line,count=1,flags=re.I)
   found+=1
 if found>1:raise ValueError('duplicate use_input_w entries in &dynamics')
 if found==0: rows.append(' use_input_w = .true.,\n')
 newbody=''.join(rows)
 new=text[:m.start(1)]+newbody+text[m.end(1):]
 m2=list(re.finditer(r'(?ims)^\s*&dynamics\b(.*?)(^\s*/)',new))
 if len(m2)!=1 or len(re.findall(r'(?im)^\s*use_input_w\s*=\s*\.true\.',m2[0].group(1)))!=1:
  raise ValueError('failed to emit one true use_input_w within &dynamics')
 return new

def verify_build_and_sources(base):
 head=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()
 if head!=EXPECTED_HEAD:raise RuntimeError(f'target HEAD changed: {head}')
 rec=json.loads(REBUILD.read_text())
 if rec.get('source_head')!=head or rec.get('compile_return_code')!=0 or not rec.get('freshness_checks_passed'):
  raise RuntimeError('start_em rebuild receipt invalid for current source head')
 for rel,item in rec['files'].items():
  p=ROOT/rel
  if not p.is_file() or sha(p)!=item['sha256']:raise RuntimeError(f'rebuild receipt/file mismatch: {rel}')
 if rec['files']['dyn_em/start_em.F']['sha256']!=EXPECTED_START_EM_SHA:
  raise RuntimeError('start_em patch hash mismatch')
 if rec['files']['main/wrf.exe']['sha256']!=EXPECTED_EXE_SHA or rec['files']['external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a']['sha256']!=EXPECTED_LIB_SHA:
  raise RuntimeError('new executable/library hash mismatch')
 if rec['files']['configure.wrf']['sha256']!=EXPECTED_CONFIG_SHA or not rec.get('CPP_archive_unchanged') or not rec.get('module_em_interface_unchanged'):
  raise RuntimeError('ABI/config/C++ archive reuse gate failed')
 comp=json.loads(PREFLIGHT.read_text())
 if comp['target_head']!=head or comp['new_executable_sha256']!=EXPECTED_EXE_SHA:
  raise RuntimeError('preserve-W preflight does not match target/build')
 # Seven primary sources stay identical to the PR298 executable; startup sources
 # are pinned in preserve_w_preflight, with only the receipt-backed start_em.F edit.
 base_sources=base.source_hashes(ROOT)
 if base_sources!=base.EXPECTED_SOURCE_SHA256:raise RuntimeError('primary seven source pins changed')
 for rel,h in comp['authoritative_source_sha256'].items():
  if sha(ROOT/rel)!=h:raise RuntimeError(f'startup source changed: {rel}')
 if sha(INPUT)!=EXPECTED_INPUT_SHA or sha(INPUT)!=json.loads(FIXTURE.read_text())['output_sha256']:
  raise RuntimeError('corrected input fixture hash mismatch')
 if sha(NML)!=EXPECTED_NML_SHA or sha(DIAG)!=EXPECTED_DIAG_SHA:
  raise RuntimeError('source namelist/diagnostics checksum mismatch')
 if sha(EXE)!=EXPECTED_EXE_SHA or sha(LIB)!=EXPECTED_LIB_SHA or sha(CONFIG)!=EXPECTED_CONFIG_SHA:
  raise RuntimeError('post-rebuild executable/library/config hash mismatch')
 return {'target_head':head,'target_source_sha256':comp['authoritative_source_sha256'],
         'start_em_rebuild_receipt':str(REBUILD),'start_em_rebuild_receipt_sha256':sha(REBUILD),
         'start_em_rebuild_receipt_body':rec,'cpp_archive_sha256':sha(LIB),
         'executable_sha256':sha(EXE),'configure_sha256':sha(CONFIG),
         'baseline_corrected_run_receipt':str(E/'corrected_runs.json'),'baseline_corrected_run_receipt_sha256':sha(E/'corrected_runs.json'),
         'corrected_input_sha256':sha(INPUT),'fixture_receipt_sha256':sha(FIXTURE),
         'source_namelist_sha256':sha(NML),'diagnostics_sha256':sha(DIAG),
         'primary_seven_source_hashes':base_sources}

def namelist_config(folder):
 out=(folder/'namelist.output').read_text(errors='replace') if (folder/'namelist.output').is_file() else ''
 nml=(folder/'namelist.input').read_text()
 group=re.search(r'(?ims)^\s*&dynamics\b(.*?)(^\s*/)',nml)
 if not group or len(re.findall(r'(?im)^\s*use_input_w\s*=\s*\.true\.',group.group(1)))!=1:
  raise RuntimeError('staged namelist does not have use_input_w=.true. in &dynamics')
 runtime=bool(re.search(r'(?i)USE_INPUT_W\s*=\s*T\b',out))
 if not runtime:raise RuntimeError('runtime namelist.output does not report USE_INPUT_W=T')
 return {'namelist_input_has_use_input_w_true':True,'namelist_output_use_input_w_true':runtime}

def run_artifacts(base,corrected,folder,method):
 rec=base.artifact_receipt(folder,method)
 for n in ('wrf_u_hdiff_snapshot.bin','wrf_u_vdiff_before.bin','port_hdiff_u_snapshot.bin','port_vdiff_u_snapshot.bin'):
  if n in rec:rec[n]['schema']=corrected.h_v_schema(folder/n,method,n)
 return rec

def stage(label,method,plan):
 folder=CAPROOT/label
 if folder.exists():raise FileExistsError(f'refusing existing case directory: {folder}')
 folder.mkdir(parents=True);shutil.copy2(INPUT,folder/'wrfinput_d01');shutil.copy2(DIAG,folder/'diagnostics.txt')
 # Static tables were absent from both pinned worktrees; do not invent new ones.
 nml=NML.read_text()
 for key,value in (('time_step',15),('time_step_fract_num',0),('time_step_fract_den',1),('run_seconds',15),('rk_ord',3),
                   ('time_integration_scheme',0 if method=='RK3' else 6),('sdirk3_debug_level',2)):
  nml=set_namelist_int(nml,key,value)
 nml=set_use_input_w(nml);(folder/'namelist.input').write_text(nml)
 if sha(folder/'wrfinput_d01')!=EXPECTED_INPUT_SHA:raise RuntimeError('staged input SHA differs')
 row={'label':label,'method':method,'time_step_seconds':15,'run_seconds':15,'use_input_w':True,
      'input_sha256':sha(folder/'wrfinput_d01'),'namelist_sha256':sha(folder/'namelist.input'),'diagnostics_sha256':sha(folder/'diagnostics.txt'),
      'input_origin':str(INPUT),'executable_path':str(EXE),'executable_sha256':sha(EXE),
      'start_em_source_sha256':EXPECTED_START_EM_SHA,'rebuild_receipt_sha256':sha(REBUILD),'workdir':str(folder),'status':'staged'}
 plan['runs'].append(row)
 cmd=['/usr/bin/time','-l','-o',str(folder/'time.log'),'/opt/homebrew/bin/mpirun','-np','1','--bind-to','none',str(EXE)]
 return row,cmd

def main():
 import argparse
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--timeout',type=int,default=1200);args=ap.parse_args()
 corrected=load_base();base=corrected.load_base()
 if RUNS.exists() or CAPROOT.exists():raise FileExistsError('refusing to overwrite preserve-W plan/captures')
 for p in (INPUT,FIXTURE,REBUILD,EXE,LIB,CONFIG,NML,DIAG,PREFLIGHT,base.BUILD_COMPILE_LOG,base.BUILD_REUSE_RECEIPT):
  if not p.is_file():raise FileNotFoundError(p)
 build=verify_build_and_sources(base);source_before=base.source_hashes(ROOT)
 CAPROOT.mkdir(parents=True)
 plan={'schema':'pr300-corrected-state-preserve-w-two-case-v1','status':'running','target_root':str(ROOT),
  'target_head':EXPECTED_HEAD,'start_em_modified_authoritative_source_sha256':EXPECTED_START_EM_SHA,
  'primary_seven_source_sha256':source_before,'build_lineage':build,
  'historical_PR298_build_receipt_HEAD':'51527694a3cb139ae43c20532b138e4a65dd6153',
  'corrected_input_sha256':EXPECTED_INPUT_SHA,'run_policy':'exactly two additional h=15 s one-step calls; no rebuild or other native calls; WRF_PARITY_RK_TEND_DUMP=1; use_input_w=.true. in &dynamics',
  'step_seconds':15,'duration_seconds':15,'mpi_ranks':1,'omp_threads':1,'debug_level':2,
  'run_labels':['preserve_w_fortran_rk3_h15','preserve_w_cpp_ark3_h15'],'runs':[]}
 RUNS.write_text(json.dumps(plan,indent=2)+'\n')
 clean={k:v for k,v in os.environ.items() if not k.startswith(('WRF_SDIRK3_','WRF_PARITY_'))}
 clean.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
 try:
  for label,method in (('preserve_w_fortran_rk3_h15','RK3'),('preserve_w_cpp_ark3_h15','ARK3')):
   row,cmd=stage(label,method,plan);row['command']=cmd;row['status']='running';RUNS.write_text(json.dumps(plan,indent=2)+'\n')
   folder=Path(row['workdir']);runenv=dict(clean,WRF_PARITY_RK_TEND_DUMP='1');t0=time.monotonic()
   with (folder/'run.log').open('wb') as log:proc=subprocess.run(cmd,cwd=folder,env=runenv,stdout=log,stderr=subprocess.STDOUT,timeout=args.timeout,check=False)
   out=(folder/'rsl.out.0000').read_text(errors='replace') if (folder/'rsl.out.0000').is_file() else ''
   err=(folder/'rsl.error.0000').read_text(errors='replace') if (folder/'rsl.error.0000').is_file() else ''
   row.update({'return_code':proc.returncode,'wall_seconds':time.monotonic()-t0,
      'completion_marker':'SUCCESS COMPLETE' in (out+err),'effective_use_input_w':namelist_config(folder),
      'runtime_route':base.capture_runtime_config(folder,method),
      'artifacts':run_artifacts(base,corrected,folder,method),
      'time_log_sha256':sha(folder/'time.log') if (folder/'time.log').is_file() else None,
      'rsl_out_sha256':sha(folder/'rsl.out.0000') if (folder/'rsl.out.0000').is_file() else None,
      'rsl_error_sha256':sha(folder/'rsl.error.0000') if (folder/'rsl.error.0000').is_file() else None})
   row['status']='completed' if proc.returncode==0 and row['completion_marker'] else 'failed'
   RUNS.write_text(json.dumps(plan,indent=2)+'\n')
   if row['status']!='completed':raise RuntimeError(f'case failed: {label}')
   if sha(EXE)!=EXPECTED_EXE_SHA or sha(LIB)!=EXPECTED_LIB_SHA:raise RuntimeError('reused executable/archive changed during run')
  after=base.source_hashes(ROOT)
  if after!=source_before or sha(ROOT/'dyn_em/start_em.F')!=EXPECTED_START_EM_SHA:raise RuntimeError('authoritative source changed during capture')
  plan['source_sha256_after']=after;plan['status']='completed';plan['native_calls']=2
  plan['completion_note']='Exactly two additional opt-in preserve-input-W captures completed. Baseline corrected-state pair/receipts are preserved.'
  RUNS.write_text(json.dumps(plan,indent=2)+'\n')
  print(json.dumps({'status':'completed','plan':str(RUNS),'runs':[{'label':r['label'],'status':r['status'],'return_code':r['return_code'],'use_input_w':r['effective_use_input_w']} for r in plan['runs']]},sort_keys=True))
 except Exception as exc:
  plan['status']='failed';plan['failure']=f'{type(exc).__name__}: {exc}';plan['source_sha256_after']=base.source_hashes(ROOT);RUNS.write_text(json.dumps(plan,indent=2)+'\n');raise

if __name__=='__main__':main()
