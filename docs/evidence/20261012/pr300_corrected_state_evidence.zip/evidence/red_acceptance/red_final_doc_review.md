# PR300 Red final-document review

Local timestamp: 2026-10-12 15:22 JST (+0900)

Target: `/private/tmp/pr300-corrected-state-20261012/docs/(202610121520)_pr300_corrected_cold_state_rhs.md`. Read-only review against the run, call-state/source60, Full RHS, PGF, H/V and Red raw-parser receipts. No additional run, build or test.

**No blocking numerical or scope overclaim found.** The report correctly distinguishes: (a) the input's six state arrays are copied bitwise from the 60-second frame; (b) FT and C++ actual first-call states match bitwise; and (c) actual cold-call W is reset, so the full six-field source60 call-state gate fails. The `start_em` surface-W route, `set_w_surface` fill, zero-height explanation and run-log evidence are consistent with the source and receipts. The report does not call this a checkpoint or warm continuation.

The call/unit claims match the receipts. Full physical deltas are U/V/MU on their stated owner sets; isolated PGF is U-only in the reused C++ observer. The elementwise `R = DeltaFullU - DeltaHdiff - DeltaVdiff` and `R - DeltaPGF` accounting, residual norm, RMS change and squared-norm reduction are reported as diagnostics rather than forecast or production improvements. The source-state correction and pressure recomputation are kept separate from actual call-time pressure. Frozen V3 remains failed in 24 rows, the reference is unqualified, and no general accuracy threshold is adopted. The report also avoids claiming assembled W/PH/THM parity, complete FΔ parity, forecast quality or equal-accuracy runtime benefit.

One publication-status item remains in the current text: its final sentence says packaging and latest-head CI records “are linked below after final verification,” but the document currently ends there without those links. Before calling the document packaged/final, either append the verified package/CI receipts or remove that forward reference if those artifacts are out of scope. No other blocker identified.
