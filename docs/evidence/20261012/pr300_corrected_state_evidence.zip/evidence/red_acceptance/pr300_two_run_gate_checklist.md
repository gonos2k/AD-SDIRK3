# PR300 corrected-state two-run evidence gates

Local timestamp: 2026-10-12 14:54 JST (+0900)

Scope amendment: 2026-10-12 15:14 JST (+0900). The existing C++ observer provides isolated physical U-PGF only. V and MU are compared as Full-RHS components; no V-PGF component claim is required or supported by this reused executable.

## Frozen scope

This review is limited to the already-authorized pair of native runs: the
corrected cold input `fc37c8c0…39d14df`, Fortran RK3 and C++ SDIRK3 mode at
`h=15 s`, one step, reusing the existing executable/source stack. The task is
to close the corrected first-PGF call-state comparison and measure same-state
Full `U/V/MU` RHS plus physical PGF components. This is an operator/state
diagnostic, not a 240-second forecast or an acceptance-threshold decision.
Do not tune a pressure coefficient, alter the input, rebuild, or extend the
run.

## Required evidence gates

1. **Bind the fixture and execution.** Record the input SHA for each run and
   require both to equal `fc37c8c0…39d14df`; also bind the input producer
   `81a4215a…8a18ddf6f`, its source frame and source hash, run namelists,
   executable hash, source/build receipt, compiler/MPI stack, actual mode,
   timestep and stop time. Preserve the two outputs separately. Confirm the
   two runs differ only in the intended integrator selection.

2. **Prove the corrected six-field state.** On the correct staggered owner
   domains and `[k,j,i]`/`[j,k,i]` mapping, compare `U,V,W,PH,THM,MU` from the
   corrected input byte-for-byte with the unique 60-second RK3 source frame.
   The prognostic temperature is Registry `THM`/`t`; diagnostic `T` is a
   separate copied field and cannot stand in for it. At each first-PGF / Full
   RHS call, verify the six actual Fortran and C++ prognostic state arrays
   against each other and against the corrected input after the documented
   startup mapping. Require exact equality where the current initialization
   path copies the values; if a field is transformed, show the source mapping
   and report that difference explicitly rather than relabeling it equal.
   Also verify shared `PB,PHB,MUB`, moisture/thermodynamic context, geometry,
   effective flags, call identity, and boundary/owner masks.

3. **Compare Full `U/V/MU` consistently.** Use the existing same-state Full
   RHS and Fortran tendency observers at the same call, reporting one fixed
   physical unit per equation (`U,V`: acceleration; `MU`: pressure tendency)
   and the exact conversion from each raw record. Compare vector arrays on
   unique owned faces/cells; document periodic seams, vertical/horizontal
   staggering, halos and duplicated endpoints. Report pointwise difference,
   RMS, max-absolute and bias, plus the two source RMS scales and relative
   ratios where the denominator is nonzero. Preserve signed vectors and do
   not subtract RMS values or combine component norms as vectors.

4. **Compare the PGF components the reused executable actually captures.**
   The existing Fortran snapshot stores U/V tendency before/after the PGF
   call, but the C++ observer stores only U-PGF; its Full V-RHS record is not
   a V-PGF decomposition. Therefore compare the directly captured U-PGF
   component only: convert Fortran and C++ once to physical acceleration
   using recorded mass/map scaling; compare unique U owners with the
   periodic west face retained and duplicated closing face omitted; report
   the direct vector difference and matching Full-RHS contribution. Do not
   infer or claim C++ V-PGF from assembled Full V RHS. V remains covered by
   the Full-RHS gate above; an isolated V-PGF comparison requires a newly
   instrumented executable and is outside this two-run/reuse scope.

5. **Keep the conclusion bounded.** A complete artifact set can close that
   this two-run corrected cold input is a genuine common-state probe and
   provide quantitative same-state RHS/PGF comparisons. It does not, by
   itself, establish forecast accuracy, convergence, long-time stability,
   full six-equation parity, or superiority. The corrected input is not a
   warm restart or a continuous trajectory. The original mixed-time probe
   and its historical measurements remain preserved and must remain labeled
   as such.

## Explicit non-gates

No new numerical tolerance is introduced by this checklist. Report the
measured errors and scales without converting them into a pass target. Frozen
V3 reference qualification remains failed in all 24 rows; the reference is
unqualified, and no project-wide accuracy target is adopted. No forecast or
240-second result follows from these one-step runs. Do not use them to reopen
the rotating test or to tune pressure scaling.

No native run, build, test, repository-source edit, or model-framework action
was performed in preparing this checklist.
