#!/usr/bin/env python3
"""Portable, fail-closed verifier for an unpacked PR300 evidence bundle.

The verifier reads only paths named relative to --root in bundle_manifest.json.
It rechecks source60/input fields, actual Fortran/C++ call-state snapshots,
optional default-off physical masks and optional U residual-vector identities.
It does not run WRF, compile code, or write inside the bundle by default.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path, PurePosixPath
import struct
import sys
import zipfile
import zlib
from typing import Any

import numpy as np

MANIFEST_NAME = "bundle_manifest.json"
REQ_PATHS = (
    "corrected_input", "source60_wrfout", "corrected_runs", "preserve_w_runs",
    "corrected_state_gate", "preserve_w_state_gate", "corrected_full_rhs",
    "corrected_pgf_context", "default_off_runs", "default_off_acceptance",
    "corrected_residual_npz", "preserve_w_residual_npz",
)
REQ_RUN_DIRS = (
    "corrected_fortran_rk3_h15", "corrected_cpp_ark3_h15",
    "preserve_w_fortran_rk3_h15", "preserve_w_cpp_ark3_h15",
    "default_off_newexe_fortran_rk3_h15",
)
STATE_MAP = {"u": "U", "v": "V", "w": "W", "ph": "PH", "t": "THM", "mu": "MU"}
INPUT_FIELDS = ("U", "V", "W", "PH", "T", "THM", "MU", "P")
BASE_FIELDS = ("PB", "PHB", "MUB")
F3_FIELDS = {"u2", "v2", "w2", "ph2", "t2", "ru_tend", "rv_tend", "ru", "rv"}
F2_FIELDS = {"mu2", "mu_tend", "muu", "muv", "mut", "msfux", "msfuy", "msfvx", "msfvy", "msftx", "msfty"}


class VerifyError(RuntimeError):
    pass


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def _inside(root: Path, relative: str) -> Path:
    rel = PurePosixPath(relative)
    if rel.is_absolute() or not rel.parts or any(p in ("..", "") for p in rel.parts):
        raise VerifyError(f"manifest path must be relative and traversal-free: {relative!r}")
    candidate = root.joinpath(*rel.parts)
    try:
        candidate.resolve(strict=False).relative_to(root.resolve())
    except ValueError as exc:
        raise VerifyError(f"manifest path escapes unpacked root: {relative!r}") from exc
    return candidate


def _need_path(root: Path, manifest: dict[str, Any], key: str, required: bool = True) -> Path | None:
    rel = manifest.get("paths", {}).get(key)
    if rel is None:
        if required:
            raise VerifyError(f"bundle manifest missing paths.{key}")
        return None
    if not isinstance(rel, str):
        raise VerifyError(f"paths.{key} must be a relative path string")
    path = _inside(root, rel)
    if required and not path.is_file():
        raise VerifyError(f"bundle file missing for paths.{key}: {rel}")
    return path


def _need_run_dir(root: Path, manifest: dict[str, Any], key: str) -> Path:
    rel = manifest.get("run_dirs", {}).get(key)
    if not isinstance(rel, str):
        raise VerifyError(f"bundle manifest missing run_dirs.{key}")
    path = _inside(root, rel)
    if not path.is_dir():
        raise VerifyError(f"run directory missing for run_dirs.{key}: {rel}")
    return path


def _load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text())
    except Exception as exc:
        raise VerifyError(f"cannot parse JSON {path.name}: {exc}") from exc
    if not isinstance(data, dict):
        raise VerifyError(f"expected JSON object: {path.name}")
    return data


def verify_manifest_files(root: Path, manifest: dict[str, Any]) -> dict[str, Any]:
    files = manifest.get("files", manifest.get("manifest_files", []))
    if not isinstance(files, list):
        raise VerifyError("manifest files must be a list")
    checked = []
    for item in files:
        if not isinstance(item, dict) or not isinstance(item.get("path"), str):
            raise VerifyError("each manifest file entry needs a relative path")
        path = _inside(root, item["path"])
        if not path.is_file():
            raise VerifyError(f"manifest-listed file missing: {item['path']}")
        size = path.stat().st_size
        digest = sha256_file(path)
        if item.get("bytes") is not None and int(item["bytes"]) != size:
            raise VerifyError(f"byte-count mismatch for {item['path']}: {size} != {item['bytes']}")
        expected_sha = item.get("sha256")
        if expected_sha and digest.lower() != str(expected_sha).lower():
            raise VerifyError(f"SHA-256 mismatch for {item['path']}")
        expected_crc = item.get("crc32")
        crc = zlib.crc32(path.read_bytes()) & 0xFFFFFFFF
        if expected_crc is not None:
            exp = int(str(expected_crc), 16) if isinstance(expected_crc, str) and str(expected_crc).lower().startswith("0x") else int(expected_crc, 0) if isinstance(expected_crc, str) else int(expected_crc)
            if crc != exp:
                raise VerifyError(f"CRC32 mismatch for {item['path']}: {crc:#010x} != {exp:#010x}")
        checked.append({"path": item["path"], "bytes": size, "sha256": digest, "crc32": f"{crc:08x}"})
    return {"count": len(checked), "files": checked}


def verify_archive(archive_path: Path | None, expected_sha: str | None = None) -> dict[str, Any] | None:
    if archive_path is None:
        return None
    if not archive_path.is_file():
        raise VerifyError(f"archive not found: {archive_path}")
    digest = sha256_file(archive_path)
    if expected_sha and digest.lower() != expected_sha.lower():
        raise VerifyError("archive SHA-256 mismatch")
    try:
        with zipfile.ZipFile(archive_path) as archive:
            bad = archive.testzip()
            if bad is not None:
                raise VerifyError(f"ZIP CRC failure in member {bad}")
            members = [{"path": x.filename, "crc32": f"{x.CRC:08x}", "bytes": x.file_size} for x in archive.infolist()]
    except zipfile.BadZipFile as exc:
        raise VerifyError(f"invalid ZIP archive: {exc}") from exc
    return {"path": str(archive_path), "sha256": digest, "crc_checked": True, "members": len(members)}


def _load_parser_modules(root: Path, manifest: dict[str, Any]):
    dep_root = _inside(root, manifest.get("dependencies_dir", "dependencies"))
    if not dep_root.is_dir():
        raise VerifyError("portable dependency directory missing")
    full_rel = manifest.get("full_parser", "dependencies/analyze_snapshots.py")
    pgf_rel = manifest.get("pgf_parser", "dependencies/analyze_pgf_capture_context.py")
    full_path = _inside(root, full_rel)
    pgf_path = _inside(root, pgf_rel)
    if not full_path.is_file() or not pgf_path.is_file():
        raise VerifyError("required bundled snapshot parsers are missing")
    sys.path.insert(0, str(dep_root))
    import analyze_snapshots as full_parser  # type: ignore
    import analyze_pgf_capture_context as pgf_parser  # type: ignore
    if Path(full_parser.__file__).resolve() != full_path.resolve() or Path(pgf_parser.__file__).resolve() != pgf_path.resolve():
        raise VerifyError("imported snapshot parser did not resolve from this bundle")
    return full_parser, pgf_parser, {"full_parser": full_rel, "pgf_parser": pgf_rel,
                                     "full_parser_sha256": sha256_file(full_path),
                                     "pgf_parser_sha256": sha256_file(pgf_path)}


def _read_times(dataset) -> list[str]:
    if "Times" not in dataset.variables:
        raise VerifyError("NetCDF file missing Times")
    return [b"".join(row.tolist()).decode("ascii").rstrip("\x00 ") for row in dataset.variables["Times"][:]]


def _read_source_record(dataset, name: str, time_index: int) -> np.ndarray:
    if name not in dataset.variables:
        raise VerifyError(f"NetCDF missing required variable {name}")
    value = np.asarray(dataset.variables[name][time_index])
    if value.ndim == 3:
        value = value.transpose(1, 0, 2)  # NetCDF [k,j,i] -> captured [j,k,i]
    return np.asarray(value)


def _metric(actual: np.ndarray, expected: np.ndarray) -> dict[str, Any]:
    a, b = np.asarray(actual), np.asarray(expected)
    if a.shape != b.shape:
        return {"shape_equal": False, "actual_shape": list(a.shape), "expected_shape": list(b.shape), "exact": False}
    if not np.isfinite(a).all() or not np.isfinite(b).all():
        return {"shape_equal": True, "finite": False, "exact": False, "count": int(a.size)}
    d = a.astype(np.float64) - b.astype(np.float64)
    return {"shape_equal": True, "finite": True, "exact": bool(np.array_equal(a, b)),
            "count": int(a.size), "mismatch_count": int(np.count_nonzero(a != b)),
            "rms_delta": float(np.sqrt(np.mean(d * d))) if d.size else 0.0,
            "max_abs_delta": float(np.max(np.abs(d))) if d.size else 0.0}


def _file_sha(path: Path) -> str:
    return sha256_file(path)


def _check_run_receipt(receipt: dict[str, Any], expected_labels: tuple[str, str], input_sha: str, label: str) -> dict[str, Any]:
    if receipt.get("status") != "completed":
        raise VerifyError(f"{label} receipt is not completed")
    runs = receipt.get("runs")
    if not isinstance(runs, list) or len(runs) != 2:
        raise VerifyError(f"{label} receipt must contain exactly two runs")
    by_label = {r.get("label"): r for r in runs if isinstance(r, dict)}
    if set(by_label) != set(expected_labels):
        raise VerifyError(f"{label} run labels mismatch: {sorted(by_label)}")
    result = {}
    for key, method in zip(expected_labels, ("RK3", "ARK3")):
        run = by_label[key]
        if run.get("status") != "completed" or int(run.get("return_code", -1)) != 0:
            raise VerifyError(f"{label} run failed: {key}")
        if run.get("input_sha256") != input_sha:
            raise VerifyError(f"{label} run input differs from bundled corrected input: {key}")
        if run.get("method") != method:
            raise VerifyError(f"{label} method mismatch for {key}")
        if int(run.get("time_step_seconds", -1)) != 15 or int(run.get("run_seconds", -1)) != 15:
            raise VerifyError(f"{label} step/window mismatch for {key}")
        if int(run.get("mpi_ranks", 1)) != 1 or int(run.get("omp_threads", 1)) != 1:
            raise VerifyError(f"{label} rank/thread mismatch for {key}")
        if not run.get("executable_sha256"):
            raise VerifyError(f"{label} missing executable hash for {key}")
        result[key] = {k: run.get(k) for k in ("method", "status", "return_code", "input_sha256", "executable_sha256", "wall_seconds")}
    if by_label[expected_labels[0]]["executable_sha256"] != by_label[expected_labels[1]]["executable_sha256"]:
        raise VerifyError(f"{label} Fortran/C++ runs used different executables")
    return result


def _physical_source_state(source_vars: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
    return {"u": source_vars["U"], "v": source_vars["V"], "w": source_vars["W"],
            "ph": source_vars["PH"], "t": source_vars["THM"], "mu": source_vars["MU"]}


def _extract_actual_call_state(full_parser, pgf_parser, run_dir: Path, cpp: bool):
    full_path = run_dir / ("port_full_rhs_snapshot.bin" if cpp else "wrf_full_rhs_snapshot.bin")
    pgf_path = run_dir / ("port_u_pgf_snapshot.bin" if cpp else "wrf_u_pgf_snapshot.bin")
    if not full_path.is_file() or not pgf_path.is_file():
        raise VerifyError(f"call/full snapshot missing in {run_dir.name}")
    if cpp:
        full_meta, full_state, _ = full_parser.read_cpp(full_path)
        pgf_meta, pgf_state, _ = pgf_parser.read_cpp_pgf(pgf_path)
        dims = tuple(pgf_meta["dimensions"])
        if tuple(full_meta["dims_nx_ny_nz_nxu_nyv_nzw"]) != dims:
            raise VerifyError(f"C++ Full/PGF dimensions differ in {run_dir.name}")
    else:
        full_meta, full_fields = full_parser.read_fortran(full_path)
        pgf_meta, pgf_fields = pgf_parser.read_ft_pgf(pgf_path)
        dims = None
        # Fortran full-RHS headers contain physical+storage bounds; C++ sizes are known from the paired capture.
        raise RuntimeError("internal: Fortran dimensions must be supplied from the paired C++ capture")
    return full_meta, pgf_meta, full_state, pgf_state, dims


def _extract_ft_state(full_parser, pgf_parser, run_dir: Path, dims: tuple[int, ...]):
    full_meta, full_fields = full_parser.read_fortran(run_dir / "wrf_full_rhs_snapshot.bin")
    pgf_meta, pgf_fields = pgf_parser.read_ft_pgf(run_dir / "wrf_u_pgf_snapshot.bin")
    ft_full_state = full_parser.logical_fortran_state(full_meta, full_fields, dims)
    ft_pgf_state = full_parser.logical_fortran_state(
        {"bounds": pgf_meta["bounds_dict"]},
        {"u2": pgf_fields["u"], "v2": pgf_fields["v"], "w2": pgf_fields["w"],
         "ph2": pgf_fields["ph"], "t2": pgf_fields["t"], "mu2": pgf_fields["mu"]}, dims)
    return full_meta, pgf_meta, ft_full_state, ft_pgf_state


def _state_contract(full_parser, pgf_parser, ft_dir: Path, cpp_dir: Path) -> dict[str, Any]:
    cpp_full_meta, cpp_full, _ = full_parser.read_cpp(cpp_dir / "port_full_rhs_snapshot.bin")
    cpp_pgf_meta, cpp_pgf, _ = pgf_parser.read_cpp_pgf(cpp_dir / "port_u_pgf_snapshot.bin")
    dims = tuple(cpp_pgf_meta["dimensions"])
    ft_full_meta, ft_pgf_meta, ft_full, ft_pgf = _extract_ft_state(full_parser, pgf_parser, ft_dir, dims)
    if tuple(cpp_full_meta["dims_nx_ny_nz_nxu_nyv_nzw"]) != dims:
        raise VerifyError("CPP Full and PGF dimensions disagree")
    call_full = {"ft_pgf_vs_full": full_parser.state_audit(ft_pgf, ft_full),
                 "cpp_pgf_vs_full": full_parser.state_audit(cpp_pgf, cpp_full),
                 "ft_vs_cpp_full_storage": full_parser.state_audit(ft_full, cpp_full),
                 "ft_vs_cpp_pgf_full_storage": full_parser.state_audit(ft_pgf, cpp_pgf)}
    ft_phys = full_parser.physical_state(ft_pgf, dims)
    cpp_phys = full_parser.physical_state(cpp_pgf, dims)
    state_pair = full_parser.state_audit(ft_phys, cpp_phys)
    seam = full_parser.periodic_u_seam_audit(ft_pgf, cpp_pgf, dims)
    passed = (all(v["equal"] for gate in call_full.values() for v in gate.values()) and
              all(v["equal"] for v in state_pair.values()) and
              all(seam[k] for k in ("fortran_first_equals_closing_face", "cpp_first_equals_closing_face", "fortran_cpp_closing_face_equal")))
    if not passed:
        raise VerifyError("actual FT/CPP PGF-to-Full six-state gate failed")
    return {"passed": passed, "dims": list(dims), "state_gates": call_full,
            "physical_ft_cpp_state": state_pair, "periodic_u_seam": seam,
            "ft_meta": ft_pgf_meta, "cpp_meta": cpp_pgf_meta, "ft_full_meta": ft_full_meta,
            "state_physical": {"fortran": ft_phys, "cpp": cpp_phys}, "ft_full_state": ft_full}


def _input_and_source_gate(input_path: Path, source_path: Path, timestamp: str):
    try:
        from netCDF4 import Dataset
    except Exception as exc:
        raise VerifyError(f"netCDF4 required for raw source-state checks: {exc}") from exc
    with Dataset(source_path) as source, Dataset(input_path) as inp:
        src_times, inp_times = _read_times(source), _read_times(inp)
        if src_times.count(timestamp) != 1:
            raise VerifyError(f"source timestamp must occur once; got {src_times.count(timestamp)}")
        source_i = src_times.index(timestamp)
        expected_zero = str(inp_times[0])
        if len(inp_times) != 1 or expected_zero != "0001-01-01_00:00:00":
            raise VerifyError(f"corrected input is not one time-zero record: {inp_times}")
        src = {name: _read_source_record(source, name, source_i) for name in INPUT_FIELDS}
        copied = {name: _read_source_record(inp, name, 0) for name in INPUT_FIELDS}
        copied_gate = {name: _metric(copied[name], src[name]) for name in INPUT_FIELDS}
        if not all(v["exact"] for v in copied_gate.values()):
            raise VerifyError("corrected input does not contain all eight source60 state/data fields")
        base_gate = {}
        for name in BASE_FIELDS + ("QVAPOR",):
            if name in source.variables and name in inp.variables:
                a = _read_source_record(inp, name, 0)
                b = _read_source_record(source, name, source_i)
                base_gate[name] = _metric(a, b)
                if not base_gate[name]["exact"]:
                    raise VerifyError(f"input/base thermodynamic context differs from source60: {name}")
            elif name in BASE_FIELDS:
                raise VerifyError(f"missing base field {name} in source or corrected input")
        return {"source_times": src_times, "source_timestamp": timestamp, "source_time_index": source_i,
                "input_times": inp_times, "copied_input_fields": copied_gate,
                "shared_base_context": base_gate, "source_state": _physical_source_state(src),
                "source_record": src, "input_record": copied}


def _call_vs_source(actual: dict[str, np.ndarray], source_state: dict[str, np.ndarray], mode: str) -> dict[str, Any]:
    results = {}
    for field in STATE_MAP:
        actual_array = actual[field]
        # The full-state parser keeps mass as [j,1,i] to align with the
        # staggered tensor bundle; NetCDF MU is the equivalent [j,i] field.
        if field == "mu" and actual_array.ndim == 3 and actual_array.shape[1] == 1:
            actual_array = actual_array[:, 0, :]
        results[field] = _metric(actual_array, source_state[field])
    all_exact = all(m.get("exact", False) for m in results.values())
    return {"mode": mode, "fields": results, "all_six_exact": all_exact}


def _check_gate_receipt(path: Path | None, preserve_w: bool, actual_gate: dict[str, Any]) -> dict[str, Any] | None:
    if path is None:
        return None
    doc = _load_json(path)
    if preserve_w:
        if doc.get("schema") != "pr300-actual-prognostic-state-vs-source60-preserve-w-v1":
            raise VerifyError("unexpected preserve-W state-gate schema")
        if not doc.get("all_six_actual_call_fields_exact_to_source60"):
            raise VerifyError("preserve-W state-gate receipt does not report all six exact")
        if not actual_gate["all_six_exact"]:
            raise VerifyError("preserve-W state-gate claim disagrees with raw capture comparison")
    else:
        if not doc.get("same_call_state_gates", {}).get("passed"):
            raise VerifyError("corrected cold-state gate reports same-call gate failure")
        reported = doc.get("actual_prognostic_state_vs_source60", {})
        if not reported:
            raise VerifyError("corrected state-gate receipt lacks source60 field results")
    return {"schema": doc.get("schema"), "reported_status": doc.get("status"),
            "raw_gate_all_six_exact": actual_gate["all_six_exact"]}


def _full_p(raw_meta: dict[str, Any], raw_fields: dict[str, np.ndarray], cpp_operands: dict[str, np.ndarray], source: dict[str, np.ndarray]):
    b = raw_meta["bounds_dict"]
    i0, j0, k0 = 1 - b["ims"], 1 - b["jms"], 1 - b["kms"]
    ny, nz, nx = source["P"].shape
    ft_p = raw_fields["p"][j0:j0+ny, k0:k0+nz, i0:i0+nx]
    cpp_p = cpp_operands["p_prime"][:ny, :nz, :nx]
    return {"fortran_call_P_vs_source60_P": _metric(ft_p, source["P"]),
            "cpp_call_Pprime_vs_source60_P": _metric(cpp_p, source["P"])}


def _verify_residual_npz(path: Path | None) -> dict[str, Any] | None:
    if path is None:
        return None
    try:
        z = np.load(path, allow_pickle=False)
    except Exception as exc:
        raise VerifyError(f"cannot load residual NPZ {path.name}: {exc}") from exc
    required = ("delta_full_u_cpp_minus_ft_owner_m_s2", "delta_hdiff_u_cpp_minus_ft_owner_m_s2",
                "delta_vdiff_u_cpp_minus_ft_owner_m_s2", "remainder_full_minus_hdiff_minus_vdiff_m_s2",
                "delta_pgf_u_cpp_minus_ft_owner_m_s2", "remainder_after_pgf_m_s2", "owner_mask_u_unique_periodic_x")
    if any(k not in z.files for k in required):
        raise VerifyError(f"residual NPZ missing required vector arrays: {path.name}")
    a = {k: np.asarray(z[k]) for k in required}
    mask = a["owner_mask_u_unique_periodic_x"]
    if mask.dtype != np.bool_ or not mask.all():
        raise VerifyError(f"residual owner mask is not all unique-owner points: {path.name}")
    full = a["delta_full_u_cpp_minus_ft_owner_m_s2"]
    hd = a["delta_hdiff_u_cpp_minus_ft_owner_m_s2"]
    vd = a["delta_vdiff_u_cpp_minus_ft_owner_m_s2"]
    rem = a["remainder_full_minus_hdiff_minus_vdiff_m_s2"]
    pgf = a["delta_pgf_u_cpp_minus_ft_owner_m_s2"]
    post = a["remainder_after_pgf_m_s2"]
    if len({x.shape for x in (full, hd, vd, rem, pgf, post, mask)}) != 1:
        raise VerifyError(f"residual vector shapes differ: {path.name}")
    r_identity = rem - (full - hd - vd)
    p_identity = post - (rem - pgf)
    if not all(np.isfinite(x).all() for x in (full, hd, vd, rem, pgf, post)):
        raise VerifyError(f"nonfinite residual vector: {path.name}")
    if np.any(r_identity != 0) or np.any(p_identity != 0):
        raise VerifyError(f"residual vector identities do not close exactly: {path.name}")
    return {"path": str(path), "sha256": sha256_file(path), "shape": list(rem.shape),
            "owner_count": int(np.count_nonzero(mask)), "full_hv_identity_max_abs": float(np.max(np.abs(r_identity))),
            "after_pgf_identity_max_abs": float(np.max(np.abs(p_identity))),
            "remainder_before_pgf_rms": float(np.sqrt(np.mean(rem * rem))),
            "remainder_after_pgf_rms": float(np.sqrt(np.mean(post * post)))}


def _verify_default_off(full_parser, baseline_dir: Path, changed_dir: Path,
                        pgf_baseline: Path | None = None) -> dict[str, Any]:
    baseline_meta, baseline = full_parser.read_fortran(baseline_dir / "wrf_full_rhs_snapshot.bin")
    changed_meta, changed = full_parser.read_fortran(changed_dir / "wrf_full_rhs_snapshot.bin")
    if baseline_meta["bounds"] != changed_meta["bounds"]:
        raise VerifyError("default-off baseline/new bounds differ")
    b = baseline_meta["bounds"]; ids, ide, jds, jde, kds, kde = (b[x] for x in ("ids", "ide", "jds", "jde", "kds", "kde"))
    ims, jms, kms = b["ims"], b["jms"], b["kms"]
    i0, j0, k0 = ids - ims, jds - jms, kds - kms
    nx, ny, nz = ide - ids, jde - jds, kde - kds
    regions: dict[str, tuple[slice, ...]] = {}
    for name in F3_FIELDS:
        if name in ("u2", "ru_tend", "ru"):
            regions[name] = (slice(j0,j0+ny), slice(k0,k0+nz), slice(i0,i0+nx+1))
        elif name in ("v2", "rv_tend", "rv"):
            regions[name] = (slice(j0,j0+ny+1), slice(k0,k0+nz), slice(i0,i0+nx))
        elif name in ("w2", "ph2"):
            regions[name] = (slice(j0,j0+ny), slice(k0,k0+nz+1), slice(i0,i0+nx))
        else:
            regions[name] = (slice(j0,j0+ny), slice(k0,k0+nz), slice(i0,i0+nx))
    for name in F2_FIELDS:
        if name in ("muu", "msfux", "msfuy"):
            regions[name] = (slice(j0,j0+ny), slice(i0,i0+nx+1))
        elif name in ("muv", "msfvx", "msfvy"):
            regions[name] = (slice(j0,j0+ny+1), slice(i0,i0+nx))
        else:
            regions[name] = (slice(j0,j0+ny), slice(i0,i0+nx))
    regions["dnw"] = (slice(k0,k0+nz),); regions["c1h"] = (slice(k0,k0+nz),); regions["c2h"] = (slice(k0,k0+nz),)
    physical = {}
    for name in (*F3_FIELDS, *F2_FIELDS, "dnw", "c1h", "c2h"):
        a, z = baseline[name][regions[name]], changed[name][regions[name]]
        physical[name] = {"exact": bool(np.array_equal(a, z)), "count": int(a.size),
                          "mismatch_count": int(np.count_nonzero(a != z))}
    if not all(x["exact"] for x in physical.values()):
        raise VerifyError("default-off physical field parity failed")
    mu0, mu1 = baseline["mu_tend"], changed["mu_tend"]
    p_mask = np.zeros(mu0.shape, dtype=bool); p_mask[j0:j0+ny, i0:i0+nx] = True
    if not np.array_equal(mu0[p_mask], mu1[p_mask]):
        raise VerifyError("default-off physical mu_tend parity failed")
    ghost_diff_count = int(np.count_nonzero((mu0 != mu1) & ~p_mask))
    observer_equal = {}
    for name in ("wrf_u_pgf_snapshot.bin", "wrf_u_hdiff_snapshot.bin", "wrf_u_vdiff_before.bin"):
        a, z = baseline_dir / name, changed_dir / name
        if not a.is_file() or not z.is_file():
            raise VerifyError(f"default-off observer missing: {name}")
        observer_equal[name] = {"equal_bytes": a.read_bytes() == z.read_bytes(), "baseline_sha256": sha256_file(a), "candidate_sha256": sha256_file(z)}
        if not observer_equal[name]["equal_bytes"]:
            raise VerifyError(f"default-off observer differs: {name}")
    strict_equal = (baseline_dir / "wrf_full_rhs_snapshot.bin").read_bytes() == (changed_dir / "wrf_full_rhs_snapshot.bin").read_bytes()
    return {"physical_fields_all_exact": True, "physical_field_gates": physical,
            "mu_tend_changed_off_owner_count": ghost_diff_count, "strict_full_snapshot_byte_equal": strict_equal,
            "observer_byte_gates": observer_equal,
            "scope_note": "Physical owner parity is checked from raw snapshots; strict whole-storage byte parity is reported separately."}


def verify(root: Path, manifest_path: Path, manifest_sha_expected: str | None = None,
           archive_path: Path | None = None, archive_sha_expected: str | None = None) -> dict[str, Any]:
    root = root.resolve(strict=True)
    if not root.is_dir():
        raise VerifyError("--root must be an unpacked bundle directory")
    manifest_path = manifest_path if manifest_path.is_absolute() else root / manifest_path
    manifest_path = manifest_path.resolve(strict=True)
    if manifest_path.parent.resolve() != root and root not in manifest_path.parents:
        raise VerifyError("manifest path is outside unpacked root")
    manifest_sha = sha256_file(manifest_path)
    if manifest_sha_expected and manifest_sha.lower() != manifest_sha_expected.lower():
        raise VerifyError("bundle manifest SHA-256 mismatch")
    manifest = _load_json(manifest_path)
    if manifest.get("schema") != "pr300-portable-bundle-v1":
        raise VerifyError(f"unsupported bundle manifest schema: {manifest.get('schema')}")
    manifest_checks = verify_manifest_files(root, manifest)
    archive_result = verify_archive(archive_path, archive_sha_expected)
    full_parser, pgf_parser, parser_receipts = _load_parser_modules(root, manifest)

    paths = {key: _need_path(root, manifest, key, required=key in REQ_PATHS) for key in REQ_PATHS}
    input_sha = sha256_file(paths["corrected_input"])
    source_sha = sha256_file(paths["source60_wrfout"])
    corrected_doc = _load_json(paths["corrected_runs"])
    preserve_doc = _load_json(paths["preserve_w_runs"])
    expected_input_sha = corrected_doc.get("corrected_input_sha256")
    if expected_input_sha != input_sha or preserve_doc.get("corrected_input_sha256") != input_sha:
        raise VerifyError("run receipts do not bind to the bundled corrected input")
    if corrected_doc.get("native_calls") != 2 or preserve_doc.get("native_calls") != 2:
        raise VerifyError("native run receipts must each state exactly two calls")
    corrected_run_labels = tuple(manifest.get("run_labels", {}).get("corrected", ["corrected_fortran_rk3_h15", "corrected_cpp_ark3_h15"]))
    preserve_labels = tuple(manifest.get("run_labels", {}).get("preserve_w", ["preserve_w_fortran_rk3_h15", "preserve_w_cpp_ark3_h15"]))
    corrected_runs = _check_run_receipt(corrected_doc, corrected_run_labels, input_sha, "corrected")
    preserve_runs = _check_run_receipt(preserve_doc, preserve_labels, input_sha, "preserve-W")
    run_dirs = {key: _need_run_dir(root, manifest, key) for key in REQ_RUN_DIRS}
    for key, folder in run_dirs.items():
        file = folder / "wrfinput_d01"
        if not file.is_file() or sha256_file(file) != input_sha:
            raise VerifyError(f"raw capture input is missing/different for {key}")

    timestamp = str(manifest.get("source_timestamp", "0001-01-01_00:01:00"))
    try:
        from netCDF4 import Dataset
    except Exception as exc:
        raise VerifyError(f"netCDF4 required for raw state verification: {exc}") from exc
    with Dataset(paths["source60_wrfout"]) as source_ds:
        source_times = _read_times(source_ds)
        if source_times.count(timestamp) != 1:
            raise VerifyError("source60 timestamp is missing or not unique")
        source_i = source_times.index(timestamp)
        source_record = {name: _read_source_record(source_ds, name, source_i) for name in INPUT_FIELDS}
        source_context = {name: _read_source_record(source_ds, name, source_i) for name in BASE_FIELDS + ("QVAPOR",) if name in source_ds.variables}
    with Dataset(paths["corrected_input"]) as input_ds:
        input_times = _read_times(input_ds)
        if input_times != [str(manifest.get("input_timestamp", "0001-01-01_00:00:00"))]:
            raise VerifyError("corrected input is not the expected single cold time-zero record")
        input_record = {name: _read_source_record(input_ds, name, 0) for name in INPUT_FIELDS}
        input_context = {name: _read_source_record(input_ds, name, 0) for name in source_context if name in input_ds.variables}
    input_gate = {name: _metric(input_record[name], source_record[name]) for name in INPUT_FIELDS}
    if not all(x.get("exact") for x in input_gate.values()):
        raise VerifyError("corrected input does not copy all eight source60 field arrays exactly")
    context_gate = {name: _metric(input_context[name], source_context[name]) for name in source_context}
    if not all(x.get("exact") for x in context_gate.values()):
        raise VerifyError("corrected input base/thermodynamic context differs from source60")

    source_state = _physical_source_state({**source_record, **source_context})
    corrected_sources = {}
    preserve_sources = {}
    raw_p = {}
    for label, ft_dir, cpp_dir, dest, is_preserve in (
        ("corrected", run_dirs["corrected_fortran_rk3_h15"], run_dirs["corrected_cpp_ark3_h15"], corrected_sources, False),
        ("preserve_w", run_dirs["preserve_w_fortran_rk3_h15"], run_dirs["preserve_w_cpp_ark3_h15"], preserve_sources, True),
    ):
        gate = _state_contract(full_parser, pgf_parser, ft_dir, cpp_dir)
        for mode in ("fortran", "cpp"):
            actual = gate["state_physical"][mode]
            dest[(label, mode)] = _call_vs_source(actual, source_state, mode)
        if is_preserve:
            if not all(v["all_six_exact"] for v in (dest[(label, "fortran")], dest[(label, "cpp")])):
                raise VerifyError("preserve-W raw actual call states do not match all six source60 fields")
        else:
            # Cold default path intentionally reconstructs W at startup; all other actual state must remain from source60.
            for mode in ("fortran", "cpp"):
                fields = dest[(label, mode)]["fields"]
                nonw = ("u", "v", "ph", "t", "mu")
                if not all(fields[k].get("exact") for k in nonw):
                    raise VerifyError("corrected cold raw call differs from source60 outside the documented W initializer")
                if not np.all(gate["state_physical"][mode]["w"] == 0):
                    raise VerifyError("corrected cold W did not match the documented zero startup profile")
        # Call-time P is a diagnostic pressure context, not a prognostic-state gate.
        ft_meta, ft_fields = pgf_parser.read_ft_pgf(ft_dir / "wrf_u_pgf_snapshot.bin")
        cpp_meta, cpp_state, cpp_outputs = pgf_parser.read_cpp_pgf(cpp_dir / "port_u_pgf_snapshot.bin")
        oper_meta, cpp_operands = pgf_parser.read_cpp_operands(cpp_dir / "port_u_pgf_operands_snapshot.bin")
        raw_p[label] = _full_p(ft_meta, ft_fields, cpp_operands, source_record)
        raw_p[label]["fortran_call_P_sha256"] = hashlib.sha256(np.ascontiguousarray(ft_fields["p"]).tobytes()).hexdigest()
        raw_p[label]["cpp_pgf_meta"] = {"version": cpp_meta["version"], "dimensions": cpp_meta["dimensions"], "native_nonhydrostatic": cpp_meta["native_nonhydrostatic"]}
        raw_p[label]["operand_schema"] = oper_meta

    corrected_state_doc = _load_json(paths["corrected_state_gate"])
    preserve_state_doc = _load_json(paths["preserve_w_state_gate"])
    if corrected_state_doc.get("same_call_state_gates", {}).get("passed") is not True:
        raise VerifyError("corrected raw-call context receipt gate failed")
    if preserve_state_doc.get("schema") != "pr300-actual-prognostic-state-vs-source60-preserve-w-v1":
        raise VerifyError("preserve-W state-gate receipt schema mismatch")
    if preserve_state_doc.get("all_six_actual_call_fields_exact_to_source60") is not True:
        raise VerifyError("preserve-W state-gate receipt disagrees with its expected contract")

    full_analysis = _load_json(paths["corrected_full_rhs"])
    if full_analysis.get("comparison_available") is not True or full_analysis.get("state_exact_match") is not True:
        raise VerifyError("corrected Full RHS raw-state comparison is not available/passing")

    default_off = None
    if paths.get("default_off_runs") is not None and paths.get("default_off_acceptance") is not None:
        default_off_doc = _load_json(paths["default_off_runs"])
        acceptance = _load_json(paths["default_off_acceptance"])
        if acceptance.get("default_off_physical_owner_regression") != "PASS":
            raise VerifyError("default-off acceptance record lacks physical-owner PASS")
        default_off = _verify_default_off(full_parser, run_dirs["corrected_fortran_rk3_h15"], run_dirs["default_off_newexe_fortran_rk3_h15"])
        if default_off_doc.get("input_sha256") != input_sha:
            raise VerifyError("default-off run input does not match corrected input")
        default_off["run_manifest_status"] = default_off_doc.get("status")
        default_off["acceptance_strict_raw_parity"] = acceptance.get("strict_raw_artifact_parity")

    residuals = {}
    for label in ("corrected_residual_npz", "preserve_w_residual_npz"):
        p = _need_path(root, manifest, label, required=False)
        if p is not None:
            residuals[label] = _verify_residual_npz(p)

    required_map = {k: manifest.get("paths", {}).get(k) for k in REQ_PATHS}
    result = {
        "schema": "pr300-portable-bundle-verification-v1",
        "status": "verified",
        "bundle_root": ".",
        "manifest": {"path": manifest_path.relative_to(root).as_posix(), "sha256": manifest_sha},
        "manifest_files": manifest_checks,
        "archive": archive_result,
        "portable_dependencies": parser_receipts,
        "source60": {"path": required_map["source60_wrfout"], "sha256": source_sha, "timestamp": timestamp, "time_index": source_i},
        "corrected_input": {"path": required_map["corrected_input"], "sha256": input_sha, "cold_time": input_times[0],
                             "eight_field_source_copy": input_gate, "shared_context": context_gate},
        "run_receipts": {"corrected": corrected_runs, "preserve_w": preserve_runs},
        "raw_call_state": {"corrected": {m: corrected_sources[("corrected", m)] for m in ("fortran", "cpp")},
                           "preserve_w": {m: preserve_sources[("preserve_w", m)] for m in ("fortran", "cpp")}},
        "raw_ft_cpp_pgf_to_full_gates": {"corrected": "passed", "preserve_w": "passed"},
        "call_pressure_context_not_state_gate": raw_p,
        "default_off_physical_owner_regression": default_off,
        "residual_vector_identities": residuals,
        "scope": "Raw first-call state/Full/PGF observer verification and supplied physical-owner/residual checks only; no forecast or later-stage claim.",
    }
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path, help="unpacked portable bundle root")
    parser.add_argument("--manifest", type=Path, default=Path(MANIFEST_NAME), help="relative manifest path under --root")
    parser.add_argument("--manifest-sha256", help="optional detached expected manifest digest")
    parser.add_argument("--archive", type=Path, help="optional ZIP to CRC-test")
    parser.add_argument("--archive-sha256", help="optional expected ZIP SHA-256")
    parser.add_argument("--out", type=Path, help="optional report file; must not already exist")
    args = parser.parse_args()
    try:
        result = verify(args.root, args.manifest, args.manifest_sha256, args.archive, args.archive_sha256)
        text = json.dumps(result, indent=2, sort_keys=True) + "\n"
        if args.out:
            flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
            fd = os.open(args.out, flags, 0o644)
            with os.fdopen(fd, "w") as stream:
                stream.write(text)
        else:
            sys.stdout.write(text)
        return 0
    except Exception as exc:
        sys.stderr.write(f"verify_pr300_bundle: FAIL: {exc}\n")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
