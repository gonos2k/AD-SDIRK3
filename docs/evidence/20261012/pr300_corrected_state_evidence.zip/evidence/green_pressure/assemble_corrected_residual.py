#!/usr/bin/env python3
"""Close the corrected-state U residual with shared Full, H/V, and PGF arrays."""
from __future__ import annotations
import hashlib, json
from pathlib import Path
import numpy as np

E=Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012')
OUT=E/'green_pressure'
GATE=E/'green_execution/corrected_pgf_context_gate.json'
RUNS=E/'green_execution/corrected_runs.json'
FULL_NPZ=E/'green_metric/physical_rhs_arrays.npz'
FULL_JSON=E/'green_metric/physical_rhs_arrays.json'
HV_NPZ=E/'green_transport/corrected_state_hv_physical_arrays.npz'
HV_JSON=E/'green_transport/corrected_state_hv_physical_components.json'
PGF_NPZ=OUT/'corrected_pgf_physical_arrays.npz'
PGF_JSON=OUT/'corrected_pgf_physical_analysis.json'
SOURCE_GATE=E/'green_rhs/corrected_state_gate.json'

def receipt(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def stats(x):
    a=np.asarray(x,dtype=np.float64)
    return {'count':int(a.size),'rms':float(np.sqrt(np.mean(a*a))),
            'max_abs':float(np.max(np.abs(a))),'max':float(np.max(a)),
            'min':float(np.min(a))}
def proj(r,d):
    rr=float(np.sum(r*r));dd=float(np.sum(d*d));dot=float(np.sum(r*d))
    return {'cosine':float(dot/np.sqrt(rr*dd)) if rr and dd else None,
            'signed_projection_share_of_R_pct':100*dot/rr if rr else None,
            'deltaPGF_energy_share_of_R_pct':100*dd/rr if rr else None,
            'squared_residual_reduction_pct':100*(1-float(np.sum((r-d)**2))/rr) if rr else None}

g=json.loads(GATE.read_text()); f=json.loads(FULL_JSON.read_text()); h=json.loads(HV_JSON.read_text()); p=json.loads(PGF_JSON.read_text()); source=json.loads(SOURCE_GATE.read_text()); runs=json.loads(RUNS.read_text())
if not g.get('all_same_call_state_gates_pass') or not f.get('state_gate',{}).get('passed') or not h.get('gate',{}).get('call_context_all_same_state_gates_passed') or not p.get('same_call_state_gate',{}).get('all_same_call_state_gates_pass'):
    raise RuntimeError('One or more same-call state/component gates failed')
if runs.get('native_calls') != 2 or h.get('native_execution_receipt',{}).get('native_calls') != 2:
    raise RuntimeError('Expected exactly two corrected-input native calls')
if f.get('run_receipt',{}).get('input_sha256') != h.get('native_execution_receipt',{}).get('input_sha256') or f.get('run_receipt',{}).get('input_sha256') != g.get('input_sha256'):
    raise RuntimeError('Full and H/V arrays do not share the corrected input hash')
if f.get('same_call_context_gate',{}).get('sha256') != h.get('gate',{}).get('call_context_gate_sha256'):
    raise RuntimeError('Full and H/V arrays do not share the exact call-context gate')
if source.get('source_scope',{}).get('corrected_input_sha256') != g.get('input_sha256') or not source.get('same_call_state_gates',{}).get('passed'):
    raise RuntimeError('Source-state receipt does not bind this corrected input and same-call state')

zf=np.load(FULL_NPZ); zh=np.load(HV_NPZ); zp=np.load(PGF_NPZ)
df=np.asarray(zf['delta_u_cpp_minus_fortran_m_s2'],dtype=np.float64)
dh=np.asarray(zh['hd_delta'],dtype=np.float64)
dv=np.asarray(zh['delta_vdiff_cpp_minus_fortran'],dtype=np.float64)
mask=np.asarray(zh['owner_mask_u_unique_periodic_x'],dtype=bool)
dp=np.asarray(zp['delta_pgf_cpp_minus_ft_owner'],dtype=np.float64)
if df.shape!=(16,16,16) or dh.shape!=(16,16,17) or dv.shape!=(16,16,17) or mask.shape!=(16,16,17) or int(mask.sum())!=4096:
    raise RuntimeError('Unexpected U physical/periodic geometry or owner mask')
if not np.all(mask[:,:,:16]) or np.any(mask[:,:,16]):
    raise RuntimeError('Owner mask does not select unique periodic U faces')
if dp.shape!=df.shape or not np.isfinite(df).all() or not np.isfinite(dh).all() or not np.isfinite(dv).all() or not np.isfinite(dp).all():
    raise RuntimeError('Nonfinite or mismatched U component arrays')
# GreenTransport's whole delta is a cross-producer cross-check of GreenMetric.
whole=np.asarray(zh['whole_delta'],dtype=np.float64)[:,:,:16]
if not np.array_equal(df,whole):
    raise RuntimeError('GreenMetric full delta differs from GreenTransport paired whole delta')

# First remove actual H/V differences from the corrected-state Full difference;
# only then subtract the isolated PGF contribution pointwise.
R=df-dh[:,:,:16]-dv[:,:,:16]
if not np.allclose(R,zh['delta_full_minus_hd_minus_vdiff'][:,:,:16],rtol=0,atol=1e-20):
    raise RuntimeError('Independent R construction differs from GreenTransport stored remainder')
N=R-dp
regions={'all_4096_owners':(slice(None),slice(None),slice(None)),
         'periodic_seam_x0':(slice(None),slice(None),slice(0,1)),
         'interior_x1_to15':(slice(None),slice(None),slice(1,None))}
metrics={}
for name,s in regions.items():
    metrics[name]={'delta_full_cpp_minus_ft':stats(df[s]),'delta_hdiff_cpp_minus_ft':stats(dh[:,:,:16][s]),
       'delta_vdiff_cpp_minus_ft':stats(dv[:,:,:16][s]),'R_full_minus_hdiff_minus_vdiff':stats(R[s]),
       'delta_pgf_cpp_minus_ft':stats(dp[s]),'R_minus_delta_pgf':stats(N[s]),
       'pgf_projection':proj(R[s],dp[s])}

arrays={'delta_full_u_cpp_minus_ft_owner_m_s2':df,
        'delta_hdiff_u_cpp_minus_ft_owner_m_s2':dh[:,:,:16],
        'delta_vdiff_u_cpp_minus_ft_owner_m_s2':dv[:,:,:16],
        'remainder_full_minus_hdiff_minus_vdiff_m_s2':R,
        'delta_pgf_u_cpp_minus_ft_owner_m_s2':dp,
        'remainder_after_pgf_m_s2':N,
        'owner_mask_u_unique_periodic_x':mask[:,:,:16]}
npzout=OUT/'corrected_actual_full_hv_pgf_residual_arrays.npz'
np.savez_compressed(npzout,**arrays)
report={'schema':'pr300-corrected-state-full-hv-pgf-residual-v1','case':'corrected',
 'native_calls':2,'corrected_input_sha256':g['input_sha256'],'executable_sha256':g['reused_executable_sha256'],
 'units':'m/s^2','geometry':'owner U faces j=0..15,k=0..15,i=0..15; periodic closing face i=16 excluded',
 'owner_count':4096,'gates':{'same_call_state':{'path':str(GATE),'sha256':receipt(GATE)['sha256'],'passed':True},
   'Full_state':{'path':str(FULL_JSON),'sha256':receipt(FULL_JSON)['sha256'],'passed':True},
   'H_V_frame_pair':{'path':str(HV_JSON),'sha256':receipt(HV_JSON)['sha256'],'passed':True},
   'PGF_state':{'path':str(PGF_JSON),'sha256':receipt(PGF_JSON)['sha256'],'passed':True},
   'full_delta_matches_hv_producer_exactly':True},
 'inputs':{'run_receipt':receipt(RUNS),'full_arrays':receipt(FULL_NPZ),'full_metadata':receipt(FULL_JSON),
   'hv_arrays':receipt(HV_NPZ),'hv_metadata':receipt(HV_JSON),'pgf_arrays':receipt(PGF_NPZ),'pgf_metadata':receipt(PGF_JSON),
   'source_state_gate':receipt(SOURCE_GATE)},
 'equations':{'R':'delta_full - delta_hdiff - delta_vdiff',
   'post_pgf':'R - delta_pgf','all_subtractions_elementwise_after_same_state_gates':True},
 'metrics_by_region':metrics,
 'source60_state_interpretation':{'status':source.get('status'),'same_call_state_gate_passed':source.get('same_call_state_gates',{}).get('passed'),
   'call_fields_matching_source60':['U','V','PH','THM','MU'],'call_field_reset':['W'],
   'w_reset_explanation':source.get('startup_w_update',{}).get('interpretation'),
   'call_P_note':'Runtime pressure is recomputed at startup and is reported separately from the prognostic input-state gate.'},
 'scope':'Corrected cold-start state component accounting only. The exact same-call Fortran/C++ state gates pass; W has startup reset relative to source 60. This does not claim an all-six-field source-60 call state, forecast parity, or a broader causal diagnosis.',
 'arrays_npz':receipt(npzout)}
(OUT/'corrected_actual_full_hv_pgf_residual.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(OUT/'corrected_actual_full_hv_pgf_residual.json')
