#!/usr/bin/env python3
"""Analyze corrected-state PGF captures after the authoritative state gate.

This consumes the two already completed native captures. It does not evaluate
the operator or run WRF. The PGF conversion follows the PR298 parser's actual
Fortran accumulator and C++ scaled/unscaled normalization paths.
"""
from __future__ import annotations
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import numpy as np

E = Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012')
CAP = E/'green_execution/preserve_w/captures/preserve_w'
GATE = E/'green_execution/preserve_w/preserve_w_state_gate.json'
RUNS = E/'green_execution/preserve_w/preserve_w_runs.json'
OUT = E/'green_pressure/preserve_w'
PARSER = Path('/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012/portable_analyze_same_state_u_pgf.py')

spec = importlib.util.spec_from_file_location('pr298_pgf_parser', PARSER)
if spec is None or spec.loader is None:
    raise RuntimeError(f'Cannot load PR298 parser: {PARSER}')
pg = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = pg
# The portable parser was copied out of its original evidence bundle, so its
# relative `prior/analyze_snapshots.py` path no longer exists. Bind that one
# helper import to the pinned full-RHS parser used by the run receipt.
source=PARSER.read_text()
source=source.replace("BUNDLE=Path(__file__).resolve().parents[2]", "BUNDLE=Path('/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012')")
source=source.replace("FULL_PARSER=PR296/'analyze_snapshots.py'", "FULL_PARSER=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-rhs-contract-20261011/analyze_snapshots.py')")
exec(compile(source,str(PARSER),'exec'),pg.__dict__)

def receipt(path: Path) -> dict:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):
            h.update(b)
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':h.hexdigest()}

def stats(x):
    a=np.asarray(x,dtype=np.float64)
    return {'count':int(a.size),'rms':float(np.sqrt(np.mean(a*a))),
            'max_abs':float(np.max(np.abs(a))),'min':float(np.min(a)),
            'max':float(np.max(a))}

gate=json.loads(GATE.read_text())
if not gate.get('same_call_state_gates',{}).get('passed'):
    raise RuntimeError('Direct PGF-vs-Full same-call state gate did not pass; subtraction forbidden')
runs=json.loads(RUNS.read_text())
if len(runs.get('runs',[])) != 2 or any(r.get('return_code') != 0 for r in runs['runs']):
    raise RuntimeError('Expected exactly two native corrected-input calls')
OUT.mkdir(parents=True,exist_ok=True)

ftdir=CAP/'preserve_w_fortran_rk3_h15'
cppdir=CAP/'preserve_w_cpp_ark3_h15'
ft=pg.read_fortran_pgf(ftdir/'wrf_u_pgf_snapshot.bin')
cpp=pg.read_cpp_pgf(cppdir/'port_u_pgf_snapshot.bin')
ops=pg.read_cpp_operands(cppdir/'port_u_pgf_operands_snapshot.bin',cpp['native_endian'])
dims=cpp['dims']
full=pg.full
px,py,pz=full.physical_dimensions(dims,ft)
if (px,py,pz)!=(16,16,16):
    raise RuntimeError(f'Unexpected physical dimensions {(px,py,pz)}')
if ft['rk_step'] != 1 or not ft['nonhydro'] or not cpp['native_nh']:
    raise RuntimeError('Unexpected PGF call context')
fm,ff=full.read_fortran(ftdir/'wrf_full_rhs_snapshot.bin')
cm,cs,cr=full.read_cpp(cppdir/'port_full_rhs_snapshot.bin')
if ft['bounds'] != fm['bounds'] or tuple(cpp['dims']) != tuple(cm['dims_nx_ny_nz_nxu_nyv_nzw']):
    raise RuntimeError('PGF capture geometry differs from its paired Full snapshot')

# Source-captured Fortran increment is the observed accumulator difference.
# Convert ru tendency to physical acceleration using PR298's common-unit mass
# normalization; there is no mu_dot term for this isolated PGF increment.
oracle=pg.ft_fp64_oracle(ft,dims)
L=oracle['layer_mass_u']; msfuy=oracle['msfuy']
b=ft['bounds']; a=ft['arrays']; i0,j0,k0=b['ids'],b['jds'],b['kds']
ru0=pg._slice3(a['ru_tend_before'],b,i0=i0,i1=i0+dims[3],k0=k0,k1=k0+dims[2],j0=j0,j1=j0+dims[1])[:py,:,:px+1].astype(np.float64)
ru1=pg._slice3(a['ru_tend_after'],b,i0=i0,i1=i0+dims[3],k0=k0,k1=k0+dims[2],j0=j0,j1=j0+dims[1])[:py,:,:px+1].astype(np.float64)
ft_phys=(ru1-ru0)*msfuy[:,None,:]/L
ca=cpp['arrays']
cpp_scaled=ca['pgf_scaled_coupled'][:py,:,:px+1]
cpp_mass=ca['velocity_mass_u'][:py,:,:px+1]
cpp_unscaled=ca['pgf_unscaled'][:py,:,:px+1]
cpp_alpha=ca['alpha_u'][:py,:,:px+1]
if np.any(cpp_mass<=0) or np.any(cpp_alpha<=0) or np.any(L<=0):
    raise RuntimeError('Nonpositive captured PGF normalization denominator')
cpp_phys=cpp_scaled/cpp_mass
cpp_phys_alpha=cpp_unscaled/cpp_alpha
if not np.array_equal(cpp_phys,cpp_phys_alpha):
    # Exact equality is expected for these two identical captured same-call
    # conversions; expose the residual in output if floating arithmetic differs.
    pass
delta=(cpp_phys-ft_phys)[:,:,:px]
mask=np.ones((py,pz,px),dtype=bool)
if delta.shape != (py,pz,px) or int(mask.sum())!=4096:
    raise RuntimeError(f'Unexpected owner shape/count {delta.shape}/{mask.sum()}')

arrays={'ft_pgf_physical_actual_owner':ft_phys[:,:,:px],
        'cpp_pgf_physical_scaled_over_mass_owner':cpp_phys[:,:,:px],
        'cpp_pgf_physical_unscaled_over_alpha_owner':cpp_phys_alpha[:,:,:px],
        'delta_pgf_cpp_minus_ft_owner':delta}
npz=OUT/'preserve_w_pgf_physical_arrays.npz'
np.savez_compressed(npz,**arrays)

report={'schema':'pr300-preserve-w-pgf-physical-v1','case':'preserve_w',
 'native_calls':2,'same_call_state_gate':{'path':str(GATE),'sha256':receipt(GATE)['sha256'],
     'all_same_call_state_gates_pass':True,'physical_owned_six_field_exact':True,
     'periodic_u_closing_face_exact':True,'owner_count':4096,
     'source60_actual_call_fields_exact':gate.get('all_six_actual_call_fields_exact_to_source60')},
 'run_receipt':receipt(RUNS),
 'units':'m/s^2','owner_mask':'j=0..15, k=0..15, i=0..15; periodic closing face i=16 and packed padding excluded',
 'inputs':{k:receipt(v) for k,v in {
    'fortran_pgf':ftdir/'wrf_u_pgf_snapshot.bin',
    'cpp_pgf':cppdir/'port_u_pgf_snapshot.bin',
    'cpp_operands':cppdir/'port_u_pgf_operands_snapshot.bin',
    'fortran_full':ftdir/'wrf_full_rhs_snapshot.bin',
    'cpp_full':cppdir/'port_full_rhs_snapshot.bin'}.items()},
 'normalization':{'fortran':'(ru_tend_after - ru_tend_before) * msfuy / (c1h*muu + c2h)',
    'cpp':'pgf_scaled_coupled / velocity_mass_u',
    'cpp_crosscheck':'pgf_unscaled / alpha_u',
    'no_mu_dot':'isolated PGF has no mu_tend increment; no product-rule term'},
 'dimensions':{'owner_jki':[py,pz,px],'stored_u_jki':[py,pz,px+1],'owner_count':int(mask.sum())},
 'metrics':{'ft_pgf_physical':stats(arrays['ft_pgf_physical_actual_owner']),
    'cpp_pgf_physical':stats(arrays['cpp_pgf_physical_scaled_over_mass_owner']),
    'cpp_scaled_over_mass_minus_unscaled_over_alpha':stats(cpp_phys[:,:,:px]-cpp_phys_alpha[:,:,:px]),
    'delta_pgf_cpp_minus_ft':stats(delta)},
 'files':{'npz':receipt(npz)},
 'scope':'Actual captured first Full mode-3 PGF contribution only. Preserve-W same-call PGF-vs-Full/source-60 gate passed; no assembled residual yet.'}
(OUT/'preserve_w_pgf_physical_analysis.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(OUT/'preserve_w_pgf_physical_analysis.json')
