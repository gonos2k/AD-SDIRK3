from pathlib import Path
import os,shutil,hashlib,json,subprocess
old=Path('/private/tmp/pr298-u-pgf-20261012');new=Path('/private/tmp/pr300-corrected-state-20261012');E=Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(old/'main/wrf.exe')=='4201790d363fb9bdc1e49bf9a83fd3a506b91147c1b34b8a8fbbc0ff77e22ec3'
assert sha(old/'external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a')=='21f7bc79a131f4608f506259b7c0434f2350749486774f14aea260cc69910565'
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=new).decode().split('\0');same=[];different=[]
for rel in tracked:
 if not rel:continue
 a=old/rel;b=new/rel
 if a.is_file() and b.is_file() and a.read_bytes()==b.read_bytes():
  os.utime(b,ns=(a.stat().st_atime_ns,a.stat().st_mtime_ns));same.append(rel)
 elif a.is_file() and b.is_file() and Path(rel).suffix in {'.F','.F90','.cpp','.c','.h','.hpp'}:different.append(rel)
assert different==['dyn_em/start_em.F'],different
copied=[]
for a in old.rglob('*'):
 if not a.is_file() or a.is_symlink() or '.git' in a.parts:continue
 rel=a.relative_to(old);b=new/rel
 if str(rel) in {'dyn_em/start_em.o','dyn_em/start_em.f90','main/wrf.exe','main/ideal.exe'}:continue
 eligible=a.suffix in {'.o','.a','.mod'} or str(rel) in {'tools/registry','tools/standard.exe','tools/standard','tools/yacc','tools/yacc.exe'}
 if a.suffix=='.f90':
  owner=a.with_suffix('.F');target=new/owner.relative_to(old)
  eligible=owner.is_file() and target.is_file() and sha(owner)==sha(target)
 if rel.parts[0]=='inc' and a.suffix in {'.inc','.h'}:eligible=True
 if eligible:b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(a,b);copied.append(str(rel))
config=old/'configure.wrf';(new/'configure.wrf').write_text(config.read_text().replace(str(old),str(new)))
r={'donor':str(old),'target':str(new),'affected':'dyn_em/start_em.F','source_sha256':sha(new/'dyn_em/start_em.F'),'same_tracked_mtime_alignment_count':len(same),'authoritative_source_differences':different,'seeded_artifacts_count':len(copied),'changed_start_em_object_or_generated_not_seeded':True,'old_archive_seeded_requires_update_and_executable_relink':True,'configure_sha256':sha(new/'configure.wrf'),'archive_before_sha256':sha(new/'main/libwrflib.a'),'CPP_library_sha256':sha(new/'external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a')}
(E/'start_em_build_seed_receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
