# PR300 graph reuse navigation

Target `303fd8e22dc6908a0493ca87b49b2b6b2b3e9456` (tree `55b6c04f0c9370b4769317086703f752ca50b04a`) reuses the 76-source Graphify corpus at `583e2a64c1879372c2e0a1b9f4770298a05ffd75`. Every bound source hash matches this worktree; no Fortran/C++ model source changed relative to the graph revision. The graph was not refreshed.

- Fortran call-time U-PGF: `dyn_em/module_em.F:717-800`, gated first eligible RK1 capture to `wrf_u_pgf_snapshot.bin`.
- C++ Full RHS diagnostic: `wrf_sdirk3_tile_unified_impl.cpp:6928-7002`, first debug split-check Full call to `port_full_rhs_snapshot.bin`, gated by single full-domain rank, periodic X/symmetric Y and zero `F_phys`.
- C++ Full U-PGF: `wrf_sdirk3_tile_unified_impl.cpp:19946-20000`, first canonical Full/IMEX-3 call to `port_u_pgf_snapshot.bin`, with packed six-field state, PGF, velocity mass, unscaled PGF, alpha, and pressure/EOS sidecar.
- State-input dependency: `tools/make_wrf_common_state_input.py` copies `U,V,W,PH,T,THM,MU,P`; verifies fixed base `PB,PHB,MUB` and theta context `QVAPOR` match the time-zero input, preserving other input variables. Registry mapping remains in `Registry/Registry.EM_COMMON`: prognostic `t` maps to `THM`, while `th_phy_m_t0` maps to `T`. Nonrestart `start_em` reconstructs first-call pressure from active prognostic theta and base thermodynamics.

The graph provides navigation only; it does not establish numerical parity. This task made no runner/analysis changes and ran no tests, build, or model. Full receipt: `pr300_graph_reuse_receipt.json`.
