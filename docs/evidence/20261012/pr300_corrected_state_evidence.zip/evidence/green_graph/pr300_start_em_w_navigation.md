# PR300 W input initialization navigation

Target `c26a0f9a86d4ca83642d2cf82326399f8c79fe8a` (tree `8bfeabc6f26f904100fb931f614e8e5dd7498074`); frozen source, `dyn_em/start_em.F` SHA-256 `f3cf233cb8223601629a5779625a421bdd92cad639d9f7f7eef2502fdc5d8fd6`. The verified 76-source corpus was reused; the other 75 source hashes are exact. No AST was generated for this `.F` file because Graphify does not extract the WRF Fortran extension.

`Registry/Registry.EM_COMMON:2887` declares `use_input_w` in the dynamics namelist with default `.false.`; generated `frame/module_configure.f90:10576` also initializes it false. In `start_domain_em` (`start_em.F:1500-1554`), startup/cycling nonrestart logic scans `w_2`: the default flag scans only surface level `k=1`; when true, the changed `w_input_k_end` extends the scan through `MIN(kte,kde)`. If the scanned global extrema are both near zero, it schedules initialization; if input W is flagged and a nonzero value is found, it preserves input W. Otherwise the existing path calls `set_w_surface` separately for `w_1` and `w_2`.

`module_bc_em.F:1196-1295` defines `set_w_surface`: it sets surface W from terrain slopes and U/V, then fills levels above the surface with `w_surface * znw(k)^2` when `fill_w_flag` is true. Its source was read for this manual edge but is not in the 76-source binding set. All Fortran caller/Registry/config edges here are manual navigation, not Graphify proof. No other graph source was refreshed; no build/test/model run was performed.

See `pr300_start_em_w_refresh_receipt.json` for hashes and scope.

Source freeze note: root confirmed the final change from the previously inspected hash only adjusts comments/indentation; the W-scan semantics above are unchanged. The source-binding receipt was updated without refreshing AST.

Committed binding update: `c26a0f9a86d4ca83642d2cf82326399f8c79fe8a` (`8bfeabc6f26f904100fb931f614e8e5dd7498074`), with `dyn_em/start_em.F` still at `f3cf233cb8223601629a5779625a421bdd92cad639d9f7f7eef2502fdc5d8fd6` and all other 75 graph-bound sources verified identical. This remains a manual Fortran source trace; no AST refresh was performed.
