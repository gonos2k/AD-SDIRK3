With `use_input_w=true`, a valid cold input can have zero surface W and nonzero interior W. The startup missing-W check examined only the surface and could overwrite the column. Scan the physical W column only when that existing option is enabled; preserve the default-false surface test and all-zero fallback.

The corrected PR299 input was used in five bounded native `em_b_wave` calls: two retained-binary probes, one rebuilt default-off control, and the rebuilt Fortran/C++ opt-in pair. All six actual opt-in call fields match the archived 60-second source exactly, and the paired Full/PGF call states match. Only `start_em` was rebuilt; the C++ archive and interface are unchanged. Exact source bytes are bound to code commit `c26a0f9` separately from the pre-commit build receipt.

Validation:
- Both opt-in native runs completed successfully; all six source-state gates pass, including all physical W faces.
- Default-off physical state, Full U/V/MU and six RK tendencies match the retained run exactly. Whole-file byte parity still fails on 109 off-owner `mu_tend` ghost values (max 1.57e-40); original files and the independent physical-use audit are preserved.
- Independent Green/Red raw-array checks reproduce Full U/V/MU and U-PGF/H/V accounting. The post-PGF U remainder remains 3.0691e-9 m/s² RMS and is unassigned.
- The evidence ZIP includes raw captures, input/source data, build/source/hash receipts, and a portable verification entrypoint. No new 240-second forecast, reference qualification, integrated JVP/VJP, or rotating inverse run is claimed.

Details and reproducible evidence: [session report](docs/(202610121600)_pr300_input_w_and_actual_rhs.md).
