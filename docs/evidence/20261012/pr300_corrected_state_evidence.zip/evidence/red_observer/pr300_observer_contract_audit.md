# PR300 observer-contract audit

Local timestamp: 2026-10-12 14:57:04 JST (+0900). Read-only review of the existing two-run gate and provenance receipts. No build, native run, source edit, or RHS invocation.

Preflight is correctly bounded to two 15-second, h=15 cold-start runs from the corrected input, one Fortran RK3 and one C++ mode-3 ARK, using the existing PR298 executable. The corrected input/helper/source hashes are pinned; all seven compiled native sources and startup/ABI interface inputs match the PR298 built tree byte-for-byte. The checklist also requires actual method/route, input, six-state call-time, owner/seam, and runtime flag gates. It explicitly rules out a continuous trajectory, 240-second forecast, or accuracy claim.

**Blocker in the requested PGF comparison:** the existing C++ observer only writes `port_u_pgf_snapshot.bin`; there is no C++ V-PGF component snapshot. The Fortran `wrf_u_pgf_snapshot.bin` stores before/after `ru_tend` and `rv_tend`, but the C++ `port_full_rhs_snapshot.bin` is an assembled Full RHS record, not a V-PGF decomposition. Therefore the current, reused executable can support same-call U-PGF plus full V-RHS comparisons, but cannot isolate a C++ V-PGF contribution as checklist item 4 requests. Since this run must reuse the existing executable, either narrow the deliverable to U-PGF or defer V-PGF until an instrumented build is explicitly in scope. Do not infer V-PGF from Full V RHS.

No PR300 runner plan or post-run receipt is present yet, so there is no basis to claim the two calls ran or passed the post-run gates. For the eventual receipts, keep scope to these first cold calls: Fortran `rk_step=1`/one-rank/full-domain guard (the dump has no `itimestep` field), and C++ Full/mode-3/packed-periodic/single-process first eligible call, each tied to its same-run Full snapshot by exact six-field state equality. Record actual input SHA, `restart=false`, route, and effective flags; these do not establish later-stage or restart behavior.

See `pr300_observer_contract_audit.json` for the preflight source/input pins and exact observer scope.


## Two-run closure — 2026-10-12 15:11:10 JST (+0900)

Read-only review of the completed corrected-state receipts and raw observers; no new run, build, or source change. Exactly two native calls completed (`corrected_fortran_rk3_h15`, `corrected_cpp_ark3_h15`), both h=15, duration=15 s, same corrected cold input SHA `fc37c8c0…639d14df`, same reused executable SHA `4201790d…77e22ec3`, return code 0 and success marker. Source pins remained unchanged. This is an initial/cold call comparison only; no +15 s output endpoint is compared.

The same-call full-state/PGF gates pass: all six physical prognostic fields agree exactly between Fortran and C++ at the captured call, and the periodic U closing-face checks pass. Physical owner sets are 4096 U faces, 3840 V faces, and 256 MU cells. Full RHS differences are separate: U RMS `8.3997e-8 m/s²` (relative RMS `2.2819e-4`), V RMS `8.4893e-8 m/s²` (relative RMS `1.4833e-3`), MU RMS `3.3693e-8 Pa/s` (relative RMS `8.9316e-6`). No tolerance was adopted.

Offline replay of the actual U-PGF snapshots on 4096 unique U owners gives Fortran physical U-PGF RMS `3.6810104e-4 m/s²`, C++ RMS `3.6810090e-4 m/s²`; C++ minus Fortran bias `-3.43e-13`, RMS `8.39315e-8`, max absolute `3.74262e-7 m/s²` (relative RMS `2.28012e-4`). Captured pressure context is finite and shape-aligned but not bitwise equal: P′ differs `0.005535 Pa` RMS (`0.1560%` relative RMS), AL/ALT differ around `5e-8` relative RMS, while PH and input PB match exactly. This is measured same-state evidence, not a pressure-cause or formula-parity conclusion.

The prior C++ V-PGF observer gap is closed under the clarified scope: direct PGF comparison is U-only; V and MU are compared as Full RHS components. The old acceptance checklist still asks to compare V-PGF, so that sentence should be synchronized before packaging. Source citations are now authoritative `dyn_em/module_bc_em.F:960-1021` and `dyn_em/start_em.F:787-804`; no generated `.f90` path is cited. The Fortran dump records `rk_step=1`, `n_moist=2`; its routine lacks `itimestep`, so evidence remains limited to this first eligible cold call. The C++ PGF state is tied to its same-run Full snapshot by the six-field exact gate.

Raw run, source and artifact receipts plus the offline U-PGF replay metrics are recorded in `pr300_observer_contract_audit.json` under `followup_20261012`. No claim is made about later stages, restarts, continuous trajectories, convergence, forecast accuracy, or full operator parity.


Checklist synchronization completed: `red_acceptance/pr300_two_run_gate_checklist.md` now specifies direct U-PGF only, with V/MU handled as Full-RHS components. The prior V-PGF observer gap is closed under this scope.
