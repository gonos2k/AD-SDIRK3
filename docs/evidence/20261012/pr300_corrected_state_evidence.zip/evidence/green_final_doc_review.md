# Green final review of PR300 cold-state RHS report

Read-only review against the frozen PR300 sources, two-call receipt, actual-state/source gate, full/H/V/PGF arrays, and W startup logs. No additional calls, tests, or source changes.

No concrete error found in the report's state/source or numerical claims:

- The corrected time-zero input copies the archived source-60 U/V/W/PH/T/THM/MU/P fields exactly. The paired Fortran/C++ actual first-call six-field state gate also passes exactly.
- The document separately reports the source-60 gate failure for call-time W. Both actual W arrays are zero; source/input W is zero at the surface but nonzero above it. `USE_INPUT_W=F`, the runtime `set_w_surface` log, and `start_em.F:1490-1551` support the stated cold-start reset. This does not relabel the cold input as a complete source checkpoint.
- The prognostic theta comparison is correctly `call t` to NetCDF THM. NetCDF T remains diagnostic. File P equality is not used as a runtime P invariant; call-time FT P and C++ P′ are reported separately because startup recomputes them.
- Full U/V/MU and isolated U-PGF component units and owner masks match the exported arrays. The elementwise `R=DeltaFull-DeltaHdiff-DeltaVdiff`, then `R-DeltaPGF`, values reproduce the recorded RMS and squared-norm reductions. The remainder is labeled measured and unassigned; no source fix or forecast improvement is claimed.
- The report keeps the scope to two one-step cold-start calls. It explicitly leaves the full six-field source-60 state, residual cause, W/PH/THM assembled RHS, forecast qualification, and broader accuracy/performance open.

No blocking correction identified.
