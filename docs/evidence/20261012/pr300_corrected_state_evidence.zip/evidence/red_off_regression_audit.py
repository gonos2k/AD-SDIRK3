#!/usr/bin/env python3
"""Independent read-only raw-byte/physical RHS audit for default-off startup regression."""
import hashlib,json,struct
from pathlib import Path
import numpy as np
E=Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012')
BASE=E/'green_execution/captures/corrected/corrected_fortran_rk3_h15'
NEW=E/'green_execution/preserve_w/captures/off_regression/newexe_default_off_fortran_rk3_h15'
CPP=E/'green_execution/captures/corrected/corrected_cpp_ark3_h15'
OUT=E/'red_off_regression_audit.json'
FORDER=('u2','v2','w2','ph2','t2','mu2','ru_tend','rv_tend','mu_tend','ru','rv','muu','muv','mut','dnw','c1h','c2h','msfux','msfuy','msfvx','msfvy','msftx','msfty')
F3=set(('u2','v2','w2','ph2','t2','ru_tend','rv_tend','ru','rv'))
F2=set(('mu2','mu_tend','muu','muv','mut','msfux','msfuy','msfvx','msfvy','msftx','msfty'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def parse_full(p):
 b=p.read_bytes();version,=struct.unpack_from('<I',b,0);assert version==1
 bounds=struct.unpack_from('<12i',b,4);rdx,rdy=struct.unpack_from('<2f',b,52)
 ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme=bounds;ni,nj,nk=ime-ims+1,jme-jms+1,kme-kms+1
 n3=ni*nj*nk;n2=ni*nj;o=60;f={}
 for name in FORDER:
  n=n3 if name in F3 else n2 if name in F2 else nk
  arr=np.frombuffer(b,dtype='<f4',count=n,offset=o)
  f[name]=arr.reshape((nj,nk,ni)) if name in F3 else arr.reshape((nj,ni)) if name in F2 else arr
  o+=4*n
 assert o==len(b),(o,len(b))
 return {'bounds':bounds,'rdx':rdx,'rdy':rdy,'f':f,'sha256':sha(p)}
def parse_cpp_full(p):
 b=p.read_bytes();head=struct.unpack_from('<7i',b,0);version,nx,ny,nz,nxu,nyv,nzw=head;assert version==1
 shapes={'u':(ny,nz,nxu),'v':(nyv,nz,nx),'w':(ny,nzw,nx),'ph':(ny,nzw,nx),'t':(ny,nz,nx),'mu':(ny,1,nx)}
 o=28;state={};rhs={}
 for dest in (state,rhs):
  for name,sh in shapes.items():
   n=int(np.prod(sh));dest[name]=np.frombuffer(b,dtype='<f4',count=n,offset=o).reshape(sh);o+=4*n
 assert o==len(b)
 return {'dims':head[1:],'state':state,'rhs':rhs,'sha256':sha(p)}
def parse_rktend(p):
 b=p.read_bytes(); bounds=struct.unpack_from('>6i',b,0);ims,ime,jms,jme,kms,kme=bounds
 ni,nj,nk=ime-ims+1,jme-jms+1,kme-kms+1;n3=ni*nj*nk;n2=ni*nj;o=24;f={}
 for name in ('ru_tend','rv_tend','rw_tend','ph_tend','t_tend'):
  f[name]=np.frombuffer(b,dtype='>f4',count=n3,offset=o).reshape((nj,nk,ni));o+=4*n3
 f['mu_tend']=np.frombuffer(b,dtype='>f4',count=n2,offset=o).reshape((nj,ni));o+=4*n2
 for name in ('p','al'):
  f[name]=np.frombuffer(b,dtype='>f4',count=n3,offset=o).reshape((nj,nk,ni));o+=4*n3
 assert o==len(b),(o,len(b))
 return {'bounds':bounds,'f':f,'sha256':sha(p)}
def metrics_diff(a,b):
 a=np.asarray(a);b=np.asarray(b);d=a.astype(np.float64)-b.astype(np.float64)
 return {'shape':list(a.shape),'count':int(d.size),'mismatch_count':int(np.count_nonzero(a!=b)),
  'max_abs':float(np.max(np.abs(d))) if d.size else 0.0,'rms':float(np.sqrt(np.mean(d*d))) if d.size else 0.0}
def file_record(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def main():
 b=parse_full(BASE/'wrf_full_rhs_snapshot.bin');n=parse_full(NEW/'wrf_full_rhs_snapshot.bin');c=parse_cpp_full(CPP/'port_full_rhs_snapshot.bin')
 ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme=b['bounds'];assert b['bounds']==n['bounds']
 nx=ide-ids;ny=jde-jds;nz=kde-kds;i0=ids-ims;j0=jds-jms;k0=kds-kms
 fs=b['f'];fn=n['f'];
 mu0=fs['mu_tend'];mu1=fn['mu_tend'];d=mu1.astype(np.float64)-mu0.astype(np.float64)
 phys=np.zeros(mu0.shape,dtype=bool);phys[j0:j0+ny,i0:i0+nx]=True
 changed=(mu0!=mu1);jj,ii=np.where(changed)
 ghost_rows=[]
 for j,i in zip(jj,ii):ghost_rows.append({'j':int(jms+j),'i':int(ims+i),'old':float(mu0[j,i]),'new':float(mu1[j,i]),'delta':float(d[j,i])})
 # Full physical RHS reconstruction from raw output arrays.
 def region3(f,name,jend,kend,iend):return f[name][j0:j0+jend,k0:k0+kend,i0:i0+iend].astype(np.float64)
 def region2(f,name,jend,iend):return f[name][j0:j0+jend,i0:i0+iend].astype(np.float64)
 c1=fs['c1h'][k0:k0+nz].astype(np.float64);c2=fs['c2h'][k0:k0+nz].astype(np.float64);dnw=fs['dnw'][k0:k0+nz].astype(np.float64)
 ru_flux=region3(fs,'ru',ny,nz,nx+1);rv_flux=region3(fs,'rv',ny+1,nz,nx)
 msftx=region2(fs,'msftx',ny,nx);msfty=region2(fs,'msfty',ny,nx)
 mdot=np.sum(dnw[None,:,None]*(msftx*msfty)[:,None,:]*(b['rdx']*(ru_flux[:,:,1:]-ru_flux[:,:,:-1])+b['rdy']*(rv_flux[1:]-rv_flux[:-1])),axis=1)+region2(fs,'mu_tend',ny,nx)
 mudotu=np.empty((ny,nx+1));mudotu[:,0]=.5*(mdot[:,-1]+mdot[:,0]);mudotu[:,1:nx]=.5*(mdot[:,:-1]+mdot[:,1:]);mudotu[:,nx]=mudotu[:,0]
 mudotv=np.empty((ny+1,nx));mudotv[0,:]=mdot[0,:];mudotv[1:ny,:]=.5*(mdot[:-1,:]+mdot[1:,:]);mudotv[ny,:]=mdot[-1,:]
 def full_physical(f):
  ru=region3(f,'ru_tend',ny,nz,nx+1);u=region3(f,'u2',ny,nz,nx+1)
  rv=region3(f,'rv_tend',ny+1,nz,nx);v=region3(f,'v2',ny+1,nz,nx)
  muu=region2(f,'muu',ny,nx+1);muv=region2(f,'muv',ny+1,nx)
  my=region2(f,'msfuy',ny,nx+1);mx=region2(f,'msfvx',ny+1,nx)
  lu=c1[None,:,None]*muu[:,None,:]+c2[None,:,None];lv=c1[None,:,None]*muv[:,None,:]+c2[None,:,None]
  fu=(ru*my[:,None,:]-u*c1[None,:,None]*mudotu[:,None,:])/lu
  fv=(rv*mx[:,None,:]-v*c1[None,:,None]*mudotv[:,None,:])/lv
  return {'u':fu[:,:,:nx],'v':fv[1:ny,:,:],'mu':mdot}
 pb=full_physical(fs);pn=full_physical(fn)
 # Six RK tendency arrays: compare native physical domains by stagger; also U unique owners separately.
 rb=parse_rktend(BASE/'wrf_rk_tend_dump.bin');rn=parse_rktend(NEW/'wrf_rk_tend_dump.bin');assert rb['bounds']==rn['bounds']
 ris,rie,rjs,rje,rks,rke=rb['bounds'];ri0=ids-ris;rj0=jds-rjs;rk0=kds-rks
 def r3(name,jlen,klen,ilen):return (rb['f'][name][rj0:rj0+jlen,rk0:rk0+klen,ri0:ri0+ilen],rn['f'][name][rj0:rj0+jlen,rk0:rk0+klen,ri0:ri0+ilen])
 def r2(name,jlen,ilen):return (rb['f'][name][rj0:rj0+jlen,ri0:ri0+ilen],rn['f'][name][rj0:rj0+jlen,ri0:ri0+ilen])
 rkphysical={}
 for name,jlen,klen,ilen in [('ru_tend',ny,nz,nx+1),('rv_tend',ny+1,nz,nx),('rw_tend',ny,nz+1,nx),('ph_tend',ny,nz+1,nx),('t_tend',ny,nz,nx)]:
  a,z=r3(name,jlen,klen,ilen);rkphysical[name]={'physical_storage':metrics_diff(a,z)}
  if name=='ru_tend':rkphysical[name]['unique_U_owners']=metrics_diff(a[:,:,:nx],z[:,:,:nx])
  if name=='rv_tend':rkphysical[name]['internal_V_faces']=metrics_diff(a[1:ny,:,:],z[1:ny,:,:])
 a,z=r2('mu_tend',ny,nx);rkphysical['mu_tend']={'physical_mass_cells':metrics_diff(a,z)}
 # Compare derived new/old FT and against same preserved CPP snapshot.
 cpprhs=c['rhs'];pp={'u':cpprhs['u'][:ny,:,:nx].astype(np.float64),'v':cpprhs['v'][1:ny,:,:nx].astype(np.float64),'mu':cpprhs['mu'][:ny,0,:nx].astype(np.float64)}
 derived={}
 for name in ('u','v','mu'):
  derived[name]={'new_FT_vs_baseline_FT':metrics_diff(pn[name],pb[name]),
    'new_FT_vs_same_CPP_snapshot':metrics_diff(pn[name],pp[name]),
    'baseline_FT_vs_same_CPP_snapshot':metrics_diff(pb[name],pp[name])}
 out={'schema':'pr300-off-regression-red-raw-ghost-stencil-audit-v1','scope':'Independent parse of saved baseline/new FT Full and RK tendency binaries; no model/compiler/build. Full-field cross differences widened to float64 before arithmetic. Physical ranges from stored domain bounds; U owner masks retain periodic x=0 and omit closing duplicate.',
  'provenance':{'input_sha256':'fc37c8c0c8be8053a16e0d3424609d496f4a023c6c17ee3a06371970639d14df','baseline_ft_full':file_record(BASE/'wrf_full_rhs_snapshot.bin'),'new_ft_full':file_record(NEW/'wrf_full_rhs_snapshot.bin'),'same_old_cpp_full':file_record(CPP/'port_full_rhs_snapshot.bin'),'baseline_ft_rk_tend':file_record(BASE/'wrf_rk_tend_dump.bin'),'new_ft_rk_tend':file_record(NEW/'wrf_rk_tend_dump.bin')},
  'storage_geometry':{'bounds':list(b['bounds']),'physical_mass_shape_jki':[ny,nx],'physical_mass_wrf_i':[ids,ide-1],'physical_mass_wrf_j':[jds,jde-1],'storage_ghost_wrf_i':[ims,ime],'storage_ghost_wrf_j':[jms,jme]},
  'full_raw_fields':{name:metrics_diff(fs[name],fn[name]) for name in FORDER},
  'mu_tend_ghost_audit':{'changed_count_all_storage':int(np.count_nonzero(changed)),'changed_inside_physical_mass_cells':int(np.count_nonzero(changed&phys)),'changed_outside_physical_mass_cells':int(np.count_nonzero(changed&~phys)),'max_abs_delta':float(np.max(np.abs(d))),'rms_delta_all_storage':float(np.sqrt(np.mean(d*d))),'all_changed_new_values_zero':bool(np.all(mu1[changed]==0.0)),'changed_old_min':float(np.min(mu0[changed])),'changed_old_max':float(np.max(mu0[changed])),'changed_ghost_positions_ij_old_new_delta':ghost_rows},
  'derived_full_physical_rhs_new_FT_vs_baseline_FT_and_old_CPP':derived,
  'rk_tendency_six_physical_fields_new_vs_baseline':rkphysical,
  'boundary_source_contract':{'advance_mu_t_direct_mu_tend_reads':'only pointwise mu_tend(i,j) in physical i_start:i_end and j_start:j_end loops (module_small_step_em.F:1055 onward; usages at 1112 and 1789). No difference stencil is applied to mu_tend. For this whole-domain periodic-X, symmetric-Y, non-nested/non-specified case, physical mass loop is i=ids:ide-1 and j=jds:jde-1. Ghost values outside that rectangle are not read by those physical updates.', 'separate_specified_or_nested_boundary_update':'not active per this case config; no ghost tendency relaxation/boundary stencil consumes these values.', 'source_sha256':hashlib.sha256(Path('/private/tmp/pr300-corrected-state-20261012/dyn_em/module_small_step_em.F').read_bytes()).hexdigest()},
  'independent_parser_sha256':sha(Path(__file__))}
 OUT.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({'changed_mu_tend':out['mu_tend_ghost_audit'],'derived':derived,'rk':rkphysical},indent=2))
if __name__=='__main__':main()
