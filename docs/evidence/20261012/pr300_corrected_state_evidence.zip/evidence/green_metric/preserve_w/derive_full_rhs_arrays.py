#!/usr/bin/env python3
"""Export physical-owner U/V/MU RHS arrays from a gated paired snapshot capture."""
from __future__ import annotations
import hashlib, importlib.util, json
from pathlib import Path
import numpy as np

E = Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012/green_execution/preserve_w')
OUT = Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012/green_metric/preserve_w')
RUNS = E / 'preserve_w_runs.json'
SOURCE60_GATE = E / 'preserve_w_state_gate.json'

ANALYZER = Path('/Users/yhlee/AD-SDIRK3-review-evidence/seam-cause-acceptance-20261012/analyze_snapshots.py')
SOURCE_ROOT = Path('/private/tmp/pr300-corrected-state-20261012')


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

spec = importlib.util.spec_from_file_location('snapshot_analyzer', ANALYZER)
if spec is None or spec.loader is None:
    raise RuntimeError(f'cannot load authoritative snapshot analyzer: {ANALYZER}')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)

runs = json.loads(RUNS.read_text())
source60_gate = json.loads(SOURCE60_GATE.read_text())
if runs.get('status') != 'completed' or len(runs.get('runs', [])) != 2:
    raise RuntimeError('expected exactly two completed native cases')
labels = {r['label']: r for r in runs['runs']}
ft_run = labels['preserve_w_fortran_rk3_h15']
cpp_run = labels['preserve_w_cpp_ark3_h15']
if ft_run['input_sha256'] != cpp_run['input_sha256'] or ft_run['input_sha256'] != runs['corrected_input_sha256']:
    raise RuntimeError('paired cases do not use identical corrected input')
if ft_run['executable_sha256'] != cpp_run['executable_sha256']:
    raise RuntimeError('paired cases used different executable bytes')
if not source60_gate.get('all_six_actual_call_fields_exact_to_source60') or not source60_gate.get('same_call_state_gates', {}).get('passed'):
    raise RuntimeError('preserve-W source-60 or same-call state gate failed')
ft_path = Path(ft_run['workdir']) / 'wrf_full_rhs_snapshot.bin'
cpp_path = Path(cpp_run['workdir']) / 'port_full_rhs_snapshot.bin'
if sha(ft_path) != ft_run['artifacts']['wrf_full_rhs_snapshot.bin']['sha256']:
    raise RuntimeError('Fortran snapshot does not match the run receipt')
if sha(cpp_path) != cpp_run['artifacts']['port_full_rhs_snapshot.bin']['sha256']:
    raise RuntimeError('C++ snapshot does not match the run receipt')
# Reuse the established analyzer's own end-to-end gate and authoritative readers.
rechecked = a.analyze(ft_path, cpp_path, SOURCE_ROOT)
if not rechecked.get('comparison_available') or not rechecked.get('state_gate', {}).get('passed'):
    raise RuntimeError('reloaded captures fail the exact-state/source analysis gate')
ft_meta, ft = a.read_fortran(ft_path)
cpp_meta, cpp_state, cpp_rhs = a.read_cpp(cpp_path)
dims = tuple(cpp_meta['dims_nx_ny_nz_nxu_nyv_nzw'])
ft_state = a.logical_fortran_state(ft_meta, ft, dims)
phys_nx, phys_ny, phys_nz = a.physical_dimensions(dims, ft_meta)
b = ft_meta['bounds']
i0, j0, k0 = b['ids'], b['jds'], b['kds']
ny_store, nx_store, nxu_store, nyv_store = dims[1], dims[0], dims[3], dims[4]

def s3(name, i1, j1):
    return a._slice3(ft[name], b, i0=i0, i1=i1, k0=k0, k1=k0+phys_nz, j0=j0, j1=j1).astype(np.float64)
def s2(name, i1, j1):
    return a._slice2(ft[name], b, i0=i0, i1=i1, j0=j0, j1=j1).astype(np.float64)

continuity = a.calc_mu_dot(ft_meta, ft, dims)
c1h = ft['c1h'][k0-b['kms']:k0-b['kms']+phys_nz].astype(np.float64)
c2h = ft['c2h'][k0-b['kms']:k0-b['kms']+phys_nz].astype(np.float64)
# Use the analyzer's reconstructed WRF mass-coordinate conversion on captured tendencies.
muu = s2('muu', i0+nxu_store, j0+ny_store)[:phys_ny, :phys_nx+1]
muv = s2('muv', i0+nx_store, j0+nyv_store)[:phys_ny+1, :phys_nx]
msfuy = s2('msfuy', i0+nxu_store, j0+ny_store)[:phys_ny, :phys_nx+1]
msfvx = s2('msfvx', i0+nx_store, j0+nyv_store)[:phys_ny+1, :phys_nx]
lu = c1h[None,:,None]*muu[:,None,:] + c2h[None,:,None]
lv = c1h[None,:,None]*muv[:,None,:] + c2h[None,:,None]
ru_tend = s3('ru_tend', i0+nxu_store, j0+ny_store)[:phys_ny, :, :phys_nx+1]
rv_tend = s3('rv_tend', i0+nx_store, j0+nyv_store)[:phys_ny+1, :, :phys_nx]
u_conv = ft_state['u'][:phys_ny, :, :phys_nx+1].astype(np.float64)
v_conv = ft_state['v'][:phys_ny+1, :, :phys_nx].astype(np.float64)
ft_u_full = a.fortran_tendency_to_physical(ru_tend, u_conv, c1h, continuity['mu_u_dot'], msfuy, lu)
ft_v_full = a.fortran_tendency_to_physical(rv_tend, v_conv, c1h, continuity['mu_v_dot'], msfvx, lv)
# Owner masks: omit periodic closing U face and physical symmetric-y V boundary rows.
ft_u = ft_u_full[:, :, :phys_nx]
cpp_u = cpp_rhs['u'][:phys_ny, :, :phys_nx].astype(np.float64)
du = cpp_u - ft_u
ft_v = ft_v_full[1:phys_ny, :, :phys_nx]
cpp_v = cpp_rhs['v'][1:phys_ny, :, :phys_nx].astype(np.float64)
dv = cpp_v - ft_v
ft_mu = continuity['mu_dot'][:phys_ny, :phys_nx].astype(np.float64)
cpp_mu = cpp_rhs['mu'][:phys_ny, 0, :phys_nx].astype(np.float64)
dmu = cpp_mu - ft_mu
arrays = {'fortran_u_m_s2': ft_u, 'cpp_u_m_s2': cpp_u, 'delta_u_cpp_minus_fortran_m_s2': du,
          'fortran_v_m_s2': ft_v, 'cpp_v_m_s2': cpp_v, 'delta_v_cpp_minus_fortran_m_s2': dv,
          'fortran_mu_pa_s': ft_mu, 'cpp_mu_pa_s': cpp_mu, 'delta_mu_cpp_minus_fortran_pa_s': dmu}
npz = OUT / 'physical_rhs_arrays.npz'
np.savez_compressed(npz, **arrays)

def metric(x):
    x = np.asarray(x, dtype=np.float64)
    return {'count': int(x.size), 'rms': float(np.sqrt(np.mean(x*x))), 'max_abs': float(np.max(np.abs(x))), 'finite': bool(np.isfinite(x).all())}
metrics = {'u': metric(du), 'v': metric(dv), 'mu': metric(dmu)}
source60 = {
    'status': 'all six actual call fields are bitwise equal to the archived source-60 state; paired Fortran/C++ same-call gate passes',
    'receipt_path': str(SOURCE60_GATE),
    'receipt_sha256': sha(SOURCE60_GATE),
    'full_six_field_source60_exact': source60_gate['all_six_actual_call_fields_exact_to_source60'],
    'same_call_state_gates_passed': source60_gate['same_call_state_gates']['passed'],
    'source_timestamp': source60_gate['source_and_input_metadata']['source_timestamp'],
    'source_WRFOUT_sha256': source60_gate['source_and_input_metadata']['source_file']['sha256'],
    'corrected_input_sha256': runs['corrected_input_sha256'],
    'input_use_w': True,
}
report = {
    'schema': 'pr300-physical-full-rhs-arrays-v1',
    'scope': 'same-state assembled U/V/MU physical RHS only; W/PH/T RHS not compared; no isolated V-PGF claim',
    'status': 'preserve-W Full U/V/MU comparison gated by exact physical six-state and periodic U seam checks',
    'state_gate': rechecked['state_gate'],
    'same_call_context_gate': {'status': 'paired full-RHS exact physical six-state and periodic U seam checked by reused analyzer', 'passed': rechecked['state_gate']['passed']},
    'source60_gate': source60,
    'run_receipt': {'path': str(RUNS), 'sha256': sha(RUNS), 'status': runs['status'], 'labels': [ft_run['label'], cpp_run['label']], 'input_sha256': ft_run['input_sha256'], 'executable_sha256': ft_run['executable_sha256']},
    'snapshots': {'fortran': {'path': str(ft_path), 'sha256': sha(ft_path)}, 'cpp': {'path': str(cpp_path), 'sha256': sha(cpp_path)}},
    'physical_grid': {'nx': phys_nx, 'ny': phys_ny, 'nz': phys_nz, 'u_shape': list(du.shape), 'v_shape': list(dv.shape), 'mu_shape': list(dmu.shape), 'owner_masks': 'U y<ny,x<nx (periodic closing x duplicate excluded); V 1<=y<ny,x<nx (symmetric boundary rows excluded); MU all physical cells'},
    'units': {'u': 'm/s^2', 'v': 'm/s^2', 'mu': 'Pa/s'},
    'metrics_delta_cpp_minus_fortran': metrics,
    'metric_relationship': 'RMS and max absolute values are computed from elementwise CPP-minus-Fortran delta arrays; no difference of norms is used.',
    'arrays_npz': {'path': str(npz), 'sha256': sha(npz), 'keys': sorted(arrays)},
    'analyzer_source': {'path': str(ANALYZER), 'sha256': sha(ANALYZER)},
    'source_revision': rechecked['source_revision'],
}
json_path = OUT / 'physical_rhs_arrays.json'
json_path.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps(report, indent=2, sort_keys=True))
