#!/usr/bin/env python3
"""Independent raw-binary audit of corrected-state Full, PGF, Hdiff and Vdiff U."""
import hashlib,json,struct
from pathlib import Path
import numpy as np
E=Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012/green_execution/preserve_w/captures/preserve_w')
OUT=Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012/red_preserve_w_raw_check.json')
FORDER=('u2','v2','w2','ph2','t2','mu2','ru_tend','rv_tend','mu_tend','ru','rv','muu','muv','mut','dnw','c1h','c2h','msfux','msfuy','msfvx','msfvy','msftx','msfty')
F3=set(('u2','v2','w2','ph2','t2','ru_tend','rv_tend','ru','rv'))
F2=set(('mu2','mu_tend','muu','muv','mut','msfux','msfuy','msfvx','msfvy','msftx','msfty'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def rms(a): return float(np.sqrt(np.mean(np.asarray(a,dtype=np.float64)**2)))
def metric(a):
 a=np.asarray(a,dtype=np.float64)
 return {'count':int(a.size),'rms':rms(a),'max_abs':float(np.max(np.abs(a)))}
def parse_fortran_full(p):
 b=p.read_bytes(); ver,=struct.unpack_from('<I',b,0); assert ver==1
 bounds=struct.unpack_from('<12i',b,4); rdx,rdy=struct.unpack_from('<2f',b,52)
 ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme=bounds
 ni,nj,nk=ime-ims+1,jme-jms+1,kme-kms+1; n3=ni*nj*nk;n2=ni*nj
 o=60; fs={}
 for name in FORDER:
  n=n3 if name in F3 else n2 if name in F2 else nk
  a=np.frombuffer(b,dtype='<f4',count=n,offset=o)
  fs[name]=a.reshape((nj,nk,ni)) if name in F3 else a.reshape((nj,ni)) if name in F2 else a
  o+=4*n
 assert o==len(b),(o,len(b))
 return {'bounds':bounds,'rdx':float(rdx),'rdy':float(rdy),'f':fs,'sha256':sha(p)}
def parse_cpp_full(p):
 b=p.read_bytes(); head=struct.unpack_from('<7i',b,0); ver,nx,ny,nz,nxu,nyv,nzw=head; assert ver==1
 shapes={'u':(ny,nz,nxu),'v':(nyv,nz,nx),'w':(ny,nzw,nx),'ph':(ny,nzw,nx),'t':(ny,nz,nx),'mu':(ny,1,nx)}
 o=28; state={}; rhs={}
 for out in (state,rhs):
  for name,sh in shapes.items():
   n=int(np.prod(sh));out[name]=np.frombuffer(b,dtype='<f4',count=n,offset=o).reshape(sh);o+=4*n
 assert o==len(b),(o,len(b))
 return {'dims':head[1:],'state':state,'rhs':rhs,'sha256':sha(p)}
def parse_pgf_ft(p):
 b=p.read_bytes();ver,=struct.unpack_from('<i',b,0);assert ver==1
 bounds=struct.unpack_from('<12i',b,4);rkstep,nmoist=struct.unpack_from('<2i',b,52); scalars=struct.unpack_from('<7f',b,60);nh,tl=struct.unpack_from('<2i',b,88)
 ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme=bounds
 ni,nj,nk=ime-ims+1,jme-jms+1,kme-kms+1;n3=ni*nj*nk;n2=ni*nj;o=96;f={}
 for name in ('ru_before','rv_before','u','v','w','t','ph'):
  f[name]=np.frombuffer(b,dtype='<f4',count=n3,offset=o).reshape(nj,nk,ni);o+=4*n3
 f['mu']=np.frombuffer(b,dtype='<f4',count=n2,offset=o).reshape(nj,ni);o+=4*n2
 for name in ('p','pb','al','alt','php','cqu'):
  f[name]=np.frombuffer(b,dtype='<f4',count=n3,offset=o).reshape(nj,nk,ni);o+=4*n3
 f['muu']=np.frombuffer(b,dtype='<f4',count=n2,offset=o).reshape(nj,ni);o+=4*n2
 for name in ('c1h','c2h'):
  f[name]=np.frombuffer(b,dtype='<f4',count=nk,offset=o);o+=4*nk
 for name in ('msfux','msfuy'):
  f[name]=np.frombuffer(b,dtype='<f4',count=n2,offset=o).reshape(nj,ni);o+=4*n2
 for name in ('rdnw','fnm','fnp'):
  f[name]=np.frombuffer(b,dtype='<f4',count=nk,offset=o);o+=4*nk
 for name in ('ru_after','rv_after'):
  f[name]=np.frombuffer(b,dtype='<f4',count=n3,offset=o).reshape(nj,nk,ni);o+=4*n3
 assert o==len(b),(o,len(b))
 return {'bounds':bounds,'f':f,'sha256':sha(p),'n_moist':nmoist,'nonhydro':bool(nh),'rkstep':rkstep}
def parse_pgf_cpp(p):
 b=p.read_bytes();head=struct.unpack_from('<8i',b,0);ver,nx,ny,nz,nxu,nyv,nzw,nstate=head;assert ver==2
 dims=(ny,nz,nxu); n=int(np.prod(dims)); o=36
 state={}
 sh={'u':(ny,nz,nxu),'v':(nyv,nz,nx),'w':(ny,nzw,nx),'ph':(ny,nzw,nx),'t':(ny,nz,nx),'mu':(ny,nx)}
 for name in ('u','v','w','ph','t','mu'):
  cnt=int(np.prod(sh[name]));state[name]=np.frombuffer(b,dtype='<f8',count=cnt,offset=o).reshape(sh[name]);o+=8*cnt
 pgf={}
 for name in ('increment','mass','unscaled','alpha'):
  pgf[name]=np.frombuffer(b,dtype='<f8',count=n,offset=o).reshape(dims);o+=8*n
 assert o==len(b),(o,len(b))
 return {'state':state,'pgf':pgf,'sha256':sha(p)}
def parse_fortran_hdiff(p):
 b=p.read_bytes();ver,=struct.unpack_from('<I',b,0);assert ver==1
 bounds=struct.unpack_from('<12i',b,4);rdx,rdy=struct.unpack_from('<2f',b,52)
 ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme=bounds
 ni,nj,nk=ime-ims+1,jme-jms+1,kme-kms+1;n3=ni*nj*nk;o=60
 before=np.frombuffer(b,dtype='<f4',count=n3,offset=o).reshape(nj,nk,ni);o+=4*n3
 after=np.frombuffer(b,dtype='<f4',count=n3,offset=o).reshape(nj,nk,ni);o+=4*n3
 assert len(b)==o+32*n3,(len(b),o+32*n3)
 return {'bounds':bounds,'before':before,'after':after,'rdx':rdx,'rdy':rdy,'sha256':sha(p)}
def parse_fortran_vbefore(p):
 b=p.read_bytes();ver,=struct.unpack_from('<I',b,0);assert ver==1
 bounds=struct.unpack_from('<12i',b,4)
 ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme=bounds
 ni,nj,nk=ime-ims+1,jme-jms+1,kme-kms+1;n3=ni*nj*nk;o=60
 ru=np.frombuffer(b,dtype='<f4',count=n3,offset=o).reshape(nj,nk,ni)
 return {'bounds':bounds,'ru':ru,'sha256':sha(p)}
def parse_cpp_increment(p):
 b=p.read_bytes();ver,ny,nz,nxu=struct.unpack_from('<4i',b,0);assert ver==1
 sh=(ny,nz,nxu);n=int(np.prod(sh));o=16
 inc=np.frombuffer(b,dtype='<f8',count=n,offset=o).reshape(sh);o+=8*n
 mass=np.frombuffer(b,dtype='<f8',count=n,offset=o).reshape(sh);o+=8*n
 assert o==len(b)
 return inc,mass,sha(p)
def stats(a):
 a=np.asarray(a,dtype=np.float64)
 out={'all_owners':metric(a),'min':float(np.min(a)),'max':float(np.max(a))}
 if a.ndim==3: out['x0_included']=metric(a[:,:,0:1])
 return out
def main():
 ft_dir=E/'preserve_w_fortran_rk3_h15'; cp_dir=E/'preserve_w_cpp_ark3_h15'
 ff=parse_fortran_full(ft_dir/'wrf_full_rhs_snapshot.bin'); cf=parse_cpp_full(cp_dir/'port_full_rhs_snapshot.bin')
 pf=parse_pgf_ft(ft_dir/'wrf_u_pgf_snapshot.bin'); pc=parse_pgf_cpp(cp_dir/'port_u_pgf_snapshot.bin')
 hf=parse_fortran_hdiff(ft_dir/'wrf_u_hdiff_snapshot.bin'); vf=parse_fortran_vbefore(ft_dir/'wrf_u_vdiff_before.bin')
 hc,hm,hsha=parse_cpp_increment(cp_dir/'port_hdiff_u_snapshot.bin'); vc,vm,vsha=parse_cpp_increment(cp_dir/'port_vdiff_u_snapshot.bin')
 b=ff['bounds'];ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme=b
 nx,ny,nz=ide-ids,jde-jds,kde-kds; assert (nx,ny,nz)==(16,16,16)
 i0=ids-ims;j0=jds-jms;k0=kds-kms
 sl3=lambda a,jend=ny,kend=nz,iend=nx: a[j0:j0+jend,k0:k0+kend,i0:i0+iend]
 sl2=lambda a,jend=ny,iend=nx: a[j0:j0+jend,i0:i0+iend]
 f=ff['f']; c=cf['rhs'];
 # Source-output conversion: U full is coupled RU plus product-rule mu-face term.
 ru=sl3(f['ru_tend'],ny,nz,nx+1).astype(np.float64); u=sl3(f['u2'],ny,nz,nx+1).astype(np.float64)
 muu=sl2(f['muu'],ny,nx+1).astype(np.float64); msfuy=sl2(f['msfuy'],ny,nx+1).astype(np.float64)
 c1=f['c1h'][k0:k0+nz].astype(np.float64);c2=f['c2h'][k0:k0+nz].astype(np.float64);dnw=f['dnw'][k0:k0+nz].astype(np.float64)
 # Mass-flux divergence from captured total RU/RV, map factors and signed dnw.
 ru_flux=sl3(f['ru'],ny,nz,nx+1).astype(np.float64);rv_flux=sl3(f['rv'],ny+1,nz,nx).astype(np.float64)
 msftx=sl2(f['msftx']).astype(np.float64);msfty=sl2(f['msfty']).astype(np.float64)
 dmdt=np.sum(dnw[None,:,None]*(msftx*msfty)[:,None,:]*(ff['rdx']*(ru_flux[:,:,1:]-ru_flux[:,:,:-1])+ff['rdy']*(rv_flux[1:]-rv_flux[:-1])),axis=1)
 mu_tend=sl2(f['mu_tend']).astype(np.float64);mu_dot=dmdt+mu_tend
 mu_u=np.empty((ny,nx+1),dtype=np.float64);mu_u[:,0]=.5*(mu_dot[:,-1]+mu_dot[:,0]);mu_u[:,1:nx]=.5*(mu_dot[:,:-1]+mu_dot[:,1:]);mu_u[:,nx]=mu_u[:,0]
 mu_v=np.empty((ny+1,nx),dtype=np.float64);mu_v[0,:]=mu_dot[0,:];mu_v[1:ny,:]=.5*(mu_dot[:-1,:]+mu_dot[1:,:]);mu_v[ny,:]=mu_dot[-1,:]
 layer=c1[None,:,None]*muu[:,None,:]+c2[None,:,None]
 ft_full=(ru*msfuy[:,None,:]-u*c1[None,:,None]*mu_u[:,None,:])/layer
 cpp_full=c['u'][:ny,:,:nx].astype(np.float64)
 full_delta=cpp_full-ft_full[:,:,:nx]
 ft_mu_product_physical=-(u*c1[None,:,None]*mu_u[:,None,:])/layer
 rv_full=sl3(f['rv_tend'],ny+1,nz,nx).astype(np.float64); vstate=sl3(f['v2'],ny+1,nz,nx).astype(np.float64)
 muv=sl2(f['muv'],ny+1,nx).astype(np.float64);msfvx=sl2(f['msfvx'],ny+1,nx).astype(np.float64)
 lv=c1[None,:,None]*muv[:,None,:]+c2[None,:,None]
 ft_v_full=(rv_full*msfvx[:,None,:]-vstate*c1[None,:,None]*mu_v[:,None,:])/lv
 cpp_v_full=c['v'][1:ny,:,:nx].astype(np.float64)
 full_v_delta=cpp_v_full-ft_v_full[1:ny,:,:]
 full_mu_delta=c['mu'][:ny,0,:nx].astype(np.float64)-mu_dot
 # Partial isolated PGF: endpoints widen before differencing; no mu-dot term.
 pff=pf['f']; jp=jds-pf['bounds'][8]; ip=ids-pf['bounds'][6]; kp=kds-pf['bounds'][10]
 pgf_dru=(pff['ru_after'][jp:jp+ny,kp:kp+nz,ip:ip+nx].astype(np.float64)-pff['ru_before'][jp:jp+ny,kp:kp+nz,ip:ip+nx].astype(np.float64))
 pgf_l=(pff['c1h'][kp:kp+nz].astype(np.float64)[None,:,None]*pff['muu'][jp:jp+ny,ip:ip+nx].astype(np.float64)[:,None,:]+pff['c2h'][kp:kp+nz].astype(np.float64)[None,:,None])
 pgf_ft=pgf_dru*pff['msfuy'][jp:jp+ny,ip:ip+nx].astype(np.float64)[:,None,:]/pgf_l
 pgf_cp=pc['pgf']['increment'][:ny,:,:nx]/pc['pgf']['mass'][:ny,:,:nx]
 pgf_delta=pgf_cp-pgf_ft
 # Hdiff/vdiff are increments, not total tendencies: convert only each increment.
 hru=(hf['after'].astype(np.float64)-hf['before'].astype(np.float64)); hru=sl3(hru,ny,nz,nx)
 vru=(hf['before'].astype(np.float64)-vf['ru'].astype(np.float64)); vru=sl3(vru,ny,nz,nx)
 hft=hru*msfuy[:,:nx][:,None,:]/layer[:,:,:nx]
 vft=vru*msfuy[:,:nx][:,None,:]/layer[:,:,:nx]
 hcpp=hc[:ny,:,:nx]/hm[:ny,:,:nx];vcpp=vc[:ny,:,:nx]/vm[:ny,:,:nx]
 hdelta=hcpp-hft;vdelta=vcpp-vft
 residual_hv=full_delta-hdelta-vdelta
 residual=residual_hv-pgf_delta
 projection={'cosine':float(np.sum(residual_hv*pgf_delta)/np.sqrt(np.sum(residual_hv**2)*np.sum(pgf_delta**2))),
  'squared_residual_reduction_pct':float((1.0-np.sum(residual**2)/np.sum(residual_hv**2))*100.0)}
 cpp_mass=pc['pgf']['mass'][:ny,:,:nx]
 ft_mass=layer[:,:,:nx]
 cpp_hmass=hm[:ny,:,:nx]; cpp_vmass=vm[:ny,:,:nx]
 # U owners = y0..15,k0..15,x0..15, retaining periodic face 0, dropping closing x=16.
 assert full_delta.shape==pgf_delta.shape==hdelta.shape==vdelta.shape==(16,16,16)
 out={'schema':'pr300-independent-raw-preserve-w-full-pgf-diffusion-check-v1','scope':'Independent direct binary parser and source-unit reconstruction; no captured analyzer callbacks. Every cross-implementation subtraction occurs in float64 after reading/widening raw f32, except native CPP PGF/diffusion captures which are f64. Unique 4096 U owners retain x-face 0 and exclude duplicated closing x-face 16.',
  'source_receipts':{},'formula_notes':{'FT_full_u':'(RU_tend*MSFUY - U*C1H*mu_u_dot)/(C1H*Muu+C2H); mu_u_dot comes from raw RU/RV mass-flux divergence plus captured MU_TEND, periodic x-face average.',
  'FT_partial_PGF_HD_VD':'isolated coupled increment * MSFUY / (C1H*Muu+C2H), no U*C1H*mu_u_dot product-rule term because each capture isolates only that increment.',
  'CPP_full_u':'captured full RHS is already physical U acceleration.', 'CPP_partial':'captured coupled increment / its captured velocity mass.'},
  'dimensions_jki':[ny,nz,nx],'owner_count':int(full_delta.size),'fortran_mu_dot':stats(mu_dot),'fortran_mu_u_dot':stats(mu_u),
  'full_CPP_minus_FT_m_per_s2':stats(full_delta),'full_CPP_minus_FT_v_m_per_s2':stats(full_v_delta),'full_CPP_minus_FT_mu_Pa_per_s':stats(full_mu_delta),'ft_full_mu_product_rule_physical_m_per_s2':stats(ft_mu_product_physical[:,:,:nx]),'pgf_CPP_minus_FT_m_per_s2':stats(pgf_delta),
  'hdiff_CPP_minus_FT_m_per_s2':stats(hdelta),'vdiff_CPP_minus_FT_m_per_s2':stats(vdelta),
  'full_minus_hdiff_vdiff_R_m_per_s2':stats(residual_hv),'full_minus_pgf_hdiff_vdiff_m_per_s2':stats(residual),'pgf_projection_on_R':projection,
  'mass_unit_crosschecks':{'ft_layer_mass_Pa':stats(ft_mass),'cpp_pgf_mass_Pa':stats(cpp_mass),'cpp_hdiff_mass_minus_pgf_mass_Pa':metric(cpp_hmass-cpp_mass),'cpp_vdiff_mass_minus_pgf_mass_Pa':metric(cpp_vmass-cpp_mass),'cpp_pgf_mass_minus_FT_layer_mass_Pa':metric(cpp_mass-ft_mass)},
  'component_sizes':{'ft_pgf_delta_RU':stats(pgf_dru),'ft_hdiff_delta_RU':stats(hru),'ft_vdiff_delta_RU':stats(vru)},
  'captured_paths':{},'independent_parser_sha256':sha(Path(__file__))}
 paths={'ft_full':ft_dir/'wrf_full_rhs_snapshot.bin','cpp_full':cp_dir/'port_full_rhs_snapshot.bin','ft_pgf':ft_dir/'wrf_u_pgf_snapshot.bin','cpp_pgf':cp_dir/'port_u_pgf_snapshot.bin','ft_hdiff':ft_dir/'wrf_u_hdiff_snapshot.bin','ft_vdiff_before':ft_dir/'wrf_u_vdiff_before.bin','cpp_hdiff':cp_dir/'port_hdiff_u_snapshot.bin','cpp_vdiff':cp_dir/'port_vdiff_u_snapshot.bin'}
 out['captured_paths']={k:{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for k,p in paths.items()}
 runrec=Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012/green_execution/preserve_w/preserve_w_runs.json')
 rr=json.loads(runrec.read_text())
 out['source_receipts']={'run_receipt':{'path':str(runrec),'sha256':sha(runrec)},'input_sha256':rr['corrected_input_sha256'],'target_head':rr['target_head'],'executable_sha256':rr['runs'][0]['executable_sha256']}
 OUT.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
