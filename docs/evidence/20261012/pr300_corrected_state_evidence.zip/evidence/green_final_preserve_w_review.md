# Final Green review: PR300 preserve-W report

Local timestamp: 2026-10-12 16:04:14 JST (+0900)

Reviewed `docs/(202610121600)_pr300_input_w_and_actual_rhs.md` against the preserved-W two-case receipt, state/context gates, default-off physical-acceptance append, H/V and PGF component records, and `dyn_em/start_em.F`.

No blocking numerical overclaim or source-contract error found. The report correctly distinguishes the time-zero cold input from a checkpoint, limits the claim to first-call state preservation, keeps full RHS and forecast/AD closure open, and reports the frozen V3 reference as unqualified. Its source explanation matches the opt-in full-column W scan, default-off surface-only scan, and zero-field fallback. Five-call accounting is supported by the two PR298 baseline calls, two preserve-W calls, and one rebuilt default-off control; the preserve-W input/executable hashes and completion codes match the table.

One evidence-traceability omission: `off_regression_runs.json` still has top-level `status: failed`, while the append-only `off_regression_physical_acceptance.json` records completion and physical-owner PASS (with raw artifact parity still FAIL). The report states both conclusions accurately, but does not call out that the latter is the completion/physical acceptance supplement to the stale original manifest. A short sentence or direct link to the append would prevent a reader from mistaking the stale manifest status for a failed launch.

No edits, builds, or model runs were made during this review.
