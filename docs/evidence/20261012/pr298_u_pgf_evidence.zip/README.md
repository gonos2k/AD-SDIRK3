# PR298 evidence

Producer source binding: evidence/producer_source_binding.json. Native runs recorded base 51527694 plus exact source hashes; the committed source has identical bytes. Executable/library bytes remain local; recorded hashes are observations, not bundled-byte rehashes.

Portable verification: `python3 -m pip install numpy netCDF4` if unavailable, then `python3 verify_bundle.py`. This hashes every payload, reads both actual same-call PGF/Full pairs, checks state equality and prior residual linkage, reproduces every final pressure-budget array, and runs three P2 contract tests. It performs no native/model execution. The portable primary analyzer differs from the original only in root paths.

`evidence/` holds original run receipts, inputs, snapshots, logs and final agent analyses. Original auxiliary investigation scripts retain historical machine paths; only verify_bundle.py and its primary analyzer/P2-test path are portable entrypoints. The before/after PGF subtraction is a diagnostic budget, not a changed production RHS. The stored remainder, six-equation parity and RK3 reference/forecast acceptance remain open. Existing V3's 24 failed rows remain unchanged. Earlier corrected/superseded replay work is described in final reviews and retained locally, not a source for current claims.
