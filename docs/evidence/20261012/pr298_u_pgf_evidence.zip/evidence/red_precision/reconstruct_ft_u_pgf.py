#!/usr/bin/env python3
"""Reconstruct the source-defined four-term WRF U-PGF from preserved raw FT arrays.

This is a read-only, FP64 postprocessing reconstruction from FP32 captures. It does
not model internal FP32 operation rounding and does not attribute a C++ mismatch.
"""
from __future__ import annotations
import hashlib, json, struct, sys, re
import subprocess
from pathlib import Path
import numpy as np
from netCDF4 import Dataset

EVIDENCE=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-rhs-contract-20261011')
OUT=Path(__file__).with_name('ft_u_pgf_reconstruction.json')
sys.path.insert(0,str(EVIDENCE)); import analyze_snapshots as AS
CASES={
 'rk3_h3p75_dump_on':EVIDENCE/'initial_snapshot_runs/rk3_h3p75_dump_on',
 'stored_rk3_h15_dump_on':EVIDENCE/'initial_snapshot_runs/stored_rk3_h15_dump_on',
}

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def rms(x): return float(np.sqrt(np.mean(np.asarray(x,dtype=np.float64)**2)))
def stats(x):
    a=np.asarray(x,dtype=np.float64)
    return {'rms':rms(a),'max_abs':float(np.max(np.abs(a))),'seam_x0_rms':rms(a[:,:,0]),'seam_x0_max_abs':float(np.max(np.abs(a[:,:,0])))}
def percentiles(a):
    x=np.asarray(a,dtype=np.float64).ravel(); x=x[np.isfinite(x)]
    return {str(p):float(np.percentile(x,p)) for p in (50,90,99,99.9,100)}
def periodic_raw_check(a,axis=-1):
    # Physical i=1..16; west ghost i=0 aliases i=16 and east i=17 aliases i=1.
    # Raw arrays have ims=-4, so these are offsets 4,20,21,5.
    west=a[...,4]; last=a[...,20]; east=a[...,21]; first=a[...,5]
    return {'west_ghost_vs_last_mass_max_abs':float(np.max(np.abs(west.astype('f8')-last.astype('f8')))),
            'east_ghost_vs_first_mass_max_abs':float(np.max(np.abs(east.astype('f8')-first.astype('f8'))))}

def reconstruct(label,run):
    snap=run/'wrf_full_rhs_snapshot.bin'; tend=run/'wrf_rk_tend_dump.bin'; inp=run/'wrfinput_d01'
    nml=run/'namelist.input'
    mp0=bool(re.search(r'(?im)^\s*mp_physics\s*=\s*0\s*,\s*0\s*,\s*0\s*,?',nml.read_text()))
    meta,f=AS.read_fortran(snap); b=meta['bounds']; j0=1-b['jms']; i0=1-b['ims']; k0=1-b['kms']
    # Physical mass owners; PH retains 17 vertical faces.
    ph32=f['ph2'][j0:j0+16,k0:k0+17,i0:i0+16]
    mu32=f['mu2'][j0:j0+16,i0:i0+16]
    muu32=f['muu'][j0:j0+16,i0:i0+16]
    msfux32=f['msfux'][j0:j0+16,i0:i0+16]
    msfuy32=f['msfuy'][j0:j0+16,i0:i0+16]
    c1=f['c1h'][:16]; c2=f['c2h'][:16]
    raw=tend.read_bytes(); ims,ime,jms,jme,kms,kme=struct.unpack_from('>6i',raw)
    ni,nj,nk=ime-ims+1,jme-jms+1,kme-kms+1; n3=ni*nj*nk; n2=ni*nj; o=24+5*4*n3+4*n2
    pfull32=np.frombuffer(raw,dtype='>f4',count=n3,offset=o).reshape(nj,nk,ni); o+=4*n3
    alfull32=np.frombuffer(raw,dtype='>f4',count=n3,offset=o).reshape(nj,nk,ni)
    p32=pfull32[j0:j0+16,k0:k0+16,i0:i0+16]; al32=alfull32[j0:j0+16,k0:k0+16,i0:i0+16]
    with Dataset(inp) as ds:
        get=lambda n:np.asarray(ds.variables[n][0],dtype=np.float32)
        # NetCDF [k,j,i] -> physical owner order [j,k,i].
        pb32=np.transpose(get('PB'),(1,0,2)); alb32=np.transpose(get('ALB'),(1,0,2)); phb32=np.transpose(get('PHB'),(1,0,2))
        rdnw32=get('RDNW'); fnm32=get('FNM'); fnp32=get('FNP')
        cf1,cf2,cf3=(float(get(x).reshape(-1)[0]) for x in ('CF1','CF2','CF3'))
    # Reconstruct Fortran 4-term dpx in float64 from the stored float32 operands.
    ph=ph32.astype('f8'); p=p32.astype('f8'); al=al32.astype('f8'); mu=mu32.astype('f8')
    pb=pb32.astype('f8'); alb=alb32.astype('f8'); phb=phb32.astype('f8')
    muu=muu32.astype('f8'); msfux=msfux32.astype('f8'); msfuy=msfuy32.astype('f8')
    c1=c1.astype('f8'); c2=c2.astype('f8'); rdnw=rdnw32.astype('f8'); fnm=fnm32.astype('f8'); fnp=fnp32.astype('f8')
    dx=lambda x:x-np.roll(x,1,axis=2)
    sx=lambda x:x+np.roll(x,1,axis=2)
    alt=al+alb
    # Three pressure/geopotential terms in module_big_step_utilities_em.F:2389-2392.
    a_phi=dx(ph[:,1:,:])+dx(ph[:,:-1,:])
    a_alt_dp=sx(alt)*dx(p)
    a_al_dpb=sx(al)*dx(pb)
    # calc_php: full geopotential averaged from adjacent PH/PHB faces.
    php=.5*(phb[:,:-1,:]+phb[:,1:,:]+ph[:,:-1,:]+ph[:,1:,:])
    dphp=dx(php)
    psum=sx(p); nz=16
    dpn=np.zeros((16,nz+1,16),dtype=np.float64)
    dpn[:,0,:]=.5*(cf1*psum[:,0,:]+cf2*psum[:,1,:]+cf3*psum[:,2,:])
    for k in range(1,nz):
        dpn[:,k,:]=.5*(fnm[k]*psum[:,k,:]+fnp[k]*psum[:,k-1,:])
    # top_lid=false, as in the preserved em_b_wave namelist.
    dpn[:,-1,:]=0.0
    bracket4=rdnw[None,:,None]*(dpn[:,1:,:]-dpn[:,:-1,:])-.5*c1[None,:,None]*sx(mu[:,None,:])
    a4=dphp*bracket4
    rdx=float(meta['scalars']['rdx']); map_ratio=msfux/msfuy
    layer=c1[None,:,None]*muu[:,None,:]+c2[None,:,None]
    dpx_phi=.5*rdx*map_ratio[:,None,:]*layer*a_phi
    dpx_alt_dp=.5*rdx*map_ratio[:,None,:]*layer*a_alt_dp
    dpx_al_dpb=.5*rdx*map_ratio[:,None,:]*layer*a_al_dpb
    dpx_fourth=rdx*map_ratio[:,None,:]*a4
    dpx_total=dpx_phi+dpx_alt_dp+dpx_al_dpb+dpx_fourth
    # WRF RU tendency includes -cqu*dpx. Dry cqu=1. Convert only this PGF tendency
    # to physical du/dt: map_y*delta(RU)/L; do not include a mu-dot recoupling.
    q={'phi':-msfuy[:,None,:]*dpx_phi/layer,
       'alt_dP':-msfuy[:,None,:]*dpx_alt_dp/layer,
       'al_dPB':-msfuy[:,None,:]*dpx_al_dpb/layer,
       'fourth':-msfuy[:,None,:]*dpx_fourth/layer,
       'total':-msfuy[:,None,:]*dpx_total/layer}
    abs_primary=np.abs(dpx_phi)+np.abs(dpx_alt_dp)+np.abs(dpx_al_dpb)
    primary=np.abs(dpx_phi+dpx_alt_dp+dpx_al_dpb)
    abs_all=sum(np.abs(x) for x in (dpx_phi,dpx_alt_dp,dpx_al_dpb,dpx_fourth))
    all_sum=np.abs(dpx_total)
    def cancel(a,b):
        r=a/(b+1e-300); idx=np.unravel_index(np.argmax(r),r.shape)
        return {'median':float(np.median(r)), 'p95':float(np.percentile(r,95)),
                'max':float(r[idx]), 'max_location_jki':[int(x) for x in idx],
                'max_location_abs_sum':float(b[idx]),'zero_after_count':int(np.count_nonzero(b==0)),
                'seam_x0_median':float(np.median(r[:,:,0])),'seam_x0_p95':float(np.percentile(r[:,:,0],95)),
                'seam_x0_max':float(np.max(r[:,:,0]))}
    cond123=abs_primary/(primary+1e-300); condall=abs_all/(all_sum+1e-300)
    idx123=np.unravel_index(np.argmax(cond123),cond123.shape); idxall=np.unravel_index(np.argmax(condall),condall.shape)
    # Raw Fortran periodic checks on state and P/AL, including west and east ghosts.
    periodic={
      'P':periodic_raw_check(pfull32[j0:j0+16,k0:k0+16,:]),
      'AL':periodic_raw_check(alfull32[j0:j0+16,k0:k0+16,:]),
      'PH':periodic_raw_check(f['ph2'][j0:j0+16,k0:k0+17,:]),
      'MU':periodic_raw_check(f['mu2'][j0:j0+16,:]),
      'Muu_closing_face_vs_face0_max_abs':float(np.max(np.abs(f['muu'][j0:j0+16,i0+16].astype('f8')-f['muu'][j0:j0+16,i0].astype('f8'))))}
    return {
      'source_files':{str(x):{'sha256':sha(x),'size_bytes':x.stat().st_size} for x in (snap,tend,inp,nml)},
      'snapshot_bounds':meta['bounds'],'rdx_m_inv':rdx,'cqu_assumed':1.0,
      'dry_case_namelist_mp_physics_zero':mp0,
      'cqu_basis':'module_big_step_utilities_em.F calc_cq dry branch sets cqu=1 when there are no moisture scalars; input namelist mp_physics=0',
      'array_shapes':{'physical_mass_P_AL':list(p32.shape),'physical_PH_faces':list(ph32.shape),'physical_U_owners':list(dpx_total.shape)},
      'periodic_raw_closure_max_abs':periodic,
      'pressure_and_alpha_operand_ranges':{'P_pert_Pa':[float(p.min()),float(p.max())],'AL_pert_m3kg':[float(al.min()),float(al.max())],
        'ALT_m3kg':[float(alt.min()),float(alt.max())],'Muu_Pa':[float(muu.min()),float(muu.max())]},
      'coupled_dpx_terms':{name:stats(x) for name,x in {'phi':dpx_phi,'alt_dP':dpx_alt_dp,'al_dPB':dpx_al_dpb,'fourth':dpx_fourth,'total':dpx_total}.items()},
      'physical_acceleration_terms_m_s2':{name:stats(x) for name,x in q.items()},
      'cancellation_conditioning':{'primary_three_terms_sumabs_over_abs_sum':cancel(abs_primary,primary),
        'all_four_terms_sumabs_over_abs_sum':cancel(abs_all,all_sum),
        'formula':'condition=sum(abs(component dpx))/abs(sum(component dpx)); reported over physical U owners'},
      'max_cancellation_term_values_dpx':{
        'primary_hotspot':[float(x[idx123]) for x in (dpx_phi,dpx_alt_dp,dpx_al_dpb)],
        'primary_hotspot_total':float((dpx_phi+dpx_alt_dp+dpx_al_dpb)[idx123]),
        'all_term_hotspot':[float(x[idxall]) for x in (dpx_phi,dpx_alt_dp,dpx_al_dpb,dpx_fourth)],
        'all_term_hotspot_total':float(dpx_total[idxall])},
      'max_abs_physical_total_location_jki':[int(x) for x in np.unravel_index(np.argmax(np.abs(q['total'])),q['total'].shape)],
      'seam_face0_physical_terms_at_j15_k10':{name:float(x[15,10,0]) for name,x in q.items()},
      'scope_note':'Terms are reconstructed in FP64 from exact FP32 FT captures; this verifies the array/formula mapping and magnitudes only, not the internal FP32 rounding path or CPP difference.'
    }

def main():
    head=subprocess.check_output(['git','-C','/private/tmp/pr298-u-pgf-20261012','rev-parse','HEAD'],text=True).strip()
    source_root=Path('/private/tmp/pr298-u-pgf-20261012')
    source_files=('dyn_em/module_big_step_utilities_em.F','dyn_em/module_em.F',
      'external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp',
      'external/libtorch_wrf/sdirk3/wrf_sdirk3_acoustic_substep.cpp',
      'external/libtorch_wrf/sdirk3/wrf_hydrostatic_pressure.h')
    out={'schema':'red-ft-u-pgf-reconstruction-v1','source_pin':{'worktree':'/private/tmp/pr298-u-pgf-20261012','git_head':head,
      'current_worktree_file_sha256':{x:sha(source_root/x) for x in source_files}},
         'source_equations':{'ft':'dyn_em/module_big_step_utilities_em.F:2384-2396','calc_php':'dyn_em/module_big_step_utilities_em.F:1224-1265',
          'cpp_full_branch':'external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp:19426-19505 (pressure/AL/ALT), 19641-19673 (primary 3 terms), 19802-19805 (native NH term 4), 19925-19951 (mass scaling and before-add capture hook)',
          'cpp_shared_kernel':'external/libtorch_wrf/sdirk3/wrf_sdirk3_acoustic_substep.h:257-264',
          'cpp_eos':'external/libtorch_wrf/sdirk3/wrf_hydrostatic_pressure.h:83-112 (calc_p_rho_wrf)',
          'normalization':'analyze_snapshots.py:294-299; physical PGF-only deltaU=(msfuy*(-cqu*dpx))/(c1h*muu+c2h), no mu_dot term'},
         'cpp_full_capture_status':'not present in evidence directory at reconstruction time; no cpp mismatch/causality claim and no output-precision bound assigned yet',
         'cpp_full_capture_layout_from_source':{'port_u_pgf_snapshot.bin':'int32 header {version,ny,nz,nxu}, then float64 increment and velocity_mass tensors, both [j,k,i]; written after mass-basis scale before ru_tend addition at tile_impl.cpp:19936-19961',
          'port_u_pgf_operands_snapshot.bin':'int32 header {version,ny,nz,nx,nzw}, then float64 Ppert, ALpert, ALT, PH tensors, contiguous [j,k,i]; tile_impl.cpp:19963-19989; these are stored FP32 tensors widened to float64, not internal arithmetic intermediates',
          'pre_subtraction_eos_pressure':'not included in sidecar; any bound on pressure-before/after-PB cancellation requires an actual captured pre-subtraction tensor or an explicitly labeled replay, not a reconstructed estimate'},
         'cases':{}}
    for name,run in CASES.items():
        case=reconstruct(name,run); out['cases'][name]=case
    OUT.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps({name:{'physical_total':v['physical_acceleration_terms_m_s2']['total'],
      'primary_condition':v['cancellation_conditioning']['primary_three_terms_sumabs_over_abs_sum'],
      'all_condition':v['cancellation_conditioning']['all_four_terms_sumabs_over_abs_sum'],
      'periodic':v['periodic_raw_closure_max_abs']} for name,v in out['cases'].items()},indent=2))

if __name__=='__main__': main()
