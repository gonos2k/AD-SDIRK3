# U horizontal-PGF formula, normalization, and preserved-array reconstruction

Local time: 2026-10-12 09:01:01 JST  
Worktree: `/private/tmp/pr298-u-pgf-20261012`, HEAD `51527694a3cb139ae43c20532b138e4a65dd6153`.  
Scope: read-only source/array audit. No production edit, build, or model run.

## Formula and units

In `dyn_em/module_big_step_utilities_em.F:2389-2396`, WRF forms a coupled U-tendency contribution from four terms:

- `Aφ = Δx PH(k+1) + Δx PH(k)`
- `Aalt = (ALT_i + ALT_{i−1}) Δx P`
- `Aal = (AL_i + AL_{i−1}) Δx PB`
- `A4 = Δx PHP * (RDNW(k) Δdpn − 0.5*C1H*(MU_i+MU_{i−1}))`

The first three enter `dpx123 = 0.5*rdx*(msfux/msfuy)*(c1h*muu+c2h)*(Aφ+Aalt+Aal)`. The fourth enters `dpx4 = rdx*(msfux/msfuy)*A4`; WRF accumulates `ru_tend -= cqu*(dpx123+dpx4)`. `calc_php` forms `PHP=0.5*(PHB_k+PHB_{k+1}+PH_k+PH_{k+1})` at `module_big_step_utilities_em.F:1244-1265`; `dpn` uses the captured pressure plus `CF1/2/3`, `FNM/FNP` and has a zero top when `top_lid` is false.

For the **PGF-only physical acceleration**, apply the existing coupled-tendency conversion and set its `mu_dot` arm to zero:

`u_dot_PGF = −cqu * msfuy * (dpx123+dpx4)/(c1h*muu+c2h)`.

This is `map_y * ΔRU / L`; the full state-RHS conversion's `−u*c1h*mu_u_dot/L` term does not belong in a PGF-only operand delta. The exact conversion is independently encoded at `analyze_snapshots.py:294-299`. Here `muu` has WRF column-mass units of Pa, and the cancellation of the common `(c1h*muu+c2h)` factor in `dpx123` leaves the physical primary-term sensitivity `−0.5*cqu*msfux*rdx*(Aφ+Aalt+Aal)`.

The Fortran opt1 diagnosis is `AL=−(ALB*C1H*MU + RDNW*ΔPH)/(C1H*MUTS+C2H)` at `module_big_step_utilities_em.F:1025-1031`; `ALT=AL+ALB` at `module_big_step_utilities_em.F:910-949`; dry `P=p0*(Rd*(t0+T)/(p0*ALT))^(cp/cv)−PB` at `module_big_step_utilities_em.F:1084-1094`. The actual C++ target is the canonical `RhsMode::Full` path, not the alternate split-explicit call to `acoustic::horizontal_pgf`. At `wrf_sdirk3_tile_unified_impl.cpp:19426-19505`, it obtains `p_pert`, `AL`, and `ALT` through `calc_p_rho_wrf` (`wrf_hydrostatic_pressure.h:83-112`). It then forms the three primary terms at `wrf_sdirk3_tile_unified_impl.cpp:19641-19673` via the shared `horizontal_pgf_primary` (`wrf_sdirk3_acoustic_substep.h:257-264`), adds native nonhydrostatic term 4 at `:19802-19805`, applies cqu and the WRF-mass basis conversion at `:19869` and `:19925-19933`, and captures after that scale but before addition at `:19936-19951`. C++ `calc_p_rho_wrf` computes geometric `ALT` and the same nonlinear EOS family; under matching base-alpha and signed-RDNW relations its `ALT` is algebraically equivalent to Fortran `AL+ALB`. Actual operation order and captured operands still need direct comparison.

## Preserved Fortran array check

The script [`reconstruct_ft_u_pgf.py`](reconstruct_ft_u_pgf.py) reconstructs `dpx123`, `dpx4`, and the normalized PGF-only acceleration in FP64 from the exact stored FP32 pressure, alpha, PH, MU, mass, map, and vertical-metric arrays. Inputs are the preserved big-endian RK tendency dumps plus full-RHS snapshots and their run-local `wrfinput_d01`; all file hashes are in [`ft_u_pgf_reconstruction.json`](ft_u_pgf_reconstruction.json).

Both preserved cases pass raw x-ghost closure exactly for P, AL, PH and MU, and `Muu`'s closing face equals face 0 exactly. The reconstruction retains all 16 unique U owners including face 0; the close face is represented by that same periodic value. This verifies the physical seam mapping independently of C++ packing.

| Preserved FT case | normalized PGF RMS (m/s²) | largest primary cancellation ratio `sum|Aφ,Aalt,Aal|/|sum|` (all owners) | p95 ratio | seam-face max ratio |
|---|---:|---:|---:|---:|
| RK3 h=3.75, initial | 3.68529e-4 | 30.53 | 1.018 | 21.22 |
| stored RK3 h=15 | 3.68169e-4 | 674.08 | 1.467 | 31.11 |

The maxima occur at near-zero post-sums; medians are 1.000 and 1.0009. These summarize this reconstructed Fortran field, not a CPP-minus-Fortran error budget. `AL*ΔPB` is exactly zero in these two cases because `PB` is x-uniform. At `(j=15,k=10,x-face0)` the h=3.75 physical terms are `phi=+1.03870e-4`, `ALT*ΔP=−0`, `AL*ΔPB=0`, `fourth=+2.69206e-11 m/s²`; this is not the cancellation hotspot.

## C++ pressure/EOS comparison status

In the canonical Full path, `calc_p_rho_wrf` promotes the FP32 state and coefficients to FP64, computes `AL`, `ALT`, and the nonlinear EOS absolute pressure, subtracts `p_base` in FP64, then casts `AL`, `ALT`, and `P'` back to the input dtype. The subsequent horizontal-PGF primary operator consumes those stored-dtype tensors; its native nonhydrostatic term 4 is added before the mass-basis conversion. The corresponding Fortran opt1 path uses FP32 `AL`, `ALT=AL+ALB`, and EOS pressure subtraction. A pointwise output-storage interval must be computed from the **captured before-cancellation absolute pressure, after-cancellation P', AL, ALT, and each pre/post-sum PGF term**. It must keep final FP32 storage rounding distinct from internal multiplication/power/add/subtract rounding. The Full-branch source includes opt-in `port_u_pgf_snapshot.bin` capture of `{increment,velocity_mass}` after its mass-basis scale and before RU addition at `wrf_sdirk3_tile_unified_impl.cpp:19936-19961`, plus `port_u_pgf_operands_snapshot.bin` with `{Ppert,AL,ALT,PH}` at `:19963-19989`. Those tensors are stored FP32 values widened to FP64 for serialization, not internal arithmetic intermediates; the sidecar does not include the EOS absolute-pressure value before subtraction of `PB`. No such capture binaries are present in the evidence directory yet. Therefore this report makes no CPP parity or pressure-causality claim and assigns no tolerance. The pending analysis must distinguish final FP32 output half-ULP intervals on captured operands from internal arithmetic differences; the latter require captured internal terms or a separately labeled operation replay.
