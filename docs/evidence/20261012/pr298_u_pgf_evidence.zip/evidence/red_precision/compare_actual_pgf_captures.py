#!/usr/bin/env python3
"""Independent parse/recompute of the four matched same-state Full U-PGF captures.

No run/build/source edit. Reads the preserved FT pre/post call snapshots and the
C++ Full PGF + operand sidecars, reconstructs the four WRF terms from captured
operands in float64, and keeps output-storage intervals separate from the
observed operation/accumulator residuals.
"""
from __future__ import annotations
import hashlib,json,struct
from pathlib import Path
import numpy as np
from netCDF4 import Dataset

E=Path('/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012/green_build/captures/pgf')
OUT=Path(__file__).with_name('captured_pgf_comparison.json')
CASES={
 'initial':('initial_fortran_rk3_h15','initial_cpp_ark3_h15'),
 'stored':('stored_fortran_rk3_h15','stored_cpp_ark3_h15'),
}

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def rms(a):return float(np.sqrt(np.mean(np.asarray(a,dtype=np.float64)**2)))
def metric(a):
 x=np.asarray(a,dtype=np.float64)
 return {'rms':rms(x),'max_abs':float(np.max(np.abs(x))),'count':int(x.size)}
def rel_metrics(x,ref):
 x=np.asarray(x,dtype=np.float64);ref=np.asarray(ref,dtype=np.float64)
 d=x-ref;ulp=np.abs(np.spacing(np.asarray(ref,dtype=np.float32))).astype(np.float64)
 return {'rms_abs':rms(d),'max_abs':float(np.max(np.abs(d))),
         'rms_in_ref_f32_ulp':rms(d/np.maximum(ulp,1e-300)),
         'max_in_ref_f32_ulp':float(np.max(np.abs(d)/np.maximum(ulp,1e-300)))}
def f32_storage_half_ulp(x):
 a=np.asarray(x,dtype=np.float32)
 return .5*np.abs(np.spacing(a)).astype(np.float64)
def summarize_bound(b):
 b=np.asarray(b,dtype=np.float64)
 return {'rms_halfwidth':rms(b),'max_halfwidth':float(np.max(b)),'count':int(b.size)}

def parse_ft(path):
 b=path.read_bytes();ver,=struct.unpack_from('<i',b,0)
 if ver!=1:raise ValueError(f'{path}: FT schema {ver}')
 bounds=struct.unpack_from('<12i',b,4);rkstep,nmoist=struct.unpack_from('<2i',b,52)
 vals=struct.unpack_from('<7f',b,60);nonhydro,toplid=struct.unpack_from('<2i',b,88)
 ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme=bounds
 ni,nj,nk=ime-ims+1,jme-jms+1,kme-kms+1;n3=ni*nj*nk;n2=ni*nj;o=96
 f={}
 names3=('ru_before','rv_before','u','v','w','t','ph')
 for n in names3:
  f[n]=np.frombuffer(b,dtype='<f4',count=n3,offset=o).reshape(nj,nk,ni);o+=4*n3
 f['mu']=np.frombuffer(b,dtype='<f4',count=n2,offset=o).reshape(nj,ni);o+=4*n2
 for n in ('p','pb','al','alt','php','cqu'):
  f[n]=np.frombuffer(b,dtype='<f4',count=n3,offset=o).reshape(nj,nk,ni);o+=4*n3
 f['muu']=np.frombuffer(b,dtype='<f4',count=n2,offset=o).reshape(nj,ni);o+=4*n2
 for n in ('c1h','c2h'):
  f[n]=np.frombuffer(b,dtype='<f4',count=nk,offset=o);o+=4*nk
 for n in ('msfux','msfuy'):
  f[n]=np.frombuffer(b,dtype='<f4',count=n2,offset=o).reshape(nj,ni);o+=4*n2
 for n in ('rdnw','fnm','fnp'):
  f[n]=np.frombuffer(b,dtype='<f4',count=nk,offset=o);o+=4*nk
 for n in ('ru_after','rv_after'):
  f[n]=np.frombuffer(b,dtype='<f4',count=n3,offset=o).reshape(nj,nk,ni);o+=4*n3
 if o!=len(b):raise ValueError(f'{path}: parsed {o} != {len(b)}')
 return {'version':ver,'bounds':bounds,'rk_step':rkstep,'rkstep':rkstep,'n_moist':nmoist,'nmoist':nmoist,'scalars':vals,
         'nonhydrostatic':bool(nonhydro),'nonhydro':bool(nonhydro),'top_lid':bool(toplid),'fields':f,'f':f,'sha256':sha(path),'bytes':len(b)}
def parse_cpp(path,sidecar):
 b=path.read_bytes();head=struct.unpack_from('<8i',b,0);ver,nx,ny,nz,nxu,nyv,nzw,nstate=head
 if ver!=2:raise ValueError(f'{path}: schema {ver}')
 native_nh,=struct.unpack_from('<i',b,32);o=36
 sh={'u':(ny,nz,nxu),'v':(nyv,nz,nx),'w':(ny,nzw,nx),'ph':(ny,nzw,nx),'t':(ny,nz,nx),'mu':(ny,nx)}
 state={}
 for n in ('u','v','w','ph','t','mu'):
  nval=int(np.prod(sh[n]));state[n]=np.frombuffer(b,dtype='<f8',count=nval,offset=o).reshape(sh[n]);o+=8*nval
 if o!=36+8*nstate:raise ValueError('cpp input-state count/header mismatch')
 ush=(ny,nz,nxu);npgf=int(np.prod(ush));pgf={}
 for n in ('increment','mass','unscaled','alpha'):
  pgf[n]=np.frombuffer(b,dtype='<f8',count=npgf,offset=o).reshape(ush);o+=8*npgf
 if o!=len(b):raise ValueError(f'{path}: parsed {o} != {len(b)}')
 c=sidecar.read_bytes();h=struct.unpack_from('<5i',c,0);v2,sy,sz,sx,sw=h
 if v2!=1 or (sy,sz,sx,sw)!=(ny,nz,nx,nzw):raise ValueError('cpp operand sidecar header/dims mismatch')
 o=20;op={}
 for n,shape in (('p',(ny,nz,nx)),('al',(ny,nz,nx)),('alt',(ny,nz,nx)),('ph',(ny,nzw,nx))):
  nval=int(np.prod(shape));op[n]=np.frombuffer(c,dtype='<f8',count=nval,offset=o).reshape(shape);o+=8*nval
 if o!=len(c):raise ValueError(f'{sidecar}: parsed {o} != {len(c)}')
 return {'dims':head[1:7],'native_nh':bool(native_nh),'state':state,'pgf':pgf,'operands':op,
         'sha256':sha(path),'bytes':len(b),'sidecar_sha256':sha(sidecar),'sidecar_bytes':len(c)}

def ft_phys(ft):
 f=ft['fields'];ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme=ft['bounds']
 jo=jds-jms;io=ids-ims;ko=kds-kms;ny=jde-jds;nz=kde-kds;nx=ide-ids
 def m3(n,nk=nz,nxcol=nx):return f[n][jo:jo+ny,ko:ko+nk,io:io+nxcol]
 def m2(n,nxcol=nx):return f[n][jo:jo+ny,io:io+nxcol]
 def v1(n):return f[n][ko:ko+nz]
 return {'ru_before':m3('ru_before'),'ru_after':m3('ru_after'),'u':m3('u',nz,nx+1),
  't':m3('t'),'ph':m3('ph',nz+1),'p':m3('p'),'pb':m3('pb'),'al':m3('al'),'alt':m3('alt'),
  'php':m3('php'),'cqu':m3('cqu',nz,nx+1),'mu':m2('mu'),'muu':m2('muu',nx+1),
  'msfux':m2('msfux',nx+1),'msfuy':m2('msfuy',nx+1),'c1h':v1('c1h'),'c2h':v1('c2h'),
  'rdnw':v1('rdnw'),'fnm':v1('fnm'),'fnp':v1('fnp'),'owner_shape':(ny,nz,nx)}

def pgf_terms(p,pb,al,alt,ph,php,mu,muu,msfux,msfuy,cqu,c1h,c2h,rdnw,fnm,fnp,rdx,cf1,cf2,cf3,top_lid=False,cfn=0.,cfn1=0.,layer_override=None):
 p=np.asarray(p,dtype=np.float64);pb=np.asarray(pb,dtype=np.float64);al=np.asarray(al,dtype=np.float64);alt=np.asarray(alt,dtype=np.float64)
 ph=np.asarray(ph,dtype=np.float64);php=np.asarray(php,dtype=np.float64);mu=np.asarray(mu,dtype=np.float64)
 dx=lambda x:x-np.roll(x,1,axis=2);sx=lambda x:x+np.roll(x,1,axis=2)
 phi=dx(ph[:,1:,:])+dx(ph[:,:-1,:]); pterm=sx(alt)*dx(p); albterm=sx(al)*dx(pb)
 nz=p.shape[1]; psum=sx(p);dpn=np.zeros((p.shape[0],nz+1,p.shape[2]),dtype=np.float64)
 dpn[:,0,:]=.5*(cf1*psum[:,0,:]+cf2*psum[:,1,:]+cf3*psum[:,2,:])
 for k in range(1,nz):dpn[:,k,:]=.5*(fnm[k]*psum[:,k,:]+fnp[k]*psum[:,k-1,:])
 if top_lid:dpn[:,-1,:]=.5*(cfn*psum[:,-2,:]+cfn1*psum[:,-3,:])
 dphp=dx(php);c1=np.asarray(c1h,dtype=np.float64);c2=np.asarray(c2h,dtype=np.float64)
 v4=np.asarray(rdnw,dtype=np.float64)[None,:,None]*(dpn[:,1:,:]-dpn[:,:-1,:])-.5*c1[None,:,None]*sx(mu[:,None,:])
 a4=dphp*v4
 muu=np.asarray(muu,dtype=np.float64);msx=np.asarray(msfux,dtype=np.float64);msy=np.asarray(msfuy,dtype=np.float64)
 L=(c1[None,:,None]*muu[:,None,:]+c2[None,:,None]) if layer_override is None else np.asarray(layer_override,dtype=np.float64)
 ratio=msx/msy
 scale=.5*rdx*ratio[:,None,:]*L
 terms={'phi':scale*phi,'alt_dP':scale*pterm,'al_dPB':scale*albterm,'term4':rdx*ratio[:,None,:]*a4}
 total=sum(terms.values())
 cq=np.asarray(cqu,dtype=np.float64)[:,:,(0 if np.asarray(cqu).shape[2]==p.shape[2] else 0):p.shape[2]]
 # physical RU increment and physical velocity rate from the Fortran conversion.
 ru=-cq*total
 phys=-msy[:,None,:]*cq*total/L
 return {'terms_ru':terms,'total_ru':total,'increment_ru':ru,'physical':phys,'layer_mass':L,
         'phi_bracket':phi,'alt_dp_bracket':pterm,'al_dpb_bracket':albterm,'term4_vertical_product':a4}

def extract_owner_cpp(cpp):
 nx,ny,nz,nxu,nyv,nzw=cpp['dims'];m=ny-1;n=nx-1
 # Packed periodic geometry has 16 physical mass rows/columns and one duplicated mass endpoint.
 q={}
 for name,a in cpp['state'].items():
  if name=='u':
   q[name]=a[:m,:,:n] # unique U owners only: x=0..15; keep seam face 0
   q['u_owner_plus_closing']=a[:m,:,:n+1] # retain duplicated closing face x=16 for audits
   q['u_full_capture']=a
  elif name=='ph':q[name]=a[:m,:,:n]
  elif name=='mu':q[name]=a[:m,:n]
  elif name=='t':q[name]=a[:m,:,:n]
 # full PGF output has closing U face at x=16; unique owners take first nx-1=16.
 for name,a in cpp['pgf'].items():q['pgf_'+name]=a[:m,:,:n]
 q['cpp_closing_minus_face0']=cpp['pgf']['increment'][:m,:,:1]-cpp['pgf']['increment'][:m,:,n:n+1]
 q['cpp_extra_face17_max_abs']=float(np.max(np.abs(cpp['pgf']['increment'][:m,:,n+1]))) if nxu>n+1 else 0.
 for name,a in cpp['operands'].items():
  if name=='ph':q['op_'+name]=a[:m,:,:n]
  else:q['op_'+name]=a[:m,:,:n]
 return q

# Further analysis is in main() below.

def extract_ft_physical(ft):
 f=ft['f'];ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme=ft['bounds']
 j0=jds-jms;i0=ids-ims;k0=kds-kms;ny=jde-jds;nz=kde-kds;nx=ide-ids
 def m3(name,nk=nz,nxcol=nx):return f[name][j0:j0+ny,k0:k0+nk,i0:i0+nxcol].astype(np.float64)
 def m2(name,nxcol=nx):return f[name][j0:j0+ny,i0:i0+nxcol].astype(np.float64)
 def v1(name):return f[name][k0:k0+nz].astype(np.float64)
 # U owner mask: retain Fortran face i=1..16 (incl seam i=1), discard closing i=17.
 return {'ru_before':m3('ru_before'),'ru_after':m3('ru_after'),'u':m3('u',nz,nx+1),
  't':m3('t'),'ph':m3('ph',nz+1),'p':m3('p'),'pb':m3('pb'),'al':m3('al'),'alt':m3('alt'),
  'php':m3('php'),'cqu':m3('cqu',nz,nx+1),'mu':m2('mu'),'muu':m2('muu',nx+1),
  'msfux':m2('msfux',nx+1),'msfuy':m2('msfuy',nx+1),'c1h':v1('c1h'),'c2h':v1('c2h'),
  'rdnw':v1('rdnw'),'fnm':v1('fnm'),'fnp':v1('fnp'),'owner_shape':(ny,nz,nx),
  'closing_ru_before':f['ru_before'][j0:j0+ny,k0:k0+nz,i0+nx].astype(np.float64),
  'closing_ru_after':f['ru_after'][j0:j0+ny,k0:k0+nz,i0+nx].astype(np.float64)}

def parse_old_tend(path, ft):
 b=path.read_bytes();bounds=struct.unpack_from('>6i',b,0);ims,ime,jms,jme,kms,kme=bounds
 ni,nj,nk=ime-ims+1,jme-jms+1,kme-kms+1;n3=ni*nj*nk;n2=ni*nj;o=24+5*4*n3+4*n2
 p=np.frombuffer(b,dtype='>f4',count=n3,offset=o).reshape(nj,nk,ni);o+=4*n3
 al=np.frombuffer(b,dtype='>f4',count=n3,offset=o).reshape(nj,nk,ni)
 ids,ide,jds,jde,kds,kde,ims2,ime2,jms2,jme2,kms2,kme2=ft['bounds'];j0=ids-jms;i0=ids-ims2;k0=kds-kms2
 return {'P':p[j0:j0+16,k0:k0+16,i0:i0+16].astype(np.float64),
         'AL':al[j0:j0+16,k0:k0+16,i0:i0+16].astype(np.float64),'sha256':sha(path),'bytes':len(b)}

def reconstruct_from_operands(a, L_override=None):
 return pgf_terms(a['p'],a['pb'],a['al'],a['alt'],a['ph'],a['php'],a['mu'],a['muu'],
   a['msfux'],a['msfuy'],a['cqu'],a['c1h'],a['c2h'],a['rdnw'],a['fnm'],a['fnp'],a['rdx'],
   a['cf1'],a['cf2'],a['cf3'],a['top_lid'],a['cfn'],a['cfn1'],layer_override=L_override)

def stats_condition(terms):
 abs_sum=sum(np.abs(v) for v in terms.values());signed=sum(terms.values());cond=abs_sum/(np.abs(signed)+1e-300)
 return {'median':float(np.median(cond)),'p95':float(np.percentile(cond,95)),'max':float(np.max(cond)),
  'seam0_median':float(np.median(cond[:,:,0])),'seam0_p95':float(np.percentile(cond[:,:,0],95)),
  'seam0_max':float(np.max(cond[:,:,0])),'max_location_jki':[int(x) for x in np.unravel_index(np.argmax(cond),cond.shape)]}

def exact_fp32_roundtrip_fraction(x):
 x=np.asarray(x,dtype=np.float64)
 return float(np.mean(x==x.astype(np.float32).astype(np.float64)))

def operand_pair_stats(cpp,ft):
 d=np.asarray(cpp,dtype=np.float64)-np.asarray(ft,dtype=np.float64)
 ft_half=f32_storage_half_ulp(ft)
 # C++ captures are float64 files; report whether values are exact widened FP32.
 cpp_f32=exact_fp32_roundtrip_fraction(cpp)
 if cpp_f32==1.0:cpp_half=f32_storage_half_ulp(cpp)
 else:cpp_half=.5*np.abs(np.spacing(np.asarray(cpp,dtype=np.float64)))
 b=ft_half+cpp_half
 ratio=np.abs(d)/np.maximum(b,1e-300)
 return {'delta_rms':rms(d),'delta_max_abs':float(np.max(np.abs(d))),
  'ft_half_ulp_rms':rms(ft_half),'cpp_exact_fp32_roundtrip_fraction':cpp_f32,
  'capture_storage_interval_rms':rms(b),'capture_storage_interval_max':float(np.max(b)),
  'pointwise_delta_over_interval_p95':float(np.percentile(ratio,95)),
  'pointwise_delta_over_interval_max':float(np.max(ratio)),
  'points_outside_storage_interval':int(np.count_nonzero(np.abs(d)>b))}

def summarize_case(label,ftdir,cppdir):
 ft=parse_ft(ftdir/'wrf_u_pgf_snapshot.bin');fp=extract_ft_physical(ft)
 cpp=parse_cpp(cppdir/'port_u_pgf_snapshot.bin',cppdir/'port_u_pgf_operands_snapshot.bin');co=extract_owner_cpp(cpp)
 ny,nz,nx=fp['owner_shape']; ift=ft['fields'];rdx,rdy,cf1,cf2,cf3,cfn,cfn1=ft['scalars']
 # C++ capture is full padded storage; owner faces are x=0..15; x=16 is the periodic close.
 cpgf={n:v for n,v in co.items() if n.startswith('pgf_')}
 cpp_inc=cpgf['pgf_increment'];cpp_mass=cpgf['pgf_mass'];cpp_unscaled=cpgf['pgf_unscaled'];cpp_alpha=cpgf['pgf_alpha']
 # Same-state grid/input arrays from the FT call capture. Static PHB comes from the exact paired wrfinput.
 with Dataset(cppdir/'wrfinput_d01') as ds:
  phb=np.transpose(np.asarray(ds.variables['PHB'][0],dtype=np.float32),(1,0,2)).astype(np.float64)
  alb=np.transpose(np.asarray(ds.variables['ALB'][0],dtype=np.float32),(1,0,2)).astype(np.float64)
  pb_input=np.transpose(np.asarray(ds.variables['PB'][0],dtype=np.float32),(1,0,2)).astype(np.float64)
 # Ensure the input file's base PB is exactly the captured FT PB on physical mass owners.
 pb_input=pb_input[:ny,:,:nx]
 ft_base_pb=fp['pb']
 # C++ PH sidecar plus WRF's static PHB reconstructs the Full-branch PHP used in native term 4.
 ph_cpp=co['op_ph'][:ny,:,:nx]
 phb_owner=phb[:ny,:,:nx]
 php_cpp=.5*(ph_cpp[:,:-1,:]+ph_cpp[:,1:,:]+phb_owner[:,:-1,:]+phb_owner[:,1:,:])
 # alpha_u is source's L/msfuy; recover the same coupled layer mass used by the Full primary PGF.
 msfux=fp['msfux'][:,:nx];msfuy=fp['msfuy'][:,:nx]
 alpha_cpp=cpp_alpha[:ny,:,:nx];mass_cpp=cpp_mass[:ny,:,:nx]
 layer_cpp=alpha_cpp*msfuy[:,None,:]
 fto={n:fp[n] for n in ('p','pb','al','alt','ph','php','mu','cqu','c1h','c2h','rdnw','fnm','fnp')}
 fto.update({'muu':fp['muu'][:,:nx],'msfux':fp['msfux'][:,:nx],'msfuy':fp['msfuy'][:,:nx]})
 fto.update({'rdx':rdx,'cf1':cf1,'cf2':cf2,'cf3':cf3,'cfn':cfn,'cfn1':cfn1,'top_lid':ft['top_lid']})
 cto={'p':co['op_p'][:ny,:,:nx],'pb':ft_base_pb,'al':co['op_al'][:ny,:,:nx],
      'alt':co['op_alt'][:ny,:,:nx],'ph':ph_cpp,'php':php_cpp,
      'mu':co['mu'][:ny,:nx],'muu':fp['muu'][:,:nx],
      'msfux':msfux,'msfuy':msfuy,'cqu':fp['cqu'][:ny,:,:nx],
      'c1h':fp['c1h'],'c2h':fp['c2h'],'rdnw':fp['rdnw'],'fnm':fp['fnm'],'fnp':fp['fnp'],
      'rdx':rdx,'cf1':cf1,'cf2':cf2,'cf3':cf3,'cfn':cfn,'cfn1':cfn1,'top_lid':ft['top_lid']}
 ft_rec=pgf_terms(**fto)
 cpp_rec=pgf_terms(**cto,layer_override=layer_cpp)
 # Full Fortran call's actual stored accumulator increment; difference is observed after-call minus before-call.
 ft_delta=fp['ru_after'][:,:,:nx]-fp['ru_before'][:,:,:nx]
 ft_formula=ft_rec['increment_ru'][:,:,:nx]
 ft_internal_resid=ft_delta-ft_formula
 ft_layer=ft_rec['layer_mass'][:,:,:nx]
 ft_phys=ft_delta*msfuy[:,None,:]/ft_layer
 ft_physical_formula=ft_formula*msfuy[:,None,:]/ft_layer
 ft_capture_bound=.5*(np.abs(np.spacing(fp['ru_before'][:,:,:nx].astype('f4')))+
                      np.abs(np.spacing(fp['ru_after'][:,:,:nx].astype('f4')))).astype('f8')
 ft_physical_capture_bound=ft_capture_bound*msfuy[:,None,:]/ft_layer
 # C++ actual output is captured after mass scaling; the unscaled block is before that multiply/divide.
 cpp_inc_owner=cpp_inc[:ny,:,:nx];cpp_mass_owner=mass_cpp;cpp_unscaled_owner=cpp_unscaled[:ny,:,:nx]
 cpp_alpha_owner=alpha_cpp
 cpp_physical=cpp_inc_owner/cpp_mass_owner
 cpp_physical_unscaled=cpp_unscaled_owner/cpp_alpha_owner
 cpp_formula=cpp_rec['increment_ru'][:,:,:nx]
 cpp_internal_resid=cpp_unscaled_owner-cpp_formula
 cpp_scalerel=cpp_inc_owner-(cpp_unscaled_owner*cpp_mass_owner/cpp_alpha_owner)
 ft_component_phys={k:-msfuy[:,None,:]*fp['cqu'][:,:,:nx]*v[:,:,:nx]/ft_layer
                    for k,v in ft_rec['terms_ru'].items()}
 cpp_component_phys={k:-msfuy[:,None,:]*fp['cqu'][:,:,:nx]*v[:,:,:nx]/layer_cpp
                     for k,v in cpp_rec['terms_ru'].items()}
 component_delta_phys={k:cpp_component_phys[k]-ft_component_phys[k] for k in ft_component_phys}
 # Same-call state and diagnostic operands against FT captures.
 cpp_state=co['u_full_capture'][:ny,:,:nx+1]
 ft_state=fp['u'][:ny,:,:nx+1]
 state_match={
  'U_owner_plus_closing':rel_metrics(cpp_state,ft_state),
  'T':rel_metrics(co['t'][:ny,:,:nx],fp['t'][:ny,:,:nx]),
  'PH':rel_metrics(co['ph'][:ny,:,:nx],fp['ph'][:ny,:,:nx]),
  'MU':rel_metrics(co['mu'][:ny,:nx],fp['mu'][:ny,:nx]),
  'CPP_sidecar_PH_vs_input_state_PH':rel_metrics(co['op_ph'][:ny,:,:nx],co['ph'][:ny,:,:nx])}
 op_compare={}
 for name,cppa,fta in (('P',cto['p'],fp['p']),('AL',cto['al'],fp['al']),('ALT',cto['alt'],fp['alt']),('PH',cto['ph'],fp['ph']),('PHP_rebuilt',php_cpp,fp['php']),('PB_input_vs_FT_capture',pb_input,fp['pb'])):
  op_compare[name]=operand_pair_stats(cppa,fta)
 # FP64 EOS replays from actual call operands; they reveal the internal FT roundoff residual but are not internal captures.
 Tft=fp['t'][:,:,:nx];Tcpp=co['t'][:ny,:,:nx];pb=fp['pb']
 p_abs_ft_replay=100000.*np.power(287.*(Tft+300.)/(100000.*fp['alt'][:,:,:nx]),1004.5/717.5)
 p_ft_replay=p_abs_ft_replay-pb
 p_abs_cpp_replay=100000.*np.power(287.*(Tcpp+300.)/(100000.*cto['alt']),1004.5/717.5)
 p_cpp_replay=p_abs_cpp_replay-pb
 p_ft_replay_resid=fp['p'][:,:,:nx]-p_ft_replay
 p_cpp_replay_resid=cto['p']-p_cpp_replay
 # Post-cancellation absolute-pressure reconstruction is not the internal pre-subtraction value.
 p_abs_ft_post=fp['p'][:,:,:nx]+pb;p_abs_cpp_post=cto['p']+pb
 pb_ulp=np.abs(np.spacing(pb.astype('f4'))).astype('f8')
 dp_cpp_ft=cto['p']-fp['p'][:,:,:nx]
 dx=lambda x:x-np.roll(x,1,axis=2);sx=lambda x:x+np.roll(x,1,axis=2)
 dp_ft=dx(fp['p'][:,:,:nx]);dp_cpp=dx(cto['p']);dp_delta=dp_cpp-dp_ft
 p_ulp_ft=np.abs(np.spacing(fp['p'][:,:,:nx].astype('f4'))).astype('f8')
 p_ulp_cpp=.5*np.abs(np.spacing(cto['p'].astype('f8')))
 dp_storage_bound=.5*(p_ulp_ft+np.roll(p_ulp_ft,1,axis=2))+p_ulp_cpp+np.roll(p_ulp_cpp,1,axis=2)
 alt_sum_ft=sx(fp['alt'][:,:,:nx]);alt_sum_cpp=sx(cto['alt'])
 scale_ft=.5*rdx*(msfux/msfuy)[:,None,:]*ft_layer
 ponly_phys=-msfuy[:,None,:]*scale_ft*alt_sum_ft*dp_delta/ft_layer
 altonly_phys=-msfuy[:,None,:]*scale_ft*(alt_sum_cpp-alt_sum_ft)*dp_ft/ft_layer
 interact_phys=-msfuy[:,None,:]*scale_ft*(alt_sum_cpp-alt_sum_ft)*dp_delta/ft_layer
 # Verify FT PGF P/AL fields are the same operands emitted by the older RK tendency dump.
 old=parse_old_tend(ftdir/'wrf_rk_tend_dump.bin',ft)
 alt_ft_calc=(fp['al'].astype(np.float32)+alb[:ny,:,:nx].astype(np.float32)).astype(np.float32).astype(np.float64)
 alt_ft_sum_resid=fp['alt'][:,:,:nx]-alt_ft_calc
 # Endpoint-capture storage interval: observed (after-before) difference inherits two endpoint half-ULPs.
 ru_resid_rms=metric(ft_internal_resid)
 ft_bound=summarize_bound(ft_capture_bound)
 out={
  'fortran_capture':{'sha256':ft['sha256'],'bytes':ft['bytes'],'rk_step':ft['rkstep'],'n_moist':ft['nmoist'],
   'nonhydrostatic':ft['nonhydro'],'top_lid':ft['top_lid'],'scalars':[float(v) for v in ft['scalars']],
   'FT_P_capture_vs_full_RK_dump':rel_metrics(fp['p'],old['P']),'FT_AL_capture_vs_full_RK_dump':rel_metrics(fp['al'],old['AL']),
   'FT_ALT_capture_vs_float32_AL_plus_ALB':metric(alt_ft_sum_resid),
   'ru_increment_after_minus_before':metric(ft_delta),'ru_increment_reconstructed_from_FT_operands':metric(ft_formula),
   'formula_residual_vs_stored_RU_increment':ru_resid_rms,
   'RU_before_after_output_storage_only_halfwidth':ft_bound,
   'point_count_residual_exceeds_endpoint_storage_interval':int(np.count_nonzero(np.abs(ft_internal_resid)>ft_capture_bound)),
   'physical_rate_from_observed_RU_delta':metric(ft_phys),
   'physical_rate_from_reconstructed_four_terms':metric(ft_physical_formula),
   'physical_output_interval_from_RU_endpoint_storage_only':summarize_bound(ft_physical_capture_bound),
   'captured_four_term_RU_contributions':{k:metric(v[:,:,:nx]) for k,v in ft_rec['terms_ru'].items()},
   'primary_three_term_cancellation':stats_condition({k:v[:,:,:nx] for k,v in ft_rec['terms_ru'].items() if k!='term4'}),
  'termwise_CPP_minus_FT_physical_acceleration_reconstruction':{k:metric(component_delta_phys[k]) for k in component_delta_phys},
  'ALT_times_delta_P_precision_path_split_physical':{'P_only_holding_FT_ALT':metric(ponly_phys),
    'ALT_only_holding_FT_deltaP':metric(altonly_phys),'interaction':metric(interact_phys),
    'fixed_FT_scale_total_delta':metric(ponly_phys+altonly_phys+interact_phys),
    'remainder_from_layer_scale_difference':metric(component_delta_phys['alt_dP']-(ponly_phys+altonly_phys+interact_phys))},
   'per_operand_FP32_spacing':{k:{'median':float(np.median(np.abs(np.spacing(np.asarray(fp[k],dtype='f4'))))),
       'max':float(np.max(np.abs(np.spacing(np.asarray(fp[k],dtype='f4')))))} for k in ('p','al','alt','ph','php','pb')},
   'periodic_U_captured_RU_closing_vs_face0':{'before_max_abs':float(np.max(np.abs(fp['closing_ru_before'][:ny]-fp['ru_before'][:ny,:,0]))),
       'after_max_abs':float(np.max(np.abs(fp['closing_ru_after'][:ny]-fp['ru_after'][:ny,:,0])))}},
  'cpp_capture':{'sha256':cpp['sha256'],'sidecar_sha256':cpp['sidecar_sha256'],'bytes':cpp['bytes'],'sidecar_bytes':cpp['sidecar_bytes'],
   'native_nh_term4_enabled':cpp['native_nh'],'input_state_match_to_FT':state_match,
   'pressure_EOS_sidecar_vs_FT_operand_capture':op_compare,
   'Pprime_EOS_FP64_operation_replay_vs_CPP_capture':metric(p_cpp_replay_resid),
   'Pprime_EOS_FP64_operation_replay_vs_FT_capture':metric(p_ft_replay_resid),
   'captured_Pprime_delta_decomposition':{
      'CPP_minus_FT_actual_capture':metric(dp_cpp_ft),
      'CPP_minus_FT_double_replay_from_each_capture_ALT_T_PB':metric(p_cpp_replay-p_ft_replay),
      'FT_capture_minus_FP64_replay_internal_residual':metric(p_ft_replay_resid),
      'CPP_capture_minus_FP64_replay_internal_residual':metric(p_cpp_replay_resid),
      'identity_residual':metric(dp_cpp_ft-((p_cpp_replay-p_ft_replay)+p_cpp_replay_resid-p_ft_replay_resid))},
   'CPP_minus_FT_Pprime_over_base_pressure_f32_spacing':{
      'delta_rms':rms(dp_cpp_ft),'delta_max_abs':float(np.max(np.abs(dp_cpp_ft))),
      'rms_in_PB_ulp32':rms(dp_cpp_ft/np.maximum(pb_ulp,1e-300)),
      'max_in_PB_ulp32':float(np.max(np.abs(dp_cpp_ft)/np.maximum(pb_ulp,1e-300)))},
   'deltaP_CPP_minus_FT_over_final_operand_storage_interval':{
      'actual_deltaP_rms':rms(dp_delta),'max_abs':float(np.max(np.abs(dp_delta))),
      'storage_interval_rms':rms(dp_storage_bound),'storage_interval_max':float(np.max(dp_storage_bound)),
      'points_outside_interval':int(np.count_nonzero(np.abs(dp_delta)>dp_storage_bound)),
      'max_delta_over_interval':float(np.max(np.abs(dp_delta)/np.maximum(dp_storage_bound,1e-300)))},
   'EOS_Pfull_double_replay_scale_not_internal_capture':{
      'FT_Pfull_range': [float(p_abs_ft_replay.min()),float(p_abs_ft_replay.max())],
      'CPP_Pfull_range':[float(p_abs_cpp_replay.min()),float(p_abs_cpp_replay.max())],
      'FT_Pfull_f32_ulp_median':float(np.median(np.abs(np.spacing(p_abs_ft_replay.astype('f4'))))),
      'FT_Pprime_f32_ulp_median':float(np.median(np.abs(np.spacing(fp['p'][:,:,:nx].astype('f4'))))),
      'median_Pfull_ulp_over_Pprime_ulp':float(np.median(np.abs(np.spacing(p_abs_ft_replay.astype('f4')))/
         np.maximum(np.abs(np.spacing(fp['p'][:,:,:nx].astype('f4'))),1e-300)))},
   'p_abs_after_addback_from_captured_Pprime_not_internal_pre_subtraction':{
      'FT_range':[float((fp['p']+fp['pb']).min()),float((fp['p']+fp['pb']).max())],
      'CPP_range':[float((cto['p']+ft_base_pb).min()),float((cto['p']+ft_base_pb).max())]},
   'unscaled_RU_basis_PGF_actual':metric(cpp_unscaled_owner),
   'unscaled_RU_basis_PGF_reconstructed_from_CPP_sidecar':metric(cpp_formula),
   'unscaled_formula_residual_internal_operation_replay':metric(cpp_internal_resid),
   'mass_scaled_coupled_PGF_actual':metric(cpp_inc_owner),
   'increment_minus_unscaled_times_mass_over_alpha_replay_residual':metric(cpp_scalerel),
   'physical_rate_actual_increment_over_velocity_mass':metric(cpp_physical),
   'physical_rate_unscaled_over_alpha_u':metric(cpp_physical_unscaled),
   'physical_rate_reconstructed_from_four_terms':metric(cpp_formula*msfuy[:,None,:]/layer_cpp),
   'captured_four_term_RU_contributions':{k:metric(v[:,:,:nx]) for k,v in cpp_rec['terms_ru'].items()},
   'primary_three_term_cancellation':stats_condition({k:v[:,:,:nx] for k,v in cpp_rec['terms_ru'].items() if k!='term4'}),
   'CPP_U_increment_periodic_closure':{'closing_face16_vs_face0_max_abs':float(np.max(np.abs(co['cpp_closing_minus_face0']))),
      'extra_face17_max_abs':co['cpp_extra_face17_max_abs']},
   'sidecar_f64_values_exactly_representable_in_FP32':{k:exact_fp32_roundtrip_fraction(co['op_'+k][:ny,:,:nx]) for k in ('p','al','alt','ph')}},
  'cross_capture_actual_physical_rate_CPP_minus_FT':metric(cpp_physical-ft_phys),
  'cross_capture_coupled_CPP_increment_minus_FT_after_before':metric(cpp_inc_owner-ft_delta),
  'cross_capture_CPP_unscaled_minus_FT_formula_RU':metric(cpp_unscaled_owner-ft_formula),
  'seam_face0':{'physical_rate_FT':metric(ft_phys[:,:,0:1]),'physical_rate_CPP':metric(cpp_physical[:,:,0:1]),
    'physical_rate_CPP_minus_FT':metric((cpp_physical-ft_phys)[:,:,0:1]),
    'RU_delta_FT':metric(ft_delta[:,:,0:1]),'RU_coupled_CPP':metric(cpp_inc_owner[:,:,0:1])},
  'uncertainty_interpretation':'The FT RU before/after half-ULP interval is a pointwise output-storage bound only. Reconstructed-FP64 formula residuals and CPP internal-replay residuals are reported separately; they are not asserted to be bounded by the capture interval.'}
 return out

def run():
 receipt=json.loads((E.parent/'pgf_runs.json').read_text()); rr={r['label']:r for r in receipt['runs']}
 out={'schema':'red-captured-u-pgf-comparison-v1','receipt':str(E.parent/'pgf_runs.json'),
  'scope':'Four same-state initial/stored FT RK3 and CPP ARK3 stage-1 captures; no new run/build/source edit.',
  'normalization':'Fortran physical PGF-only rate = ΔRU * MSFUY/(C1H*Muu+C2H); the isolated PGF has no mu-dot/product-rule term. C++ coupled increment is captured after existing mass-basis scale; physical rate is increment/velocity_mass_u.',
  'quantification':'Captured FT arrays are FP32. The before/after RU interval is half-ULP(before)+half-ULP(after). Per-operand FP32 intervals are reported separately from reconstructed formula residuals; no global internal arithmetic bound.',
  'cases':{}}
 for label,(ftlab,cpplab) in CASES.items():
  rec=summarize_case(label,E/ftlab,E/cpplab)
  rec['run_receipts']={x:{'input_sha256':rr[x]['input_sha256'],'source_sha256':rr[x]['source_sha256'],
     'executable_sha256':rr[x]['executable_sha256'],'status':rr[x]['status']} for x in (ftlab,cpplab)}
  out['cases'][label]=rec
 OUT.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
 print(json.dumps({k:{'physical_CPP_minus_FT':v['cross_capture_actual_physical_rate_CPP_minus_FT'],
  'FT_formula_residual':v['fortran_capture']['formula_residual_vs_stored_RU_increment'],
  'CPP_formula_residual':v['cpp_capture']['unscaled_formula_residual_internal_operation_replay'],
  'PGF_operand_deltas':v['cpp_capture']['pressure_EOS_sidecar_vs_FT_operand_capture']} for k,v in out['cases'].items()},indent=2))
if __name__=='__main__':run()
