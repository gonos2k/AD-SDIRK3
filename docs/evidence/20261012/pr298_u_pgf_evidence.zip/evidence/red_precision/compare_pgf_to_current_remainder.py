#!/usr/bin/env python3
"""Compare captured same-state Full U-PGF CPP−FT delta to current PR297 remainder."""
import hashlib, json, sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).parent))
import compare_actual_pgf_captures as c
E=c.E
NPZ=Path('/Users/yhlee/AD-SDIRK3-review-evidence/rk3-reference-shape-20261012/green_rhs/remainder_arrays.npz')
OUT=Path(__file__).with_name('current_remainder_pgf_comparison.json')
def metric(a):
 a=np.asarray(a,dtype=np.float64)
 return {'rms':float(np.sqrt(np.mean(a*a))), 'max_abs':float(np.max(np.abs(a)))}
def main():
 z=np.load(NPZ); rows={}
 for label in ('initial','stored'):
  ft=c.parse_ft(E/f'{label}_fortran_rk3_h15'/'wrf_u_pgf_snapshot.bin')
  cpdir=E/f'{label}_cpp_ark3_h15'
  cp=c.parse_cpp(cpdir/'port_u_pgf_snapshot.bin',cpdir/'port_u_pgf_operands_snapshot.bin')
  f=c.extract_ft_physical(ft); q=c.extract_owner_cpp(cp)
  L=f['c1h'][None,:,None]*f['muu'][:,None,:16]+f['c2h'][None,:,None]
  ft_rate=(f['ru_after']-f['ru_before'])*f['msfuy'][:,None,:16]/L
  cpp_rate=q['pgf_increment']/q['pgf_mass']
  delta=cpp_rate-ft_rate
  rem=z[f'{label}_u_remainder']
  resid=rem-delta
  rows[label]={'owners':int(delta.size),'PGF_CPP_minus_FT':metric(delta),
    'current_post_HV_remainder':metric(rem),'remainder_minus_PGF':metric(resid),
    'cosine_PGF_vs_remainder':float(np.sum(delta*rem)/np.sqrt(np.sum(delta*delta)*np.sum(rem*rem))),
    'RMS_ratio_PGF_over_remainder':float(np.sqrt(np.mean(delta*delta))/np.sqrt(np.mean(rem*rem)))}
 h=hashlib.sha256(NPZ.read_bytes()).hexdigest()
 out={'schema':'current-pr297-remainder-vs-captured-full-pgf-v1','npz':str(NPZ),'npz_sha256':h,
  'scope':'Read-only postprocessed arrays; same 4096 unique U owners, face 0 retained, duplicated closing face excluded. Delta sign is CPP minus FT. Fortran column arrays use [j,1,i] broadcasting and layer arrays [1,k,1].',
  'cases':rows}
 OUT.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
