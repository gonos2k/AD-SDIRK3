#!/usr/bin/env python3
"""Fail-closed offline comparison of actual same-state Fortran/C++ U-PGF captures.

No model operator is evaluated. The script consumes PGF observations, paired Full
snapshots, and the PR296 H/V residual. It computes in physical m/s^2 and includes
a source-equation FP64 reconstruction plus an explicitly labeled FP32 accumulator
resolution estimate.
"""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, math, struct, sys
from pathlib import Path
from typing import Any
import numpy as np

BUNDLE=Path(__file__).resolve().parents[2]
E=BUNDLE/'evidence'
PR296=BUNDLE/'prior'
FULL_PARSER=PR296/'analyze_snapshots.py'
spec=importlib.util.spec_from_file_location('full_snapshot_contract',FULL_PARSER)
if spec is None or spec.loader is None: raise RuntimeError(f'cannot load {FULL_PARSER}')
full=importlib.util.module_from_spec(spec);spec.loader.exec_module(full)

class SnapshotError(RuntimeError): pass

def sha(p:Path)->str:
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()
def receipt(p:Path)->dict[str,Any]:
 if not p.is_file(): raise SnapshotError(f'missing input {p}')
 return {'path':str(p),'byte_count':p.stat().st_size,'sha256':sha(p)}
def f64(x):return np.asarray(x,dtype=np.float64)
def rms(x):return float(np.sqrt(np.mean(f64(x)**2))) if np.size(x) else 0.0
def stats(x)->dict[str,Any]:
 a=f64(x)
 return {'count':int(a.size),'rms':rms(a),'max_abs':float(np.max(np.abs(a))) if a.size else 0.0,
         'l2_norm':float(np.linalg.norm(a.ravel()))}
def projection(old,term):
 o=f64(old);p=f64(term);n=o-p
 oo=float(np.sum(o*o));pp=float(np.sum(p*p));nn=float(np.sum(n*n));dot=float(np.sum(o*p))
 den=float(np.linalg.norm(o.ravel())*np.linalg.norm(p.ravel()))
 return {'old_remainder':stats(o),'pressure_component_delta_cpp_minus_ft':stats(p),'new_remainder_old_minus_delta_pgf':stats(n),
   'old_rms_minus_pressure_rms_is_not_used':True,
   'inner_product_oldR_dot_deltaPGF':dot,'cosine_similarity':float(dot/den) if den else None,
   'signed_projection_share_of_old_R_pct':100*dot/oo if oo else None,
   'pressure_delta_energy_share_of_old_R_pct':100*pp/oo if oo else None,
   'old_remainder_squared_norm':oo,'new_remainder_squared_norm':nn,
   'squared_residual_reduction_pct':100*(1-nn/oo) if oo else None,
   'squared_norm_identity_residual':nn-(oo+pp-2*dot)}
def idx_stats(x):
 return list(map(int,np.unravel_index(np.argmax(np.abs(x)),np.shape(x))))

def _native_endian_version(data:bytes,expected:int)->str:
 if len(data)<4:raise SnapshotError('short native header')
 if struct.unpack_from('<i',data,0)[0]==expected:return '<'
 if struct.unpack_from('>i',data,0)[0]==expected:return '>'
 raise SnapshotError(f'header version is neither {expected} endian')

def read_fortran_pgf(path:Path):
 data=path.read_bytes()
 if len(data)<96:raise SnapshotError(f'FT PGF header short: {len(data)} bytes')
 ver,=struct.unpack_from('<i',data,0)
 if ver!=1:raise SnapshotError(f'FT PGF version {ver}, expected 1')
 bounds=struct.unpack_from('<12i',data,4)
 rk_step,n_moist=struct.unpack_from('<2i',data,52)
 scalars=struct.unpack_from('<7f',data,60)
 nonhydro,top_lid=struct.unpack_from('<2i',data,88)
 ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme=map(int,bounds)
 ni,nj,nk=ime-ims+1,jme-jms+1,kme-kms+1
 if min(ni,nj,nk)<=0:raise SnapshotError(f'invalid FT bounds {bounds}')
 n3=ni*nj*nk;n2=ni*nj
 names3_pre=('ru_tend_before','rv_tend_before','u','v','w','t','ph')
 names3_mid=('p','pb','al','alt','php','cqu')
 arr={};off=96
 for name in names3_pre:
  arr[name]=np.frombuffer(data,dtype='<f4',count=n3,offset=off).reshape((nj,nk,ni)).copy();off+=n3*4
 # Exact WRITE order in module_em.F: mu, pressure fields, muu, c1/c2,
 # map factors, vertical coefficients, then post-call accumulators.
 arr['mu']=np.frombuffer(data,dtype='<f4',count=n2,offset=off).reshape((nj,ni)).copy();off+=n2*4
 for name in names3_mid:
  arr[name]=np.frombuffer(data,dtype='<f4',count=n3,offset=off).reshape((nj,nk,ni)).copy();off+=n3*4
 arr['muu']=np.frombuffer(data,dtype='<f4',count=n2,offset=off).reshape((nj,ni)).copy();off+=n2*4
 for name in ('c1h','c2h'):
  arr[name]=np.frombuffer(data,dtype='<f4',count=nk,offset=off).copy();off+=nk*4
 for name in ('msfux','msfuy'):
  arr[name]=np.frombuffer(data,dtype='<f4',count=n2,offset=off).reshape((nj,ni)).copy();off+=n2*4
 for name in ('rdnw','fnm','fnp'):
  arr[name]=np.frombuffer(data,dtype='<f4',count=nk,offset=off).copy();off+=nk*4
 for name in ('ru_tend_after','rv_tend_after'):
  arr[name]=np.frombuffer(data,dtype='<f4',count=n3,offset=off).reshape((nj,nk,ni)).copy();off+=n3*4
 if off!=len(data):raise SnapshotError(f'FT PGF byte count: parsed {off}, file has {len(data)}')
 return {'bounds':dict(zip(('ids','ide','jds','jde','kds','kde','ims','ime','jms','jme','kms','kme'),bounds)),
  'memory_shape_jki':[nj,nk,ni],'rk_step':int(rk_step),'n_moist':int(n_moist),
  'rdx':float(scalars[0]),'rdy':float(scalars[1]),'cf1':float(scalars[2]),'cf2':float(scalars[3]),'cf3':float(scalars[4]),
  'cfn':float(scalars[5]),'cfn1':float(scalars[6]),'nonhydro':bool(nonhydro),'top_lid':bool(top_lid),
  'native_layout':'little-endian stream','arrays':arr,'receipt':receipt(path)}

def read_cpp_pgf(path:Path):
 data=path.read_bytes();endian=_native_endian_version(data,2)
 if len(data)<36:raise SnapshotError(f'C++ PGF header short: {len(data)}')
 h=struct.unpack_from(endian+'8i',data,0);ver,nx,ny,nz,nxu,nyv,nzw,nstate=map(int,h)
 native_nh,=struct.unpack_from(endian+'i',data,32)
 dims=(nx,ny,nz,nxu,nyv,nzw)
 shapes=full.cpp_shapes(dims)
 expected_state=sum(int(np.prod(v)) for v in shapes.values())
 if nstate!=expected_state:raise SnapshotError(f'C++ PGF rawStateCount {nstate} != shape sum {expected_state}')
 count=ny*nz*nxu;expected=36+8*(nstate+4*count)
 if len(data)!=expected:raise SnapshotError(f'C++ PGF bytes expected {expected}, got {len(data)}')
 off=36;state={}
 for name in ('u','v','w','ph','t','mu'):
  n=int(np.prod(shapes[name]));state[name]=np.frombuffer(data,dtype=endian+'f8',count=n,offset=off).reshape(shapes[name]).copy();off+=8*n
 components={}
 for name in ('pgf_scaled_coupled','velocity_mass_u','pgf_unscaled','alpha_u'):
  components[name]=np.frombuffer(data,dtype=endian+'f8',count=count,offset=off).reshape((ny,nz,nxu)).copy();off+=8*count
 return {'dims':dims,'native_nh':bool(native_nh),'state_count':nstate,'shapes':shapes,'state_f64':state,
  'arrays':components,'native_endian':('little' if endian=='<' else 'big'),'receipt':receipt(path)}

def read_cpp_operands(path:Path,endian:str):
 endian={'little':'<','big':'>'}.get(endian,endian)
 data=path.read_bytes()
 if len(data)<20:raise SnapshotError('C++ operands sidecar header short')
 h=struct.unpack_from(endian+'5i',data,0);ver,ny,nz,nx,nzw=map(int,h)
 if ver!=1:raise SnapshotError(f'C++ operands version {ver}')
 count3=ny*nz*nx;countph=ny*nzw*nx;expected=20+8*(3*count3+countph)
 if len(data)!=expected:raise SnapshotError(f'C++ operands bytes expected {expected}, got {len(data)}')
 off=20;arr={}
 for name,n,shape in (('p',count3,(ny,nz,nx)),('al',count3,(ny,nz,nx)),('alt',count3,(ny,nz,nx)),('ph',countph,(ny,nzw,nx))):
  arr[name]=np.frombuffer(data,dtype=endian+'f8',count=n,offset=off).reshape(shape).copy();off+=8*n
 return {'version':ver,'shape_mass_jki':[ny,nz,nx],'shape_ph_jki':[ny,nzw,nx],'arrays':arr,'receipt':receipt(path)}

def extract_ft_state(pgf,full_meta,full_fields,dims):
 # Captured state fields use the same full-memory origin and shape as solve_em's Full snapshot.
 b=pgf['bounds'];fm=full_meta['bounds'];a=pgf['arrays']
 mapping={'u':'u','v':'v','w':'w','ph':'ph','t':'t','mu':'mu'}
 fullmap={'u':'u2','v':'v2','w':'w2','ph':'ph2','t':'t2','mu':'mu2'}
 result={};ok={}
 for name in mapping:
  l=a[mapping[name]];r=full_fields[fullmap[name]]
  samebounds=(b==fm)
  ok[name]=bool(samebounds and l.shape==r.shape and np.array_equal(l,r))
  result[name]=l
 return result,ok

def state_gate(ft_full,cpp_full,ftpgf,cpppgf):
 # First, use the pinned fail-closed six-field physical + storage gate.
 fr=full.analyze(ft_full,cpp_full,BUNDLE/'source')
 if not fr.get('comparison_available') or not fr.get('state_exact_match') or not fr.get('full_storage_exact_match'):
  return {'passed':False,'reason':'paired Full snapshot state gate failed','full_gate':fr},None
 fm,ff=full.read_fortran(ft_full);cm,cs,cr=full.read_cpp(cpp_full);dims=tuple(cm['dims_nx_ny_nz_nxu_nyv_nzw'])
 fpg_state,fpg_ok=extract_ft_state(ftpgf,fm,ff,dims)
 cpg_ok={k:bool(np.array_equal(cpppgf['state_f64'][k],cs[k].astype(np.float64))) for k in ('u','v','w','ph','t','mu')}
 if not all(fpg_ok.values()) or not all(cpg_ok.values()):
  return {'passed':False,'reason':'PGF call-local six-field input differs from paired Full snapshot; no RHS comparison allowed',
    'full_gate':fr,'fortran_pgf_state_equal_to_full_memory':fpg_ok,'cpp_pgf_state_equal_to_full_packed_state':cpg_ok},None
 return {'passed':True,'full_gate':fr,'fortran_pgf_state_equal_to_full_memory':fpg_ok,
    'cpp_pgf_state_equal_to_full_packed_state':cpg_ok,'physical_state_exact':True,'storage_audit_exact':True},(fm,ff,cm,cs,cr,dims)

def _slice3(a,b,*,i0,i1,k0,k1,j0,j1):return a[j0-b['jms']:j1-b['jms'],k0-b['kms']:k1-b['kms'],i0-b['ims']:i1-b['ims']]
def _slice2(a,b,*,i0,i1,j0,j1):return a[j0-b['jms']:j1-b['jms'],i0-b['ims']:i1-b['ims']]
def mass_to_u_periodic(a):
 # Mass-grid columns 0..15 become faces 0..16. The physical closing face
 # reproduces the periodic west-face gradient; storage padding x=17 is excluded.
 return np.concatenate((a,a[...,:1]),axis=-1),np.concatenate((a[...,-1:],a[...,:-1],a[...,-1:]),axis=-1)

def ft_fp64_oracle(pgf, dims):
 b=pgf['bounds'];nx,ny,nz,nxu,nyv,nzw=dims;px,py,pz=full.physical_dimensions(dims,pgf)
 # `physical_dimensions` expects full bounds metadata; pgf shares bounds but no dimension object.
 i0,j0,k0=b['ids'],b['jds'],b['kds'];a=pgf['arrays'];
 def raw3(name,nxcount,kcount=nz,jcount=ny):
  return _slice3(a[name],b,i0=i0,i1=i0+nxcount,k0=k0,k1=k0+kcount,j0=j0,j1=j0+jcount)
 def raw2(name,nxcount,jcount=ny):return _slice2(a[name],b,i0=i0,i1=i0+nxcount,j0=j0,j1=j0+jcount)
 # Owned mass cells and their 17 physical U faces.
 p=raw3('p',nx,kcount=pz,jcount=py)[:,:,:px].astype(np.float64)
 pb=raw3('pb',nx,kcount=pz,jcount=py)[:,:,:px].astype(np.float64)
 al=raw3('al',nx,kcount=pz,jcount=py)[:,:,:px].astype(np.float64)
 alt=raw3('alt',nx,kcount=pz,jcount=py)[:,:,:px].astype(np.float64)
 mu=raw2('mu',nx,jcount=py)[:,:px].astype(np.float64)
 ph=raw3('ph',nx,kcount=pz+1,jcount=py)[:,:,:px].astype(np.float64)
 php=raw3('php',nx,kcount=pz,jcount=py)[:,:,:px].astype(np.float64)
 cqu=raw3('cqu',nxu,kcount=pz,jcount=py)[:,:,:px+1].astype(np.float64)
 muu=raw2('muu',nxu,jcount=py)[:,:px+1].astype(np.float64)
 msfux=raw2('msfux',nxu,jcount=py)[:,:px+1].astype(np.float64)
 msfuy=raw2('msfuy',nxu,jcount=py)[:,:px+1].astype(np.float64)
 c1=pgf['arrays']['c1h'][k0-b['kms']:k0-b['kms']+pz].astype(np.float64)
 c2=pgf['arrays']['c2h'][k0-b['kms']:k0-b['kms']+pz].astype(np.float64)
 rdnw=pgf['arrays']['rdnw'][k0-b['kms']:k0-b['kms']+pz+1].astype(np.float64)
 fnm=pgf['arrays']['fnm'][k0-b['kms']:k0-b['kms']+pz+1].astype(np.float64)
 fnp=pgf['arrays']['fnp'][k0-b['kms']:k0-b['kms']+pz+1].astype(np.float64)
 pr,pl=mass_to_u_periodic(p);pbr,pbl=mass_to_u_periodic(pb);alr,all_=mass_to_u_periodic(al);altr,altl=mass_to_u_periodic(alt)
 mur,mul=mass_to_u_periodic(mu)
 phr,phl=mass_to_u_periodic(ph);phpr,phpl=mass_to_u_periodic(php)
 aa=(phr[:,1:,:]-phl[:,1:,:])+(phr[:,:-1,:]-phl[:,:-1,:])
 bb=(altr+altl)*(pr-pl)
 cc=(alr+all_)*(pbr-pbl)
 # dpn: WRF horizontal pressure gradient, Fortran levels 1-based.
 psum=pr+pl;dpn=np.zeros((py,pz+1,px+1),dtype=np.float64)
 dpn[:,0,:]=0.5*(pgf['cf1']*psum[:,0,:]+pgf['cf2']*psum[:,1,:]+pgf['cf3']*psum[:,2,:])
 if pz>1:
  for k in range(1,pz):dpn[:,k,:]=0.5*(fnm[k]*psum[:,k,:]+fnp[k]*psum[:,k-1,:])
 if pgf['top_lid']:
  dpn[:,-1,:]=0.5*(pgf['cfn']*psum[:,-2,:]+pgf['cfn1']*psum[:,-3,:])
 else:dpn[:,-1,:]=0.0
 if pgf['nonhydro']:
  fourth=(phpr-phpl)*(rdnw[None,:pz,None]*(dpn[:,1:,:]-dpn[:,:-1,:])-0.5*c1[None,:,None]*(mul+mur)[:,None,:])
 else:fourth=np.zeros_like(aa)
 L=c1[None,:,None]*muu[:,None,:]+c2[None,:,None]
 ratio=msfux/msfuy
 dpx={'phi':0.5*pgf['rdx']*ratio[:,None,:]*L*aa,
      'alt_dP':0.5*pgf['rdx']*ratio[:,None,:]*L*bb,
      'al_dPB':0.5*pgf['rdx']*ratio[:,None,:]*L*cc,
      'fourth':pgf['rdx']*ratio[:,None,:]*fourth}
 coupled={k:-cqu*v for k,v in dpx.items()};coupled['total']=sum(coupled.values())
 physical={k:v*msfuy[:,None,:]/L for k,v in coupled.items()}
 return {'layer_mass_u':L,'msfuy':msfuy,'ru_delta_coupled_f64_source_oracle':coupled,'ft_physical_f64_source_oracle':physical,
         'dpn':dpn,'p':p,'al':al,'alt':alt,'ph':ph,'pb':pb}

def current_full_u_physical(ctx):
 fm,ff,cm,cs,cr,dims=ctx;nx,ny,nz,nxu,nyv,nzw=dims;px,py,pz=full.physical_dimensions(dims,fm);b=fm['bounds'];i0,j0,k0=b['ids'],b['jds'],b['kds']
 continuity=full.calc_mu_dot(fm,ff,dims);state=full.logical_fortran_state(fm,ff,dims)
 ru=full._slice3(ff['ru_tend'],b,i0=i0,i1=i0+nxu,k0=k0,k1=k0+nz,j0=j0,j1=j0+ny)[:py,:,:px+1].astype(np.float64)
 muu=full._slice2(ff['muu'],b,i0=i0,i1=i0+nxu,j0=j0,j1=j0+ny)[:py,:px+1].astype(np.float64)
 msfuy=full._slice2(ff['msfuy'],b,i0=i0,i1=i0+nxu,j0=j0,j1=j0+ny)[:py,:px+1].astype(np.float64)
 c1=ff['c1h'][k0-b['kms']:k0-b['kms']+pz].astype(np.float64);c2=ff['c2h'][k0-b['kms']:k0-b['kms']+pz].astype(np.float64)
 layer=c1[None,:,None]*muu[:,None,:]+c2[None,:,None]
 ft_u=full.fortran_tendency_to_physical(ru,state['u'][:py,:,:px+1].astype(np.float64),c1,continuity['mu_u_dot'][:py,:px+1],msfuy,layer)
 cpp_u=cr['u'][:py,:,:px+1].astype(np.float64)
 return ft_u,cpp_u

def ft_accumulator_resolution(before,after,scale):
 # Resolution estimate, not a total formula-error bound. The accumulated WRF
 # arrays are REAL*4; the per-call addition rounds once into the post value.
 b=np.asarray(before,dtype=np.float32);a=np.asarray(after,dtype=np.float32)
 def ulp(x):
  xp=np.nextafter(x,np.float32(np.inf),dtype=np.float32);xm=np.nextafter(x,np.float32(-np.inf),dtype=np.float32)
  return np.maximum(np.abs(xp.astype(np.float64)-x.astype(np.float64)),np.abs(x.astype(np.float64)-xm.astype(np.float64)))
 def distribution(x):
  q=np.asarray(x,dtype=np.float64);return {**stats(q),'percentiles':{str(p):float(np.percentile(q,p)) for p in (50,90,95,99,99.9,100)},
      'exact_zero_count':int(np.count_nonzero(q==0.0))}
 ub,ua=ulp(b),ulp(a);s=f64(scale)
 add_bound=0.5*ua*s
 endpoint_bound=0.5*(ub+ua)*s
 return {'definition':'single-precision accumulator resolution only: 0.5 ULP(post) scaled estimates one rounded accumulator add; 0.5*(ULP(pre)+ULP(post)) is a conservative endpoint uncertainty scale. Neither bounds internal PGF formula-rounding.',
   'half_ulp_post_add_physical':distribution(add_bound),'half_sum_endpoint_ulps_physical':distribution(endpoint_bound),
   'subnormal_minimum_is_not_interpreted_as_typical_floor':float(np.min(endpoint_bound[endpoint_bound>0])) if np.any(endpoint_bound>0) else 0.0}

def analyze_case(args):
 ft=read_fortran_pgf(args.fortran_pgf);cpp=read_cpp_pgf(args.cpp_pgf);oper=read_cpp_operands(args.cpp_operands,cpp['native_endian'])
 gate,ctx=state_gate(args.fortran_full,args.cpp_full,ft,cpp)
 base={'case':args.case,'inputs':{'ft_pgf':ft['receipt'],'cpp_pgf':cpp['receipt'],'cpp_operands':oper['receipt'],
      'ft_full':receipt(args.fortran_full),'cpp_full':receipt(args.cpp_full)},
      'ft_pgf_header':{k:v for k,v in ft.items() if k not in ('arrays','receipt')},
      'cpp_pgf_header':{k:v for k,v in cpp.items() if k not in ('arrays','state_f64','receipt','shapes')},
      'state_gate':gate}
 run_receipt_path=E/'green_build/captures/pgf_runs.json'
 if run_receipt_path.is_file():
  run_receipt=json.loads(run_receipt_path.read_text())
  run_by_label={r['label']:r for r in run_receipt.get('runs',[])}
  base['capture_run_provenance']={'receipt':receipt(run_receipt_path),
   'fortran_case':run_by_label.get(f'{args.case}_fortran_rk3_h15'),
   'cpp_case':run_by_label.get(f'{args.case}_cpp_ark3_h15')}
 if not gate['passed']:
  base['comparison_available']=False;base['reason']=gate['reason'];return base,{}
 fm,ff,cm,cs,cr,dims=ctx;nx,ny,nz,nxu,nyv,nzw=dims;px,py,pz=full.physical_dimensions(dims,fm)
 if ft['rk_step']!=1:raise SnapshotError(f'FT capture is not from rk_step=1: {ft["rk_step"]}')
 if ft['nonhydro']!=cpp['native_nh']:raise SnapshotError('FT nonhydrostatic flag differs from C++ captured nativeNH flag')
 if ft['bounds']!=fm['bounds']:raise SnapshotError('FT PGF and Full snapshot bounds differ')
 if cpp['dims']!=tuple(cm['dims_nx_ny_nz_nxu_nyv_nzw']):raise SnapshotError('C++ PGF and Full snapshot dimensions differ')
 # Old R is meaningful only for the exact same saved six-field input state;
 # validate that source pair before computing any component delta/projection.
 old_npz=args.old_remainder_npz
 prdir=PR296/'red_provenance/fixed_xy'
 prft=prdir/f'{args.case}_fortran_rk3_h15'/'wrf_full_rhs_snapshot.bin';prcpp=prdir/f'{args.case}_cpp_ark3_h15'/'port_full_rhs_snapshot.bin'
 old_gate=full.analyze(prft,prcpp,BUNDLE/'prior_source')
 if not (old_gate.get('comparison_available') and old_gate.get('state_exact_match') and old_gate.get('full_storage_exact_match')):
  raise SnapshotError(f'PR296 residual source state gate failed for {args.case}')
 om,of=full.read_fortran(prft);oc,os,orr=full.read_cpp(prcpp)
 current_ft_state=full.logical_fortran_state(fm,ff,dims);old_ft_state=full.logical_fortran_state(om,of,dims)
 old_state_cpp=os
 cross_old={k:{'current_fortran_equals_old_fortran':bool(np.array_equal(current_ft_state[k],old_ft_state[k])),
                'current_cpp_equals_old_cpp':bool(np.array_equal(cs[k],old_state_cpp[k]))} for k in ('u','v','w','ph','t','mu')}
 if not all(v for item in cross_old.values() for v in item.values()):raise SnapshotError('current PGF run does not exactly match the old residual Full-state inputs')
 old_npz=args.old_remainder_npz
 z=np.load(old_npz)
 required=('delta_full_minus_hd_minus_vdiff','ft_full_u_phys','cpp_full_u_phys','whole_delta')
 if any(k not in z for k in required):raise SnapshotError(f'old residual NPZ lacks required fields {required}')
 oldR=np.asarray(z['delta_full_minus_hd_minus_vdiff'][...,:px],dtype=np.float64)
 if oldR.shape!=(py,pz,px) or not np.isfinite(oldR).all():raise SnapshotError(f'old residual shape/nonfinite failure: {oldR.shape}')
 current_ft_full_u,current_cpp_full_u=current_full_u_physical(ctx)
 old_ft_full_u=np.asarray(z['ft_full_u_phys'],dtype=np.float64);old_cpp_full_u=np.asarray(z['cpp_full_u_phys'],dtype=np.float64);old_whole=np.asarray(z['whole_delta'],dtype=np.float64)
 full_u_reuse_gate={'ft_physical_full_u_matches_old_bitwise':bool(np.array_equal(current_ft_full_u,old_ft_full_u)),
   'cpp_physical_full_u_matches_old_bitwise':bool(np.array_equal(current_cpp_full_u,old_cpp_full_u)),
   'whole_delta_matches_old_bitwise':bool(np.array_equal(current_cpp_full_u-current_ft_full_u,old_whole))}
 if not all(full_u_reuse_gate.values()):raise SnapshotError(f'old residual full-U source arrays differ from current run: {full_u_reuse_gate}')
 # Geometry, six-field state, and reuse of the exact old full-RHS difference are gated before component differencing.
 b=ft['bounds'];i0,j0,k0=b['ids'],b['jds'],b['kds'];a=ft['arrays']
 ru0=_slice3(a['ru_tend_before'],b,i0=i0,i1=i0+nxu,k0=k0,k1=k0+nz,j0=j0,j1=j0+ny)[:py,:,:px+1].astype(np.float64)
 ru1=_slice3(a['ru_tend_after'],b,i0=i0,i1=i0+nxu,k0=k0,k1=k0+nz,j0=j0,j1=j0+ny)[:py,:,:px+1].astype(np.float64)
 ft_coupled=ru1-ru0
 oracle=ft_fp64_oracle(ft,dims)
 L=oracle['layer_mass_u'];msfuy=oracle['msfuy']
 ft_phys=ft_coupled*msfuy[:,None,:]/L
 cpparr=cpp['arrays'];cpp_inc=cpparr['pgf_scaled_coupled'][:py,:,:px+1];cpp_mass=cpparr['velocity_mass_u'][:py,:,:px+1]
 cpp_unscaled=cpparr['pgf_unscaled'][:py,:,:px+1];cpp_alpha=cpparr['alpha_u'][:py,:,:px+1]
 if np.any(cpp_mass==0) or np.any(cpp_alpha==0) or np.any(L==0):raise SnapshotError('zero physical normalization denominator')
 cpp_phys=cpp_inc/cpp_mass;cpp_phys_from_unscaled=cpp_unscaled/cpp_alpha
 if not all(np.isfinite(x).all() for x in (ft_phys,cpp_phys,cpp_phys_from_unscaled)):raise SnapshotError('non-finite PGF normalization')
 pgf_delta=(cpp_phys-ft_phys)[:,:,:px]
 # Compare operand sidecar on overlapping physical mass cells; differences are reported, not gated.
 ops=oper['arrays']; opcomp={}
 for name,ftname,nzcount in [('p','p',pz),('al','al',pz),('alt','alt',pz),('ph','ph',pz+1)]:
  farr=a[ftname]
  fs=_slice3(farr,b,i0=i0,i1=i0+nx,k0=k0,k1=k0+nzcount,j0=j0,j1=j0+ny)[:py,:nzcount,:px].astype(np.float64)
  ca=ops[name][:py,:nzcount,:px]
  if fs.shape!=ca.shape:raise SnapshotError(f'operand {name} paired shapes differ {fs.shape} {ca.shape}')
  opcomp[name]={'fortran_vs_cpp_actual_call':stats(ca-fs),'fortran':stats(fs),'cpp':stats(ca),'bitwise_equal':bool(np.array_equal(ca,fs))}
 ft_oracle=oracle['ft_physical_f64_source_oracle']['total'][:,:,:px]
 ft_actual_owner=ft_phys[:,:,:px]
 cpp_owner=cpp_phys[:,:,:px]
 dpgf_oracle=cpp_owner-ft_oracle
 # Decompose the old residual after the newly measured PGF discrepancy.
 newR=oldR-pgf_delta
 regions={'all_owner':(slice(None),slice(None),slice(None)), 'seam_x0':(slice(None),slice(None),slice(0,1)),
          'interior_x1_to15':(slice(None),slice(None),slice(1,px))}
 region_metrics={}
 arrays={'ft_pgfcoupled_observed':ft_coupled,'ft_pgf_physical_actual':ft_phys,'ft_pgf_physical_f64_oracle':oracle['ft_physical_f64_source_oracle']['total'],
   'cpp_pgf_coupled_scaled':cpparr['pgf_scaled_coupled'][:py,:,:px+1],'cpp_velocity_mass_u':cpparr['velocity_mass_u'][:py,:,:px+1],
   'cpp_pgf_physical_actual':cpp_phys,'cpp_pgf_physical_from_unscaled_alpha':cpp_phys_from_unscaled,
   'delta_pgf_cpp_minus_ft':pgf_delta,'delta_pgf_cpp_minus_ft_f64oracle':dpgf_oracle,
   'old_remainder_unique_u':oldR,'new_remainder_after_pgf':newR}
 for name,sl in regions.items():
  d=pgf_delta[sl];r=oldR[sl];nr=newR[sl]
  region_metrics[name]={'count':int(d.size),'pgf_component_delta':stats(d),'old_R':stats(r),'new_R_old_minus_deltaPGF':stats(nr),
      'projection':projection(r,d),'oracle_pressure_delta':stats(dpgf_oracle[sl]),
      'ft_actual_minus_f64_oracle':stats(ft_actual_owner[sl]-ft_oracle[sl]),
      'cpp_scaled_over_mass_vs_unscaled_over_alpha':stats(cpp_phys[sl]-cpp_phys_from_unscaled[sl])}
 acc_floor=ft_accumulator_resolution(ru0[:,:,:px],ru1[:,:,:px],(msfuy[:,None,:]/L)[:,:,:px])
 base.update({'comparison_available':True,'physical_dims':[px,py,pz],'cpp_storage_dims':list(dims),
   'cross_run_state_gate_to_old_R':cross_old,'old_full_rhs_reuse_gate':full_u_reuse_gate,'owner_mask_counts':{'all_owner':py*pz*px,'seam_x0':py*pz,'interior_x1_to15':py*pz*(px-1)},
   'normalization':{'fortran_actual':'(ru_tend_after-ru_tend_before)*msfuy/(c1h*muu+c2h)','fortran_source_oracle':'-cqu*dpx*msfuy/(c1h*muu+c2h), source terms A-D computed in float64 from actual FP32 operands; captured cqu is used directly, with no dry cqu=1 assumption','cpp_actual':'scaled_coupled_PGF/velocity_mass_u; cross-checked against unscaled_PGF/alpha_u','no_mu_dot':'PGF has no mu_tend increment, so no product-rule subtraction is applied'},
   'fortran_f64_source_oracle':{'terms_physical_m_s2':{k:stats(v[:,:,:px]) for k,v in oracle['ft_physical_f64_source_oracle'].items()},
     'actual_minus_oracle':stats(ft_actual_owner-ft_oracle),
     'actual_minus_oracle_over_half_ulp_post_rms_scale':rms(ft_actual_owner-ft_oracle)/acc_floor['half_ulp_post_add_physical']['rms'] if acc_floor['half_ulp_post_add_physical']['rms'] else None,
     'cqu_owner':stats(_slice3(a['cqu'],b,i0=i0,i1=i0+nxu,k0=k0,k1=k0+nz,j0=j0,j1=j0+ny)[:py,:,:px].astype(np.float64)),
     'cqu_max_abs_minus_one':float(np.max(np.abs(_slice3(a['cqu'],b,i0=i0,i1=i0+nxu,k0=k0,k1=k0+nz,j0=j0,j1=j0+ny)[:py,:,:px].astype(np.float64)-1.0))),
     'accumulator_fp32_resolution':acc_floor},
   'cpp_scaling_identity':stats(cpp_phys-cpp_phys_from_unscaled),'same_call_pressure_operand_comparisons':opcomp,
   'regions':region_metrics,'old_remainder_provenance':receipt(old_npz),
   'source_refs':{'fortran_call':'dyn_em/module_em.F:778-788','fortran_formula':'dyn_em/module_big_step_utilities_em.F:2384-2412','cpp_increment_and_mass_scale':'external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp:19934-19937,19940-19988','cpp_physical_conversion':'external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp:25016-25140'}})
 arrays.update({'fortran_source_oracle_component_'+k:v[:,:,:px] for k,v in oracle['ft_physical_f64_source_oracle'].items()})
 return base,arrays

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--case',choices=('initial','stored'),required=True)
 p.add_argument('--fortran-pgf',type=Path,required=True);p.add_argument('--cpp-pgf',type=Path,required=True);p.add_argument('--cpp-operands',type=Path,required=True)
 p.add_argument('--fortran-full',type=Path,required=True);p.add_argument('--cpp-full',type=Path,required=True)
 p.add_argument('--old-remainder-npz',type=Path,default=None);p.add_argument('--out',type=Path,default=None);p.add_argument('--npz',type=Path,default=None)
 a=p.parse_args();a.old_remainder_npz=a.old_remainder_npz or (PR296/f'final_{a.case}_term_arrays.npz')
 out=a.out or E/'red_arrays'/f'{a.case}_u_pgf_delta_analysis.json';npz=a.npz or E/'red_arrays'/f'{a.case}_u_pgf_delta_arrays.npz'
 try: report,arrays=analyze_case(a)
 except (SnapshotError,full.SnapshotError,ValueError,KeyError,struct.error) as exc:
  report={'schema':'red-same-state-u-pgf-delta-v1','case':a.case,'comparison_available':False,'reason':str(exc),
   'input_receipts':{str(x):receipt(x) for x in (a.fortran_pgf,a.cpp_pgf,a.cpp_operands,a.fortran_full,a.cpp_full,a.old_remainder_npz) if x.exists()}}
 else:
  npz.parent.mkdir(parents=True,exist_ok=True);np.savez_compressed(npz,**arrays)
  report['npz']={'path':str(npz),'sha256':sha(npz),'byte_count':npz.stat().st_size}
 out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(out)
if __name__=='__main__':main()
