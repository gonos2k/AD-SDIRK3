# Red review: same-state U-PGF component

**Evidence scope:** Four frozen 15-second captures (initial/stored Fortran RK3 and C++ ARK3), plus PR296’s captured post-H/V U remainder. The offline analyzer makes no model calls. All displayed RHS values are physical U acceleration in m/s².

## Gates and method

Both initial and stored Fortran/C++ Full snapshots pass the physical and storage six-field state gate. Each Fortran PGF-call state (`u,v,w,t,ph,mu`) matches its Fortran Full snapshot exactly; each C++ call input state matches its C++ Full snapshot exactly. All six Fortran/C++ state arrays also match bitwise between current PGF captures and the PR296 Full-state inputs used for the old remainder. The current Full-U outputs and whole deltas likewise match PR296 bitwise before the component removal. Both captures are RK stage 1, nonhydrostatic; `n_moist=2`, and captured `cqu` is exactly 1 over the 4,096 U owners.

Fortran’s actual PGF-only accumulator delta is normalized as `(ru_tend_after − ru_tend_before) * msfuy / (c1h*muu+c2h)`. C++ uses its actual scaled coupled PGF divided by `velocity_mass_u`; `scaled/mass` agrees with `unscaled/alpha` within `1.1e-19` max. I also reconstructed the Fortran A–D source equation in FP64 from the actual call’s FP32 operands. This is an operand-based source oracle, not a simulated stage-zero tendency.

The old remainder is `R_old = Full_CPP−Full_Fortran−ΔH−ΔV` on the unique owner mask. The updated residual is formed elementwise as `R_old − (PGF_CPP−PGF_Fortran)`. Projection and squared-norm identities are reported directly; RMS norms are not subtracted.

## Results

Initial: the PGF component delta is `6.48457e-8` RMS / `2.32847e-7` max, against old remainder `6.48458e-8` RMS / `2.32848e-7` max. After subtracting the captured PGF delta, the remainder is `1.33602e-11` RMS / `6.78544e-11` max. The pressure delta has cosine similarity `0.999999979` with old R and explains `99.999996%` of its squared norm. At x=0 (256 points), the new remainder is `3.55703e-12` RMS; x=1..15 (3,840 points), it is `1.37677e-11` RMS.

Stored: PGF delta is `7.48577e-8` RMS / `2.65124e-7` max, against old remainder `7.49192e-8` RMS / `2.65139e-7` max. The new remainder is `3.06900e-9` RMS / `3.43776e-8` max, with `0.999161` cosine similarity and `99.8322%` squared-norm reduction. Seam x=0 remainder is `2.90144e-9` RMS; interior x=1..15 is `3.07985e-9` RMS. The stored residual remains measurable after removing PGF.

The same-call C++ pressure sidecar differs from the Fortran operands in p by `4.81e-3` Pa RMS initially and `5.15e-3` Pa stored; PH is bitwise equal, while al/alt differences are much smaller. These are operand comparisons, not a causal decomposition of the remaining residual.

## Precision and limits

The FP64 Fortran source reconstruction differs from the captured Fortran physical increment by `2.70e-11` RMS initially and `2.80e-11` stored. The estimated single-precision accumulator half-ULP scale is `1.66e-11` RMS (maximum `4.28e-11`); this describes accumulator resolution only and does not bound all intermediate PGF arithmetic. Consequently the initial post-subtraction residue is at this precision scale, while the stored residue remains about two orders of magnitude larger. The remaining stored difference is not assigned to pressure, transport, or another term by subtraction alone.

Both captured pressure/geometry contexts are nonhydrostatic with `top_lid=false`. The pressure increment comparison uses captured actual call terms; it does not infer C++ PGF from an old pre-add RK tendency dump. The Fortran capture also records `n_moist=2`; the measured `cqu` field, rather than a dry-case assumption, is used in the source reconstruction.

## Artifacts

- `analyze_same_state_u_pgf.py`: fail-closed, rerunnable analyzer for the frozen schemas.
- `initial_u_pgf_delta_analysis.json` / `.npz` and `stored_u_pgf_delta_analysis.json` / `.npz`: complete state gates, file hashes, component/remnant arrays, projections, source-oracle terms, and accumulator precision scales.
- `red_pgf_component_receipt.json`: case hashes and gate/precision summary.
- `green_build/captures/pgf_runs.json`: native run/build/source receipts.
