# PR298 Full U PGF capture source note

Target worktree: `/private/tmp/pr298-u-pgf-20261012` at `51527694a3cb139ae43c20532b138e4a65dd6153`. The pre-edit graph gate passed (graph SHA-256 `67c7872b99d4c85f5f85b96e317743cbb2eeeeba25cc8c38d653c427f9c5566d`; receipt `/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012/green_graph/pre_edit_pgf_graph_receipt.json`).

The one-shot observer is inside `computeUnifiedRHS` Full U-PGF, after the existing `use_wrf_mass_flux` scaling and just before `ru_tend += u_tend_pgf`. It requires `RhsMode::Full`, the canonical horizontal mass-flux path, `imex_split_mode==3`, `isPackedPeriodicDomain()`, one rank in each horizontal direction, and `WRF_PARITY_RK_TEND_DUMP=1`. The snapshot records the actual `native_nh` bool for this same call. It does not add an RHS evaluation or alter pressure, mass, boundary, or stage values.

`port_u_pgf_snapshot.bin` is version 2. Its first eight int32 values are `[version, Nx, Ny, Nz, Nxu, Nyv, Nzw, raw_input_state_count]`; an int32 `native_nh` flag follows. Five float64 C-order blocks then store (1) the raw input state vector from this call in pack order `u,v,w,ph,t,mu`, (2) actual coupled `u_tend_pgf`, (3) `velocity_mass_u`, (4) the same contribution before the existing `velocity_mass_u/alpha_u` scale, and (5) that `alpha_u` denominator. All PGF/mass/alpha blocks retain full `[Ny,Nz,Nxu]`; no U seam, closing face, or packed padding is removed. The raw state count is checked against all six staggered-field dimensions.

This supports a direct same-call check that `unscaled PGF / alpha_u` equals `coupled PGF / velocity_mass_u`. The PGF block mutates only `ru_tend`; it has no `mu_tend` contribution. The later `-u*rate_u` product-rule term remains in the whole-RHS conversion and is not included in this partial component.

When same-call `p_pert_mass`, `al_pert_mass_fs`, `alt_mass_fs`, and `ph` exist, `port_u_pgf_operands_snapshot.bin` records them in a separate four-block float64 schema with header `[version=1, Ny, Nz, Nx, Nzw]`. These values are observed from the current PGF call and are not recomputed.

The C++ implementation changed from SHA-256 `ff722deccd094ac507a16eb4940423b4a60a11ce124df11fd20be78b5bb4f2c3` to `473a9b5affe2e1251a85fa113bb4beb9087dce81a6860a594276ece0a347d3e8`. No build, test, or native run was performed; the same-state capture run is left for the parent. Other dirty paths (`dyn_em/module_em.F`, the portable metric analyzer, and `tools/__pycache__/`) were left untouched.
