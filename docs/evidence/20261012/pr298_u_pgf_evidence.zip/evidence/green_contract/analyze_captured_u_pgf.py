#!/usr/bin/env python3
"""Independent offline replay of captured Fortran U-PGF and paired C++ increment."""
import hashlib, importlib.util, json, struct, sys
from pathlib import Path
import numpy as np
from netCDF4 import Dataset

ROOT=Path('/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012')
CAP=ROOT/'green_build/captures/pgf'
OUT=ROOT/'green_contract/captured_u_pgf_replay.json'
PR296=Path('/Users/yhlee/AD-SDIRK3-review-evidence/seam-cause-acceptance-20261012')
FULLMOD=PR296/'analyze_snapshots.py'
sp=importlib.util.spec_from_file_location('full_snapshot_contract',FULLMOD)
full=importlib.util.module_from_spec(sp);sys.modules[sp.name]=full;sp.loader.exec_module(full)
RED=ROOT/'red_arrays/analyze_same_state_u_pgf.py'
sp=importlib.util.spec_from_file_location('cpp_pgf_reader',RED)
reader=importlib.util.module_from_spec(sp);sys.modules[sp.name]=reader;sp.loader.exec_module(reader)

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def receipt(p): return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def stats(x):
 x=np.asarray(x,dtype=np.float64)
 return {'count':int(x.size),'rms':float(np.sqrt(np.mean(x*x))) if x.size else 0.,'max_abs':float(np.max(np.abs(x))) if x.size else 0.}
def proj(r,d):
 r=np.asarray(r,dtype=np.float64);d=np.asarray(d,dtype=np.float64);rr=float(np.sum(r*r));dd=float(np.sum(d*d));rd=float(np.sum(r*d));n=float(np.sum((r-d)**2))
 return {'R_dot_delta':rd,'R_energy':rr,'delta_energy':dd,'new_R_energy':n,'signed_projection_pct':100*rd/rr if rr else None,'delta_energy_share_pct':100*dd/rr if rr else None,'squared_residual_reduction_pct':100*(1-n/rr) if rr else None}
def read_ft(path):
 d=path.read_bytes(); ver,=struct.unpack_from('<i',d,0)
 if ver!=1: raise ValueError('unexpected FT schema')
 b=struct.unpack_from('<12i',d,4);rk,nm=struct.unpack_from('<2i',d,52);sc=struct.unpack_from('<7f',d,60);nh,top=struct.unpack_from('<2i',d,88)
 ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme=b;ni,nj,nk=ime-ims+1,jme-jms+1,kme-kms+1
 p=96;arr={};sh3=(nj,nk,ni);sh2=(nj,ni);sh1=(nk,)
 def get(name,shape):
  nonlocal p
  n=int(np.prod(shape));v=np.frombuffer(d,dtype='<f4',count=n,offset=p).reshape(shape).copy();p+=n*4;arr[name]=v
 # Exact WRITE order at module_em.F:769-770, including ranks.
 for n in ('ru_before','rv_before','u','v','w','t','ph'):get(n,sh3)
 get('mu',sh2)
 for n in ('p','pb','al','alt','php','cqu'):get(n,sh3)
 get('muu',sh2);get('c1h',sh1);get('c2h',sh1);get('msfux',sh2);get('msfuy',sh2)
 for n in ('rdnw','fnm','fnp'):get(n,sh1)
 get('ru_after',sh3);get('rv_after',sh3)
 if p!=len(d):raise ValueError(f'FT parse cursor {p} != file bytes {len(d)}')
 bdict=dict(zip(('ids','ide','jds','jde','kds','kde','ims','ime','jms','jme','kms','kme'),map(int,b)))
 return {'bounds':bdict,'rk_step':rk,'n_moist':nm,'rdx':float(sc[0]),'rdy':float(sc[1]),'cf1':sc[2],'cf2':sc[3],'cf3':sc[4],'cfn':sc[5],'cfn1':sc[6],'nonhydro':bool(nh),'top_lid':bool(top),'arrays':arr,'receipt':receipt(path)}
def s3(a,b,i0,i1,k0,k1,j0,j1):return a[j0-b['jms']:j1-b['jms'],k0-b['kms']:k1-b['kms'],i0-b['ims']:i1-b['ims']]
def s2(a,b,i0,i1,j0,j1):return a[j0-b['jms']:j1-b['jms'],i0-b['ims']:i1-b['ims']]
def periodic_faces(a):return np.concatenate((a[...,-1:],a[...,:-1]),axis=-1),a

def replay(ft,dims):
 b=ft['bounds'];a=ft['arrays'];nx,ny,nz,nxu,nyv,nzw=dims;px,py,pz=full.physical_dimensions(dims,{'bounds':b})
 i,j,k=b['ids'],b['jds'],b['kds']
 def m3(n,ni=nx,nk=nz):return s3(a[n],b,i,i+ni,k,k+nk,j,j+ny)[:py,:,:]
 def m2(n,ni=nx):return s2(a[n],b,i,i+ni,j,j+ny)[:py,:]
 # unique physical mass cells x=0..15; U faces x=0..16 incl duplicate periodic endpoint.
 p=m3('p')[:,:,:px].astype(np.float64);pb=m3('pb')[:,:,:px].astype(np.float64)
 al=m3('al')[:,:,:px].astype(np.float64);alt=m3('alt')[:,:,:px].astype(np.float64)
 ph=m3('ph',nk=pz+1)[:,:,:px].astype(np.float64);php=m3('php')[:,:,:px].astype(np.float64)
 mu=m2('mu')[:,:px].astype(np.float64);muu=m2('muu',nxu)[:,:px+1].astype(np.float64)
 mx=m2('msfux',nxu)[:,:px+1].astype(np.float64);my=m2('msfuy',nxu)[:,:px+1].astype(np.float64)
 cq=m3('cqu',ni=nxu)[:,:,:px+1].astype(np.float64)
 pl,pr=periodic_faces(p);pbl,pbr=periodic_faces(pb);all_,alr=periodic_faces(al);altl,altr=periodic_faces(alt);phl,phr=periodic_faces(ph);phpl,phpr=periodic_faces(php);mul,mur=periodic_faces(mu)
 A=(phr[:,1:,:]-phl[:,1:,:])+(phr[:,:-1,:]-phl[:,:-1,:])
 B=(altr+altl)*(pr-pl);C=(alr+all_)*(pbr-pbl)
 ps=pr+pl;dpn=np.zeros((py,pz+1,px),dtype=np.float64)
 dpn[:,0,:]=.5*(ft['cf1']*ps[:,0,:]+ft['cf2']*ps[:,1,:]+ft['cf3']*ps[:,2,:])
 for kk in range(1,pz):dpn[:,kk,:]=.5*(a['fnm'][kk]*ps[:,kk,:]+a['fnp'][kk]*ps[:,kk-1,:])
 dpn[:,-1,:]=.5*(ft['cfn']*ps[:,-2,:]+ft['cfn1']*ps[:,-3,:]) if ft['top_lid'] else 0.
 D=(phpr-phpl)*(a['rdnw'][None,:pz,None]*(dpn[:,1:,:]-dpn[:,:-1,:])-.5*a['c1h'][None,:pz,None]*(mul+mur)[:,None,:]) if ft['nonhydro'] else np.zeros_like(A)
 L=a['c1h'][None,:pz,None]*muu[:,:px][:,None,:]+a['c2h'][None,:pz,None]
 mx=mx[:,:px];my=my[:,:px];cq=cq[:,:,:px]
 with np.errstate(divide='ignore',invalid='ignore'):
  fac=.5*ft['rdx']*(mx/my)[:,None,:]*L
  terms={'A_phi':-cq*fac*A,'B_alt_p':-cq*fac*B,'C_al_pb':-cq*fac*C,'D_nh':-cq*ft['rdx']*(mx/my)[:,None,:]*D}
  coupled=sum(terms.values());physical={q:x*my[:,None,:]/L for q,x in terms.items()};physical['total']=coupled*my[:,None,:]/L
 # Separate FP32 operation-order replay of the Fortran expression and its one
 # accumulator update. This is not a compiler bitwise emulator, but keeps each
 # REAL array operation at the source dtype and gives a check independent of the
 # FP64 algebraic reconstruction above.
 p32=p.astype(np.float32);pb32=pb.astype(np.float32);al32=al.astype(np.float32);alt32=alt.astype(np.float32);ph32=ph.astype(np.float32);php32=php.astype(np.float32);mu32=mu.astype(np.float32)
 pl32,pr32=periodic_faces(p32);pbl32,pbr32=periodic_faces(pb32);all32,alr32=periodic_faces(al32);altl32,altr32=periodic_faces(alt32);phl32,phr32=periodic_faces(ph32);phpl32,phpr32=periodic_faces(php32);mul32,mur32=periodic_faces(mu32)
 A32=(phr32[:,1:,:]-phl32[:,1:,:])+(phr32[:,:-1,:]-phl32[:,:-1,:])
 B32=(altr32+altl32)*(pr32-pl32);C32=(alr32+all32)*(pbr32-pbl32)
 ps32=pr32+pl32;dpn32=np.zeros((py,pz+1,px),dtype=np.float32)
 f32=lambda x:np.float32(x)
 dpn32[:,0,:]=f32(.5)*(f32(ft['cf1'])*ps32[:,0,:]+f32(ft['cf2'])*ps32[:,1,:]+f32(ft['cf3'])*ps32[:,2,:])
 for kk in range(1,pz):dpn32[:,kk,:]=f32(.5)*(a['fnm'][kk]*ps32[:,kk,:]+a['fnp'][kk]*ps32[:,kk-1,:])
 dpn32[:,-1,:]=f32(.5)*(f32(ft['cfn'])*ps32[:,-2,:]+f32(ft['cfn1'])*ps32[:,-3,:]) if ft['top_lid'] else f32(0.)
 mu_coupled32=f32(.5)*(a['c1h'][None,:pz,None]*mul32[:,None,:]+a['c1h'][None,:pz,None]*mur32[:,None,:])
 D32=(phpr32-phpl32)*(a['rdnw'][None,:pz,None]*(dpn32[:,1:,:]-dpn32[:,:-1,:])-mu_coupled32) if ft['nonhydro'] else np.zeros_like(A32)
 L32=a['c1h'][None,:pz,None]*muu[:,:px].astype(np.float32)[:,None,:]+a['c2h'][None,:pz,None]
 ratio32=mx.astype(np.float32)/my.astype(np.float32)
 inside32=A32+B32+C32
 dpx32=ratio32[:,None,:]*f32(.5);dpx32=dpx32*f32(ft['rdx']);dpx32=dpx32*L32;dpx32=dpx32*inside32
 dpx32=dpx32+ratio32[:,None,:]*f32(ft['rdx'])*D32 if ft['nonhydro'] else dpx32
 cq32=cq.astype(np.float32);before32=a['ru_before'][j-b['jms']:j-b['jms']+py,k-b['kms']:k-b['kms']+pz,i-b['ims']:i-b['ims']+px].astype(np.float32)
 after32=before32-cq32*dpx32
 return {'terms_coupled':terms,'terms_physical':physical,'terms_fp32':{'actual_update_predicted_after':after32,'dpx':dpx32},'L':L,'msfux':mx,'msfuy':my,'p':p,'pb':pb,'al':al,'alt':alt,'ph':ph,'php':php,'cqu':cq,'muu':muu,'mu':mu,'dpn':dpn,'dims':[px,py,pz]}

def analyze(case):
 fd=CAP/f'{case}_fortran_rk3_h15';cd=CAP/f'{case}_cpp_ark3_h15'
 ft=read_ft(fd/'wrf_u_pgf_snapshot.bin');cpp=reader.read_cpp_pgf(cd/'port_u_pgf_snapshot.bin');ops=reader.read_cpp_operands(cd/'port_u_pgf_operands_snapshot.bin',cpp['native_endian'])
 fmeta,ff=full.read_fortran(fd/'wrf_full_rhs_snapshot.bin');cmeta,cs,cr=full.read_cpp(cd/'port_full_rhs_snapshot.bin')
 dims=tuple(cmeta['dims_nx_ny_nz_nxu_nyv_nzw']);nx,ny,nz,nxu,nyv,nzw=dims;px,py,pz=full.physical_dimensions(dims,fmeta)
 gate=full.analyze(fd/'wrf_full_rhs_snapshot.bin',cd/'port_full_rhs_snapshot.bin',Path('/private/tmp/pr298-u-pgf-20261012'))
 if not(gate.get('comparison_available') and gate.get('state_exact_match') and gate.get('full_storage_exact_match')):raise ValueError('six-field exact state/storage gate failed')
 if ft['nonhydro']!=cpp['native_nh']:raise ValueError('FT nonhydro flag != C++ nativeNH flag')
 b=ft['bounds'];i,j,k=b['ids'],b['jds'],b['kds'];a=ft['arrays']
 before=s3(a['ru_before'],b,i,i+nxu,k,k+nz,j,j+ny)[:py,:,:px].astype(np.float64)
 after=s3(a['ru_after'],b,i,i+nxu,k,k+nz,j,j+ny)[:py,:,:px].astype(np.float64)
 obs=after-before;rep=replay(ft,dims);L=rep['L'];my=rep['msfuy']
 ft_actual=obs*my[:,None,:]/L
 c=cpp['arrays'];cinc=c['pgf_scaled_coupled'][:py,:,:px];cmass=c['velocity_mass_u'][:py,:,:px];calpha=c['alpha_u'][:py,:,:px];cun=c['pgf_unscaled'][:py,:,:px]
 if np.any(cmass==0) or np.any(calpha==0) or np.any(L==0):raise ValueError('zero mass normalization within unique face owners')
 cpp_actual=cinc/cmass;cpp_unscaled=cun/calpha
 # Rebuild the C++ source equation from its actual same-call P'/AL'/ALT/PH sidecar,
 # using the shared captured Fortran geometry/base. This is an offline formula replay,
 # not an observation of internal C++ intermediates.
 co=ops['arrays'];caop=lambda n:co[n][:py,:,:px].astype(np.float64)
 cp=caop('p');ca=caop('al');cat=caop('alt');cph=co['ph'][:py,:,:px].astype(np.float64)
 pf=rep['p'];pbf=rep['pb'];af=rep['al'];altf=rep['alt'];phf=rep['ph'];phpf=rep['php'];mf=rep['mu']
 # PB/PHB are read from the identical raw WRF input file used by both runs.
 with Dataset(fd/'wrfinput_d01') as ds:
  pb_input=np.transpose(np.asarray(ds.variables['PB'][0],dtype=np.float32),(1,0,2))[:py,:,:px]
  phb_input=np.transpose(np.asarray(ds.variables['PHB'][0],dtype=np.float32),(1,0,2))[:py,:,:px]
 if not np.array_equal(pb_input,pbf.astype(np.float32)):
  raise ValueError('captured Fortran PB does not exactly match shared raw-input PB')
 cphb=phb_input.astype(np.float32)
 # compute_php receives the actual C++ PH tensor. The sidecar widens that
 # call tensor to float64; ph_base may be float32, so PyTorch promotion makes
 # the mixed sum float64. Keep the exact source association, then multiply .5.
 cph_actual=co['ph'][:py,:,:px].astype(np.float64)
 cpphp64=np.float64(.5)*((cphb[:,:-1,:].astype(np.float64)+cphb[:,1:,:].astype(np.float64))
                         +cph_actual[:,:-1,:]+cph_actual[:,1:,:])
 php_diff=cpphp64-phpf
 cl,cr=periodic_faces(cp);cal,car=periodic_faces(ca);calt,caltar=periodic_faces(cat);cbpl,cbpr=periodic_faces(pb_input.astype(np.float64));cphl,cphr=periodic_faces(cph)
 caA=(cphr[:,1:,:]-cphl[:,1:,:])+(cphr[:,:-1,:]-cphl[:,:-1,:])
 caB=(caltar+calt)*(cr-cl);caC=(car+cal)*(cbpr-cbpl)
 cps=cr+cl;cdpn=np.zeros((py,pz+1,px),dtype=np.float64)
 cdpu=.5*(cp+np.roll(cp,1,axis=2))
 cdpu=np.concatenate((cdpu,cdpu[:,:,:1]),axis=2)
 cd_pbot=ft['cf1']*cdpu[:,0,:]+ft['cf2']*cdpu[:,1,:]+ft['cf3']*cdpu[:,2,:]
 cdpn[:,0,:]=cd_pbot[:,:px]
 for kk in range(1,pz):
  cdpn[:,kk,:]=ft['arrays']['fnm'][kk]*cdpu[:,kk,:px]+ft['arrays']['fnp'][kk]*cdpu[:,kk-1,:px]
 runtime=(cd/'rsl.error.0000').read_text(errors='replace')
 import re
 top_match=re.search(r'(?im)^\s*\[CONFIG\]\s*split_explicit_top_lid\s*=\s*(true|false)\s*$',runtime)
 if not top_match:raise ValueError('missing effective C++ split_explicit_top_lid runtime line')
 cpp_top_lid=top_match.group(1).lower()=='true'
 nml=(cd/'namelist.output').read_text(errors='replace')
 if re.search(r'(?im)^\s*TOP_LID\s*=\s*11\*F\s*,?',nml) is None:raise ValueError('WRF namelist output does not confirm TOP_LID=F')
 cdpn[:,-1,:]=ft['cfn']*cdpu[:,-2,:px]+ft['cfn1']*cdpu[:,-3,:px] if cpp_top_lid else 0.
 cmu_u=.5*(mf+np.roll(mf,1,axis=1))
 cphpu=cpphp64-np.roll(cpphp64,1,axis=2)
 cvert=ft['arrays']['rdnw'][None,:pz,None]*(cdpn[:,1:,:]-cdpn[:,:-1,:])-ft['arrays']['c1h'][None,:pz,None]*cmu_u[:,None,:]
 cD=cphpu*cvert if cpp['native_nh'] else np.zeros_like(caA)
 cqu_unique=rep['cqu'];c_ratio=rep['msfux']/rep['msfuy']; cL=L
 cLevel=calpha*rep['msfuy'][:,None,:]
 cterms={'A_phi':-.5*ft['rdx']*rep['msfux'][:,None,:]*caA,
         'B_alt_p':-.5*ft['rdx']*rep['msfux'][:,None,:]*caB,
         'C_al_pb':-.5*ft['rdx']*rep['msfux'][:,None,:]*caC,
         'D_nh':-ft['rdx']*(rep['msfux']/rep['msfuy'])[:,None,:]*cD/calpha}
 if not np.array_equal(cqu_unique,np.ones_like(cqu_unique)):
  cterms={n:x*cqu_unique for n,x in cterms.items()}
 cpp_src_phys=sum(cterms.values())
 cpp_primary_unscaled=(-.5*ft['rdx']*(rep['msfux']/rep['msfuy'])[:,None,:]*cLevel*(caA+caB+caC))*cqu_unique
 cpp_nh_unscaled=(-ft['rdx']*(rep['msfux']/rep['msfuy'])[:,None,:]*cD)*cqu_unique
 cpp_unscaled_src=cpp_primary_unscaled+cpp_nh_unscaled
 # With this dry captured configuration CQU=1 on unique faces; fail closed otherwise.
 cpp_replay_error=cpp_actual-cpp_src_phys
 ft_pressure_replay=rep['terms_physical']['total']
 operand_only_delta=cpp_src_phys-ft_pressure_replay
 # Source-replay FT terms should match the actual FP32 pre/post increment up to FP32 expression and accumulator rounding.
 err_oracle=ft_actual-rep['terms_physical']['total']
 pred_after32=rep['terms_fp32']['actual_update_predicted_after'];actual_after32=after.astype(np.float32)
 fp32_post_difference=(actual_after32.astype(np.float64)-pred_after32.astype(np.float64))*my[:,None,:]/L
 def ulp32(x):
  z=np.asarray(x,dtype=np.float32);up=np.nextafter(z,np.float32(np.inf),dtype=np.float32).astype(np.float64);dn=np.nextafter(z,np.float32(-np.inf),dtype=np.float32).astype(np.float64);v=z.astype(np.float64)
  return np.maximum(np.abs(up-v),np.abs(v-dn))
 scale=my[:,None,:]/L
 endpoint_half_ulp=.5*(ulp32(before)+ulp32(after))*scale
 err_abs=np.abs(err_oracle)
 delta=cpp_actual-ft_actual
 b_delta=cterms['B_alt_p']-rep['terms_physical']['B_alt_p']
 d_delta=cterms['D_nh']-rep['terms_physical']['D_nh']
 p=PR296/f'final_{case}_term_arrays.npz';z=np.load(p);R=np.asarray(z['delta_full_minus_hd_minus_vdiff'][...,:px],dtype=np.float64)
 d=delta[:,:,:px];new=R-d
 # This is a direct call-local operand comparison; differing p/al/alt can witness EOS/pressure derivation divergence.
 operand_diff={}
 for name in ('p','al','alt','ph'):
  f=rep[name]
  c=ops['arrays'][name][:py,:f.shape[1],:px]
  operand_diff[name]={'cpp_minus_ft':stats(c-f),'bitwise_equal':bool(np.array_equal(c,f))}
 # Shared base/geometry comparisons. WRF's full RHS capture has full-domain metric arrays; pair identity is also checked by exact input-file hash below.
 ft_full=full.read_fortran(fd/'wrf_full_rhs_snapshot.bin')[1]
 # Common captured metric arrays are compared to C++ module source's paired Full inputs through the shared state/input and are explicitly pinned.
 # Old residual is tied to the same six-field state and storage.
 olddir=PR296/'red_provenance/fixed_xy'/f'{case}_fortran_rk3_h15'
 oldcpp=PR296/'red_provenance/fixed_xy'/f'{case}_cpp_ark3_h15'
 old_gate=full.analyze(olddir/'wrf_full_rhs_snapshot.bin',oldcpp/'port_full_rhs_snapshot.bin',Path('/private/tmp/pr296-seam-cause-20261012'))
 if not(old_gate.get('comparison_available') and old_gate.get('state_exact_match') and old_gate.get('full_storage_exact_match')):raise ValueError('old-R source state gate failed')
 current_state=full.logical_fortran_state(fmeta,ff,dims);oldm,oldf=full.read_fortran(olddir/'wrf_full_rhs_snapshot.bin');oldstate=full.logical_fortran_state(oldm,oldf,dims)
 if any(not np.array_equal(current_state[n],oldstate[n]) for n in ('u','v','w','ph','t','mu')):raise ValueError('old R state differs from current captured PGF state')
 input_ft=fd/'wrfinput_d01';input_cpp=cd/'wrfinput_d01'
 result={'case':case,'same_state_gate':{'current_fortran_cpp_exact':True,'old_residual_input_exact':True,'gate_receipt':gate},
  'headers':{'ft_rk_step':ft['rk_step'],'ft_nonhydro':ft['nonhydro'],'ft_top_lid':ft['top_lid'],'cpp_native_nh':cpp['native_nh'],'cpp_top_lid_from_effective_runtime':cpp_top_lid,'physical_dims':[px,py,pz],'cpp_dims':list(dims)},
  'inputs':{'ft_pgf':ft['receipt'],'cpp_pgf':cpp['receipt'],'cpp_operands':ops['receipt'],'input_ft':receipt(input_ft),'input_cpp':receipt(input_cpp),'same_input_bytes':input_ft.read_bytes()==input_cpp.read_bytes()},
  'fortran_source_A_D_coupled_terms':{n:stats(x[:,:,:px]) for n,x in rep['terms_coupled'].items()},
  'fortran_source_A_D_physical_terms_m_s2':{n:stats(x[:,:,:px]) for n,x in rep['terms_physical'].items()},
  'fortran_source_replay_vs_actual_FP32_call':{'observed_pre_post_coupled':stats(obs),'FP64_source_oracle_coupled':stats(sum(rep['terms_coupled'].values())),'actual_minus_FP64_oracle_physical':stats(err_oracle),'actual_minus_FP64_oracle_pointwise_abs_percentiles':{str(q):float(np.percentile(err_abs,q)) for q in (50,90,99,100)},'single_precision_accumulator_endpoint_half_ulp_physical':stats(endpoint_half_ulp),'outside_endpoint_half_ulp_count':int(np.count_nonzero(err_abs>endpoint_half_ulp)),'outside_endpoint_half_ulp_max_ratio':float(np.max(err_abs/(endpoint_half_ulp+1e-300))),'actual_post_minus_FP32_expression_replay_physical':stats(fp32_post_difference),'FP32_expression_replay_post_bitwise_equal_count':int(np.count_nonzero(actual_after32==pred_after32)),'FP32_expression_replay_post_total_count':int(actual_after32.size)},
  'cpp_vs_ft_actual_pgf_physical_m_s2':stats(delta[:,:,:px]),
  'cpp_scaling_crosscheck':stats((cpp_actual-cpp_unscaled)[:,:,:px]),
  'old_U_remainder_R_decomposition':{'old_R':stats(R),'delta_PGF_CPP_minus_FT':stats(d),'R_minus_delta_PGF':stats(new),'projection':proj(R,d)},
  'same_call_pressure_operands_cpp_minus_ft':operand_diff,
  'cpp_source_replay_using_actual_operands_and_shared_basis':{'CPP_source_replay_terms_physical':{n:stats(x) for n,x in cterms.items()},'CPP_minus_FT_source_replay_terms_physical':{n:stats(x-rep['terms_physical'][n]) for n,x in cterms.items()},'CPP_source_replay_minus_captured_CPP_physical':stats(cpp_replay_error),'CPP_unscaled_source_replay_minus_captured_CPP_unscaled':stats(cpp_unscaled_src-cun),'captured_CPP_unscaled_minus_primary_only':stats(cun-cpp_primary_unscaled),'CPP_expected_NH_term4_unscaled':stats(cpp_nh_unscaled),'CPP_source_replay_minus_FT_source_replay_pressure_delta':stats(operand_only_delta),'measured_delta_minus_primary_B_operand_delta':stats(delta-b_delta),'predicted_NH_D_operand_delta':stats(d_delta),'measured_delta_minus_B_delta_minus_D_delta':stats(delta-b_delta-d_delta),'cpp_php_replay_minus_FT_captured_php':stats(php_diff),'shared_input_PB_vs_FT_PB_exact':True,'dry_cqu_unique_faces_exactly_one':bool(np.array_equal(cqu_unique,np.ones_like(cqu_unique))),'cpp_alpha_vs_shared_FT_L_over_map_y':stats(calpha-L/rep['msfuy'][:,None,:])},
  'shared_geometry_cpp_sidecar_limit':'C++ capture stores p′/al′/alt/ph and coupled PGF/mass, but not p_base, ph_base, php, actual nativeNH term-4 output, or internal dpx A-D intermediates. The shared PB/PHB input and Fortran-captured maps/vertical coefficients allow a source-equation replay; the captured C++ terms themselves are not separately observed. The replay can therefore witness whether captured pressure/EOS operands plus common geometry explain the actual PGF delta, but cannot prove absence of every internal stencil-rounding difference.',
  'scope':'No new model run. All component arithmetic is offline. The six-state gate holds; R decomposition is component attribution, not full RHS closure.'}
 return result

if __name__=='__main__':
 manifest=ROOT/'green_build/captures/pgf_runs.json'
 run_receipt=json.loads(manifest.read_text())
 out={'source_head':run_receipt['head'],'capture_manifest':receipt(manifest),'capture_source_sha256':run_receipt['source_sha256_before'],'source_refs':{'FT_write':'dyn_em/module_em.F:768-770','FT_formula':'dyn_em/module_big_step_utilities_em.F:2360-2396','CPP_calc_pressure':'external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp:19426-19437','CPP_NH':'external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp:19479-19498','CPP_compute_php':'external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp:41762-41774','CPP_capture':'external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp:19936-20018'},'cases':{c:analyze(c) for c in ('initial','stored')}}
 OUT.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(OUT)
