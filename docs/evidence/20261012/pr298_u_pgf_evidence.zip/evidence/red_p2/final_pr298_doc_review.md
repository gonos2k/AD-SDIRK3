# Red review of final PR298 U-PGF document

Local timestamp: 2026-10-12 10:40:43 JST (+0900)

Reviewed `/private/tmp/pr298-u-pgf-20261012/docs/(202610121034)_pr298_u_pressure_gradient_and_plan_contract.md` read-only.

The numerical and scope claims are consistent with the saved artifacts:

- The step/method plan guard, 3/3 focused tests, and unchanged V3 contract SHA are accurately described.
- The four short captures use the two preserved states and two methods; direct state, source and run receipts support the same-call comparisons. No 240-second forecast or efficiency claim is made.
- The PGF-only conversion keeps the column-mass product-rule term out of the isolated component. The d1/d2 and triangle criteria are not changed; reference qualification still fails all 24 V3 rows and no project-wide target is adopted.
- The old/post-HV remainder, PGF difference, subtraction remainder, cosine and squared-residual reductions match the preserved JSON. The text keeps the remainder visible, labels the subtraction as bookkeeping, and does not call it a production correction, forecast improvement, roundoff, exclusive pressure cause, or full `F_delta` parity.
- The A–D replay, endpoint-storage versus internal-arithmetic distinction, middle-binary/runtime limitation, and pre-add W/PH/theta capture gap are accurately scoped. The claim that no pressure policy or equation changed is consistent with the capture-only source receipt.

One packaging reference is still unresolved: `docs/evidence/20261012/pr298_u_pgf_evidence.zip` and its SHA receipt are named as present, but neither file existed in that directory at review time. Keep this link explicitly pending/temporary until the evidence bundle and portable verification receipt are published. The surrounding source and array evidence does not substitute for the promised bundle.

The C++ observer gate is limited to Full, canonical mode 3, packed periodic domain and one horizontal MPI process; it does not carry a separate tile/stage identity guard. The collected same-call state gates validate these captures, but the document should not imply that this observer contract generalizes to arbitrary tiling or Full calls.

No repository edit, build, model run, or test was performed for this review.
