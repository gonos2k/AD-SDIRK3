# Red review: P2 step/method guards and endpoint checks

Local timestamp: 2026-10-12 09:03:50 JST (+0900)

## Guard regression

The focused regression calls the actual `analyze()` function while mocking the two data-boundary readers (`benchmark._load_run` and `raw_initial`). All three cases pass:

- A valid plan writes 24 rows and 48 Float64 deltas, with the expected signed d1/d2 values.
- Swapping the middle run's step is rejected with the `middle_h1p875` label.
- Giving the fine run method `ARK3` is rejected with the `fine_h0p9375` label.

The analyzer pins each label to its exact expected step (3.75/1.875/0.9375 s) and requires method `RK3`; therefore any tiny or otherwise wrong step is rejected by the same equality guard. There is no separate tiny-number fixture in this regression, so the test evidence is for exact mismatch rejection via swapped h. The method check validates the plan/loader's `method` metadata; it does not independently parse the runtime branch from a namelist. Producer runtime/source receipts remain necessary to bind that metadata to the native run.

The regression command was run with `PYTHONDONTWRITEBYTECODE=1`; it passed 3/3 tests and invokes no model. The saved swapped-h and wrong-method negative controls show that the older analyzer produced outputs for both invalid plans; the guarded analyzer now fails those cases. The final `current_after_guard.json` records the current analyzer SHA, unchanged V3 contract SHA, 24 rows and 48 arrays. It is the RK3 reference-shape analysis, not an isolated PGF metric or new PGF numerical result.

## Contract and endpoint math

Frozen V3 remains byte-identical at SHA-256
`77bc4dcc7b8e0bde91d6089e9aaa11a67a49311f824d88c97919bbbb8e64fe3f`. The compact endpoint check at [`pr297_endpoint_midpoint_audit.json`](pr297_endpoint_midpoint_audit.json) independently confirms `d1+d2 = fine-coarse` elementwise for all six owned state fields at 240 s. It also keeps the two seam quantities separate:

- Coarse-to-fine trajectory-state U difference: x=0 owns 0.4813% of squared energy; x=0 plus x=15 owns 4.3501%.
- Stored same-state U RHS remainder: x=0 is 256/4096 owners and carries 5.8253% of squared energy (5.83% rounded), with RMS `7.4919237e-8 m/s²`.

The 5.83% value belongs to the RHS remainder, not the trajectory-state difference. The V3 target and PH erratum are unchanged.

## Source boundary and remaining limitation

The source audit documents the Fortran/C++ four-term U-PGF equations, periodic face-0 wrap, coupled-to-physical acceleration conversion, and the pressure-history/capture limitations. It correctly stops short of a C++/Fortran PGF parity result: there is no paired direct PGF-term capture with all required operands for both preserved states, so pressure causality and a numeric PGF remainder remain open. No source edit, build or native model run was performed for this review.

The subsequently added C++ one-shot PGF capture note is instrumentation-only: it records the coupled U-PGF increment and mass tensor, optionally the actual pressure/EOS operands, after existing mass conversion and before `ru_tend` accumulation. Its receipt says zero extra RHS evaluations and no build/test/model run; no capture bytes or PGF parity result exist yet. The criterion and V3 remain unchanged.
