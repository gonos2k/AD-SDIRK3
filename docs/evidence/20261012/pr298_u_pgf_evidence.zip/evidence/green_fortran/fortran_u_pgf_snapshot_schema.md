# Fortran actual U-PGF observation schema

This is an opt-in diagnostic around the existing `horizontal_pressure_gradient` call in `dyn_em/module_em.F` (capture block at line 717; unchanged production call at line 758 in the edited file). It observes the active `rk_tendency` accumulator and operands. It does not call the PGF routine a second time or alter its arguments/formula.

The gate uses exact `WRF_PARITY_RK_TEND_DUMP=1`, `rk_step==1`, first eligible invocation in the process, one MPI rank in DM builds, one tile spanning the complete horizontal compute domain and all active mass levels (`kts<=kds`, `kte>=kde-1`), and no microphysics (`mp_physics==0`), periodic X, and symmetric nonperiodic Y. `n_moist` is recorded but is not required to be zero because WRF may include QVAPOR without microphysics. It also rejects open X/Y, specified, nested, and polar boundary modes. `rk_tendency` has no `grid%itimestep` argument; therefore the dump is from the first eligible RK1 call (expected to be timestep 1 in the target run, but the diagnostic cannot encode or independently prove that timestep number). No OpenMP race is possible for the gated single full-domain tile call; tiled calls cannot satisfy both full-domain extent checks.

`wrf_u_pgf_snapshot.bin` is stream binary, explicitly little-endian. Layout:

1. `int32 version=1`.
2. Twelve `int32` bounds in order: `ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme`.
3. Two `int32` values: `rk_step,n_moist`.
4. Seven `float32` scalars: `rdx,rdy,cf1,cf2,cf3,cfn,cfn1`.
5. Two `int32` flags: `non_hydrostatic,top_lid` (0/1).
6. Full memory-bounds raw Fortran arrays (REAL, Fortran `i`-fastest, then `k`, then `j`) in order: `ru_tend_before`, `rv_tend_before`, `u`, `v`, `w`, `t`, `ph`, `mu`, `p`, `pb`, `al`, `alt`, `php`, `cqu`, `muu`, `c1h`, `c2h`, `msfux`, `msfuy`, `rdnw`, `fnm`, `fnp`, `ru_tend_after`, `rv_tend_after`.

State/pressure/coefficient 3-D fields use `(ims:ime,kms:kme,jms:jme)`; `muu/mu/msfux/msfuy` use `(ims:ime,jms:jme)`; `c1h/c2h/rdnw/fnm/fnp` use `(kms:kme)`. This permits reconstructing the actual call's U increment and separately retaining the pressure/base-state context. The pre-call accumulators include the upstream terms already assembled by `rk_tendency`; the post-minus-pre difference isolates this call's increment. `rv_tend` is included as a paired accumulator check, not because this task attributes V PGF. QVAPOR is not an `rk_tendency` argument; `n_moist` and captured `cqu` are recorded, but a claim that vapor is exactly zero must be supported by the frozen caller/input evidence rather than this payload.

No model build or execution was performed by Green. Validation so far is source-only: `git diff --check` passed. The edit is limited to `dyn_em/module_em.F`; its post-edit SHA256 is `790b09734aba5db1f2fe12401e634382e3c89ef0879604a2d4cceffc6caffab6`. Target worktree: `/private/tmp/pr298-u-pgf-20261012`, HEAD `51527694a3cb139ae43c20532b138e4a65dd6153`. Pre-edit graph receipt: `../green_graph/pre_edit_pgf_graph_receipt.json`.
