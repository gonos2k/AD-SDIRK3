# PR298 U-PGF runtime/context source audit

Read-only review of the uncommitted PR298 diff at base HEAD `51527694a3cb139ae43c20532b138e4a65dd6153`. No build, native execution, or source edit.

Fortran calls `horizontal_pressure_gradient` at `dyn_em/module_em.F:717-727`; it is reached inside `rk_tendency` from `solve_em.F:1159-1189`. The C++ Full branch computes the current-state pressure via `calc_p_rho_wrf` at `wrf_sdirk3_tile_unified_impl.cpp:19426-19437`, then builds primary U PGF at `:19670-19678` and converts its contribution into the coupled tendency basis at `:19925-19936`.

The Fortran wrapper now captures pre/post `ru_tend/rv_tend` and the actual U-PGF operands around `horizontal_pressure_gradient` at the call site. Its opt-in guard requires `rk_step==1`, one MPI task, full physical tile bounds, and the case’s dry/periodic/symmetric boundary contract, then uses a saved one-shot latch. `rk_tendency` has no `itimestep` argument; this captures the first eligible stage-1 call in the process. That is acceptable only for the verified initial/cold route; a DFI/restart pre-call would need an explicit route marker or arming at `solve_em` call site.

The added C++ diagnostic is opt-in (`WRF_PARITY_RK_TEND_DUMP=1`) and uses detached copies, so the capture itself does not mutate the RHS or solver caches. However, its only execution gate is `mode==Full && canonical_horizontal`, plus a process-local one-shot atomic. It is not tied to the validated initial mode-3 Full diagnostic call/state, nor does it check MPI/full-domain/tile ownership. Full calls also occur in optional probes and residual diagnostics (`:6875-78`, `:6946`, `:7965-67`, `:14122`, `:14135`). The first such call under the flag wins. On multi-rank execution, each process has its own atomic and the same output filename may be overwritten or contain partial-domain data. This is a P2 capture-validity gap; no production-path behavior change is indicated while the flag is absent.

The Fortran pressure operand at initial RK stage is carry-in `grid%p`; the current stage's `calc_p_rho(step=0)` happens later in `small_step_prep`. Later RK stages carry pressure forward from the prior acoustic loop. A valid comparison must use the matching stage/state. The new C++ sidecar captures p/al/alt/ph but not all pressure geometry/base-profile operands, so pair it with the existing full-state/geometry artifact and the exact same `wrfinput`/source pins. Without paired runtime artifacts, equality of actual geometry/source profiles remains unproven.

See `pr298_u_pgf_runtime_source_audit.json` for hashes, locations, and the minimum capture-only correction.


## Final-source closure — 2026-10-12 10:49:50 JST (+0900)

Refreshed against PR head `0d994faa00091cc746ca591e4cc1e43097fb7c79` and PGF source commit `05137f9`. The final C++ capture guard now requires `RhsMode::Full`, `canonical_horizontal`, `imex_split_mode==3`, packed periodic domain, one MPI x/y process, exact `WRF_PARITY_RK_TEND_DUMP=1`, and the first eligible call. The Fortran wrapper captures around the actual `horizontal_pressure_gradient` call and requires `rk_step==1`, a single MPI task, complete physical tile and vertical bounds, `mp_physics=0`, and the qualified boundary contract. It records `n_moist=2` rather than rejecting it; the frozen initial/stored inputs have QVAPOR and QV_BASE zero.

The four existing 15-second captures completed on the same executable (`4201790d…77e22ec3`), with initial input SHA `e71b730a…c00dd2a9` and stored input SHA `90bec3e9…7b8aea4` matched within each Fortran/C++ pair. Corrected analysis reports all six same-call state gates, physical-owner comparisons, and periodic U seam checks pass. The earlier P2 concern is therefore closed for these four actual paired cold-start calls.

Scope remains limited to those four calls. There is no separate C++ ARK stage/time-step identifier or tile-count/owner guard, and `rk_tendency` has no `grid%itimestep` argument; the Fortran latch selects the first eligible RK1 call. Do not generalize this evidence to arbitrary multi-tile runs or later ARK stages. Same-call pressure operands are finite but not bitwise equal (P′ differs about 0.136% RMS initial and 0.145% stored); this audit makes no PGF numerical-parity, pressure-filter-parity, full-RHS-equality, or causal-attribution claim. This closure review read existing source and artifacts only; no build or model run was performed.

Detailed final-source pins and scope are appended in `pr298_u_pgf_runtime_source_audit.json` under `closure_20261012`.
