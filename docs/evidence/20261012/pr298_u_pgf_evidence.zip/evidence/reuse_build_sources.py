from pathlib import Path
import hashlib,json,shutil,os,subprocess
old=Path('/private/tmp/pr296-seam-cause-20261012');new=Path('/private/tmp/pr298-u-pgf-20261012');E=Path('/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012');affected={'dyn_em/module_em.F','external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(old/'main/wrf.exe')=='f7c4e1dbb69a3ec68e5376294e326cbaff339531f31dac13ed47e0fcbf413b64'
assert sha(old/'external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a')=='5f28e24cc3019c59c45ed8942e9ad104fc6a8a2c62f59416fe0d04fec317556f'
# Verify every unchanged authoritative Fortran/C/C++ source and header before sharing objects.
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=new).decode().split('\0');equal=[];mismatch=[]
for rel in tracked:
 if not rel:continue
 a=old/rel;b=new/rel
 if a.is_file() and b.is_file() and a.read_bytes()==b.read_bytes() and (not a.is_symlink() or (b.is_symlink() and os.readlink(a)==os.readlink(b))):
  if rel not in affected:os.utime(b,ns=(a.stat().st_atime_ns,a.stat().st_mtime_ns));equal.append(rel)
 elif rel not in affected and Path(rel).suffix in {'.F','.F90','.cpp','.c','.h','.hpp'}:
  mismatch.append(rel)
assert not mismatch,mismatch
copied=[];generated=[]
for a in old.rglob('*'):
 if not a.is_file() or a.is_symlink() or '.git' in a.parts:continue
 rel=a.relative_to(old);b=new/rel
 if a.suffix in {'.o','.a','.mod'} or str(rel) in {'main/wrf.exe','main/ideal.exe','tools/registry','tools/standard.exe','tools/standard','tools/yacc','tools/yacc.exe'}:
  b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(a,b);copied.append(str(rel))
 elif a.suffix=='.f90':
  owner=a.with_suffix('.F');owner_new=new/owner.relative_to(old)
  if owner.is_file() and owner_new.is_file() and sha(owner)==sha(owner_new):
   b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(a,b);generated.append(str(rel))
config=old/'configure.wrf';text=config.read_text().replace(str(old),str(new));(new/'configure.wrf').write_text(text)
for rel in affected:assert (new/rel).stat().st_mtime_ns>(old/rel).stat().st_mtime_ns
r={'purpose':'same-source build artifact reuse; unchanged authoritative code byte-verified; two observers require rebuild; no ABI interface change','old_root':str(old),'new_root':str(new),'equal_tracked_source_mtime_alignment_count':len(equal),'unchanged_authoritative_source_mismatches':mismatch,'copied_object_archive_mod_count':len(copied),'same_authoritative_source_generated_f90_count':len(generated),'affected_sources':{rel:sha(new/rel) for rel in affected},'configure_old_sha256':sha(config),'configure_new_sha256':sha(new/'configure.wrf'),'configure_change':'path relocation only; compiler/MPI/libtorch flags unchanged','baseline_executable_sha256':sha(old/'main/wrf.exe'),'baseline_library_sha256':sha(old/'external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a')};(E/'build_reuse_receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
