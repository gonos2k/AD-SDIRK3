# PR298 pre-edit PGF navigation

Target `51527694a3cb139ae43c20532b138e4a65dd6153` (`codex/u-pgf-same-state-20261012`) has tree `4630319cd50766b49e5143351b90385ed00ae2eb`, exactly matching PR297 HEAD `a3c01dcb9149a39e88cac4288017d9adc7eb950f`. All 57 reused source hashes matched; only the missing PGF-specific acoustic header/source and actual-RHS PGF test were added. The graph has 60 bound sources; SHA-256 `67c7872b99d4c85f5f85b96e317743cbb2eeeeba25cc8c38d653c427f9c5566d`.

## Full U pressure-gradient path

`computeUnifiedRHS()` owns the Full U PGF block (Step 5, beginning near line 19380). It computes mass-level `p_pert_mass` from `calc_p_rho_wrf`, then forms the interior and boundary U x-gradient from perturbation geopotential `ph`, perturbation pressure, `al/alt`, and base pressure `pb`. It applies the vertical coupling `c1h*muu+c2h`, map-factor ratio, and U-staggered coefficient `cqu_at_u`, optionally adds the native nonhydrostatic term 4, and accumulates `u_tend_pgf` into `ru_tend`. The shared primary formula is inline `horizontal_pgf_primary()` in `wrf_sdirk3_acoustic_substep.h:L257`; Graphify skipped this inline helper, so its node/call edges are explicitly manual.

The independent Fortran large-timestep path is `solve_em` → `rk_tendency` → `horizontal_pressure_gradient`: `module_em.F:L717` calls the routine owned by `module_big_step_utilities_em.F:L2187`; the big-step helper subtracts its U-face PGF contribution into `ru_tend` (interior source around `:2411`) and uses `p`, `pb`, `ph`, `al`, `alt`, `muu`, and `cqu`. `rk_addtend_dry` later couples the separate physics `ru_tendf` into the RK tendency via `msfuy` (`module_em.F:L1067-L1069`).

## Pressure-state filter vs RK tendency

The added acoustic source files show a distinct small-step state. `State.p` and `State.pm1` are mass-level perturbation-pressure arrays `{ny,nz,nx}` in pressure units. `calc_p_rho(step=0)` sets both to `p_calc`; later substeps set `p = p_calc + smdiv*(p_calc - pm1_previous)` then advance `pm1 = p_calc`. `advance_uv` evaluates a horizontal PGF on substep pressure/geopotential deviations and updates `u/v` state. This state/filter path is not the large-timestep `rk_tendency` accumulator. In the Full-RHS path, `computeUnifiedRHS` forms a separate RK-stage `p_pert_mass` with `calc_p_rho_wrf`, while `ru_tend` is the U-staggered coupled momentum-tendency accumulator; it is not pressure-state data. The acoustic `dpx` and final `u_tend_pgf` also use U-face x extent (including the periodic seam), unlike mass-level `p`. Keep diagnostic name, shape, timing, and unit conversion distinct; `use_wrf_mass_flux` controls an additional C++ tendency conversion.

`test_horizontal_pgf_actual_rhs.cpp` exercises actual Full RHS through `TileCase::rhsAt` and checks a reduced analytic pressure-gradient oracle with uniform base column and PH/MU perturbations set to zero; it has physical/packed and optional nonperiodic-boundary cases. This is source navigation only; no test was run.

Graphify omits the header inline helper and leaves the Fortran cross-module edge unresolved; direct source checks are recorded as manual graph edges. No numerical correctness is inferred from these edges.
