# PR298 analyzer P2 contract test graph update

Target `51527694a3cb139ae43c20532b138e4a65dd6153` (`codex/u-pgf-same-state-20261012`), 61 source bindings with exact target/mirror hashes. Reused the existing 60-source PGF graph unchanged and added only `tools/test_reference_plan_contract.py` (SHA-256 `f5e1e96b2469cd59af97a5fbd8c80de183a21b83b6529a834b6651661af01a52`; AST 10 nodes / 20 edges). The previous graph is retained at `.graphify_pre_p2_repository_test.json`.

The test imports the analyzer through `Path(__file__).resolve().parent`, stubs the benchmark loader, and uses all-one raw initial arrays. Its existing saved log reports three passes: valid plan emits 24 metrics/48 delta arrays, wrong middle resolution is rejected with label, and wrong method is rejected with label. This is synthetic plan/analyzer contract evidence; it does not rerun or validate pressure math, native model outputs, or the four PGF captures.

Receipt: `p2_test_graph_refresh_receipt.json`. No tests, builds, or model runs were performed for this graph refresh.
