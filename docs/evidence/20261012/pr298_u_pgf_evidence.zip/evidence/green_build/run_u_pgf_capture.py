#!/usr/bin/env python3
"""Run four short, paired Fortran/C++ U-PGF capture cases.

This runner is intentionally limited to four 15-second, h=15-second captures.
It does not build WRF or run the 240-second validation. Each run gets a fresh
directory; existing evidence is never overwritten. It validates capture file
schemas and hashes; cross-method state equivalence is handled by the separate
analysis step.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import shutil
import struct
import subprocess
import time
from pathlib import Path
from typing import Any


DEFAULT_ROOT = Path("/private/tmp/pr298-u-pgf-20261012")
DEFAULT_EVIDENCE = Path("/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012/green_build/captures")
BUILD_COMPLETED_RECEIPT = Path("/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012/build_completed_receipt.json")
BUILD_COMPILE_LOG = Path("/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012/compile_u_pgf.log")
BUILD_REUSE_RECEIPT = Path("/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012/build_reuse_receipt.json")
EXPECTED_HEAD = "51527694a3cb139ae43c20532b138e4a65dd6153"
EXPECTED_CONFIGURE_SHA256 = "8cdf647666634cdb8cc2624d5d627c6bdd79472b3ed99481831f2a3e27873289"
OLD_EVIDENCE = Path("/Users/yhlee/AD-SDIRK3-review-evidence/full-rhs-contract-20261011")
ORIGINAL_INPUT = Path("/Users/yhlee/Documents/AD-SDIRK3-worktree-archive/20261005/native_wave_refinement/wrf_runs/signfix_fp64_carry_on15_240/wrfinput_d01")
ORIGINAL_NAMELIST = ORIGINAL_INPUT.parent / "namelist.input"
ORIGINAL_DIAGNOSTICS = ORIGINAL_INPUT.parent / "diagnostics.txt"
STORED_INPUT = OLD_EVIDENCE / "initial_snapshot_runs/stored_state_input/wrfinput_d01"

EXPECTED_INITIAL_INPUT_SHA = "e71b730a12e5a16d181f404f6314e7904e0165eefa622ffd0c508bf8c00dd2a9"
EXPECTED_STORED_INPUT_SHA = "90bec3e95b2b98c9281d5b0ffbd7a16124e9611273b8a7318056ef8337b8aea4"

# These seven authoritative inputs are pinned at the frozen PR298 source state.
# Generated .f90 files and offline-only analysis tools are excluded.
SOURCE_PATHS = (
    "dyn_em/solve_em.F",
    "dyn_em/module_em.F",
    "dyn_em/module_small_step_em.F",
    "dyn_em/module_big_step_utilities_em.F",
    "dyn_em/module_implicit_sdirk3.F",
    "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp",
    "dyn_em/module_first_rk_step_part2.F",
)
EXPECTED_SOURCE_SHA256 = {
    "dyn_em/solve_em.F": "859883043a3af98a05ac682afec63a680cc3e0b7a17623dddd7f4e126260ba8c",
    "dyn_em/module_em.F": "790b09734aba5db1f2fe12401e634382e3c89ef0879604a2d4cceffc6caffab6",
    "dyn_em/module_small_step_em.F": "cabf1a177d50fb0096db79644af20cfe6d75217dbe63ab406a7e29bb54c17634",
    "dyn_em/module_big_step_utilities_em.F": "0c18cf55d444de1dff1b7b45a88156934718525df483ae516e916708c939bf71",
    "dyn_em/module_implicit_sdirk3.F": "041c49f0e03b6f998fd120cdd0dbe6e7068aa68f39af9c027967324b88ddb11a",
    "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp": "473a9b5affe2e1251a85fa113bb4beb9087dce81a6860a594276ece0a347d3e8",
    "dyn_em/module_first_rk_step_part2.F": "f7b8dc143d1621d55508828fb1adc81ad056980cc2f5768bfea1707c49f9646c",
}
CASES = (
    ("initial_fortran_rk3_h15", "initial", "RK3"),
    ("initial_cpp_ark3_h15", "initial", "ARK3"),
    ("stored_fortran_rk3_h15", "stored", "RK3"),
    ("stored_cpp_ark3_h15", "stored", "ARK3"),
)
EXPECTED_OUTPUTS = {
    "RK3": ("wrf_rk_tend_dump.bin", "wrf_full_rhs_snapshot.bin", "wrf_u_pgf_snapshot.bin"),
    "ARK3": ("port_full_rhs_snapshot.bin", "port_u_pgf_snapshot.bin",
             "port_u_pgf_operands_snapshot.bin"),
}


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def source_hashes(root: Path) -> dict[str, str]:
    return {rel: sha(root / rel) for rel in SOURCE_PATHS}


def set_namelist_int(text: str, key: str, value: int) -> str:
    pattern = r"(\b" + re.escape(key) + r"\s*=\s*)[-+0-9]+"
    updated, count = re.subn(pattern, lambda m: m.group(1) + str(value), text,
                             count=1, flags=re.IGNORECASE)
    if count != 1:
        raise ValueError(f"required namelist integer {key!r} not found exactly once")
    return updated


def compiler_receipt() -> dict[str, Any]:
    result: dict[str, Any] = {}
    for label, command in (
        ("gfortran", ["gfortran", "--version"]),
        ("gxx", ["g++", "--version"]),
        ("mpirun", ["/opt/homebrew/bin/mpirun", "--version"]),
        ("mpif90_compiler_command", ["mpif90", "--showme:command"]),
    ):
        try:
            p = subprocess.run(command, check=False, capture_output=True, text=True, timeout=15)
            result[label] = {"command": command, "return_code": p.returncode,
                             "output": (p.stdout + p.stderr).strip()[:4000]}
        except (OSError, subprocess.TimeoutExpired) as exc:
            result[label] = {"command": command, "error": f"{type(exc).__name__}: {exc}"}
    return result


def verify_completed_build_receipt(root: Path, head: str) -> dict[str, Any]:
    """Bind the capture to root's completed compile/generated-source receipt."""
    receipt = json.loads(BUILD_COMPLETED_RECEIPT.read_text())
    if receipt.get("compile_returncode") != 0 or receipt.get("head") != head:
        raise RuntimeError("completed build receipt has wrong status or HEAD")
    if Path(receipt.get("root", "")).resolve() != root:
        raise RuntimeError("completed build receipt names a different worktree")
    if not receipt.get("actual_fortran_generated_pgf_marker_present"):
        raise RuntimeError("build receipt does not verify the generated Fortran PGF observer")
    if not receipt.get("fortran_module_interface_sha_equals_baseline"):
        raise RuntimeError("Fortran module interface differs from the reused baseline")
    expected_paths = (
        "dyn_em/module_em.F", "dyn_em/module_em.f90", "dyn_em/module_em.o",
        "dyn_em/module_em.mod",
        "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp",
        "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.o",
        "external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a", "main/wrf.exe", "configure.wrf",
    )
    files = receipt.get("files", {})
    checked = {}
    for rel in expected_paths:
        item = files.get(rel)
        path = root / rel
        if not item or not path.is_file() or sha(path) != item.get("sha256"):
            raise RuntimeError(f"completed build receipt/file hash mismatch: {rel}")
        checked[rel] = item["sha256"]
    if sha(BUILD_COMPILE_LOG) != receipt.get("compile_log_sha256"):
        raise RuntimeError("compile log hash does not match completed build receipt")
    if sha(BUILD_REUSE_RECEIPT) != receipt.get("reuse_receipt_sha256"):
        raise RuntimeError("reuse receipt hash does not match completed build receipt")
    return {
        "path": str(BUILD_COMPLETED_RECEIPT), "sha256": sha(BUILD_COMPLETED_RECEIPT),
        "compile_returncode": 0, "freshness_checks": receipt.get("freshness_checks"),
        "generated_module_em_f90_sha256": checked["dyn_em/module_em.f90"],
        "module_em_object_sha256": checked["dyn_em/module_em.o"],
        "module_em_interface_sha256": checked["dyn_em/module_em.mod"],
        "cpp_object_sha256": checked["external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.o"],
        "library_sha256": checked["external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a"],
        "executable_sha256": checked["main/wrf.exe"],
        "compile_log_sha256": sha(BUILD_COMPILE_LOG),
        "reuse_receipt_sha256": sha(BUILD_REUSE_RECEIPT),
        "compiler_mpi_netcdf_libtorch_stack": receipt.get("compiler_mpi_netcdf_libtorch_stack"),
    }


def affected_build_receipt(root: Path, source_times: dict[str, int]) -> dict[str, Any]:
    """Fail closed unless the changed capture sources were actually rebuilt."""
    targets = {
        "dyn_em/module_em.F": root / "dyn_em/module_em.o",
        "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp": root / "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.o",
    }
    checked = {}
    for source, obj in targets.items():
        if not obj.is_file():
            raise FileNotFoundError(f"rebuilt affected object missing: {obj}")
        obj_stat = obj.stat()
        if obj_stat.st_mtime_ns <= source_times[source]:
            raise RuntimeError(f"affected object is not newer than source: {source} -> {obj}")
        checked[source] = {"object_path": str(obj), "object_sha256": sha(obj),
                           "source_mtime_ns": source_times[source],
                           "object_mtime_ns": obj_stat.st_mtime_ns}
    exe = root / "main/wrf.exe"
    lib = root / "external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a"
    for artifact in (exe, lib):
        if not artifact.is_file():
            raise FileNotFoundError(f"required build artifact missing: {artifact}")
    latest_obj_mtime = max((root / x["object_path"]).stat().st_mtime_ns for x in checked.values())
    cpp_obj_mtime = checked["external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp"]["object_mtime_ns"]
    if exe.stat().st_mtime_ns < latest_obj_mtime or lib.stat().st_mtime_ns < cpp_obj_mtime:
        raise RuntimeError("executable predates an affected object or C++ archive predates its object")
    return {
        "affected_objects": checked,
        "executable": {"path": str(exe), "sha256": sha(exe), "mtime_ns": exe.stat().st_mtime_ns},
        "library": {"path": str(lib), "sha256": sha(lib), "mtime_ns": lib.stat().st_mtime_ns},
        "configure_wrf": {"path": str(root / "configure.wrf"), "sha256": sha(root / "configure.wrf")},
    }


def capture_runtime_config(folder: Path, method: str) -> dict[str, Any]:
    out = folder / "rsl.out.0000"
    err = folder / "rsl.error.0000"
    nml = folder / "namelist.output"
    combined = "\n".join(p.read_text(errors="replace") for p in (out, err, nml) if p.is_file())
    needles = (
        "internal_fp64", "internal_fp64_state_carry", "enable_ad_halo_exchange",
        "diffusion_option", "phi_adv_z", "hypsometric_opt", "h_mom_adv_order",
        "h_sca_adv_order", "mix_full_fields", "periodic_x", "symmetric_ys", "symmetric_ye",
    )
    lines = [line.strip() for line in combined.splitlines()
             if any(n.lower() in line.lower() for n in needles)
             or "Ideal cases always use hypsometric_opt" in line]
    cfg = {
        "config_lines": lines,
        "effective_cpp_flags": {
            "internal_fp64_true": "[CONFIG] internal_fp64 = true" in combined,
            "internal_fp64_state_carry_true": "[CONFIG] internal_fp64_state_carry = true" in combined,
            "enable_ad_halo_exchange_zero": "[CONFIG] enable_ad_halo_exchange = 0" in combined,
        },
        "hypsometric_note_and_namelist_are_both_recorded": (
            "Ideal cases always use hypsometric_opt=1, regardless of namelist setting" in combined
            and re.search(r"HYPSOMETRIC_OPT\s*=\s*2", combined, re.IGNORECASE) is not None
        ),
        "actual_cpp_sdirk_route": ("SDIRK3 Zero-Copy: Calling actual solver" in combined
                                   or "SDIRK3 implicit time integration" in combined),
    }
    if method == "ARK3" and not all(cfg["effective_cpp_flags"].values()):
        raise RuntimeError(f"ARK config flags missing from runtime log in {folder}")
    if method == "ARK3" and not cfg["hypsometric_note_and_namelist_are_both_recorded"]:
        raise RuntimeError(f"expected effective-vs-namelist hypsometric record absent in {folder}")
    if cfg["actual_cpp_sdirk_route"] != (method == "ARK3"):
        raise RuntimeError(f"route/method mismatch in {folder}: expected {method}")
    return cfg


def artifact_receipt(folder: Path, method: str) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for name in sorted(EXPECTED_OUTPUTS[method]):
        path = folder / name
        if not path.is_file():
            raise RuntimeError(f"required PGF capture missing: {name}")
        data = path.read_bytes()
        item: dict[str, Any] = {"expected": True, "present": True, "bytes": len(data), "sha256": sha(path)}
        if name == "wrf_rk_tend_dump.bin":
            if len(data) < 24:
                raise RuntimeError("Fortran rk_tendency dump header truncated")
            bounds = struct.unpack_from(">6i", data, 0)
            ims, ime, jms, jme, kms, kme = bounds
            if min(ime - ims, jme - jms, kme - kms) <= 0:
                raise RuntimeError(f"Fortran rk_tendency bounds invalid: {bounds}")
            ni, nj, nk = ime - ims + 1, jme - jms + 1, kme - kms + 1
            n3, n2 = ni * nj * nk, ni * nj
            expected_bytes = 24 + 4 * (7 * n3 + n2)
            if len(data) != expected_bytes:
                raise RuntimeError(f"Fortran rk_tendency byte count mismatch: expected {expected_bytes}, got {len(data)}")
            item["schema"] = {"bounds_ims_ime_jms_jme_kms_kme": list(bounds), "bytes_expected": expected_bytes,
                              "payload_dtype": "native-endian float32", "arrays_3d_2d": [7, 1]}
        elif name == "wrf_full_rhs_snapshot.bin":
            if len(data) < 60:
                raise RuntimeError("Fortran Full RHS snapshot header truncated")
            version, = struct.unpack_from("<I", data, 0)
            bounds = struct.unpack_from("<12i", data, 4)
            if version != 1:
                raise RuntimeError(f"unsupported Fortran Full RHS schema {version}")
            _, _, _, _, _, _, ims, ime, jms, jme, kms, kme = bounds
            ni, nj, nk = ime - ims + 1, jme - jms + 1, kme - kms + 1
            if min(ni, nj, nk) <= 0:
                raise RuntimeError(f"Fortran Full RHS bounds invalid: {bounds}")
            expected_bytes = 60 + 4 * (9 * ni * nj * nk + 11 * ni * nj + 3 * nk)
            if len(data) != expected_bytes:
                raise RuntimeError(f"Fortran Full RHS byte count mismatch: expected {expected_bytes}, got {len(data)}")
            item["schema"] = {"version": version, "bounds": list(bounds), "memory_shape_jki": [nj, nk, ni],
                              "bytes_expected": expected_bytes, "dtype": "little-endian float32", "fields_3d_2d_1d": [9, 11, 3]}
        elif name == "wrf_u_pgf_snapshot.bin":
            if len(data) < 96:
                raise RuntimeError("Fortran U-PGF snapshot header truncated")
            version, = struct.unpack_from("<I", data, 0)
            bounds = struct.unpack_from("<12i", data, 4)
            if version != 1:
                raise RuntimeError(f"unsupported Fortran U-PGF schema {version}")
            _, _, _, _, _, _, ims, ime, jms, jme, kms, kme = bounds
            ni, nj, nk = ime - ims + 1, jme - jms + 1, kme - kms + 1
            expected_bytes = 96 + 4 * (15 * ni * nj * nk + 4 * ni * nj + 5 * nk)
            if min(ni, nj, nk) <= 0 or len(data) != expected_bytes:
                raise RuntimeError(f"Fortran U-PGF byte count mismatch: expected {expected_bytes}, got {len(data)}")
            rk_step, n_moist = struct.unpack_from("<2i", data, 52)
            if rk_step != 1:
                raise RuntimeError(f"Fortran PGF dump did not capture rk_step=1: {rk_step}")
            item["schema"] = {"version": version, "bounds": list(bounds), "rk_step": rk_step, "n_moist": n_moist,
                              "bytes_expected": expected_bytes, "dtype": "little-endian float32", "fields_3d_2d_1d": [15, 4, 5]}
        elif name == "port_full_rhs_snapshot.bin":
            if len(data) < 28:
                raise RuntimeError("C++ Full RHS snapshot header truncated")
            version, nx, ny, nz, nxu, nyv, nzw = struct.unpack_from("<I6i", data, 0)
            if version != 1 or min(nx, ny, nz) <= 0 or (nxu, nyv, nzw) != (nx + 1, ny + 1, nz + 1):
                raise RuntimeError(f"C++ Full RHS schema/dimensions invalid: {(version,nx,ny,nz,nxu,nyv,nzw)}")
            nstate = ny*nz*nxu + nyv*nz*nx + 2*ny*nzw*nx + ny*nz*nx + ny*nx
            expected_bytes = 28 + 8*nstate
            if len(data) != expected_bytes:
                raise RuntimeError(f"C++ Full RHS byte count mismatch: expected {expected_bytes}, got {len(data)}")
            item["schema"] = {"version": version, "dimensions": [nx,ny,nz,nxu,nyv,nzw],
                              "float32_count": nstate, "bytes_expected": expected_bytes}
        elif name == "port_u_pgf_snapshot.bin":
            if len(data) < 36:
                raise RuntimeError("C++ U-PGF snapshot header truncated")
            version, nx, ny, nz, nxu, nyv, nzw, state_count = struct.unpack_from("<8i", data, 0)
            if version != 2 or min(nx, ny, nz) <= 0 or (nxu, nyv, nzw) != (nx + 1, ny + 1, nz + 1):
                raise RuntimeError(f"C++ U-PGF schema/dimensions invalid: {(version,nx,ny,nz,nxu,nyv,nzw)}")
            expected_state = ny*nz*nxu + nyv*nz*nx + 2*ny*nzw*nx + ny*nz*nx + ny*nx
            expected_bytes = 36 + 8*(expected_state + 4*ny*nz*nxu)
            if state_count != expected_state or len(data) != expected_bytes:
                raise RuntimeError(f"C++ U-PGF byte/state mismatch: expected {expected_bytes}/{expected_state}, got {len(data)}/{state_count}")
            item["schema"] = {"version": version, "dimensions": [nx,ny,nz,nxu,nyv,nzw],
                              "state_float64_count": state_count, "bytes_expected": expected_bytes,
                              "payload_blocks": ["input_state", "coupled_pgf", "velocity_mass_u", "unscaled_pgf", "alpha_u"]}
        elif name == "port_u_pgf_operands_snapshot.bin":
            if len(data) < 20:
                raise RuntimeError("C++ PGF operand snapshot header truncated")
            version, ny, nz, nx, nzw = struct.unpack_from("<5i", data, 0)
            if version != 1 or min(ny, nz, nx) <= 0 or nzw != nz + 1:
                raise RuntimeError(f"C++ PGF operand schema/dimensions invalid: {(version,ny,nz,nx,nzw)}")
            expected_bytes = 20 + 8*(3*ny*nz*nx + ny*nzw*nx)
            if len(data) != expected_bytes:
                raise RuntimeError(f"C++ PGF operand byte mismatch: expected {expected_bytes}, got {len(data)}")
            item["schema"] = {"version": version, "shape": [ny,nz,nx,nzw], "bytes_expected": expected_bytes,
                              "payload_blocks": ["p_prime", "al_prime", "alt", "ph"]}
        result[name] = item
    return result

def make_case(root: Path, out_dir: Path, label: str, input_src: Path, input_kind: str,
              method: str, base_namelist: Path, diagnostics: Path, plan: dict[str, Any]) -> tuple[dict[str, Any], list[str], dict[str, str]]:
    folder = out_dir / label
    if folder.exists():
        raise FileExistsError(f"refusing to reuse existing case directory: {folder}")
    folder.mkdir(parents=True)
    shutil.copy2(input_src, folder / "wrfinput_d01")
    shutil.copy2(diagnostics, folder / "diagnostics.txt")
    for table in ("LANDUSE.TBL", "VEGPARM.TBL", "SOILPARM.TBL", "GENPARM.TBL"):
        source = root / "run" / table
        if source.is_file():
            (folder / table).symlink_to(source)

    text = base_namelist.read_text()
    for key, value in (("time_step", 15), ("time_step_fract_num", 0),
                       ("time_step_fract_den", 1), ("run_seconds", 15),
                       ("rk_ord", 3), ("time_integration_scheme", 0 if method == "RK3" else 6),
                       ("sdirk3_debug_level", 2)):
        text = set_namelist_int(text, key, value)
    (folder / "namelist.input").write_text(text)

    input_sha = sha(folder / "wrfinput_d01")
    expected = EXPECTED_INITIAL_INPUT_SHA if input_kind == "initial" else EXPECTED_STORED_INPUT_SHA
    if input_sha != expected:
        raise RuntimeError(f"{input_kind} input SHA mismatch: {input_sha} != {expected}")
    row = {
        "label": label, "method": method, "time_step_seconds": 15, "run_seconds": 15,
        "reinitialized_from_saved_state": input_kind == "stored",
        "input_origin": str(input_src), "input_sha256": input_sha,
        "namelist_path": str(folder / "namelist.input"), "namelist_sha256": sha(folder / "namelist.input"),
        "diagnostics_sha256": sha(folder / "diagnostics.txt"),
        "workdir": str(folder), "status": "staged",
    }
    plan["runs"].append(row)
    return row, ["/usr/bin/time", "-l", "-o", str(folder / "time.log"),
                 "/opt/homebrew/bin/mpirun", "-np", "1", "--bind-to", "none", str(root / "main/wrf.exe")], {}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--label", required=True, help="unique capture label such as baseline or fixed")
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT, help="built PR298 worktree")
    parser.add_argument("--out", type=Path, default=DEFAULT_EVIDENCE, help="new evidence parent; label subdir must not exist")
    parser.add_argument("--initial-input", type=Path, default=ORIGINAL_INPUT)
    parser.add_argument("--stored-input", type=Path, default=STORED_INPUT)
    parser.add_argument("--namelist", type=Path, default=ORIGINAL_NAMELIST)
    parser.add_argument("--diagnostics", type=Path, default=ORIGINAL_DIAGNOSTICS)
    parser.add_argument("--timeout", type=int, default=1200)
    args = parser.parse_args()

    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}", args.label):
        raise ValueError("--label must be a short path-safe identifier")
    root, out_parent = args.root.resolve(), args.out.resolve()
    out_dir, plan_path = out_parent / args.label, out_parent / f"{args.label}_runs.json"
    if out_dir.exists() or plan_path.exists():
        raise FileExistsError(f"refusing to overwrite capture output: {out_dir} or {plan_path}")
    for path in (args.initial_input, args.stored_input, args.namelist, args.diagnostics,
                 root / "configure.wrf", root / "main/wrf.exe", BUILD_COMPLETED_RECEIPT,
                 BUILD_COMPILE_LOG, BUILD_REUSE_RECEIPT):
        if not path.is_file():
            raise FileNotFoundError(path)

    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
    if head != EXPECTED_HEAD:
        raise RuntimeError(f"target HEAD mismatch: {head} != {EXPECTED_HEAD}")
    if sha(root / "configure.wrf") != EXPECTED_CONFIGURE_SHA256:
        raise RuntimeError("configure.wrf differs from the verified PR296 build configuration")
    source_times = {p: (root / p).stat().st_mtime_ns for p in SOURCE_PATHS}
    pins_before = source_hashes(root)
    if pins_before != EXPECTED_SOURCE_SHA256:
        raise RuntimeError(f"frozen source hash mismatch: {pins_before}")
    build = affected_build_receipt(root, source_times)
    build["completed_compile_receipt"] = verify_completed_build_receipt(root, head)
    compiler = compiler_receipt()
    out_dir.mkdir(parents=True)
    plan = {
        "schema": "same-state-u-pgf-capture-v1",
        "status": "running",
        "label": args.label,
        "worktree": str(root),
        "head": head,
        "source_paths": list(SOURCE_PATHS),
        "source_sha256_before": pins_before,
        "source_sha256_after": None,
        "build_receipt": build,
        "compiler_and_runtime_versions": compiler,
        "configure_wrf_sha256": build["configure_wrf"]["sha256"],
        "run_environment_policy": "remove all inherited WRF_SDIRK3_* and WRF_PARITY_* variables; set only WRF_PARITY_RK_TEND_DUMP=1 for each isolated capture",
        "requested_case_parameters": {
            "cases": [c[0] for c in CASES], "input_sha256": {
                "initial": EXPECTED_INITIAL_INPUT_SHA, "stored": EXPECTED_STORED_INPUT_SHA},
            "h_seconds": 15, "duration_seconds": 15, "rk_ord": 3,
            "time_integration_scheme": {"RK3": 0, "ARK3": 6},
            "debug_level": 2, "mpi_ranks": 1, "omp_threads": 1,
            "dump_env": "WRF_PARITY_RK_TEND_DUMP=1",
            "capture_u_pgf": True,
            "capture_full_rhs_context": True,
        },
        "runs": [],
    }
    plan_path.write_text(json.dumps(plan, indent=2) + "\n")
    clean_env = {k: v for k, v in os.environ.items()
                 if not k.startswith(("WRF_SDIRK3_", "WRF_PARITY_"))}
    clean_env.update(OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1",
                     VECLIB_MAXIMUM_THREADS="1")
    inputs = {"initial": args.initial_input.resolve(), "stored": args.stored_input.resolve()}
    try:
        for case_label, input_kind, method in CASES:
            row, command, _ = make_case(root, out_dir, case_label, inputs[input_kind], input_kind,
                                        method, args.namelist, args.diagnostics, plan)
            row["executable_sha256"] = build["executable"]["sha256"]
            row["source_sha256"] = pins_before
            row["command"] = command
            row["environment_dump_flag"] = "1"
            row["status"] = "running"
            plan_path.write_text(json.dumps(plan, indent=2) + "\n")
            run_env = dict(clean_env, WRF_PARITY_RK_TEND_DUMP="1")
            start = time.monotonic()
            with (Path(row["workdir"]) / "run.log").open("wb") as log:
                proc = subprocess.run(command, cwd=row["workdir"], env=run_env,
                                      stdout=log, stderr=subprocess.STDOUT,
                                      timeout=args.timeout, check=False)
            folder = Path(row["workdir"])
            row.update({
                "return_code": proc.returncode,
                "wall_seconds": time.monotonic() - start,
                "time_log_sha256": sha(folder / "time.log") if (folder / "time.log").is_file() else None,
                "rsl_out_sha256": sha(folder / "rsl.out.0000") if (folder / "rsl.out.0000").is_file() else None,
                "rsl_error_sha256": sha(folder / "rsl.error.0000") if (folder / "rsl.error.0000").is_file() else None,
                "namelist_output_sha256": sha(folder / "namelist.output") if (folder / "namelist.output").is_file() else None,
            })
            out_text = (folder / "rsl.out.0000").read_text(errors="replace") if (folder / "rsl.out.0000").is_file() else ""
            err_text = (folder / "rsl.error.0000").read_text(errors="replace") if (folder / "rsl.error.0000").is_file() else ""
            row["completion_marker"] = "SUCCESS COMPLETE" in out_text or "SUCCESS COMPLETE" in err_text
            row["effective_runtime_config"] = capture_runtime_config(folder, method)
            row["artifacts"] = artifact_receipt(folder, method)
            row["status"] = "completed" if proc.returncode == 0 and row["completion_marker"] else "failed"
            plan_path.write_text(json.dumps(plan, indent=2) + "\n")
            if row["status"] != "completed":
                raise RuntimeError(f"run did not complete cleanly: {case_label}")

        pins_after = source_hashes(root)
        if pins_after != pins_before:
            raise RuntimeError("one or more pinned sources changed during capture")
        if sha(root / "main/wrf.exe") != build["executable"]["sha256"]:
            raise RuntimeError("executable changed during capture")
        if sha(root / "external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a") != build["library"]["sha256"]:
            raise RuntimeError("C++ static library changed during capture")
        plan["source_sha256_after"] = pins_after
        plan["status"] = "completed"
        plan["completion_note"] = "All four isolated 15-second PGF captures completed; no 240-second run or timestep ladder was performed."
        plan_path.write_text(json.dumps(plan, indent=2) + "\n")
        print(json.dumps({"status": plan["status"], "plan": str(plan_path),
                          "runs": [{"label": r["label"], "status": r["status"],
                                    "return_code": r["return_code"],
                                    "artifacts": sorted(k for k,v in r["artifacts"].items() if v["present"])}
                                   for r in plan["runs"]]}, sort_keys=True))
        return 0
    except Exception as exc:
        plan["source_sha256_after"] = source_hashes(root)
        plan["status"] = "failed"
        plan["failure"] = f"{type(exc).__name__}: {exc}"
        plan_path.write_text(json.dumps(plan, indent=2) + "\n")
        raise


if __name__ == "__main__":
    raise SystemExit(main())
