# PR298 warm-build and PGF capture plan

Created 2026-10-12 08:59 JST. Planning only; no build or WRF run was performed.

## Context

The PR298 target is `/private/tmp/pr298-u-pgf-20261012`. Its two relevant source files were still being edited when this plan was prepared, so I did not inspect or hash them. This plan is intentionally not executable until the owner freezes those files and supplies their paths. No PR298-specific source, object, executable, input, or capture-output pins are asserted here.

The reusable PR296 build is `/private/tmp/pr296-seam-cause-20261012`, based on `3c8ef9c26d6caf9b3a54876d0caa19db361e5dc9`. Its `configure.wrf` SHA-256 is `8cdf647666634cdb8cc2624d5d627c6bdd79472b3ed99481831f2a3e27873289`; `main/wrf.exe` SHA-256 is `f7c4e1dbb69a3ec68e5376294e326cbaff339531f31dac13ed47e0fcbf413b64`; and `libwrf_sdirk3_libtorch.a` SHA-256 is `5f28e24cc3019c59c45ed8942e9ad104fc6a8a2c62f59416fe0d04fec317556f`. The prior build used GNU Fortran 15.2, GNU C++ 15.2, OpenMPI 5.0.9, netCDF C 4.9.3, and netCDF-Fortran 4.6.2. These are candidate reuse pins, not proof that the PR298 target is currently compatible.

## Planned gate and build

After the source freeze, record target HEAD and SHA-256 for the two changed authoritative sources. Compare every proposed reused object’s source dependency hash to its exact PR296 source; reuse only byte-identical inputs under the same configuration and ABI. Verify `configure.wrf`, compiler/MPI/netCDF/libtorch paths, and ABI flags against the PR296 receipt before any object copy. Rebuild only the frozen changed Fortran/C++ compilation units and relink the affected library and WRF executable. Reject reuse if any additional source, generated dependency, configuration, toolchain, or ABI difference appears. The old executable and archive remain provenance references and must not be used for capture.

## Planned short capture

Once the rebuilt executable is independently pinned, adapt the existing four-case runner at `seam-cause-acceptance-20261012/red_provenance/run_term_capture.py` to the PGF artifact names and route checks. Use the existing initial and stored-state inputs, Fortran RK3 and ARK h=15 s, debug level 2, one MPI rank/thread, and one 15 s step per case. Preserve input hashes, namelist hashes, runtime route/configuration lines, logs, expected PGF captures, executable/source pins, and per-case wall time. Do not extend this to a 240 s run or timestep sweep.

The runner's prior input pins are initial `e71b730a12e5a16d181f404f6314e7904e0165eefa622ffd0c508bf8c00dd2a9` and stored `90bec3e95b2b98c9281d5b0ffbd7a16124e9611273b8a7318056ef8337b8aea4`; re-verify these against the exact PR298 run inputs before use. PGF filenames and schema remain unverified and must be taken from the frozen source/runtime contract, not inferred from the earlier U-diffusion runner.

## Initial status at draft time (superseded by freeze update below)

The warm-build pins and prior runner scaffold are verified as historical PR296 evidence only. No PR298 object reuse, rebuild, or native capture has occurred. Next, obtain the frozen source paths and hashes, then complete the source-to-object dependency gate and let Red review this plan before any build or run is assigned.

## Freeze and runner update — 2026-10-12 09:20 JST

Root froze the PR298 capture sources at HEAD `51527694a3cb139ae43c20532b138e4a65dd6153`. The frozen `dyn_em/module_em.F` SHA-256 is `790b09734aba5db1f2fe12401e634382e3c89ef0879604a2d4cceffc6caffab6`; `external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp` is `473a9b5affe2e1251a85fa113bb4beb9087dce81a6860a594276ece0a347d3e8`. The seven source inputs are pinned in the runner; the other five sources match the PR296 reuse worktree byte-for-byte. The analyzer-only edit is excluded from native source pins.

The adapted runner is [run_u_pgf_capture.py](run_u_pgf_capture.py); its static pins and preflight checks are recorded in [runner_preflight.json](runner_preflight.json). It fails closed on the frozen HEAD/source hashes and `configure.wrf`, requires rebuilt `module_em.o` and C++ objects plus a freshly relinked archive/executable, then stages four one-step 15 s cases: initial/stored input × Fortran RK3/C++ ARK3. It requires exact input hashes and hashes every required output. Schema checks cover the Fortran U-PGF v1 and Full RHS snapshots, C++ U-PGF v2 and operand v1 snapshots, and the existing C++ Full RHS snapshot. Full six-field same-state comparison remains a separate analysis step.

The Fortran PGF source gate requires one rank/full-domain tile, periodic X with symmetric nonperiodic Y, dry/no-microphysics configuration, and rk_step 1. C++ requires the actual Full canonical horizontal PGF route and packed periodic domain. The runner leaves inherited WRF/Parity variables cleared except `WRF_PARITY_RK_TEND_DUMP=1`, records runtime flags/logs, and independently requires each expected artifact; a missing sidecar or capture fails the case.

Validation: Python syntax compilation passed. The runner's Fortran and C++ schema validators passed synthetic fixed-shape fixtures, and the Fortran/C++ Full RHS validators accepted archived PR296 snapshots. Input, stored-state, namelist, and diagnostics paths resolve; the two input hashes match the pinned expected values. No PR298 native build or model capture has been performed by this lane. Root's build and final receipt are the remaining gates before the four captures.

## Red review and build handoff — 2026-10-12 09:26 JST

Red reviewed the updated runner and the parent reuse recipe. The runner's `g++ --version` probe is correct; the reuse recipe ties copied generated Fortran sources to byte-identical owning `.F` sources and reports zero unchanged-source mismatches. Red accepts the capture schemas and gates, with final build provenance still contingent on root's compile receipt. Updated Red audit: `red_provenance/warm_reuse_plan_audit.json`, SHA-256 `439d7b4debf32aa621ff04baad5d09eb132c30e3c1f181b30b5042f9006e04fb`.

At the time of this update root was compiling the affected objects and relinking; no capture had yet been launched.

## Build and four-case capture complete — 2026-10-12 09:45 JST

Root's completed build receipt is `../build_completed_receipt.json`, SHA-256 `852bbf5efa89400da75c49cde86250a712c0d69a9075c69039939e006dde6bdf`. It reports compile return code 0, verifies the generated `module_em.f90` marker and source/object/archive/executable freshness, and records the linked compiler and library stack. The capture executable SHA-256 is `4201790d363fb9bdc1e49bf9a83fd3a506b91147c1b34b8a8fbbc0ff77e22ec3`; the C++ archive is `21f7bc79a131f4608f506259b7c0434f2350749486774f14aea260cc69910565`.

The four authorized runs completed successfully (return code 0 and `SUCCESS COMPLETE`): initial Fortran RK3, initial C++ ARK3, stored-state Fortran RK3, and stored-state C++ ARK3. Both inputs retained the pinned SHA-256 values. Each Fortran run produced the U-PGF v1, Full RHS, and `rk_tendency` captures; each C++ run produced U-PGF v2, operand v1, and Full RHS captures. The runner validated every expected file's complete SHA-256 and byte count/schema. All four snapshots report C++ stagger dimensions `[17,17,16,18,18,17]`; the Fortran PGF snapshots report `rk_step=1`, `n_moist=2`. Each ARK log confirmed the C++ route; each RK3 log confirmed the native route. Run receipt: [pgf_runs.json](captures/pgf_runs.json), SHA-256 `1aa3941d591dbcd6f8f18858c83b6b2b1eaf1a04e97ee25cf9d68d5e8c00606a`; raw captures are under [captures/pgf](captures/pgf/).

The capture runner itself does not assert same-state numerical equality, pressure-context equality, or PGF parity.

## Same-call state and operand audit — 2026-10-12 09:45 JST

The existing Full RHS analyzer was run on initial and stored Fortran/ARK pairs; both report `state_exact_match=true`. The additional PGF-context audit in [pgf_capture_context_analysis.json](pgf_capture_context_analysis.json) verifies for both input states that the Fortran PGF-captured six-field state equals its Fortran Full RHS snapshot, the C++ PGF-captured state equals its C++ Full RHS snapshot, and physical owned U/V/W/PH/T/MU state matches exactly across methods. The U periodic first/closing faces also match exactly; Fortran/C++ nonhydrostatic flags agree. All recorded state, pressure operands, and PGF arrays are finite; C++ velocity mass and alpha denominators are positive.

The same-call sidecar comparison shows PH is bitwise equal. P′ differs by relative RMS `0.1363%` (max absolute `0.0193 Pa`) for the initial input and `0.1455%` (`0.0242 Pa`) for the stored input. AL′ relative RMS differences are `5.06e-8` and `5.25e-8`; ALT differences are `5.22e-8` and `5.73e-8`. These are direct measurements of captured operands; no pressure-cause or PGF parity conclusion is claimed. The comparison script is [analyze_pgf_capture_context.py](analyze_pgf_capture_context.py), SHA-256 `a6d1ebcf952c43ad4d32b88f13c7469f4e82044c5a8d507b6d1b35e111ce9379`.

Root separately checked that both source inputs have zero QVAPOR and zero QV_BASE maxima; the Fortran snapshot records `n_moist=2`, so species are present in the allocated state despite their zero input values.

Independent Red raw-artifact/state/context review is pending. No additional model run was performed.

## Independent raw review complete — 2026-10-12 09:51 JST

Red independently verified all four run receipts and artifact hashes, the Fortran writer field order, the state/context comparison, and the state/periodic-face gates. It confirms the operand differences above. Review record: [actual_pgf_capture_review.json](../red_provenance/actual_pgf_capture_review.json), SHA-256 `23a28215d74ef6a38b46394e9db8fcb7dc52b37f575ae020dab6450763ac5af3`.

Red also compared the four one-step WRF history outputs against the archived PR296 `fixed_xy` outputs: all 188 variables and complete file hashes match for the single saved record at time zero. These cases emitted no `+15 s` history record, so this supports only initial-output noninterference, not endpoint parity. No PGF numerical parity, pressure-filter parity, or causal attribution is claimed. The older Red same-state parser grouped mixed-rank Fortran arrays incorrectly and is superseded by the corrected context audit; do not use that old output.
