from pathlib import Path
import numpy as np,json,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
E=Path(__file__).resolve().parent;fig,axs=plt.subplots(2,2,figsize=(10,7),constrained_layout=True)
for col,c in enumerate(['initial','stored']):
 p=E/'red_arrays'/f'{c}_u_pgf_delta_arrays.npz';z=np.load(p);r=z['old_remainder_unique_u'];d=z['delta_pgf_cpp_minus_ft'];n=z['new_remainder_after_pgf'];ax=axs[0,col]
 ax.scatter(r.ravel(),d.ravel(),s=6,alpha=.3);lo=min(r.min(),d.min());hi=max(r.max(),d.max());ax.plot([lo,hi],[lo,hi],color='black',linewidth=.8,label='equal contribution');ax.set_xlabel('Old post-H/V remainder (m/s²)');ax.set_ylabel('Measured PGF difference (m/s²)');ax.set_title(c.capitalize()+' input');ax.grid(alpha=.2);ax.ticklabel_format(style='sci',axis='both',scilimits=(0,0));ax.legend(fontsize=8)
 ax=axs[1,col]
 for label,a in [('Old remainder',r),('PGF difference',d),('After PGF subtraction',n)]:ax.semilogy(np.arange(1,a.shape[1]+1),np.sqrt(np.mean(a*a,axis=(0,2))),marker='o',markersize=3,label=label)
 ax.set_xlabel('Mass layer index (1-based)');ax.set_ylabel('Owned-face RMS (m/s²)');ax.grid(alpha=.2);ax.legend(fontsize=8)
fig.suptitle('Same-state U pressure-gradient contribution — 4096 owned faces')
out=E/'u_pgf_component_budget.png';fig.savefig(out,dpi=150);plt.close(fig)
(E/'figure_receipt.json').write_text(json.dumps({'figure':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'scope':'Bookkeeping subtraction of captured component differences; no production equation correction or forecast error claim','input_arrays':{c:hashlib.sha256((E/'red_arrays'/f'{c}_u_pgf_delta_arrays.npz').read_bytes()).hexdigest() for c in ['initial','stored']}},indent=2)+'\n');print(out)
