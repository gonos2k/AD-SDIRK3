from pathlib import Path
import hashlib,json,subprocess,sys,tempfile
import numpy as np
B=Path(__file__).resolve().parent
manifest=json.loads((B/'manifest.json').read_text())
for rel,h in manifest.items():
 assert hashlib.sha256((B/rel).read_bytes()).hexdigest()==h,rel
results={}
with tempfile.TemporaryDirectory(prefix='pr298-analysis-') as td:
 for case in ('initial','stored'):
  root=B/'evidence/green_build/captures/pgf'
  f=root/f'{case}_fortran_rk3_h15';c=root/f'{case}_cpp_ark3_h15'
  out=Path(td)/f'{case}.json';npz=Path(td)/f'{case}.npz'
  cmd=[sys.executable,str(B/'evidence/red_arrays/analyze_same_state_u_pgf.py'),'--case',case,'--fortran-pgf',str(f/'wrf_u_pgf_snapshot.bin'),'--cpp-pgf',str(c/'port_u_pgf_snapshot.bin'),'--cpp-operands',str(c/'port_u_pgf_operands_snapshot.bin'),'--fortran-full',str(f/'wrf_full_rhs_snapshot.bin'),'--cpp-full',str(c/'port_full_rhs_snapshot.bin'),'--out',str(out),'--npz',str(npz)]
  subprocess.run(cmd,check=True)
  r=json.loads(out.read_text());assert r['comparison_available'] and r['state_gate']['passed'],r
  z=np.load(npz);old=np.load(B/f'evidence/red_arrays/{case}_u_pgf_delta_arrays.npz')
  assert set(z.files)==set(old.files)
  for k in z.files: assert np.array_equal(z[k],old[k]),(case,k)
  results[case]={'actual_state_gate':True,'all_arrays_equal':True,'array_count':len(z.files),'owner_metrics':r['regions']['all_owner']}
 subprocess.run([sys.executable,str(B/'source/tools/test_reference_plan_contract.py')],check=True)
print(json.dumps({'all_manifest_payloads_valid':True,'payload_count':len(manifest),'native_runs_added':0,'p2_tests':3,'cases':results},indent=2))
