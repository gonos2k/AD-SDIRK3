#!/usr/bin/env python3
"""Compare existing PR298 mixed-time and PR300 preserve-W post-PGF U residual vectors."""
from __future__ import annotations
import hashlib, json
from pathlib import Path
import numpy as np

OLD_E = Path('/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012')
NEW_E = Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012')
OUT = Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/green_metric')
OLD_META = OLD_E / 'red_arrays/stored_u_pgf_delta_analysis.json'
OLD_NPZ = OLD_E / 'red_arrays/stored_u_pgf_delta_arrays.npz'
OLD_COMPARISON = OLD_E / 'red_precision/current_remainder_pgf_comparison.json'
OLD_REMAINDER = Path('/Users/yhlee/AD-SDIRK3-review-evidence/rk3-reference-shape-20261012/green_rhs/remainder_arrays.npz')
NEW_META = NEW_E / 'green_pressure/preserve_w/preserve_w_full_hv_pgf_residual.json'
NEW_NPZ = NEW_E / 'green_pressure/preserve_w/preserve_w_full_hv_pgf_residual_arrays.npz'
NEW_STATE_GATE = NEW_E / 'green_execution/preserve_w/preserve_w_state_gate.json'
NEW_RUNS = NEW_E / 'green_execution/preserve_w/preserve_w_runs.json'


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def receipt(path: Path) -> dict:
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}

old_meta = json.loads(OLD_META.read_text())
old_comparison = json.loads(OLD_COMPARISON.read_text())
new_meta = json.loads(NEW_META.read_text())
new_gate = json.loads(NEW_STATE_GATE.read_text())
new_runs = json.loads(NEW_RUNS.read_text())
old_z = np.load(OLD_NPZ)
new_z = np.load(NEW_NPZ)
old = np.asarray(old_z['new_remainder_after_pgf'], dtype=np.float64)
new = np.asarray(new_z['remainder_after_pgf_m_s2'], dtype=np.float64)
mask = np.asarray(new_z['owner_mask_u_unique_periodic_x'], dtype=bool)
if old.shape != (16, 16, 16) or new.shape != old.shape or mask.shape != old.shape:
    raise RuntimeError(f'expected same [j,k,i] physical U owner shape; got {old.shape}, {new.shape}, {mask.shape}')
if not mask.all() or int(mask.sum()) != 4096 or old_meta['owner_mask_counts']['all_owner'] != 4096:
    raise RuntimeError('the two arrays are not bound to all 4096 unique physical U owners')
if not (np.isfinite(old).all() and np.isfinite(new).all()):
    raise RuntimeError('nonfinite residual vector')
if old_meta.get('case') != 'stored' or not old_meta.get('old_full_rhs_reuse_gate', {}).get('whole_delta_matches_old_bitwise'):
    raise RuntimeError('old source is not the recorded PR298 stored/mixed-time residual with its reuse gate')
if old_comparison['cases']['stored']['owners'] != 4096:
    raise RuntimeError('old comparison summary has unexpected owner count')
if not new_gate.get('all_six_actual_call_fields_exact_to_source60') or not new_gate.get('same_call_state_gates', {}).get('passed'):
    raise RuntimeError('new preserve-W state/source-60 gate did not pass')
if not new_meta.get('gates', {}).get('PGF_state', {}).get('passed'):
    raise RuntimeError('new preserve-W PGF state gate did not pass')
if not new_meta.get('gates', {}).get('Full_state', {}).get('passed'):
    raise RuntimeError('new preserve-W Full-state gate did not pass')
if new_runs.get('status') != 'completed' or len(new_runs.get('runs', [])) != 2:
    raise RuntimeError('new preserve-W pair is not the completed two-case capture')

delta = new - old
old_norm = float(np.linalg.norm(old.ravel()))
new_norm = float(np.linalg.norm(new.ravel()))
cosine = float(np.vdot(old.ravel(), new.ravel()) / (old_norm * new_norm)) if old_norm and new_norm else None

def stats(a: np.ndarray) -> dict:
    a = np.asarray(a, dtype=np.float64)
    return {'count': int(a.size), 'units': 'm/s^2', 'rms': float(np.sqrt(np.mean(a*a))), 'max_abs': float(np.max(np.abs(a))), 'finite': bool(np.isfinite(a).all())}

raw_out = OUT / 'post_pgf_residual_change_arrays.npz'
np.savez_compressed(raw_out,
    old_pr298_mixed_time_post_pgf_residual_m_s2=old,
    new_pr300_preserve_w_post_pgf_residual_m_s2=new,
    change_new_minus_old_m_s2=delta,
    owner_mask_u_unique_periodic_x=mask)

old_input_origin = old_meta['capture_run_provenance']['cpp_case'].get('input_origin')
old_six_state_gate = old_meta.get('state_gate', {})
report = {
  'schema': 'pr300-preserve-w-vs-pr298-mixed-time-post-pgf-u-residual-v1',
  'comparison': 'pointwise new preserve-W post-PGF residual minus old PR298 stored/mixed-time post-PGF residual; raw vectors are compared directly, not by subtracting norms',
  'units': 'm/s^2',
  'geometry': {'array_order': '[j,k,i]', 'shape': list(old.shape), 'physical_unique_u_owners': 4096, 'mask': 'physical U faces j=0..15,k=0..15,i=0..15; face i=0 retained, periodic closing duplicate i=16 excluded', 'old_owner_count_source': 'PR298 stored analysis owner_mask_counts.all_owner=4096 and current comparison owners=4096', 'new_owner_mask_all_true': bool(mask.all())},
  'old_pr298_mixed_time': {
      'case_label': 'stored',
      'description': 'PR298 stored/mixed-time post-PGF residual as recorded by the existing paired PGF analysis; no equivalent exact source-60 state gate is claimed for this old run',
      'residual_array_key': 'new_remainder_after_pgf',
      'capture_input_origin': old_input_origin,
      'stored_input_sha256': old_meta['capture_run_provenance']['cpp_case']['input_sha256'],
      'capture_analysis': receipt(OLD_META),
      'capture_arrays': receipt(OLD_NPZ),
      'old_current_remainder_summary': receipt(OLD_COMPARISON),
      'reused_full_rhs_gate': old_meta['old_full_rhs_reuse_gate'],
      'same_call_state_gate': {
          'cpp_pgf_vs_full': old_six_state_gate.get('cpp_pgf_state_equal_to_full_packed_state'),
          'fortran_pgf_vs_full': old_six_state_gate.get('fortran_pgf_state_equal_to_full_memory'),
      },
      'residual_vector_stats': stats(old),
  },
  'new_pr300_preserve_w': {
      'case_label': 'preserve_w',
      'residual_array_key': 'remainder_after_pgf_m_s2',
      'input_sha256': new_runs['corrected_input_sha256'],
      'executable_sha256': new_runs['runs'][0]['executable_sha256'],
      'source60_state_exact_all_six_fields': new_gate['all_six_actual_call_fields_exact_to_source60'],
      'paired_call_state_gate_passed': new_gate['same_call_state_gates']['passed'],
      'state_gate': receipt(NEW_STATE_GATE),
      'run_receipt': receipt(NEW_RUNS),
      'residual_analysis': receipt(NEW_META),
      'residual_arrays': receipt(NEW_NPZ),
      'residual_vector_stats': stats(new),
  },
  'pointwise_change_new_minus_old': {
      **stats(delta),
      'cosine_old_vs_new': cosine,
      'max_abs_change_index_jki': [int(i) for i in np.unravel_index(np.argmax(np.abs(delta)), delta.shape)],
  },
  'source_state_comparison_limit': 'The old PR298 vector comes from its distinct stored/mixed-time source and does not have the preserve-W source-60 gate. The new vector is explicitly source-60 exact for all six actual-call state fields. Thus this is a residual-shape change across those recorded states, not a controlled causal attribution to W alone.',
  'raw_comparison_arrays': receipt(raw_out),
  'analysis_script': receipt(Path(__file__).resolve()),
}
json_out = OUT / 'residual_shape_comparison.json'
json_out.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps(report, indent=2, sort_keys=True))
