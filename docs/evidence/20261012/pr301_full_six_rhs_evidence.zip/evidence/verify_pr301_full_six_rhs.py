#!/usr/bin/env python3
"""Portable verifier for the PR301 Full-RHS V2 capture bundle.

This script only parses saved files. It requires no WRF checkout and runs no
model or RHS. All bundle inputs are relative to --root via bundle_manifest.json.
It checks the time-zero input against the archived source60 frame, all six
actual FT/CPP call states against source60 over the full physical staggered
extents, each PGF call against its same-run Full state, and V2 serialization.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import sys
import struct
import zipfile
import zlib
from typing import Any

import numpy as np

MANIFEST = "bundle_manifest.json"
INPUT_FIELDS = ("U", "V", "W", "PH", "T", "THM", "MU", "P")
BASE_FIELDS = ("PB", "PHB", "MUB")
STATE_MAP = {"u": "U", "v": "V", "w": "W", "ph": "PH", "t": "THM", "mu": "MU"}
EXPECTED_DIMS = {
    "U": ("Time", "bottom_top", "south_north", "west_east_stag"),
    "V": ("Time", "bottom_top", "south_north_stag", "west_east"),
    "W": ("Time", "bottom_top_stag", "south_north", "west_east"),
    "PH": ("Time", "bottom_top_stag", "south_north", "west_east"),
    "T": ("Time", "bottom_top", "south_north", "west_east"),
    "THM": ("Time", "bottom_top", "south_north", "west_east"),
    "MU": ("Time", "south_north", "west_east"),
    "P": ("Time", "bottom_top", "south_north", "west_east"),
    "PB": ("Time", "bottom_top", "south_north", "west_east"),
    "PHB": ("Time", "bottom_top_stag", "south_north", "west_east"),
    "MUB": ("Time", "south_north", "west_east"),
    "QVAPOR": ("Time", "bottom_top", "south_north", "west_east"),
}
EXPECTED_RUNS = {"pr301_v2_fortran_rk3_h15": "RK3", "pr301_v2_cpp_ark3_h15": "ARK3"}


class VerificationError(RuntimeError):
    pass


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def bundle_path(root: Path, value: str) -> Path:
    rel = PurePosixPath(value)
    if rel.is_absolute() or not rel.parts or any(x in ("", "..") for x in rel.parts):
        raise VerificationError(f"bundle paths must be relative and traversal-safe: {value!r}")
    path = root.joinpath(*rel.parts)
    try:
        path.resolve(strict=False).relative_to(root.resolve())
    except ValueError as exc:
        raise VerificationError(f"bundle path escapes root: {value}") from exc
    return path


def load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text())
    except Exception as exc:
        raise VerificationError(f"cannot parse {path.name}: {exc}") from exc
    if not isinstance(data, dict):
        raise VerificationError(f"expected JSON object: {path.name}")
    return data


def read_manifest_path(root: Path, doc: dict[str, Any], key: str, required: bool = True) -> Path | None:
    rel = doc.get("paths", {}).get(key)
    if rel is None:
        if required:
            raise VerificationError(f"manifest missing paths.{key}")
        return None
    if not isinstance(rel, str):
        raise VerificationError(f"paths.{key} must be a string")
    path = bundle_path(root, rel)
    if required and not path.is_file():
        raise VerificationError(f"manifest payload missing: {rel}")
    return path


def read_manifest_dir(root: Path, doc: dict[str, Any], label: str) -> Path:
    rel = doc.get("run_dirs", {}).get(label)
    if not isinstance(rel, str):
        raise VerificationError(f"manifest missing run_dirs.{label}")
    path = bundle_path(root, rel)
    if not path.is_dir():
        raise VerificationError(f"capture directory missing: {rel}")
    return path


def check_manifest_files(root: Path, doc: dict[str, Any]) -> list[dict[str, Any]]:
    checked = []
    for entry in doc.get("files", []):
        if not isinstance(entry, dict) or not isinstance(entry.get("path"), str):
            raise VerificationError("files entries need relative path strings")
        path = bundle_path(root, entry["path"])
        if not path.is_file():
            raise VerificationError(f"manifest file missing: {entry['path']}")
        size, sha = path.stat().st_size, digest(path)
        if entry.get("bytes") is not None and size != int(entry["bytes"]):
            raise VerificationError(f"manifest byte count mismatch: {entry['path']}")
        if entry.get("sha256") and sha.lower() != str(entry["sha256"]).lower():
            raise VerificationError(f"manifest SHA-256 mismatch: {entry['path']}")
        if entry.get("crc32") is not None:
            raw = entry["crc32"]
            if isinstance(raw, str):
                s = raw.strip().lower()
                crc_expected = int(s, 16) if s.startswith("0x") or all(c in "0123456789abcdef" for c in s) else int(s, 0)
            else:
                crc_expected = int(raw)
            if (zlib.crc32(path.read_bytes()) & 0xFFFFFFFF) != crc_expected:
                raise VerificationError(f"manifest CRC32 mismatch: {entry['path']}")
        checked.append({"path": entry["path"], "bytes": size, "sha256": sha})
    return checked


def check_zip(path: Path | None, expected_sha: str | None = None) -> dict[str, Any] | None:
    if path is None:
        return None
    if not path.is_file():
        raise VerificationError(f"ZIP not found: {path}")
    sha = digest(path)
    if expected_sha and sha.lower() != expected_sha.lower():
        raise VerificationError("ZIP SHA-256 mismatch")
    try:
        with zipfile.ZipFile(path) as archive:
            bad = archive.testzip()
            if bad:
                raise VerificationError(f"ZIP member CRC failed: {bad}")
            return {"sha256": sha, "crc_verified": True, "members": len(archive.infolist())}
    except zipfile.BadZipFile as exc:
        raise VerificationError(f"invalid ZIP: {exc}") from exc


def load_parsers(root: Path, doc: dict[str, Any]):
    deps = bundle_path(root, doc.get("dependencies_dir", "dependencies"))
    full_path = bundle_path(root, doc.get("full_parser", "evidence/green_analysis/analyze_full_six_rhs.py"))
    pgf_path = bundle_path(root, doc.get("pgf_parser", "dependencies/analyze_pgf_capture_context.py"))
    if not deps.is_dir() or not full_path.is_file() or not pgf_path.is_file():
        raise VerificationError("bundled parser dependency missing")
    sys.path.insert(0, str(deps))
    spec = importlib.util.spec_from_file_location("pr301_full_parser", full_path)
    if spec is None or spec.loader is None:
        raise VerificationError("cannot load bundled full-RHS parser")
    full = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(full)
    import analyze_pgf_capture_context as pgf  # type: ignore
    if Path(pgf.__file__).resolve() != pgf_path.resolve():
        raise VerificationError("PGF parser did not resolve from this unpacked bundle")
    return full, pgf, {"full_parser_sha256": digest(full_path), "pgf_parser_sha256": digest(pgf_path)}


def times(ds) -> list[str]:
    if "Times" not in ds.variables:
        raise VerificationError("NetCDF field Times is missing")
    return [b"".join(row.tolist()).decode("ascii").rstrip("\x00 ") for row in ds.variables["Times"][:]]


def record(ds, name: str, index: int) -> np.ndarray:
    if name not in ds.variables:
        raise VerificationError(f"NetCDF variable missing: {name}")
    var = ds.variables[name]
    if name in EXPECTED_DIMS and tuple(var.dimensions) != EXPECTED_DIMS[name]:
        raise VerificationError(f"NetCDF dimensions mismatch for {name}: {var.dimensions}")
    a = np.asarray(var[index])
    if a.ndim == 3:
        a = a.transpose(1, 0, 2)  # [k,j,i] -> [j,k,i]
    return a


def metric(a: np.ndarray, b: np.ndarray) -> dict[str, Any]:
    x, y = np.asarray(a), np.asarray(b)
    if x.shape != y.shape:
        return {"shape_equal": False, "exact": False, "a_shape": list(x.shape), "b_shape": list(y.shape)}
    if not np.isfinite(x).all() or not np.isfinite(y).all():
        return {"shape_equal": True, "finite": False, "exact": False, "count": int(x.size)}
    d = x.astype(np.float64) - y.astype(np.float64)
    return {"shape_equal": True, "finite": True, "exact": bool(np.array_equal(x, y)),
            "count": int(x.size), "mismatch_count": int(np.count_nonzero(x != y)),
            "rms_delta": float(np.sqrt(np.mean(d*d))) if d.size else 0.0,
            "max_abs_delta": float(np.max(np.abs(d))) if d.size else 0.0}


def check_run_receipt(root: Path, doc: dict[str, Any], input_sha: str) -> tuple[dict[str, Path], dict[str, Any]]:
    receipt_path = read_manifest_path(root, doc, "run_receipt")
    receipt = load_json(receipt_path)
    if receipt.get("schema") != "pr301_full_rhs_v2_two_call_capture_v1" or receipt.get("status") != "completed":
        raise VerificationError("wrong/incomplete PR301 run receipt")
    if receipt.get("native_calls_authorized") != 2 or receipt.get("native_calls_completed") != 2:
        raise VerificationError("run receipt is not exactly two native calls")
    if receipt.get("input_sha256") != input_sha or receipt.get("use_input_w") is not True:
        raise VerificationError("run input or preserve-W setting mismatch")
    if (receipt.get("step_seconds"), receipt.get("run_seconds"), receipt.get("mpi_ranks"), receipt.get("threads")) != (15, 15, 1, 1):
        raise VerificationError("run timestep/duration/rank/thread mismatch")
    labels = {r.get("label"): r for r in receipt.get("runs", [])}
    if set(labels) != set(EXPECTED_RUNS):
        raise VerificationError("run labels mismatch")
    exe_hashes = set()
    run_dirs = {}
    for label, method in EXPECTED_RUNS.items():
        r = labels[label]
        if r.get("method") != method or r.get("status") != "completed" or int(r.get("return_code", -1)) != 0 or r.get("input_sha256") != input_sha:
            raise VerificationError(f"run record mismatch: {label}")
        exe_hashes.add(r.get("executable_sha256"))
        run_dir = read_manifest_dir(root, doc, label)
        input_file = run_dir / "wrfinput_d01"
        if not input_file.is_file() or digest(input_file) != input_sha:
            raise VerificationError(f"run directory input hash mismatch: {label}")
        for name, art in r.get("artifacts", {}).items():
            f = run_dir / name
            if not f.is_file() or f.stat().st_size != int(art.get("bytes", -1)) or digest(f) != art.get("sha256"):
                raise VerificationError(f"run artifact receipt mismatch: {label}/{name}")
        run_dirs[label] = run_dir
    if len(exe_hashes) != 1:
        raise VerificationError("paired calls used different executables")
    if receipt.get("source_sha256_after") != receipt.get("build_gate", {}).get("source_pins"):
        raise VerificationError("source hashes changed after the two calls")
    return run_dirs, {"receipt_sha256": digest(receipt_path), "executable_sha256": next(iter(exe_hashes)),
                      "input_sha256": input_sha, "run_labels": sorted(labels)}


def source60_and_input(input_path: Path, source_path: Path, source_timestamp: str):
    try:
        from netCDF4 import Dataset
    except Exception as exc:
        raise VerificationError(f"netCDF4 is required: {exc}") from exc
    with Dataset(source_path) as src, Dataset(input_path) as inp:
        src_times, in_times = times(src), times(inp)
        if src_times.count(source_timestamp) != 1:
            raise VerificationError("source timestamp missing or duplicated")
        if in_times != ["0001-01-01_00:00:00"]:
            raise VerificationError("corrected input is not one cold time-zero record")
        si = src_times.index(source_timestamp)
        src_state = {n: record(src, n, si) for n in INPUT_FIELDS}
        inp_state = {n: record(inp, n, 0) for n in INPUT_FIELDS}
        copied = {n: metric(inp_state[n], src_state[n]) for n in INPUT_FIELDS}
        if not all(v.get("exact") for v in copied.values()):
            raise VerificationError("corrected input eight-field copy differs from source60")
        context = {}
        for n in BASE_FIELDS + ("QVAPOR",):
            if n not in src.variables or n not in inp.variables:
                if n in BASE_FIELDS:
                    raise VerificationError(f"required base context absent: {n}")
                continue
            a, b = record(inp, n, 0), record(src, n, si)
            context[n] = metric(a, b)
            if not context[n].get("exact"):
                raise VerificationError(f"base/thermodynamic context mismatch: {n}")
    return src_state, {"source_time_index": si, "source_timestamp": source_timestamp,
                       "source_times": src_times, "input_times": in_times,
                       "copied_input_fields": copied, "shared_context": context}


def compare_full_state_to_source(full_parser, storage: dict[str, np.ndarray], dims: tuple[int, ...], source: dict[str, np.ndarray]):
    state = full_parser.physical_state(storage, dims)
    expected = {"u": source["U"], "v": source["V"], "w": source["W"],
                "ph": source["PH"], "t": source["THM"], "mu": source["MU"]}
    result = {}
    for name in STATE_MAP:
        actual = state[name]
        if name == "mu" and actual.ndim == 3 and actual.shape[1] == 1:
            actual = actual[:, 0, :]
        result[name] = metric(actual, expected[name])
    if not all(v.get("exact") for v in result.values()):
        raise VerificationError("six actual first-call fields differ from source60 over full physical staggered extents")
    return result


def inspect_calls(full_parser, pgf_parser, ft_dir: Path, cpp_dir: Path):
    ft_meta, ft = full_parser.read_fortran(ft_dir / "wrf_full_rhs_snapshot.bin")
    cpp_meta, cpp_state, cpp_rhs = full_parser.read_cpp(cpp_dir / "port_full_rhs_snapshot.bin")
    ft_pgf_meta, ft_pgf = pgf_parser.read_ft_pgf(ft_dir / "wrf_u_pgf_snapshot.bin")
    cpp_pgf_meta, cpp_pgf_state, cpp_pgf_rhs = pgf_parser.read_cpp_pgf(cpp_dir / "port_u_pgf_snapshot.bin")
    pgf_parser.read_cpp_operands(cpp_dir / "port_u_pgf_operands_snapshot.bin")
    if ft_meta.get("version") != 2 or ft_meta.get("v2_appended_fields") != ["rw_tend", "ph_tend", "t_tend", "c1f", "c2f"]:
        raise VerificationError("Fortran Full-RHS snapshot is not the expected V2 format")
    dims = tuple(cpp_meta["dims_nx_ny_nz_nxu_nyv_nzw"])
    if cpp_pgf_meta.get("dimensions") != list(dims):
        raise VerificationError("C++ PGF and Full dimensions differ")
    if tuple(ft_pgf_meta["bounds"])[0:6] != (1, 17, 1, 17, 1, 17):
        raise VerificationError("unexpected Fortran capture domain bounds")
    for name, ndim in (("rw_tend", 3), ("ph_tend", 3), ("t_tend", 3), ("c1f", 1), ("c2f", 1)):
        arr = ft[name]
        if arr.ndim != ndim or not np.isfinite(arr).all():
            raise VerificationError(f"invalid/non-finite V2 appended array: {name}")
    ft_full_state = full_parser.logical_fortran_state(ft_meta, ft, dims)
    ft_call_state = full_parser.logical_fortran_state({"bounds": ft_pgf_meta["bounds_dict"]},
        {"u2": ft_pgf["u"], "v2": ft_pgf["v"], "w2": ft_pgf["w"], "ph2": ft_pgf["ph"], "t2": ft_pgf["t"], "mu2": ft_pgf["mu"]}, dims)
    ft_call_gate = full_parser.state_audit(ft_call_state, ft_full_state)
    cpp_full_gate = full_parser.state_audit(cpp_pgf_state, cpp_state)
    full_storage_gate = full_parser.state_audit(ft_full_state, cpp_state)
    pgf_storage_gate = full_parser.state_audit(ft_call_state, cpp_pgf_state)
    ft_physical = full_parser.physical_state(ft_call_state, dims)
    cpp_physical = full_parser.physical_state(cpp_pgf_state, dims)
    paired_physical = full_parser.state_audit(ft_physical, cpp_physical)
    seam = full_parser.periodic_u_seam_audit(ft_call_state, cpp_pgf_state, dims)
    gates = (ft_call_gate, cpp_full_gate, full_storage_gate, pgf_storage_gate, paired_physical)
    if not all(v.get("equal") for g in gates for v in g.values()):
        raise VerificationError("raw FT/CPP PGF/Full six-state equality gate failed")
    if not all(seam[k] for k in ("fortran_first_equals_closing_face", "cpp_first_equals_closing_face", "fortran_cpp_closing_face_equal")):
        raise VerificationError("periodic U seam gate failed")
    ft_finite = {k: bool(np.isfinite(v).all()) for k, v in ft.items()}
    if not all(ft_finite.values()):
        raise VerificationError("Fortran V2 Full snapshot contains non-finite serialized fields")
    cpp_state_finite = {k: bool(np.isfinite(v).all()) for k, v in cpp_state.items()}
    if not all(cpp_state_finite.values()):
        raise VerificationError("C++ Full snapshot contains a non-finite state block")
    cpp_finite_rhs = {k: bool(np.isfinite(v).all()) for k, v in cpp_rhs.items()}
    if set(cpp_finite_rhs) != set(STATE_MAP) or not all(cpp_finite_rhs.values()):
        raise VerificationError("C++ Full RHS does not contain finite all-six blocks")
    v2_meta = ft_meta["memory_shape_jki"]
    v2_shapes = {"rw_tend": v2_meta, "ph_tend": v2_meta, "t_tend": v2_meta,
                 "c1f": [v2_meta[1]], "c2f": [v2_meta[1]]}
    if any(list(ft[k].shape) != list(shape) for k, shape in v2_shapes.items()):
        raise VerificationError("Fortran V2 appended array shapes disagree with header/storage")
    return {"dims": list(dims), "fortran_meta": ft_meta, "cpp_meta": cpp_meta, "cpp_pgf_meta": cpp_pgf_meta,
            "ft_state": ft_physical, "cpp_state": cpp_physical,
            "gates": {"ft_pgf_vs_full": ft_call_gate, "cpp_pgf_vs_full": cpp_full_gate,
                      "ft_full_vs_cpp_full": full_storage_gate, "ft_pgf_vs_cpp_pgf": pgf_storage_gate,
                      "full_physical_boundaries_ft_vs_cpp": paired_physical, "periodic_u_seam": seam},
            "fortran_v2_fields": {k: {"shape": list(ft[k].shape), "finite": bool(np.isfinite(ft[k]).all())} for k in v2_shapes},
            "fortran_full_serialized_fields_finite": ft_finite,
            "cpp_full_state_blocks_finite": cpp_state_finite,
            "cpp_full_rhs_blocks_finite": cpp_finite_rhs,
            "fortran_v2_bytes": (ft_dir / "wrf_full_rhs_snapshot.bin").stat().st_size}


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", required=True, type=Path, help="unpacked bundle root")
    p.add_argument("--manifest", type=Path, default=Path(MANIFEST), help="relative bundle manifest")
    p.add_argument("--out", type=Path, help="optional exclusive-create JSON output")
    p.add_argument("--archive", type=Path, help="optional ZIP whose CRCs should be checked")
    p.add_argument("--manifest-sha256", help="optional expected manifest SHA-256")
    args = p.parse_args()
    try:
        root = args.root.resolve(strict=True)
        mpath = args.manifest if args.manifest.is_absolute() else root / args.manifest
        mpath = mpath.resolve(strict=True)
        if root not in mpath.parents:
            raise VerificationError("manifest is outside bundle root")
        msha = digest(mpath)
        if args.manifest_sha256 and msha.lower() != args.manifest_sha256.lower():
            raise VerificationError("manifest SHA-256 mismatch")
        manifest = json.loads(mpath.read_text())
        if manifest.get("schema") != "pr301-full-six-rhs-bundle-v1":
            raise VerificationError("unsupported bundle manifest schema")
        checked_files = check_manifest_files(root, manifest)
        archive_path = args.archive if args.archive and args.archive.is_absolute() else (root / args.archive if args.archive else None)
        archive = check_zip(archive_path)
        full_parser, pgf_parser, parser_receipt = load_parsers(root, manifest)
        run_receipt_path = read_manifest_path(root, manifest, "run_receipt")
        input_path = read_manifest_path(root, manifest, "corrected_input")
        source_path = read_manifest_path(root, manifest, "source60_wrfout")
        receipt = load_json(run_receipt_path)
        input_sha = digest(input_path)
        run_dirs, run_gate = check_run_receipt(root, manifest, input_sha)
        source_ts = manifest.get("source_timestamp", "0001-01-01_00:01:00")
        source, copy_gate = source60_and_input(input_path, source_path, source_ts)
        actual = inspect_calls(full_parser, pgf_parser, run_dirs["pr301_v2_fortran_rk3_h15"], run_dirs["pr301_v2_cpp_ark3_h15"])
        state_source = {
            "fortran": compare_full_state_to_source(full_parser, actual["ft_state"], tuple(actual["dims"]), source),
            "cpp": compare_full_state_to_source(full_parser, actual["cpp_state"], tuple(actual["dims"]), source),
        }
        if not all(v["exact"] for mode in state_source.values() for v in mode.values()):
            raise VerificationError("one or more full physical boundary state values differ from source60")
        old_v1 = read_manifest_path(root, manifest, "previous_v1_fortran_full", required=False)
        prefix_check = None
        if old_v1 is not None:
            old, new = old_v1.read_bytes(), (run_dirs["pr301_v2_fortran_rk3_h15"] / "wrf_full_rhs_snapshot.bin").read_bytes()
            if len(old) < 60 or struct.unpack_from("<I", old, 0)[0] != 1 or struct.unpack_from("<I", new, 0)[0] != 2:
                raise VerificationError("prior V1/new V2 version mismatch")
            if new[4:len(old)] != old[4:]:
                raise VerificationError("V2 body prefix does not match prior V1 snapshot")
            prefix_check = {"byte_equal": True, "v1_total_bytes": len(old), "v2_v1_body_bytes": len(old)-4}
        source_gate_path = read_manifest_path(root, manifest, "source_state_gate", required=False)
        if source_gate_path is not None:
            gate_doc = load_json(source_gate_path)
            if gate_doc.get("all_six_state_gates_pass") is False:
                raise VerificationError("bundled independent raw-state audit reports a failed gate")
        result = {"schema": "pr301-full-six-rhs-portable-verification-v1", "status": "verified",
                  "manifest": {"path": mpath.relative_to(root).as_posix(), "sha256": msha},
                  "manifest_files_checked": checked_files,
                  "archive": archive,
                  "parsers": parser_receipt,
                  "source60": {"path": manifest["paths"]["source60_wrfout"], "sha256": digest(source_path),
                               "timestamp": source_ts, "time_index": copy_gate["source_time_index"]},
                  "input_sha256": input_sha,
                  "input_source60_field_copy": copy_gate["copied_input_fields"],
                  "shared_base_context": copy_gate["shared_context"],
                  "runs": run_gate,
                  "actual_six_state_vs_source60_full_physical_boundaries": state_source,
                  "raw_call_full_state_gates": actual["gates"],
                  "v2_fortran_appended_payload": actual["fortran_v2_fields"],
                  "v2_full_bytes": actual["fortran_v2_bytes"],
                  "cpp_six_rhs_blocks_finite": actual["cpp_full_rhs_blocks_finite"],
                  "prior_v1_body_prefix": prefix_check,
                  "scope": "First-call raw state and V2 serialization integrity only; rate differences require source-equation physical conversions and have no pass threshold here."}
        text = json.dumps(result, indent=2, sort_keys=True) + "\n"
        if args.out:
            fd = os.open(args.out, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
            with os.fdopen(fd, "w") as stream:
                stream.write(text)
        else:
            sys.stdout.write(text)
        return 0
    except Exception as exc:
        sys.stderr.write(f"verify_pr301_full_six_rhs: FAIL: {exc}\n")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
