#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,shutil,subprocess,tempfile,zipfile,zlib
E=Path(__file__).resolve().parent
W=Path('/private/tmp/pr301-full-six-rhs-20261012')
D=W/'docs/evidence/20261012';D.mkdir(parents=True,exist_ok=True)
B=Path(tempfile.mkdtemp(prefix='pr301-evidence-freeze-'))
def cp(src,rel):
 dst=B/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
for f in sorted(E.rglob('*')):
 if f.is_file() and not f.is_symlink() and '__pycache__' not in f.parts and f.suffix not in ('.pyc','.exe','.o','.mod','.a'):
  cp(f,Path('evidence')/f.relative_to(E))
cp(E/'verify_pr301_full_six_rhs.py','verify_pr301_full_six_rhs.py')
for f in (E/'portable_dependencies').glob('*.py'):cp(f,Path('dependencies')/f.name)
cp(E/'portable_dependencies/dependency_receipt.json','dependencies/dependency_receipt.json')
cp(Path('/Users/yhlee/AD-SDIRK3-review-evidence/pressure-lineage-20261012/actual_t60_corrected_time0_wrfinput_d01_qvguard'),'inputs/corrected_wrfinput_d01.nc')
cp(Path('/Users/yhlee/AD-SDIRK3-review-evidence/same-state-rhs-20261011/wrf_validation/reference_snapshots/pr292_rk3_h3p75/wrfout_d01_0001-01-01_00:00:00'),'inputs/source60_wrfout_d01.nc')
cp(Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012/green_execution/preserve_w/captures/preserve_w/preserve_w_fortran_rk3_h15/wrf_full_rhs_snapshot.bin'),'prior/pr300_preserve_w_fortran_full.bin')
sources=['Registry/Registry.EM_COMMON','dyn_em/solve_em.F','dyn_em/start_em.F','dyn_em/module_em.F','dyn_em/module_small_step_em.F','dyn_em/module_big_step_utilities_em.F','dyn_em/module_bc_em.F','dyn_em/module_implicit_sdirk3.F','dyn_em/module_first_rk_step_part1.F','dyn_em/module_first_rk_step_part2.F','share/input_wrf.F','share/mediation_wrfmain.F','share/module_bc.F','share/module_model_constants.F','external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp','external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified.h','external/libtorch_wrf/sdirk3/wrf_sdirk3_config.cpp','tools/benchmark_wrf_accuracy_cost.py']
sourcepins={}
for rel in sources:
 data=subprocess.check_output(['git','show','2f32859:'+rel],cwd=W)
 assert hashlib.sha256(data).hexdigest()==hashlib.sha256((W/rel).read_bytes()).hexdigest(),rel
 dst=B/'source'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
 sourcepins[rel]=hashlib.sha256(data).hexdigest()
cp(W/'share/module_model_constants.f90','source/share/module_model_constants.f90')
cp(W/'configure.wrf','source/configure.wrf')
(B/'source/committed_source_binding.json').write_text(json.dumps({'code_commit':'2f32859d545bf5dc3e287653d8ebb1cb504df32c','authoritative_sha256':sourcepins,'generated_observed_only':{'share/module_model_constants.f90':hashlib.sha256((W/'share/module_model_constants.f90').read_bytes()).hexdigest()},'build_receipt':'evidence/green_build/pr301_solve_em_build_receipt.json'},indent=2)+'\n')
cp(W/'docs/(202610121817)_pr301_assembled_six_rhs_and_w_pressure.md','final_report.md')
# A relocated copy of the original pressure postprocess preserves the formulas;
# only input/source/output paths differ. Original is retained under evidence/.
p=(E/'green_w_pressure/analyze_pressure_induced_w.py').read_text()
p=p.replace("E=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012')", "import argparse\nap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--outdir',type=Path,required=True);args=ap.parse_args()\nB=args.root.resolve();E=B/'evidence'")
p=p.replace("ROOT=Path('/private/tmp/pr301-full-six-rhs-20261012')", "ROOT=B/'source'")
p=p.replace("OUT=E/'green_w_pressure'", "OUT=args.outdir.resolve();OUT.mkdir(parents=True,exist_ok=False)")
p=p.replace("'path':str(OUT/'analyze_pressure_induced_w.py'),'sha256':sha(OUT/'analyze_pressure_induced_w.py')", "'path':str(Path(__file__).resolve()),'sha256':sha(Path(__file__).resolve())")
(B/'replay_pressure_w.py').write_text(p)
(B/'README.md').write_text('PR301: two same-state native captures, six physical RHS comparisons, pressure-only W accounting. Run python3 verify_pr301_full_six_rhs.py --root UNPACKED --archive ZIP --out NEW_RESULT.json. Recompute rates with evidence/green_analysis/analyze_full_six_rhs.py --fortran FT_BIN --cpp CPP_BIN --source-root UNPACKED/source --six-field --top-lid false --out NEW_JSON --npz NEW_NPZ. Recompute W attribution with replay_pressure_w.py --root UNPACKED --outdir NEW_DIRECTORY. NumPy/netCDF4 required. Original auxiliary scripts retain historical machine paths. Exe/library bytes are excluded; recorded hashes are observations. No forecast or full-equation identity acceptance is asserted.\n')
files=[]
for f in sorted(B.rglob('*')):
 if f.is_file():
  b=f.read_bytes();files.append({'path':str(f.relative_to(B)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'crc32':f'{zlib.crc32(b)&0xffffffff:08x}'})
manifest={'schema':'pr301-full-six-rhs-bundle-v1','paths':{'run_receipt':'evidence/green_execution/pr301_v2/pr301_v2_runs.json','corrected_input':'inputs/corrected_wrfinput_d01.nc','source60_wrfout':'inputs/source60_wrfout_d01.nc','previous_v1_fortran_full':'prior/pr300_preserve_w_fortran_full.bin'},'run_dirs':{k:'evidence/green_execution/pr301_v2/captures/'+k for k in ('pr301_v2_fortran_rk3_h15','pr301_v2_cpp_ark3_h15')},'full_parser':'evidence/green_analysis/analyze_full_six_rhs.py','pgf_parser':'dependencies/analyze_pgf_capture_context.py','dependencies_dir':'dependencies','files':files,'code_commit':'2f32859d545bf5dc3e287653d8ebb1cb504df32c','source_timestamp':'0001-01-01_00:01:00','native_calls':2}
(B/'bundle_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
zp=D/'pr301_full_six_rhs_evidence.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted(B.rglob('*')):
  if f.is_file():z.write(f,f.relative_to(B))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
sha=hashlib.sha256(zp.read_bytes()).hexdigest();(D/(zp.name+'.sha256')).write_text(sha+'  '+zp.name+'\n')
print(json.dumps({'root':str(B),'zip':str(zp),'sha256':sha,'payload_files':len(files),'zip_bytes':zp.stat().st_size}))
