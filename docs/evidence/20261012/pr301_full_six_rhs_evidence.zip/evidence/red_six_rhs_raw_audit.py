#!/usr/bin/env python3
"""Independent raw V2 Full-RHS parser and field/unit/mask comparison for PR301."""
import hashlib,json,struct
from pathlib import Path
import numpy as np
E=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/green_execution/pr301_v2/captures')
F=E/'pr301_v2_fortran_rk3_h15'/'wrf_full_rhs_snapshot.bin'
C=E/'pr301_v2_cpp_ark3_h15'/'port_full_rhs_snapshot.bin'
RUN=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/green_execution/pr301_v2/pr301_v2_runs.json')
OUT=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/red_six_rhs_raw_audit.json')
NPZ=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/red_six_rhs_raw_audit_arrays.npz')
FORDER=('u2','v2','w2','ph2','t2','mu2','ru_tend','rv_tend','mu_tend','ru','rv','muu','muv','mut','dnw','c1h','c2h','msfux','msfuy','msfvx','msfvy','msftx','msfty')
F3=set(('u2','v2','w2','ph2','t2','ru_tend','rv_tend','ru','rv'))
F2=set(('mu2','mu_tend','muu','muv','mut','msfux','msfuy','msfvx','msfvy','msftx','msfty'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def metric(d,ref=None):
 d=np.asarray(d,dtype=np.float64)
 out={'count':int(d.size),'rms':float(np.sqrt(np.mean(d*d))),'max_abs':float(np.max(np.abs(d))),'mean_signed':float(np.mean(d))}
 if ref is not None:
  r=np.asarray(ref,dtype=np.float64);sig=float(np.sqrt(np.mean(r*r)));out['reference_signal_rms']=sig;out['relative_rms']=out['rms']/sig if sig else None
 return out
def h32(x):return .5*np.abs(np.spacing(np.asarray(x,dtype=np.float32))).astype(np.float64)
def parse_ft(p):
 b=p.read_bytes();version,=struct.unpack_from('<i',b,0);assert version==2,version
 bounds=struct.unpack_from('<12i',b,4);rdx,rdy=struct.unpack_from('<2f',b,52)
 ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme=bounds;ni,nj,nk=ime-ims+1,jme-jms+1,kme-kms+1
 n3=ni*nj*nk;n2=ni*nj;n1=nk;o=60;f={}
 for name in FORDER:
  n=n3 if name in F3 else n2 if name in F2 else n1;a=np.frombuffer(b,dtype='<f4',count=n,offset=o)
  f[name]=a.reshape((nj,nk,ni)) if name in F3 else a.reshape((nj,ni)) if name in F2 else a;o+=4*n
 # V2 appended suffix, in fixed schema order.
 for name in ('rw_tend','ph_tend','t_tend'):
  f[name]=np.frombuffer(b,dtype='<f4',count=n3,offset=o).reshape((nj,nk,ni));o+=4*n3
 for name in ('c1f','c2f'):
  f[name]=np.frombuffer(b,dtype='<f4',count=n1,offset=o);o+=4*n1
 assert o==len(b),(o,len(b))
 return {'bounds':bounds,'rdx':float(rdx),'rdy':float(rdy),'f':f,'sha256':sha(p),'version':version}
def parse_cpp(p):
 b=p.read_bytes();head=struct.unpack_from('<7i',b,0);v,nx,ny,nz,nxu,nyv,nzw=head;assert v==1
 shapes={'u':(ny,nz,nxu),'v':(nyv,nz,nx),'w':(ny,nzw,nx),'ph':(ny,nzw,nx),'t':(ny,nz,nx),'mu':(ny,1,nx)}
 o=28;state={};rhs={}
 for dest in (state,rhs):
  for name,sh in shapes.items():
   n=int(np.prod(sh));dest[name]=np.frombuffer(b,dtype='<f4',count=n,offset=o).reshape(sh);o+=4*n
 assert o==len(b),(o,len(b))
 return {'dims':head[1:],'state':state,'rhs':rhs,'sha256':sha(p)}

def iv32(x):
    x=np.asarray(x,dtype=np.float64)
    h=.5*np.abs(np.spacing(x.astype(np.float32))).astype(np.float64)
    return x-h,x+h
def iv_add(a,b):return (a[0]+b[0],a[1]+b[1])
def iv_sub(a,b):return (a[0]-b[1],a[1]-b[0])
def iv_mul(a,b):
    z=np.stack((a[0]*b[0],a[0]*b[1],a[1]*b[0],a[1]*b[1]),axis=0)
    return np.min(z,axis=0),np.max(z,axis=0)
def iv_div(a,b):
    if np.any(b[0]<=0):raise ValueError('interval denominator is not strictly positive')
    z=np.stack((a[0]/b[0],a[0]/b[1],a[1]/b[0],a[1]/b[1]),axis=0)
    return np.min(z,axis=0),np.max(z,axis=0)
def iv_mean(a,b):return ((a[0]+b[0])*.5,(a[1]+b[1])*.5)
def interval_floor(center, lo, hi, cpp):
    hp=.5*np.abs(np.spacing(np.asarray(cpp,dtype=np.float32))).astype(np.float64)
    radius=np.maximum(np.asarray(center)-lo,hi-np.asarray(center))
    floor=hp+radius
    lower=np.asarray(cpp,dtype=np.float64)-hp-hi
    upper=np.asarray(cpp,dtype=np.float64)+hp-lo
    outside=(lower>0)|(upper<0)
    return {'floor_rms':float(np.sqrt(np.mean(floor**2))),
      'floor_max':float(np.max(floor)), 'cpp_output_half_ulp_rms':float(np.sqrt(np.mean(hp**2))),
      'points_delta_outside_interval':int(np.count_nonzero(outside)),
      'max_abs_delta_over_floor':float(np.max(np.abs(np.asarray(cpp,dtype=np.float64)-center)/np.maximum(floor,1e-300))),
      'scope':'raw-input FP32 storage intervals propagated through source physical transform + CPP output half-ULP; excludes internal arithmetic rounding and is not an acceptance threshold'}

def file_rec(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def main():
 ft=parse_ft(F);cp=parse_cpp(C);f=ft['f'];cs=cp['state'];cr=cp['rhs'];nx,ny,nz,nxu,nyv,nzw=cp['dims'];b=ft['bounds'];ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme=b
 px,py,pz=nx-1,ny-1,nz; i0=ids-ims;j0=jds-jms;k0=kds-kms
 assert (px,py,pz,nzw)==(16,16,16,17)
 sl3=lambda a,jlen,klen,ilen:a[j0:j0+jlen,k0:k0+klen,i0:i0+ilen].astype(np.float64)
 sl2=lambda a,jlen,ilen:a[j0:j0+jlen,i0:i0+ilen].astype(np.float64)
 c1h=f['c1h'][k0:k0+pz].astype(np.float64);c2h=f['c2h'][k0:k0+pz].astype(np.float64)
 c1f=f['c1f'][k0:k0+nzw].astype(np.float64);c2f=f['c2f'][k0:k0+nzw].astype(np.float64)
 dnw=f['dnw'][k0:k0+pz].astype(np.float64)
 # Exact WRF advance_mu_t mass divergence from raw coupled RU/RV; raw mu_tend is forcing only.
 ruf=sl3(f['ru'],py,pz,px+1);rvf=sl3(f['rv'],py+1,pz,px)
 tx=sl2(f['msftx'],py,px);ty=sl2(f['msfty'],py,px)
 dmdt=np.sum(dnw[None,:,None]*(tx*ty)[:,None,:]*(ft['rdx']*(ruf[:,:,1:]-ruf[:,:,:-1])+ft['rdy']*(rvf[1:]-rvf[:-1])),axis=1)
 mu_forcing=sl2(f['mu_tend'],py,px);mu_dot=dmdt+mu_forcing
 # Conservative interval propagation of raw FP32 storage half-ULPs through signed DMDT.
 ruI=iv32(sl3(f['ru'],py,pz,px+1));rvI=iv32(sl3(f['rv'],py+1,pz,px))
 msfxI=iv32(sl2(f['msftx'],py,px));msfyI=iv32(sl2(f['msfty'],py,px))
 dnwI=iv32(f['dnw'][k0:k0+pz]);rdxI=iv32(np.float32(ft['rdx']));rdyI=iv32(np.float32(ft['rdy']))
 duI=iv_sub((ruI[0][:,:,1:],ruI[1][:,:,1:]),(ruI[0][:,:,:-1],ruI[1][:,:,:-1]))
 dvI=iv_sub((rvI[0][1:,:,:],rvI[1][1:,:,:]),(rvI[0][:-1,:,:],rvI[1][:-1,:,:]))
 mapprodI=iv_mul(msfxI,msfyI)
 horizI=iv_add(iv_mul(rdxI,duI),iv_mul(rdyI,dvI))
 colI=iv_mul((dnwI[0][None,:,None],dnwI[1][None,:,None]),(mapprodI[0][:,None,:],mapprodI[1][:,None,:]))
 colI=iv_mul(colI, horizI)
 dmdtI=(colI[0].sum(axis=1),colI[1].sum(axis=1))
 muForcingI=iv32(sl2(f['mu_tend'],py,px));muDotI=iv_add(dmdtI,muForcingI)
 muUI=(np.empty((py,px+1)),np.empty((py,px+1)));muUI[0][:,0],muUI[1][:,0]=iv_mean((muDotI[0][:,-1],muDotI[1][:,-1]),(muDotI[0][:,0],muDotI[1][:,0]))
 for ii in range(1,px):muUI[0][:,ii],muUI[1][:,ii]=iv_mean((muDotI[0][:,ii-1],muDotI[1][:,ii-1]),(muDotI[0][:,ii],muDotI[1][:,ii]))
 muUI[0][:,px]=muUI[0][:,0];muUI[1][:,px]=muUI[1][:,0]
 muVI=(np.empty((py+1,px)),np.empty((py+1,px)));muVI[0][0,:]=muDotI[0][0,:];muVI[1][0,:]=muDotI[1][0,:]
 for jj in range(1,py):muVI[0][jj,:],muVI[1][jj,:]=iv_mean((muDotI[0][jj-1,:],muDotI[1][jj-1,:]),(muDotI[0][jj,:],muDotI[1][jj,:]))
 muVI[0][py,:]=muDotI[0][-1,:];muVI[1][py,:]=muDotI[1][-1,:]
 # State gates on each whole physical stagger; no RHS comparisons if a state differs.
 ft_state={
  'u':sl3(f['u2'],py,pz,px+1),'v':sl3(f['v2'],py+1,pz,px),
  'w':sl3(f['w2'],py,nzw,px),'ph':sl3(f['ph2'],py,nzw,px),
  't':sl3(f['t2'],py,pz,px),'mu':sl2(f['mu2'],py,px)[:,None,:]}
 state_masks={
  'u':(ft_state['u'],cs['u'][:py,:,:px+1]),'v':(ft_state['v'],cs['v'][:py+1,:,:px]),
  'w':(ft_state['w'],cs['w'][:py,:,:px]),'ph':(ft_state['ph'],cs['ph'][:py,:,:px]),
  't':(ft_state['t'],cs['t'][:py,:,:px]),'mu':(ft_state['mu'],cs['mu'][:py,:,:px])}
 state={k:{'exact':bool(np.array_equal(a,z)),'mismatch_count':int(np.count_nonzero(a!=z)),'shape':list(a.shape)} for k,(a,z) in state_masks.items()}
 if not all(v['exact'] for v in state.values()):raise RuntimeError(f'same-call state gate failed {state}')
 # Fortran U/V coupled tendency to physical rates; average total mass tendency to native faces.
 muu=sl2(f['muu'],py,px+1);muv=sl2(f['muv'],py+1,px);msfuy=sl2(f['msfuy'],py,px+1);msfvx=sl2(f['msfvx'],py+1,px)
 mudot_u=np.empty((py,px+1));mudot_u[:,0]=.5*(mu_dot[:,-1]+mu_dot[:,0]);mudot_u[:,1:px]=.5*(mu_dot[:,:-1]+mu_dot[:,1:]);mudot_u[:,px]=mudot_u[:,0]
 mudot_v=np.empty((py+1,px));mudot_v[0]=mu_dot[0];mudot_v[1:py]=.5*(mu_dot[:-1]+mu_dot[1:]);mudot_v[py]=mu_dot[-1]
 Lu=c1h[None,:,None]*muu[:,None,:]+c2h[None,:,None];Lv=c1h[None,:,None]*muv[:,None,:]+c2h[None,:,None]
 uraw=sl3(f['ru_tend'],py,pz,px+1);u=ft_state['u']
 vraw=sl3(f['rv_tend'],py+1,pz,px);v=ft_state['v']
 uft=(msfuy[:,None,:]*uraw-u*c1h[None,:,None]*mudot_u[:,None,:])/Lu
 vft=(msfvx[:,None,:]*vraw-v*c1h[None,:,None]*mudot_v[:,None,:])/Lv
 # W/PH use W interfaces; THM mass levels. Fortran mu_tend is forcing only.
 mut=sl2(f['mut'],py,px);my=sl2(f['msfty'],py,px)
 rw=sl3(f['rw_tend'],py,nzw,px);ph=sl3(f['ph_tend'],py,nzw,px);tt=sl3(f['t_tend'],py,pz,px)
 wft=(my[:,None,:]*rw-ft_state['w']*c1f[None,:,None]*mu_dot[:,None,:])/(c1f[None,:,None]*mut[:,None,:]+c2f[None,:,None])
 phft=my[:,None,:]*ph/(c1f[None,:,None]*mut[:,None,:]+c2f[None,:,None])
 thmft=(my[:,None,:]*tt-ft_state['t']*c1h[None,:,None]*mu_dot[:,None,:])/(c1h[None,:,None]*mut[:,None,:]+c2h[None,:,None])
 muft=mu_dot
 # CPP Full outputs are already state-space rates.
 pairs={
  'u':(uft[:,:,:px],cr['u'][:py,:,:px].astype(np.float64),np.ones((py,pz,px),bool),'m/s^2'),
  'v':(vft[1:py,:,:],cr['v'][1:py,:,:px].astype(np.float64),np.ones((py-1,pz,px),bool),'m/s^2'),
  'w':(wft[:,1:,:],cr['w'][:py,1:nzw,:px].astype(np.float64),np.ones((py,pz,px),bool),'m/s^2'),
  'ph':(phft[:,1:,:],cr['ph'][:py,1:nzw,:px].astype(np.float64),np.ones((py,pz,px),bool),'m^2/s^3'),
  'thm':(thmft,cr['t'][:py,:,:px].astype(np.float64),np.ones((py,pz,px),bool),'K/s'),
  'mu':(muft,cr['mu'][:py,0,:px].astype(np.float64),np.ones((py,px),bool),'Pa/s')}
 # Propagate raw source-array FP32 storage intervals through each physical transform.
 # This is a capture-storage envelope only; internal Fortran arithmetic is explicitly not bounded.
 def converted_interval(name):
  if name=='u':
   coeff0=iv32(sl2(f['msfuy'],py,px+1));coeff=(coeff0[0][:,None,:],coeff0[1][:,None,:]);coef=iv32(f['c1h'][k0:k0+pz]);mface=iv32(sl2(f['muu'],py,px+1));c2=iv32(f['c2h'][k0:k0+pz]);vel=iv32(sl3(f['u2'],py,pz,px+1));raw=iv32(sl3(f['ru_tend'],py,pz,px+1));dot=muUI
   L=iv_add(iv_mul((coef[0][None,:,None],coef[1][None,:,None]),(mface[0][:,None,:],mface[1][:,None,:])),(c2[0][None,:,None],c2[1][None,:,None]))
   co3=(coef[0][None,:,None],coef[1][None,:,None]);dot3=(dot[0][:,None,:],dot[1][:,None,:]);num=iv_sub(iv_mul(coeff,raw),iv_mul(iv_mul(co3,vel),dot3))
   interval=iv_div(num,L);return interval[0][:,:,:px],interval[1][:,:,:px]
  if name=='v':
   coeff0=iv32(sl2(f['msfvx'],py+1,px));coeff=(coeff0[0][:,None,:],coeff0[1][:,None,:]);coef=iv32(f['c1h'][k0:k0+pz]);mface=iv32(sl2(f['muv'],py+1,px));c2=iv32(f['c2h'][k0:k0+pz]);vel=iv32(sl3(f['v2'],py+1,pz,px));raw=iv32(sl3(f['rv_tend'],py+1,pz,px));dot=muVI
   L=iv_add(iv_mul((coef[0][None,:,None],coef[1][None,:,None]),(mface[0][:,None,:],mface[1][:,None,:])),(c2[0][None,:,None],c2[1][None,:,None]))
   co3=(coef[0][None,:,None],coef[1][None,:,None]);dot3=(dot[0][:,None,:],dot[1][:,None,:]);num=iv_sub(iv_mul(coeff,raw),iv_mul(iv_mul(co3,vel),dot3));q=iv_div(num,L);return q[0][1:py,:,:],q[1][1:py,:,:]
  if name in ('w','ph'):
   coeff0=iv32(sl2(f['msfty'],py,px));coeff=(coeff0[0][:,None,:],coeff0[1][:,None,:]);coef=iv32(f['c1f'][k0:k0+nzw]);mass=iv32(sl2(f['mut'],py,px));c2=iv32(f['c2f'][k0:k0+nzw]);L=iv_add(iv_mul((coef[0][None,:,None],coef[1][None,:,None]),(mass[0][:,None,:],mass[1][:,None,:])),(c2[0][None,:,None],c2[1][None,:,None]))
   if name=='w':
    vel=iv32(sl3(f['w2'],py,nzw,px));raw=iv32(sl3(f['rw_tend'],py,nzw,px));co3=(coef[0][None,:,None],coef[1][None,:,None]);dot3=(muDotI[0][:,None,:],muDotI[1][:,None,:]);num=iv_sub(iv_mul(coeff,raw),iv_mul(iv_mul(co3,vel),dot3))
   else:
    raw=iv32(sl3(f['ph_tend'],py,nzw,px));num=iv_mul(coeff,raw)
   q=iv_div(num,L);return q[0][:,1:,:],q[1][:,1:,:]
  if name=='thm':
   coeff0=iv32(sl2(f['msfty'],py,px));coeff=(coeff0[0][:,None,:],coeff0[1][:,None,:]);coef=iv32(f['c1h'][k0:k0+pz]);mass=iv32(sl2(f['mut'],py,px));c2=iv32(f['c2h'][k0:k0+pz]);L=iv_add(iv_mul((coef[0][None,:,None],coef[1][None,:,None]),(mass[0][:,None,:],mass[1][:,None,:])),(c2[0][None,:,None],c2[1][None,:,None]))
   vel=iv32(sl3(f['t2'],py,pz,px));raw=iv32(sl3(f['t_tend'],py,pz,px));co3=(coef[0][None,:,None],coef[1][None,:,None]);dot3=(muDotI[0][:,None,:],muDotI[1][:,None,:]);num=iv_sub(iv_mul(coeff,raw),iv_mul(iv_mul(co3,vel),dot3));return iv_div(num,L)
  if name=='mu':return muDotI
  raise KeyError(name)
 storage_floor={}
 for name,(ftrate,cprate,mask,units) in pairs.items():
  if name.endswith('_bottom') or name.endswith('_top'):continue
  flo,fhi=converted_interval(name); storage_floor[name]=interval_floor(ftrate,flo,fhi,cprate)
 # Add separately reportable PH boundary planes and W boundary planes.
 pairs['ph_bottom']=(phft[:,0:1,:],cr['ph'][:py,0:1,:px].astype(np.float64),np.ones((py,1,px),bool),'m^2/s^3')
 pairs['ph_top']=(phft[:,-1:,:],cr['ph'][:py,nzw-1:nzw,:px].astype(np.float64),np.ones((py,1,px),bool),'m^2/s^3')
 pairs['w_bottom']=(wft[:,0:1,:],cr['w'][:py,0:1,:px].astype(np.float64),np.ones((py,1,px),bool),'m/s^2')
 pairs['w_top']=(wft[:,-1:,:],cr['w'][:py,nzw-1:nzw,:px].astype(np.float64),np.ones((py,1,px),bool),'m/s^2')
 comps={}; arrs={}
 for name,(ftrate,cprate,mask,units) in pairs.items():
  delta=cprate-ftrate; ref=ftrate
  sig=float(np.sqrt(np.mean(ref[mask]**2)));rms=float(np.sqrt(np.mean(delta[mask]**2)))
  # Output-storage-only floor after the same physical transform, not an internal-arithmetic bound.
  floor=.5*np.abs(np.spacing(cprate.astype(np.float32))).astype(np.float64)+.5*np.abs(np.spacing(ftrate.astype(np.float32))).astype(np.float64)
  comps[name]={'owners':int(mask.sum()),'units':units,'rms':rms,'max_abs':float(np.max(np.abs(delta[mask]))),
   'mean_signed':float(np.mean(delta[mask])),'signal_rms':sig,'relative_rms':rms/sig if sig else None,
   'combined_half_ulp_if_both_normalized_rates_are_stored_as_float32_rms':float(np.sqrt(np.mean(floor[mask]**2))),
   'points_outside_that_hypothetical_output_storage_interval':int(np.count_nonzero(np.abs(delta[mask])>floor[mask]))}
  arrs[f'ft_{name}']=ftrate;arrs[f'cpp_{name}']=cprate;arrs[f'delta_{name}']=delta;arrs[f'mask_{name}']=mask
 arrs['mu_dot_total']=mu_dot;arrs['dmdt']=dmdt;arrs['mu_tend_forcing']=mu_forcing
 np.savez_compressed('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/red_six_rhs_raw_audit_arrays.npz',**arrs)
 runs=json.loads(RUN.read_text())
 result={'schema':'pr301-red-independent-raw-six-rhs-audit-v1','scope':'Independent binary parser and physical transform from the Fortran V2 Full observer and C++ Full output; no Green analyzer callback. All differences in float64 after loading raw bytes. Output-storage halfwidths are not internal-error bounds or a pass threshold.',
  'same_call_state_gate':state,'all_six_state_gates_pass':all(x['exact'] for x in state.values()),
  'input_sha256':runs['input_sha256'],'executable_sha256':runs['build_gate']['exe_sha256'],'fortran_solve_em_source_sha256':runs['build_gate']['source_pins']['dyn_em/solve_em.F'],
  'top_lid':False,'physical_shape_jki':[py,pz,px],'owner_counts':{k:v['owners'] for k,v in comps.items()},
  'metrics':comps,'propagated_fp32_raw_operand_storage_envelopes':storage_floor,'mu_dot_total_rms_pa_s':float(np.sqrt(np.mean(mu_dot**2))),
  'mu_dot_components':{'dmdt_rms_pa_s':float(np.sqrt(np.mean(dmdt**2))),'forcing_mu_tend_rms_pa_s':float(np.sqrt(np.mean(mu_forcing**2)))},
  'mask_contract':{'u':'unique periodic owners i0-15; west seam i0 retained, duplicate closing i16 omitted','v':'internal symmetric-Y rows 1-15','w':'vertical interfaces 1-16; bottom excluded, top included for top_lid=false','ph':'vertical interfaces 1-16; bottom excluded, top included; boundary planes reported separately','thm':'all mass-level cells','mu':'all mass cells'},
  'formula_contract':{'mu_dot':'signed vertically integrated RU/RV mass-flux divergence plus forcing-only mu_tend','ft_w':'(MSFTY*rw_tend - w*C1F*mu_dot)/(C1F*MUT+C2F)','ft_ph':'MSFTY*ph_tend/(C1F*MUT+C2F), no PH*mu_dot product term','ft_thm':'(MSFTY*t_tend - t*C1H*mu_dot)/(C1H*MUT+C2H)','cpp':'compared as already-physical state-space RHS output','output_storage_floor':'hypothetical combined half-ULP if both normalized rate arrays were stored as FP32; distinct from the propagated raw-operand storage envelope and does not bound internal arithmetic'},
  'raw_paths':{'fortran':file_rec(F),'cpp':file_rec(C),'receipt':file_rec(RUN)},
  'independent_array_npz':str(NPZ),'independent_array_npz_sha256':sha(NPZ)}
 OUT.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
