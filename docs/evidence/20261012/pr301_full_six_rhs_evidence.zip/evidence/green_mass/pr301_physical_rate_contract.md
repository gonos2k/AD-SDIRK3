# PR301 physical-rate conversion contract

Scope: source-derived normalization contract for the post-`rk_addtend_dry` Fortran fields versus C++ Full physical RHS. No model run or code edit was performed for this note.

## Mass tendency distinction

The captured Fortran `mu_tend` is the explicit forcing contribution, not the total column mass rate. Use

`mu_dot_total = DMDT + mu_tend`

where `DMDT` is the signed vertical-integrated mass-flux divergence formed in `advance_mu_t` (`module_small_step_em.F`, around lines 1069-1104; accumulation `DMDT += dnw*DVDXI`). `rk_addtend_dry` adds `mu_tendf` into `mu_tend` without adding DMDT (`module_em.F:1180-1187`). The Full snapshot already records `msfty`; the separate DMDT/total-mass-rate field is needed to evaluate product rules.

## Physical conversions

For fixed map factors and hybrid coefficients, with rates at the same observer state:

- U: `Q_u=(c1h*muu+c2h)*u/msfuy`; `udot=(msfuy*ru_tend-c1h*u*muu_dot)/(c1h*muu+c2h)`. `muu_dot` is the x-face average of `mu_dot_total`, using `calc_mu_uv`'s periodic endpoint convention. Units m/s^2.
- V: `Q_v=(c1h*muv+c2h)*v/msfvx`; `vdot=(msfvx*rv_tend-c1h*v*muv_dot)/(c1h*muv+c2h)`. `muv_dot` is the y-face average of `mu_dot_total`, using `calc_mu_uv`'s periodic endpoint convention. Units m/s^2.
- W: `Q_w=(c1f*mut+c2f)*w/msfty`; `wdot=(msfty*rw_tend-c1f*w*mu_dot_total)/(c1f*mut+c2f)`. No horizontal interpolation is needed; broadcast mass-centered `mu_dot_total` over vertical faces. Units m/s^2.
- THM/t: `tdot=(msfty*t_tend-c1h*t*mu_dot_total)/(c1h*mut+c2h)`. The `t_tend` assembly already includes `(c1h*mut+c2h)*h_diabatic/msfty`, so its conversion retains the heating term. Units K/s.
- PH: `phdot=msfty*ph_tend/(c1f*mut+c2f)`. No `phi*mu_dot` product-rule term: PH is geopotential, not a mass-coupled prognostic scalar. Units m^2/s^3.
- MU: physical `mu_dot_total` is `DMDT+mu_tend`, units Pa/s.

`couple_momentum` (`module_big_step_utilities_em.F:329-397`) establishes the U/V/W conserved variables and their map factors. `rk_addtend_dry` (`module_em.F:1136-1187`) establishes the post-add tendency map normalization and shows MU forcing-only assembly. `advance_mu_t` (`module_small_step_em.F:1069-1112`) establishes the separate DMDT contribution. The scalar and PH small-step equations (`module_small_step_em.F:1296-1304,1364-1368`) establish the mass normalization. C++ Full output is already in physical state-rate units; convert the Fortran side only.

## Ownership cautions

W's bottom face is kinematic and is not an independent tendency owner; when `top_lid=false`, the top face is dynamic and included, and when true it is fixed and excluded. In 16x16x17 W storage with `top_lid=false`, this gives 4096 owners. PH is also vertical-interface-shaped, but this audit did not establish a separate fixed-face mask at the observer; use the solver's actual projection/ownership mask rather than assuming W's mask. Likewise preserve periodic-X U aliases and symmetric-Y V-normal wall constraints; do not count duplicate aliases as unique owners.

## Remaining capture requirement

The current FT Full schema has `w`, `mu_tend` (forcing only), `mut`, and `msfty`, but lacks `rw_tend` and `DMDT`/`mu_dot_total`; coefficient vectors are also required for U/V/W/THM/PH normalization (`c1h`, `c2h`, `c1f`, `c2f`). The derived total mass rate must be captured or reconstructed from the exact same-call flux-divergence operands. Do not substitute raw `mu_tend` for total `mu_dot`.
