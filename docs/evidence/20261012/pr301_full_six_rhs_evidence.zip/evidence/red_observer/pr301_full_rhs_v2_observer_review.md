# PR301 Red observer review — source-only V2 serialization

Local timestamp: 2026-10-12 17:35:46 JST (+0900)

Target: `/private/tmp/pr301-full-six-rhs-20261012`, base `21398d601c70d4328d74393e318bc29dd98bc367`. No build or native run was performed in this review.

## Source verdict

The only pending source diff is `dyn_em/solve_em.F`; its SHA-256 is `888b81bcb21791fc89e08d739162f7cedfbff8679cba5453010257a3f31a9be8`. `git diff --check` is clean. The edit extends the existing opt-in `wrf_full_rhs_snapshot.bin` from version 1 to version 2 while keeping its 23-array prefix unchanged, then appending `rw_tend,ph_tend,t_tend,c1f,c2f` in the documented order. The source write list and `full_rhs_snapshot_v2_schema.json` agree on field order, element type (default REAL32), Fortran i-fastest/k/j array layout, and extents. Given the recorded full-storage dimensions `ni=27,nj=27,nk=17`, expected V2 size is 627,340 bytes (60-byte header, V1 payload 478,488 bytes, V2 append 148,852 bytes); this is a source-derived expected size, not yet a validated run artifact.

The observer remains inside the existing `WRF_PARITY_RK_TEND_DUMP=1`, first-timestep/RK1, single-rank/single-tile, dry, periodic-X/symmetric-Y guard. It performs serialization only: no new RHS/operator call, input mutation, tendency scaling, branch/configuration change, or C++ modification appears in the diff. Capture is colocated with the current Full snapshot after `rk_addtend_dry` and conditional specified/perturbation tendency updates, before later physical-boundary work and the acoustic step. That point is appropriate for the requested assembled cold first-call RHS; it must not be described as a post-boundary or post-acoustic tendency.

The old `wrf_rk_tend_dump.bin` observer at `solve_em.F:1207` is before `rk_addtend_dry` and therefore cannot substitute for assembled `RW/PH/T` terms. The new V2 observer correctly takes those additional channels from the later Full snapshot point. C++ remains untouched; its existing Full snapshot carries all six RHS blocks. Offline conversion will still need field-specific source equations, masks, and units, particularly the `rw_tend` product-rule conversion using `c1f/c2f` and total `mu_dot`, and the PH/THM formulas. These are not inferred from the file format alone.

## Current limit

No V2 binary, rebuilt executable, or capture receipt is present yet, so actual byte count/header, default-off runtime behavior, source60 state gates, six-field call-to-Full identity, or numerical comparison are not validated by this review. The source-only readiness verdict is **pass with artifact validation pending**. After the gated build/capture, verify V2 length and raw parse, bind U/V/W/PH/THM/MU call states to the preserve-W source60 frame, tie each call state to same-run Full state, and compare all six tendencies only after their documented physical-rate conversions. Do not run or rebuild as part of this Red review.
