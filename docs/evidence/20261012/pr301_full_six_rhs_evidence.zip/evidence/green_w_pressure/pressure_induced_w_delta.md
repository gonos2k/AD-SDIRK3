# PR301 pressure-only W delta

This offline calculation applies the existing Fortran `pg_buoy_w` pressure term to each solver's captured pressure field while holding mass, coefficients, and vertical geometry fixed. It uses the completed PR301 V2 pair only; no model call or production source change was made.

For the paired run, the input hash is `fc37c8c0c8be8053a16e0d3424609d496f4a023c6c17ee3a06371970639d14df`, the executable hash is `78b3c01abcfc3b3e8286930e62198855891ff50c3bd1dd4026cd6fef10fd43d7`, source head `2f32859d545bf5dc3e287653d8ebb1cb504df32c`, `rk_step=1`, `non_hydrostatic=1`, and `top_lid=0`. The six PGF-call prognostic fields equal their corresponding Full-observer fields within each solver and equal across FT/C++; all 4096 owner points use the same physical state. Corrected-input `QVAPOR` is identically zero; `calc_cq` (`dyn_em/module_big_step_utilities_em.F:787-906`) therefore gives `cqw=0` for this pressure term.

`pg_buoy_w` (`module_big_step_utilities_em.F:2423-2503`) gives, for dry air,

- interior W levels, Fortran `k=2..kde-1`: `rw_pg=(g/msfty)*rdn(k)*(p(k)-p(k-1))`;
- dynamic top, Fortran `k=kde`: `rw_pg=(g/msfty)*(-2*rdnw(kde-1)*p(kde-1))`.

The physical-rate conversion is `wdot_pg=msfty*rw_pg/(c1f*mut+c2f)`, so `msfty` cancels. I evaluated the exact same formula for captured FT `p` and C++ `p_prime`, using common captured FT `mut,c1f,c2f,msfty`, corrected-input `RDN/RDNW`, and `g=9.81` from `share/module_model_constants.f90:17`. The reported sign is C++ minus Fortran. Owner mask excludes bottom W and includes dynamic top: 3840 interior plus 256 top values.

The pressure-only delta reproduces the full six-RHS W delta to near roundoff:

| Quantity | RMS (m/s²) |
|---|---:|
| Full RHS C++ minus Fortran | `1.2009458686783969e-5` |
| Pressure-only C++ minus Fortran | `1.2009458475980013e-5` |
| Full minus pressure-only residual | `4.306676610593559e-11` |

Cosine similarity is `0.9999999999935703`, the least-squares projection is `1.0000000175467307`, and residual RMS is `3.5860705489856263e-6` of the full-delta RMS. Interior and top subsets match at the same scale. Thus the pressure-operand difference under the native operator accounts for the observed W RHS difference; this result does not attribute why the captured `p` and `p_prime` values differ.

The exact source pins, input/run/artifact hashes, state gates, formulas, per-level metrics, and raw vectors are in `pressure_induced_w_delta_analysis.json` and `pressure_induced_w_delta_arrays.npz`. The rerunnable offline calculation is `analyze_pressure_induced_w.py`.
