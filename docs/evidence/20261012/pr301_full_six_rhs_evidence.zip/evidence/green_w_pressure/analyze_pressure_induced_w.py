#!/usr/bin/env python3
"""Bounded postprocess: apply native dry pg_buoy_w pressure term to paired p fields."""
from __future__ import annotations
import hashlib, importlib.util, json, sys
from pathlib import Path
import numpy as np
from netCDF4 import Dataset

E=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012')
ROOT=Path('/private/tmp/pr301-full-six-rhs-20261012')
CAP=E/'green_execution/pr301_v2/captures'
FT=CAP/'pr301_v2_fortran_rk3_h15'
CPP=CAP/'pr301_v2_cpp_ark3_h15'
INPUT=FT/'wrfinput_d01'
OUT=E/'green_w_pressure'

def loadmod(name,path):
    s=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(s); sys.modules[name]=m; s.loader.exec_module(m); return m
AS=loadmod('asnap',E/'green_analysis/analyze_full_six_rhs.py')
PG=loadmod('pgctx',E/'portable_dependencies/analyze_pgf_capture_context.py')

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def stats(x):
    x=np.asarray(x,dtype=np.float64).ravel()
    return {'count':int(x.size),'finite':bool(np.isfinite(x).all()),'rms':float(np.sqrt(np.mean(x*x))),
            'max_abs':float(np.max(np.abs(x))),'mean':float(np.mean(x))}
def cosine(a,b):
    a=np.asarray(a,dtype=np.float64).ravel(); b=np.asarray(b,dtype=np.float64).ravel()
    den=np.linalg.norm(a)*np.linalg.norm(b)
    return float(np.dot(a,b)/den) if den else None

runs_path=E/'green_execution/pr301_v2/pr301_v2_runs.json'
runs=json.loads(runs_path.read_text())
if runs.get('status')!='completed' or runs.get('native_calls_completed')!=2:
    raise SystemExit('FAIL CLOSED: V2 run receipt is not exactly the completed paired call')
run_by_label={r['label']:r for r in runs['runs']}
ft_run=run_by_label['pr301_v2_fortran_rk3_h15']; cpp_run=run_by_label['pr301_v2_cpp_ark3_h15']
if ft_run['input_sha256']!=cpp_run['input_sha256'] or ft_run['input_sha256']!=sha(INPUT):
    raise SystemExit('FAIL CLOSED: paired run inputs differ from corrected input')
ftfull_meta,ftfull=AS.read_fortran(FT/'wrf_full_rhs_snapshot.bin')
cppfull_meta,cppfull_state,cpprhs=AS.read_cpp(CPP/'port_full_rhs_snapshot.bin')
dims=tuple(cppfull_meta['dims_nx_ny_nz_nxu_nyv_nzw'])
ftpg_meta,ftpg=PG.read_ft_pgf(FT/'wrf_u_pgf_snapshot.bin')
cpppg_meta,cpppg_state,cpppg_outputs=PG.read_cpp_pgf(CPP/'port_u_pgf_snapshot.bin')
cppop_meta,cppop=PG.read_cpp_operands(CPP/'port_u_pgf_operands_snapshot.bin')
ftpg_state=AS.logical_fortran_state({'bounds':ftpg_meta['bounds_dict']},
    {'u2':ftpg['u'],'v2':ftpg['v'],'w2':ftpg['w'],'ph2':ftpg['ph'],'t2':ftpg['t'],'mu2':ftpg['mu']},dims)
ftfull_state=AS.logical_fortran_state(ftfull_meta,ftfull,dims)
cppfull_state_only=cppfull_state
state_gates={}
for n in AS.CPP_BLOCKS:
    state_gates[n]={
      'ft_pgf_equals_ft_full':bool(np.array_equal(ftpg_state[n],ftfull_state[n])),
      'cpp_pgf_equals_cpp_full':bool(np.array_equal(cpppg_state[n],cppfull_state[n])),
      'ft_pgf_equals_cpp_pgf':bool(np.array_equal(ftpg_state[n],cpppg_state[n]))}
state_pass=all(all(v.values()) for v in state_gates.values())
if not state_pass: raise SystemExit('FAIL CLOSED: PGF/Full paired state equality gate failed')
if ftpg_meta['rk_step']!=1 or ftpg_meta['nonhydrostatic']!=1 or ftpg_meta['top_lid']!=0:
    raise SystemExit(f'FAIL CLOSED: unsupported Fortran PGF context {ftpg_meta}')

b=ftpg_meta['bounds_dict']; ids,jds,kms=b['ids'],b['jds'],b['kms']
# physical unique mass columns in packed periodic X / symmetric Y case
ny=16; nx=16; nzw=17
j0=jds-b['jms']; i0=ids-b['ims']; k0=1-b['kms']
p_ft=np.asarray(ftpg['p'][j0:j0+ny,k0:k0+16,i0:i0+nx],dtype=np.float64)
p_cpp=np.asarray(cppop['p_prime'][:ny,:,:nx],dtype=np.float64)
if p_ft.shape!=(ny,16,nx) or p_cpp.shape!=(ny,16,nx): raise SystemExit(f'p shapes mismatch: {p_ft.shape}, {p_cpp.shape}')

# Full snapshot fields use [j,k,i], coefficients use k; choose same physical mass columns.
mut=np.asarray(ftfull['mut'][j0:j0+ny,i0:i0+nx],dtype=np.float64)
c1f=np.asarray(ftfull['c1f'],dtype=np.float64)[:nzw]
c2f=np.asarray(ftfull['c2f'],dtype=np.float64)[:nzw]
msfty=np.asarray(ftfull['msfty'][j0:j0+ny,i0:i0+nx],dtype=np.float64)
if c1f.shape!=(nzw,) or c2f.shape!=(nzw,) or mut.shape!=(ny,nx): raise SystemExit('mass/coeff extents fail')

# Use corrected common input for exact vertical geometry, and verify coefficients match capture.
with Dataset(INPUT) as ds:
    rdn=np.asarray(ds.variables['RDN'][0],dtype=np.float64)
    rdnw=np.asarray(ds.variables['RDNW'][0],dtype=np.float64)
    c1f_input=np.asarray(ds.variables['C1F'][0],dtype=np.float64)
    c2f_input=np.asarray(ds.variables['C2F'][0],dtype=np.float64)
    qv=np.asarray(ds.variables['QVAPOR'][0],dtype=np.float64)
    mu_input=np.asarray(ds.variables['MU'][0],dtype=np.float64)
    mub=np.asarray(ds.variables['MUB'][0],dtype=np.float64)
if np.array_equal(c1f,c1f_input) is False or np.array_equal(c2f,c2f_input) is False:
    raise SystemExit('FAIL CLOSED: captured c1f/c2f differ from corrected input')
if np.count_nonzero(qv)!=0: raise SystemExit('FAIL CLOSED: QVAPOR is nonzero; dry cqw=0 formula unsupported')
# Ensure current captured state/mass is the corrected input state and mut is MU+MUB.
ftmu=np.asarray(ftfull['mu2'][j0:j0+ny,i0:i0+nx],dtype=np.float64)
if not np.array_equal(ftmu,mu_input[:ny,:nx]): raise SystemExit('FAIL CLOSED: captured MU differs from corrected input')
mut_sum_err=mut-(mu_input[:ny,:nx]+mub[:ny,:nx])
if not np.allclose(mut,mu_input[:ny,:nx]+mub[:ny,:nx],rtol=0,atol=5e-3):
    raise SystemExit('FAIL CLOSED: captured mut != corrected input MU+MUB within f32 tolerance')

# Fortran module_big_step_utilities_em.F: pg_buoy_w, cqw=0:
# k=2..kde-1: rw_pg=g/msfty * rdn(k)*(p(k)-p(k-1));
# k=kde: rw_pg=g/msfty * (-2*rdnw(k-1)*p(k-1));
# Apply both pressure operands with the exact same mass, coefficients and geometry.
g=9.81

def native_pressure_rate(p):
    grad=np.zeros((ny,nzw,nx),dtype=np.float64)
    for kk in range(1,nzw-1): # Fortran k=2..kde-1
        grad[:,kk,:]=rdn[kk]*(p[:,kk,:]-p[:,kk-1,:])
    grad[:,-1,:]=-2.0*rdnw[-1]*p[:,-1,:]
    level_mass=c1f[None,:,None]*mut[:,None,:]+c2f[None,:,None]
    # msfty cancels between coupled rw_tend and physical conversion.
    return g*grad/level_mass

ft_pg=native_pressure_rate(p_ft)
cpp_pg=native_pressure_rate(p_cpp)
pred=cpp_pg-ft_pg # CPP-minus-FT sign matches full-RHS delta below
npz=np.load(E/'green_analysis/pr301_six_rhs_physical_arrays.npz')
full_delta=np.asarray(npz['delta_w_cpp_minus_fortran'],dtype=np.float64)
mask=np.asarray(npz['owner_mask_w'],dtype=bool)
if full_delta.shape!=(ny,nzw,nx) or mask.shape!=full_delta.shape: raise SystemExit('FAIL CLOSED: W delta shape mismatch')
# For top_lid=false physical owner policy excludes only fixed bottom k=1 and includes dynamic top.
expected=np.zeros_like(mask); expected[:,1:,:]=True
if not np.array_equal(mask,expected): raise SystemExit('FAIL CLOSED: unexpected W owner mask')
obs=full_delta[mask]; pressure=pred[mask]; remainder=obs-pressure
projection=float(np.dot(obs,pressure)/np.dot(pressure,pressure)) if np.dot(pressure,pressure) else None
report={
 'schema':'pr301-native-pressure-induced-w-delta-v1','status':'passed',
 'scope':'Offline pressure-only attribution using native Fortran pg_buoy_w formula on paired captured p fields. Does not rerun either RHS and does not infer EOS/pressure-generation cause.',
 'pair':{'runs_receipt':str(runs_path),'runs_receipt_sha256':sha(runs_path),'input_sha256':sha(INPUT),'same_corrected_input_ft_cpp':True,'target_head':runs['target_head'],'executable_sha256':runs['build_gate']['exe_sha256'],'rk_step':ftpg_meta['rk_step'],'top_lid':ftpg_meta['top_lid'],'nonhydrostatic':ftpg_meta['nonhydrostatic'],'QVAPOR_all_zero':True,'cqw_zero_source':'module_big_step_utilities_em.F:787-906 calc_cq sums QVAPOR species; QVAPOR input is identically zero'},
 'state_gate':{'all_six_fields_pgfcalls_equal_full_within_each_solver_and_ft_cpp':state_pass,'fields':state_gates},
 'inputs':{
  'fortran_p':{'sha256':sha(FT/'wrf_u_pgf_snapshot.bin'),'field':'p','shape':list(p_ft.shape),'stats':stats(p_ft)},
  'cpp_p_prime':{'sha256':sha(CPP/'port_u_pgf_operands_snapshot.bin'),'field':'p_prime','shape':list(p_cpp.shape),'stats':stats(p_cpp)},
  'p_operand_delta_cpp_minus_fortran':stats(p_cpp-p_ft),
  'rdn':{'source':'corrected same-call wrfinput_d01','sha256':sha(INPUT),'shape':list(rdn.shape),'stats':stats(rdn)},
  'rdnw':{'source':'corrected same-call wrfinput_d01','sha256':sha(INPUT),'shape':list(rdnw.shape),'stats':stats(rdnw)},
  'mut_c1f_c2f_msfty':'same FT Full observer capture; c1f/c2f exactly equal corrected input',
  'captured_mut_minus_input_mu_plus_mub':stats(mut_sum_err)},
 'operator':{
  'source':'dyn_em/module_big_step_utilities_em.F:2423-2503 pg_buoy_w; dry cqw=0',
  'interior':'rw_pg=(g/msfty)*rdn(k)*(p(k)-p(k-1)), Fortran k=2..kde-1',
  'top':'rw_pg=(g/msfty)*(-2*rdnw(kde-1)*p(kde-1)), Fortran k=kde',
  'physical_conversion':'wdot_pg=msfty*rw_pg/(c1f*mut+c2f); msfty cancels',
  'g':g,'units':'m/s^2','delta_sign':'CPP minus Fortran'},
 'comparison':{
  'owner_mask':'physical unique W columns; exclude bottom fixed interface, include dynamic top (top_lid=false)',
  'owner_count':int(mask.sum()),
  'full_delta_cpp_minus_fortran':stats(obs),
  'pressure_induced_delta_cpp_minus_fortran':stats(pressure),
  'remaining_full_minus_pressure':stats(remainder),
  'cosine_full_vs_pressure':cosine(obs,pressure),
  'least_squares_projection_full_onto_pressure':projection,
  'residual_fraction_rms':float(np.sqrt(np.mean(remainder**2))/np.sqrt(np.mean(obs**2))),
  'max_abs_residual_index_jki':[int(v) for v in np.argwhere(mask)[int(np.argmax(np.abs(remainder)))]],
  'interior_k2_to_kde_minus1':{'full_delta':stats(full_delta[:,1:-1,:]),'pressure_delta':stats(pred[:,1:-1,:])},
  'top_dynamic_kde':{'full_delta':stats(full_delta[:,-1,:]),'pressure_delta':stats(pred[:,-1,:])},
 },
 'source_pins':{
  rel:sha(ROOT/rel) for rel in ['dyn_em/module_big_step_utilities_em.F','dyn_em/solve_em.F','share/module_model_constants.f90']
 },
 'analysis_script':{'path':str(OUT/'analyze_pressure_induced_w.py'),'sha256':sha(OUT/'analyze_pressure_induced_w.py')},
 'receipts':{
  'full_analysis_json':{'path':str(E/'green_analysis/pr301_six_rhs_analysis.json'),'sha256':sha(E/'green_analysis/pr301_six_rhs_analysis.json')},
  'physical_rhs_npz':{'path':str(E/'green_analysis/pr301_six_rhs_physical_arrays.npz'),'sha256':sha(E/'green_analysis/pr301_six_rhs_physical_arrays.npz')},
  'fortran_full':{'path':str(FT/'wrf_full_rhs_snapshot.bin'),'sha256':sha(FT/'wrf_full_rhs_snapshot.bin')},
  'cpp_full':{'path':str(CPP/'port_full_rhs_snapshot.bin'),'sha256':sha(CPP/'port_full_rhs_snapshot.bin')},
  'fortran_pgf':{'path':str(FT/'wrf_u_pgf_snapshot.bin'),'sha256':sha(FT/'wrf_u_pgf_snapshot.bin')},
  'cpp_pgf_operands':{'path':str(CPP/'port_u_pgf_operands_snapshot.bin'),'sha256':sha(CPP/'port_u_pgf_operands_snapshot.bin')},
  'input':{'path':str(INPUT),'sha256':sha(INPUT)}}
}
np.savez_compressed(OUT/'pressure_induced_w_delta_arrays.npz',
    p_fortran=p_ft,p_cpp=p_cpp,p_delta_cpp_minus_fortran=p_cpp-p_ft,
    pressure_delta_cpp_minus_fortran=pred,full_delta_cpp_minus_fortran=full_delta,
    remaining_full_minus_pressure=full_delta-pred,owner_mask=mask,
    rdn=rdn,rdnw=rdnw,mut=mut,c1f=c1f,c2f=c2f,msfty=msfty)
(OUT/'pressure_induced_w_delta_analysis.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':report['status'],'full_rms':report['comparison']['full_delta_cpp_minus_fortran']['rms'],'pressure_rms':report['comparison']['pressure_induced_delta_cpp_minus_fortran']['rms'],'remaining_rms':report['comparison']['remaining_full_minus_pressure']['rms'],'cosine':report['comparison']['cosine_full_vs_pressure'],'projection':projection},sort_keys=True))
