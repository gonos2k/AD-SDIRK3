# PR301 pre-edit graph navigation

Target `21398d601c70d4328d74393e318bc29dd98bc367` (tree `13db9ca14561a7e0dfb5d55279d37f87fb312524`) reuses the verified 76-source graph at `c26a0f9a86d4ca83642d2cf82326399f8c79fe8a`. All 76 bound hashes match the target. Key Fortran/C++ hashes are in `pr301_graph_preedit_receipt.json`. No graph refresh was needed.

Manual call/order trace: `solve_em.F:1159` calls `rk_tendency` (`module_em.F`), whose existing U-PGF capture is before full-RHS assembly. `solve_em.F:1279` then calls `rk_addtend_dry` (`module_em.F`), combining physics forward-step and RK tendencies for momentum, geopotential, theta, and mu with staggered metric coupling. The existing Fortran Full snapshot at `solve_em.F:1379-1411` is after that assembly and optional `spec_bdy_dry`; it currently serializes six states, RU/RV/MU tendencies, and mass/metric operands, but omits RW/PH/T assembled tendencies. Later `set_physical_bc3d` updates occur after the snapshot, so the observer is not post-final-physical-BC.

The C++ `port_full_rhs_snapshot.bin` observer already writes the six packed state fields and six Full RHS fields, gated on the first debug split check, env value exactly `1`, one full-domain process/tile, and zero physical forcing. The Fortran and C++ serializers use different layouts and should be interpreted through their declared schemas.

Graph edges for WRF `.F` files are manual navigation: Graphify does not extract Fortran call/dataflow or generated preprocessing includes. This is not proof of numerical parity. No files were edited and no build/test/model run was performed.
