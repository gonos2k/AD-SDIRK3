# PR301 Full-RHS v2 post-edit navigation

Source-v2 is committed as `2f32859d545bf5dc3e287653d8ebb1cb504df32c`; the source hash is unchanged from the recorded post-edit snapshot.

Target `2f32859d545bf5dc3e287653d8ebb1cb504df32c` (tree `00608008cd1f159ffb0049e2a40d1af28aafe412`), source `dyn_em/solve_em.F` SHA-256 `888b81bcb21791fc89e08d739162f7cedfbff8679cba5453010257a3f31a9be8`. The 76-source cached graph is reused; the other 75 hashes match and no AST was generated for Fortran.

The existing capture at `solve_em.F:1379-1414` remains after `rk_addtend_dry` and conditional specified/perturbation tendency processing, and before later physical-boundary updates and the acoustic step. Version 2 preserves the existing v1 prefix and appends the assembled coupled `rw_tend`, `ph_tend`, `t_tend` arrays followed by `c1f`, `c2f`. It retains the six input state fields and the existing mass/metric context. It does not move the capture after the later `set_physical_bc3d` calls.

This is manual source navigation, since Graphify does not extract WRF `.F` call/dataflow. The graph was not rebuilt and no build or model run was performed. Receipt: `pr301_full_rhs_v2_postedit_receipt.json`.
