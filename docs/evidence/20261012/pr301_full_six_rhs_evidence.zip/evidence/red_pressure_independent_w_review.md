# Independent W pressure attribution review

**Scope.** Read-only validation of the pressure contribution to the PR301 same-call W-rate difference. I independently rebuilt the pressure increment from the captured `P` operands and the native `pg_buoy_w` vertical operator, then compared its owner slice against W rates parsed by the independent raw Full-RHS audit. This does not regenerate pressure/EOS operands and does not test production or full-physics parity.

## Result

Fortran and CPP captured `P` differ by RMS 0.00554436 Pa (max 0.02965762 Pa). Applying the source pressure operator gives a CPP-minus-Fortran physical W-rate delta with RMS 1.2009458476e-5 m/s² and max 4.0123177090e-5. The independently parsed full W-rate delta is RMS 1.2009458687e-5 and max 4.0123204518e-5. Their residual is RMS 4.30668e-11 m/s², max 4.55632e-10; cosine is 0.99999999999357 and the residual is 3.5861e-6 of the full-delta RMS. On this captured case, the observed W difference is therefore accounted for by the pressure-operand difference to the precision of the captured calculations.

The regional check includes 3,840 interior W owners (k=1–15) and all 256 dynamic-top owners (k=16; `top_lid=false`); the fixed bottom (256 cells) is excluded. Interior pressure/full RMS are 1.2127118192e-5 / 1.2127118425e-5 m/s². Dynamic-top RMS are 1.0081098720e-5 / 1.0081098537e-5 m/s². The owner mapping keeps the top and omits only the fixed bottom.

## Operator and context

The source `module_big_step_utilities_em.F` `pg_buoy_w` computes the interior pressure term as `(g/MSFTY)*RDN(k)*(P(k)-P(k-1))`; its dynamic-top term is `(g/MSFTY)*(-2*RDNW(kde-1)*P(kde-1))`. The W physical-rate conversion multiplies by `MSFTY` and divides by `C1F*MUT+C2F`, so the map cancels. For this exact-state CPP-minus-Fortran pressure delta, the mass-buoyancy term cancels. Here `C1F/C2F` equal the corrected input coefficients and all layer denominators are positive.

Both PGF contexts report native nonhydrostatic mode true; the Fortran capture is RK step 1, `n_moist=2`, `top_lid=false`. Corrected input SHA-256 is `fc37c8c0c8be8053a16e0d3424609d496f4a023c6c17ee3a06371970639d14df`, and the same-call Full state gate passed. Input QVAPOR is exactly zero. In `calc_cq` (`module_big_step_utilities_em.F`, lines 787–906), the vertical moisture sum spans available species through `n_moist`; with this dry `n_moist=2` case, `cqw=0`, hence `cq1=1` and `cq2=0` in `pg_buoy_w`.

The independent mathematical replay differs from the saved pressure-vector array by only RMS 8.36e-20 and max 2.88e-19 m/s²; it is not bitwise identical because the replay uses a separately evaluated algebraic expression. No threshold was applied. The pressure and W source arrays, raw capture hashes, parser, and resulting metrics are pinned in `red_pressure_independent_w_check.json`.

## Limit

This attributes the measured same-call W-rate difference to the captured pressure operands for this dry case. It does not establish why those operands differ, a production improvement, or parity of full physics or forecast evolution.
