#!/usr/bin/env python3
"""Guarded artifact seeding recipe; intentionally not executed during PR301 prep."""
from __future__ import annotations
import argparse, hashlib, json, os, shutil, subprocess
from pathlib import Path

DONOR=Path('/private/tmp/pr300-corrected-state-20261012')
TARGET=Path('/private/tmp/pr301-full-six-rhs-20261012')
E=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/green_build')
EXPECTED_EXE='5589c1a02f491bfc4e14c9e0f9bef32dea562e8e99bf59132bf22fa13b557338'
EXPECTED_CPP='21f7bc79a131f4608f506259b7c0434f2350749486774f14aea260cc69910565'
EXPECTED_UNVERIFIED=['phys/module_bl_mynnedmf.F','phys/module_bl_mynnedmf_common.F','phys/module_bl_mynnedmf_driver.F']
EXPECTED_MODULE_EM='b199e682a940fee7de7e5ba76837ccf15227d3bb26384b9aa95ff6a414c2de4e'
SOURCE_EXT={'.F','.F90','.cpp','.cc','.c','.h','.hpp','.inc'}

def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(TARGET),*args],text=True).strip()

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--arm-seed-after-root-clearance',action='store_true')
 ap.add_argument('--expected-head',required=True)
 ap.add_argument('--expected-solve-em-sha256',required=True)
 args=ap.parse_args()
 if not args.arm_seed_after_root_clearance:raise SystemExit('seed is disabled until root explicitly clears; pass the arm flag only after that clearance')
 if git('rev-parse','HEAD')!=args.expected_head:raise SystemExit('target HEAD changed')
 status=git('status','--porcelain=v1').splitlines()
 nonseed=[line[3:] for line in status if not (line[3:].endswith('.f90') or line[3:]=='configure.wrf')]
 if nonseed:raise SystemExit(f'worktree has changes outside generated lowercase F90/configure seed products: {nonseed}')
 if sha(TARGET/'dyn_em/solve_em.F')!=args.expected_solve_em_sha256:raise SystemExit('solve_em.F does not match frozen hash')
 if sha(DONOR/'main/wrf.exe')!=EXPECTED_EXE:raise SystemExit('PR300 donor executable hash mismatch')
 if sha(DONOR/'external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a')!=EXPECTED_CPP:raise SystemExit('PR300 C++ library hash mismatch')
 tracked=git('ls-files','-z').split('\0');changed=[];unverified=[]
 for rel in tracked:
  if not rel or Path(rel).suffix not in SOURCE_EXT:continue
  t,d=TARGET/rel,DONOR/rel
  if not t.is_file() or not d.is_file():unverified.append(rel);continue
  if sha(t)!=sha(d):changed.append(rel)
 if changed!=['dyn_em/solve_em.F']:raise SystemExit(f'expected only solve_em.F to differ from donor, got {changed}')
 if unverified!=EXPECTED_UNVERIFIED:raise SystemExit(f'unexpected unverified source paths: {unverified}')
 target_gitlink=subprocess.check_output(['git','-C',str(TARGET),'ls-tree','HEAD','phys/MYNN-EDMF'],text=True).strip()
 donor_gitlink=subprocess.check_output(['git','-C',str(DONOR),'ls-tree','HEAD','phys/MYNN-EDMF'],text=True).strip()
 if target_gitlink!=donor_gitlink or '90f36c25259ec1960b24325f5b29ac7c5adeac73' not in target_gitlink:raise SystemExit('unverified MYNN source paths lack matching expected gitlink')
 seed_started=(TARGET/'configure.wrf').exists() or (TARGET/'main/libwrflib.a').exists()
 if seed_started:
  cfg=DONOR/'configure.wrf'
  if not (TARGET/'configure.wrf').is_file() or (TARGET/'configure.wrf').read_text()!=cfg.read_text().replace(str(DONOR),str(TARGET)):
   raise SystemExit('existing partial seed has an unexpected configure.wrf')
  if not (TARGET/'main/libwrflib.a').is_file() or sha(TARGET/'main/libwrflib.a')!=sha(DONOR/'main/libwrflib.a'):
   raise SystemExit('existing partial seed has an unexpected Fortran archive')
  if (TARGET/'main/wrf.exe').exists() or (TARGET/'dyn_em/solve_em.o').exists():
   raise SystemExit('partial seed unexpectedly contains the new executable or affected solve_em.o')
 else:
  if any((TARGET/p).exists() for p in ('main/wrf.exe','main/libwrflib.a','dyn_em/solve_em.o')):
   raise SystemExit('target already contains unexpected build outputs')
 copied=[];skipped=[]
 for src in DONOR.rglob('*'):
  if not src.is_file() or src.is_symlink() or '.git' in src.parts:continue
  rel=src.relative_to(DONOR)
  if str(rel) in {'dyn_em/solve_em.o','dyn_em/solve_em.f90','dyn_em/solve_em.G','dyn_em/solve_em.bb','dyn_em/solve_em.i','main/wrf.exe','main/ideal.exe'}:
   skipped.append(str(rel));continue
  eligible=(src.suffix in {'.o','.a','.mod'} or str(rel) in {'tools/standard.exe','tools/standard','tools/yacc','tools/yacc.exe'})
  if src.suffix=='.f90':
   owners=[src.with_suffix('.F'),src.with_suffix('.F90'),src.with_suffix('.f')]
   owner=next((x for x in owners if x.is_file()),None)
   eligible=(owner is not None and (TARGET/owner.relative_to(DONOR)).is_file() and sha(owner)==sha(TARGET/owner.relative_to(DONOR)) and str(rel)!='dyn_em/solve_em.f90')
  if rel.parts[0]=='inc' and src.suffix in {'.inc','.h'}:eligible=True
  if eligible:
   dst=TARGET/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst);copied.append({'path':str(rel),'sha256':sha(dst),'bytes':dst.stat().st_size})
 # Match tracked-source mtimes only when source bytes are identical; solve_em stays newer.
 aligned=[]
 for rel in tracked:
  if not rel or rel=='dyn_em/solve_em.F':continue
  t,d=TARGET/rel,DONOR/rel
  if t.is_file() and d.is_file() and sha(t)==sha(d):
   os.utime(t,ns=(d.stat().st_atime_ns,d.stat().st_mtime_ns));aligned.append(rel)
 # Configure must use target paths, while retaining the exact donor toolchain settings.
 donor_cfg=DONOR/'configure.wrf';target_cfg=TARGET/'configure.wrf'
 if not donor_cfg.is_file():raise SystemExit('donor configure.wrf missing')
 target_cfg.write_text(donor_cfg.read_text().replace(str(DONOR),str(TARGET)))
 if sha(TARGET/'external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a')!=EXPECTED_CPP:
  raise SystemExit('C++ archive changed while seeding')
 if sha(TARGET/'dyn_em/module_em.mod')!=EXPECTED_MODULE_EM:raise SystemExit('module_em.mod did not seed exactly')
 if sha(TARGET/'main/libwrflib.a')!=sha(DONOR/'main/libwrflib.a'):
  raise SystemExit('seeded baseline Fortran archive does not match donor')
 if (TARGET/'dyn_em/solve_em.o').exists() or (TARGET/'main/wrf.exe').exists():
  raise SystemExit('affected solve_em.o or WRF executable unexpectedly seeded')
 receipt={'schema':'pr301_solve_em_seed_receipt_v1','target_head':args.expected_head,'target_solve_em_sha256':args.expected_solve_em_sha256,'donor_executable_sha256':sha(DONOR/'main/wrf.exe'),'donor_cpp_archive_sha256':sha(DONOR/'external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a'),'configured_target_sha256':sha(target_cfg),'source_differences_vs_donor':changed,'unverified_source_paths':unverified,'unverified_source_gitlink':target_gitlink,'tracked_mtime_aligned_count':len(aligned),'seeded_artifact_count':len(copied),'seeded_artifacts':copied,'deliberately_not_seeded':skipped,'solve_em_object_and_generated_source_excluded':True,'wrf_exe_excluded_for_relink':True,'cpp_archive_unchanged':True,'module_em_mod_sha256':sha(TARGET/'dyn_em/module_em.mod'),'cpp_archive_sha256_after_seed':sha(TARGET/'external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a'),'baseline_libwrflib_sha256':sha(TARGET/'main/libwrflib.a'),'baseline_libwrflib_matches_donor':sha(TARGET/'main/libwrflib.a')==sha(DONOR/'main/libwrflib.a'),'resumed_partial_seed':seed_started}
 (E/'pr301_solve_em_seed_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({'status':'seeded_only_no_build','receipt':str(E/'pr301_solve_em_seed_receipt.json'),'objects_archives_modules':len(copied),'aligned_sources':len(aligned)},sort_keys=True))
if __name__=='__main__':main()
