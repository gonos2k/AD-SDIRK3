#!/usr/bin/env python3
"""Execute only the root-cleared, exact historic solve_em preprocessing/object/link recipe."""
from __future__ import annotations
import hashlib, json, os, shlex, subprocess, sys, datetime
from pathlib import Path

TARGET=Path('/private/tmp/pr301-full-six-rhs-20261012')
DONOR=Path('/private/tmp/pr300-corrected-state-20261012')
E=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/green_build')
RED=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/red_provenance/pr301_solve_em_build_reuse_preflight.json')
RED_CLEAR=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/red_provenance/pr301_build_script_red_review_resolution.json')
ATTEMPT_APPEND=E/'pr301_seed_and_preprocess_failure_resolution.json'
SEED=E/'pr301_solve_em_seed_receipt.json'
FAIL_LOG=E/'pr301_solve_em_make_preprocess_failure.log'
SUCCESS_LOG=E/'pr301_solve_em_exact_build_success.log'
EXPECTED_HEAD='2f32859d545bf5dc3e287653d8ebb1cb504df32c'
EXPECTED_SOLVE='888b81bcb21791fc89e08d739162f7cedfbff8679cba5453010257a3f31a9be8'
EXPECTED_CPP='21f7bc79a131f4608f506259b7c0434f2350749486774f14aea260cc69910565'
EXPECTED_EXE='5589c1a02f491bfc4e14c9e0f9bef32dea562e8e99bf59132bf22fa13b557338'
EXPECTED_MODULE='b199e682a940fee7de7e5ba76837ccf15227d3bb26384b9aa95ff6a414c2de4e'

def sha_bytes(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(TARGET),*args],text=True).strip()
def normalized(s:str)->str:return ' '.join(shlex.split(s))
def run_command(label,command,cwd,log,*,pipefail=False):
 prefix='set -o pipefail; ' if pipefail else ''
 with log.open('ab') as out:
  out.write(f'\n===== {label} =====\n{command}\n'.encode())
  proc=subprocess.run(prefix+command,shell=True,executable='/bin/bash',cwd=cwd,
                      stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=False)
  out.write(proc.stdout)
 if proc.returncode!=0:raise RuntimeError(f'{label} failed with exit {proc.returncode}')
 return proc.returncode

def main():
 if os.environ.get('PR301_ROOT_CLEARANCE')!='approved':raise SystemExit('missing explicit root build clearance')
 if os.environ.get('PR301_EXPECTED_HEAD')!=EXPECTED_HEAD or os.environ.get('PR301_EXPECTED_SOLVE_EM_SHA256')!=EXPECTED_SOLVE:
  raise SystemExit('clearance env does not match the frozen target/source')
 if SUCCESS_LOG.exists() or (E/'pr301_solve_em_build_receipt.json').exists():raise SystemExit('refusing a second build attempt')
 if not ATTEMPT_APPEND.is_file():raise SystemExit('append-only seed/preprocess failure resolution receipt is missing')
 review=json.loads(RED_CLEAR.read_text())
 if review.get('status')!='CLEAR_FOR_ROOT_AUTHORIZED_SEED_AND_BUILD' or review.get('target_head')!=EXPECTED_HEAD or review.get('frozen_solve_em_source_sha256')!=EXPECTED_SOLVE:raise SystemExit('RedRun review resolution does not bind frozen target/source')
 if not FAIL_LOG.is_file():raise SystemExit('prior failed make preprocessing log has not been preserved distinctly')
 if git('rev-parse','HEAD')!=EXPECTED_HEAD or git('status','--short').strip()=='' :
  raise SystemExit('target HEAD mismatch or donor seed has not been staged')
 if sha(TARGET/'dyn_em/solve_em.F')!=EXPECTED_SOLVE:raise SystemExit('frozen solve_em.F hash mismatch')
 if (TARGET/'dyn_em/solve_em.o').exists() or (TARGET/'main/wrf.exe').exists():raise SystemExit('new solve_em.o or relinked executable already exists')
 if sha(TARGET/'main/libwrflib.a')!=sha(DONOR/'main/libwrflib.a'):raise SystemExit('pre-build WRF archive is not exact donor baseline')
 if sha(TARGET/'external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a')!=EXPECTED_CPP:raise SystemExit('CPP archive changed before build')
 if sha(TARGET/'dyn_em/module_em.mod')!=EXPECTED_MODULE:raise SystemExit('module_em.mod changed from donor')
 seed=json.loads(SEED.read_text())
 if seed.get('target_head')!=EXPECTED_HEAD or seed.get('target_solve_em_sha256')!=EXPECTED_SOLVE or not seed.get('baseline_libwrflib_matches_donor'):
  raise SystemExit('seed receipt does not bind the frozen source and donor archive')
 red=json.loads(RED.read_text())['historical_exact_commands']
 def cmd(key):return red[key].replace('<TARGET_ROOT>',str(TARGET))
 actual={
  'line_306_strip_comments':cmd('line_306_strip_comments'),
  'line_307_cpp_first_pass':cmd('line_307_cpp_first_pass'),
  'line_308_wrf_preprocess':cmd('line_308_wrf_preprocess'),
  'line_310_fortran_compile':cmd('line_310_fortran_compile'),
  'line_315_ranlib':cmd('line_315_ranlib'),
  'line_316_link_command':cmd('line_316_link_command'),
 }
 # Verify each executable command is the exact reviewed command after path relocation.
 exact={}
 for key,val in actual.items():
  expected=cmd(key)
  if shlex.split(val)!=shlex.split(expected):raise SystemExit(f'command-token mismatch: {key}')
  exact[key]={'normalized':normalized(val),'sha256':hashlib.sha256(val.encode()).hexdigest(),'token_count':len(shlex.split(val)),'matches_reviewed_recipe':True}
 archive_hist=shlex.split(red['line_312_archive_full_em_member_set'])
 archive_min=['ar','ru','../main/libwrflib.a','solve_em.o']
 if archive_hist[:3]!=archive_min[:3] or 'solve_em.o' not in archive_hist:raise SystemExit('minimal ar command is not a strict subset of reviewed archive recipe')
 exact['minimal_ar_member_update']={'normalized':' '.join(archive_min),'token_count':len(archive_min),'matches_reviewed_recipe_prefix_and_member':True}
 gate={'schema':'pr301_exact_historic_solve_em_build_command_gate_v1','verified_local_time':datetime.datetime.now().astimezone().isoformat(timespec='seconds'),'target_head':EXPECTED_HEAD,'solve_em_sha256':EXPECTED_SOLVE,'reviewed_red_run_receipt':str(RED),'reviewed_red_run_receipt_sha256':sha(RED),'red_clearance_review':str(RED_CLEAR),'red_clearance_review_sha256':sha(RED_CLEAR),'seed_failure_resolution_receipt':str(ATTEMPT_APPEND),'seed_failure_resolution_receipt_sha256':sha(ATTEMPT_APPEND),'commands':exact,'compile_macro_tokens':['-DNMM_CORE=0','-DDA_CORE=0','-DWRFPLUS=0','-DNMM_NEST=0'],'preserved_initial_failure_log':str(FAIL_LOG),'preserved_initial_failure_log_sha256':sha(FAIL_LOG),'authorization':'root clearance recorded via invocation environment; no model calls permitted by this build driver'}
 gatepath=E/'pr301_exact_build_command_gate.json'
 if gatepath.exists():raise SystemExit('command gate already exists; refusing overwrite')
 gatepath.write_text(json.dumps(gate,indent=2)+'\n')
 # Remove only generated intermediates for this one affected source.
 for rel in ('dyn_em/solve_em.o','dyn_em/solve_em.f90','dyn_em/solve_em.G','dyn_em/solve_em.bb'):
  p=TARGET/rel
  if p.exists():p.unlink()
 SUCCESS_LOG.write_text('PR301 exact historic solve_em rebuild; frozen source only.\n')
 cwd=TARGET/'dyn_em'
 run_command('comment stripping',actual['line_306_strip_comments'],cwd,SUCCESS_LOG)
 run_command('historical CPP first pass',actual['line_307_cpp_first_pass'],cwd,SUCCESS_LOG)
 run_command('WRF standard preprocessing',actual['line_308_wrf_preprocess'],cwd,SUCCESS_LOG,pipefail=True)
 run_command('historical Fortran compile with target module includes',actual['line_310_fortran_compile'],cwd,SUCCESS_LOG)
 obj=TARGET/'dyn_em/solve_em.o';f90=TARGET/'dyn_em/solve_em.f90'
 if not obj.is_file() or not f90.is_file():raise SystemExit('preprocessing/compile did not create both F90 and object')
 if not (obj.stat().st_mtime_ns>(TARGET/'dyn_em/solve_em.F').stat().st_mtime_ns and obj.stat().st_mtime_ns>f90.stat().st_mtime_ns):
  raise SystemExit('fresh solve_em.o timestamp does not postdate source and generated F90')
 if sha(obj)==sha(DONOR/'dyn_em/solve_em.o'):raise SystemExit('compiled object is identical to stale donor object')
 run_command('minimal archive update',' '.join(archive_min),cwd,SUCCESS_LOG)
 run_command('ranlib',actual['line_315_ranlib'],TARGET/'main',SUCCESS_LOG)
 run_command('configured WRF relink',actual['line_316_link_command'],TARGET/'main',SUCCESS_LOG)
 archive=TARGET/'main/libwrflib.a';exe=TARGET/'main/wrf.exe';cpp=TARGET/'external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a';module=TARGET/'dyn_em/module_em.mod'
 members=subprocess.check_output(['ar','t',str(archive)],text=True).splitlines()
 if members.count('solve_em.o')!=1:raise SystemExit(f'archive must contain one solve_em.o member, found {members.count("solve_em.o")}')
 member=subprocess.check_output(['ar','p',str(archive),'solve_em.o'])
 if sha_bytes(member)!=sha(obj):raise SystemExit('archive member bytes do not match fresh solve_em.o')
 if sha(cpp)!=EXPECTED_CPP:raise SystemExit('C++ archive changed')
 if sha(module)!=EXPECTED_MODULE:raise SystemExit('module_em.mod changed')
 if sha(exe)==EXPECTED_EXE or exe.stat().st_mtime_ns<=archive.stat().st_mtime_ns:raise SystemExit('executable was not freshly relinked after archive update')
 if sha(archive)==sha(DONOR/'main/libwrflib.a'):raise SystemExit('Fortran archive was not updated')
 files=['dyn_em/solve_em.F','dyn_em/solve_em.f90','dyn_em/solve_em.o','dyn_em/module_em.mod','main/libwrflib.a','main/wrf.exe','configure.wrf','external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a']
 rec={'schema':'pr301_solve_em_isolated_build_receipt_v1','built_local_time':datetime.datetime.now().astimezone().isoformat(timespec='seconds'),'target_head':git('rev-parse','HEAD'),'solve_em_expected_source_sha256':EXPECTED_SOLVE,'schema_file_sha256':'35800c75882e7d2c8f69637ae26bbdebddaf33a97a5ec45ad8e3abbbfb1deeff','seed_receipt':str(SEED),'seed_receipt_sha256':sha(SEED),'command_gate':str(gatepath),'command_gate_sha256':sha(gatepath),'historical_recipe_receipt':str(RED),'historical_recipe_receipt_sha256':sha(RED),'preserved_prior_failed_make_log':str(FAIL_LOG),'preserved_prior_failed_make_log_sha256':sha(FAIL_LOG),'successful_build_log':str(SUCCESS_LOG),'successful_build_log_sha256':sha(SUCCESS_LOG),'module_include_dirs':['../dyn_em',str(TARGET/'external/esmf_time_f90'),str(TARGET/'main'),str(TARGET/'external/io_netcdf'),str(TARGET/'external/io_int'),str(TARGET/'frame'),str(TARGET/'share'),str(TARGET/'phys'),str(TARGET/'wrftladj'),str(TARGET/'chem'),str(TARGET/'inc'),'/opt/homebrew/include'],'cpp_archive_unchanged':True,'module_em_mod_unchanged':True,'archive_solve_em_member_count':1,'archive_member_matches_object':True,'freshness_checks':{'solve_em_object_newer_than_source':obj.stat().st_mtime_ns>(TARGET/'dyn_em/solve_em.F').stat().st_mtime_ns,'solve_em_object_newer_than_generated_f90':obj.stat().st_mtime_ns>f90.stat().st_mtime_ns,'wrf_exe_newer_than_libwrflib':exe.stat().st_mtime_ns>archive.stat().st_mtime_ns},'files':{rel:{'sha256':sha(TARGET/rel),'bytes':(TARGET/rel).stat().st_size,'mtime_ns':(TARGET/rel).stat().st_mtime_ns} for rel in files},'source_status_after':git('status','--porcelain=v1').splitlines(),'build_status':'isolated solve_em object compiled, WRF archive member replaced, executable relinked; no model run executed'}
 out=E/'pr301_solve_em_build_receipt.json'
 if out.exists():raise SystemExit('build receipt already exists; refusing overwrite')
 out.write_text(json.dumps(rec,indent=2)+'\n')
 print(json.dumps({'status':'build_candidate_ready','receipt':str(out),'wrf_exe_sha256':sha(exe),'solve_em_object_sha256':sha(obj),'archive_sha256':sha(archive)},sort_keys=True))
if __name__=='__main__':main()
