#!/bin/bash
set -euo pipefail

: "${PR301_ROOT_CLEARANCE:?set only after root authorizes seed/build}"
[[ "$PR301_ROOT_CLEARANCE" == "approved" ]] || { echo "root clearance value invalid" >&2; exit 2; }
: "${PR301_EXPECTED_HEAD:?provide frozen target HEAD}"
: "${PR301_EXPECTED_SOLVE_EM_SHA256:?provide frozen solve_em.F SHA256}"

TARGET=/private/tmp/pr301-full-six-rhs-20261012
DONOR=/private/tmp/pr300-corrected-state-20261012
E=/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/green_build
SEED=$E/seed_pr301_solve_em.py
LOG=$E/pr301_solve_em_rebuild.log
EXPECTED_CPP=21f7bc79a131f4608f506259b7c0434f2350749486774f14aea260cc69910565
EXPECTED_DONOR_EXE=5589c1a02f491bfc4e14c9e0f9bef32dea562e8e99bf59132bf22fa13b557338
EXPECTED_MODULE_EM=b199e682a940fee7de7e5ba76837ccf15227d3bb26384b9aa95ff6a414c2de4e
sha() { shasum -a 256 "$1" | awk '{print $1}'; }

[[ "$(git -C "$TARGET" rev-parse HEAD)" == "$PR301_EXPECTED_HEAD" ]]
[[ "$(sha "$TARGET/dyn_em/solve_em.F")" == "$PR301_EXPECTED_SOLVE_EM_SHA256" ]]
[[ "$(sha "$DONOR/main/wrf.exe")" == "$EXPECTED_DONOR_EXE" ]]
[[ "$(sha "$DONOR/external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a")" == "$EXPECTED_CPP" ]]
python3 - <<'PYSEED'
import json, hashlib
from pathlib import Path
p=Path("/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/green_build/pr301_solve_em_seed_receipt.json")
d=json.loads(p.read_text())
assert d["target_head"] == "2f32859d545bf5dc3e287653d8ebb1cb504df32c"
assert d["target_solve_em_sha256"] == "888b81bcb21791fc89e08d739162f7cedfbff8679cba5453010257a3f31a9be8"
assert d["cpp_archive_unchanged"] and d["baseline_libwrflib_matches_donor"]
assert d["module_em_mod_sha256"] == "b199e682a940fee7de7e5ba76837ccf15227d3bb26384b9aa95ff6a414c2de4e"
PYSEED
python3 "$SEED" --arm-seed-after-root-clearance --expected-head "$PR301_EXPECTED_HEAD" --expected-solve-em-sha256 "$PR301_EXPECTED_SOLVE_EM_SHA256"

# Regenerate and compile only the changed authoritative Fortran object. The
# include list is copied from the successful PR300 startup-object compile.
python3 - <<'PYCODE'
from pathlib import Path
for p in (Path("/private/tmp/pr301-full-six-rhs-20261012/dyn_em/solve_em.o"), Path("/private/tmp/pr301-full-six-rhs-20261012/dyn_em/solve_em.f90")):
    if p.exists(): p.unlink()
PYCODE
MODULE_INCLUDES="-I../dyn_em -I$TARGET/external/esmf_time_f90 -I$TARGET/main -I$TARGET/external/io_netcdf -I$TARGET/external/io_int -I$TARGET/frame -I$TARGET/share -I$TARGET/phys -I$TARGET/wrftladj -I$TARGET/chem -I$TARGET/inc -I/opt/homebrew/include"
: > "$LOG"
make -C "$TARGET/dyn_em" WRF_SRC_ROOT_DIR="$TARGET" FC="mpif90 $MODULE_INCLUDES" solve_em.o 2>&1 | tee -a "$LOG"
test -s "$TARGET/dyn_em/solve_em.o"
test -s "$TARGET/dyn_em/solve_em.f90"
[[ "$TARGET/dyn_em/solve_em.o" -nt "$TARGET/dyn_em/solve_em.F" ]]
[[ "$TARGET/dyn_em/solve_em.o" -nt "$TARGET/dyn_em/solve_em.f90" ]]
[[ "$(sha "$TARGET/dyn_em/module_em.mod")" == "$EXPECTED_MODULE_EM" ]]

# Replace only solve_em.o in the WRF Fortran archive, then relink the WRF EXE.
(cd "$TARGET/dyn_em" && ar ru ../main/libwrflib.a solve_em.o) 2>&1 | tee -a "$LOG"
(cd "$TARGET/main" && ranlib libwrflib.a) 2>&1 | tee -a "$LOG"
make -C "$TARGET/main" -B -o wrf.o -o ../main/module_wrf_top.o \
  WRF_SRC_ROOT_DIR="$TARGET" SOLVER=em em_wrf 2>&1 | tee -a "$LOG"

python3 - <<'PYCODE'
import hashlib, json, subprocess
from datetime import datetime
from pathlib import Path
T=Path('/private/tmp/pr301-full-six-rhs-20261012')
D=Path('/private/tmp/pr300-corrected-state-20261012')
E=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/green_build')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
archive=T/'main/libwrflib.a';obj=T/'dyn_em/solve_em.o';exe=T/'main/wrf.exe';cpp=T/'external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a'
members=subprocess.check_output(['ar','t',str(archive)],text=True).splitlines()
if members.count('solve_em.o')!=1:raise SystemExit(f'expected exactly one solve_em.o archive member; found {members.count("solve_em.o")}')
member=subprocess.check_output(['ar','p',str(archive),'solve_em.o'])
if hashlib.sha256(member).hexdigest()!=sha(obj):raise SystemExit('archived solve_em.o differs from newly compiled object')
if sha(cpp)!='21f7bc79a131f4608f506259b7c0434f2350749486774f14aea260cc69910565':raise SystemExit('CPP archive changed during isolated Fortran rebuild')
if sha(exe)==sha(D/'main/wrf.exe'):raise SystemExit('WRF executable was not relinked')
if sha(obj)==sha(D/'dyn_em/solve_em.o'):raise SystemExit('solve_em object did not change from frozen V2 source')
if not exe.stat().st_mtime_ns>archive.stat().st_mtime_ns:raise SystemExit('WRF executable is not newer than the updated Fortran archive')
if sha(T/'dyn_em/module_em.mod')!='b199e682a940fee7de7e5ba76837ccf15227d3bb26384b9aa95ff6a414c2de4e':raise SystemExit('module_em.mod changed unexpectedly')
files=['dyn_em/solve_em.F','dyn_em/solve_em.f90','dyn_em/solve_em.o','dyn_em/module_em.mod','main/libwrflib.a','main/wrf.exe','configure.wrf','external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a']
receipt={'schema':'pr301_solve_em_isolated_build_receipt_v1','built_local_time':datetime.now().astimezone().isoformat(timespec='seconds'),'target_head':subprocess.check_output(['git','-C',str(T),'rev-parse','HEAD'],text=True).strip(),'solve_em_expected_source_sha256':__import__('os').environ['PR301_EXPECTED_SOLVE_EM_SHA256'],'module_include_dirs':['../dyn_em',str(T/'external/esmf_time_f90'),str(T/'main'),str(T/'external/io_netcdf'),str(T/'external/io_int'),str(T/'frame'),str(T/'share'),str(T/'phys'),str(T/'wrftladj'),str(T/'chem'),str(T/'inc'),'/opt/homebrew/include'],'cpp_archive_unchanged':True,'module_em_mod_unchanged':True,'archive_solve_em_member_count':1,'archive_object_member_sha256':hashlib.sha256(member).hexdigest(),'archive_member_matches_fresh_object':True,'freshness_checks':{'solve_em_object_newer_than_source':obj.stat().st_mtime_ns>(T/'dyn_em/solve_em.F').stat().st_mtime_ns,'solve_em_object_newer_than_generated_f90':obj.stat().st_mtime_ns>(T/'dyn_em/solve_em.f90').stat().st_mtime_ns,'wrf_exe_newer_than_libwrflib':exe.stat().st_mtime_ns>archive.stat().st_mtime_ns},'files':{rel:{'sha256':sha(T/rel),'bytes':(T/rel).stat().st_size,'mtime_ns':(T/rel).stat().st_mtime_ns} for rel in files},'build_log':str(E/'pr301_solve_em_rebuild.log'),'build_log_sha256':sha(E/'pr301_solve_em_rebuild.log'),'source_status_after':subprocess.check_output(['git','-C',str(T),'status','--porcelain=v1'],text=True).splitlines()}
out=E/'pr301_solve_em_build_receipt.json';out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':'build_candidate_ready','receipt':str(out),'wrf_exe_sha256':sha(exe),'solve_em_object_sha256':sha(obj)},sort_keys=True))
PYCODE
