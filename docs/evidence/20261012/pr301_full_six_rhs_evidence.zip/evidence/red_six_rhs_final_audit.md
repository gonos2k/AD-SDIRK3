# Red final audit: PR301 physical six-RHS comparison

Local time: 2026-10-12 18:05:04 JST. I independently parsed the raw V2 Fortran Full snapshot and C++ Full output and reconstructed the physical Fortran rates using the source formulas. The six same-call physical state arrays are bitwise equal. Both runs used the same corrected input SHA `fc37c8c0…39d14df`; executable SHA `78b3c01a…10fd43d7`; Fortran V2 `solve_em.F` SHA `888b81bc…31a9be8`. No extra model call, build, pressure replay or production edit was performed. The raw parser and physical arrays are [`red_six_rhs_raw_audit.py`](red_six_rhs_raw_audit.py), [`red_six_rhs_raw_audit.json`](red_six_rhs_raw_audit.json), and [`red_six_rhs_raw_audit_arrays.npz`](red_six_rhs_raw_audit_arrays.npz).

The Fortran V2 capture is after `rk_addtend_dry`; the older `wrf_rk_tend_dump` is before it and is not substituted here. I widened FP32 snapshot values to float64 before difference. Total mass rate is reconstructed as signed DMDT from captured RU/RV fluxes plus the forcing-only `mu_tend`. The Fortran transformations use the source-defined map, layer masses, and product terms; PH has no PH-times-mass-rate product term. C++ Full outputs are already physical rates. Units are U/V/W m/s², PH m²/s³, THM/t K/s and MU Pa/s.

| Field | Owners | RMS C++−FT | Max absolute | Relative RMS | Propagated raw-FP32 input interval RMS | Owners outside that interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| U (m/s²) | 4,096 | 8.39972e−8 | 3.74253e−7 | 2.28190e−4 | 9.27173e−11 | 4,094 |
| V (m/s²) | 3,840 | 8.48934e−8 | 3.33823e−7 | 1.48330e−3 | 1.42732e−11 | 3,839 |
| W (m/s²) | 4,096 | 1.20095e−5 | 4.01232e−5 | 4.48498e−1 | 6.61548e−12 | 4,096 |
| PH (m²/s³) | 4,096 | 3.80669e−5 | 9.82649e−5 | 1.35226e−2 | 7.03014e−10 | 3,897 |
| THM/t (K/s) | 4,096 | 2.50972e−7 | 1.35600e−6 | 1.72089e−2 | 5.19394e−11 | 3,778 |
| MU (Pa/s) | 256 | 3.36932e−8 | 1.25158e−7 | 8.93155e−6 | 7.23404e−8 | 10 |

The input intervals propagate the half-ULPs of captured FP32 Fortran operands through each physical conversion and include C++ output half-ULP. They describe snapshot-input storage uncertainty only; they do not bound internal Fortran/C++ arithmetic and are not a pass threshold. The separate hypothetical half-ULP for storing the final normalized rates as FP32 is recorded in JSON but is not used as a total error bound.

Masks retain unique periodic U face 0 and omit the closing face; V includes only internal symmetric-Y faces. W and PH exclude the fixed bottom and include the dynamic top because `top_lid=false`; each top/bottom plane is reported separately. THM/t and MU use all physical mass-cell owners. PH bottom is exactly zero; PH top delta is `5.05888e−10` RMS / `1.38520e−9` max across 256 owners, while the interior 3,840 PH owners have `3.93153e−5` RMS delta. W top delta is `1.00811e−5` RMS / `3.09885e−5` max; the bottom is zero.

These are measured first-call assembled slow-RHS differences at an exact shared state. The W difference is large relative to its signal and its raw-input FP32 interval, and THM/PH also exceed their storage intervals; this is a coverage and numerical finding, not a tolerance failure under an adopted criterion. The capture precedes the acoustic step and does not establish complete post-acoustic RHS parity, forecast accuracy, or internal-rounding attribution. No arbitrary global tolerance is proposed.
