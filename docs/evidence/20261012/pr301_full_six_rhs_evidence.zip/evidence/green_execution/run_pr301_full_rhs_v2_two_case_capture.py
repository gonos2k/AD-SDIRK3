#!/usr/bin/env python3
"""Run exactly the root-authorized PR301 V2 FT/CPP h=15 s one-step captures."""
from __future__ import annotations
import hashlib, importlib.util, json, os, re, shutil, struct, subprocess, time
from datetime import datetime
from pathlib import Path

ROOT=Path('/private/tmp/pr301-full-six-rhs-20261012')
HERE=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/green_execution')
OUT=HERE/'pr301_v2';CAPROOT=OUT/'captures';RUNS=OUT/'pr301_v2_runs.json'
INPUT=Path('/Users/yhlee/AD-SDIRK3-review-evidence/pressure-lineage-20261012/actual_t60_corrected_time0_wrfinput_d01_qvguard')
FIXTURE=Path('/Users/yhlee/AD-SDIRK3-review-evidence/pressure-lineage-20261012/actual_t60_corrected_fixture_final_receipt.json')
NML=Path('/Users/yhlee/Documents/AD-SDIRK3-worktree-archive/20261005/native_wave_refinement/wrf_runs/signfix_fp64_carry_on15_240/namelist.input')
DIAG=NML.parent/'diagnostics.txt'
EXE=ROOT/'main/wrf.exe';CPP=ROOT/'external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a';CONFIG=ROOT/'configure.wrf'
BUILD=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/green_build/pr301_solve_em_build_receipt.json')
LIVE=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/green_build/root_live_build_gate.json')
SCHEMA=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/green_pressure/full_rhs_snapshot_v2_schema.json')
PREFLIGHT=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/green_build/pr301_build_capture_preflight_base.json')
RED=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-six-rhs-20261012/red_provenance/pr301_solve_em_build_reuse_preflight.json')
BASE_RUNNER=Path('/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012/green_build/run_u_pgf_capture.py')
BASELINE_FULL=Path('/Users/yhlee/AD-SDIRK3-review-evidence/corrected-state-rhs-20261012/green_execution/preserve_w/captures/preserve_w/preserve_w_fortran_rk3_h15/wrf_full_rhs_snapshot.bin')
HEAD='2f32859d545bf5dc3e287653d8ebb1cb504df32c';SOLVE_SHA='888b81bcb21791fc89e08d739162f7cedfbff8679cba5453010257a3f31a9be8'
EXE_SHA='78b3c01abcfc3b3e8286930e62198855891ff50c3bd1dd4026cd6fef10fd43d7';CPP_SHA='21f7bc79a131f4608f506259b7c0434f2350749486774f14aea260cc69910565'
INPUT_SHA='fc37c8c0c8be8053a16e0d3424609d496f4a023c6c17ee3a06371970639d14df';NML_SHA='6258b997543f95b6cdde538aa37e14084f17862210e94c02dd23fb7fd91a8e06'
DIAG_SHA='bc5c198d7f033fa8cd5d5b9bcbe2a46a2eae7d69ea8dd414d18f0cc5dc62b224';SCHEMA_SHA='35800c75882e7d2c8f69637ae26bbdebddaf33a97a5ec45ad8e3abbbfb1deeff'
EXPECTED_OUTPUTS={
 'RK3':('wrf_rk_tend_dump.bin','wrf_full_rhs_snapshot.bin','wrf_u_pgf_snapshot.bin','wrf_u_hdiff_snapshot.bin','wrf_u_vdiff_before.bin'),
 'ARK3':('port_full_rhs_snapshot.bin','port_u_pgf_snapshot.bin','port_u_pgf_operands_snapshot.bin','port_hdiff_u_snapshot.bin','port_vdiff_u_snapshot.bin')}
def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(ROOT),*args],text=True).strip()
def load_base():
 spec=importlib.util.spec_from_file_location('pr301_pgf_helper',BASE_RUNNER);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def set_int(text,key,value):
 t,n=re.subn(r'(\b'+re.escape(key)+r'\s*=\s*)[-+0-9]+',lambda m:m.group(1)+str(value),text,count=1,flags=re.I)
 if n!=1:raise ValueError(f'missing namelist key {key}')
 return t
def set_input_w(text):
 groups=list(re.finditer(r'(?ims)^\s*&dynamics\b(.*?)(^\s*/)',text))
 if len(groups)!=1:raise ValueError(f'expected one dynamics group, found {len(groups)}')
 g=groups[0];lines=g.group(1).splitlines(keepends=True);found=0
 for i,line in enumerate(lines):
  if re.match(r'^\s*use_input_w\s*=',line.split('!')[0],re.I):
   lines[i]=re.sub(r'(\buse_input_w\s*=\s*)(\.true\.|\.false\.|true|false)',r'\1.true.',line,count=1,flags=re.I);found+=1
 if found>1:raise ValueError('duplicate use_input_w')
 if not found:lines.append(' use_input_w = .true.,\n')
 out=text[:g.start(1)]+''.join(lines)+text[g.end(1):]
 gg=re.search(r'(?ims)^\s*&dynamics\b(.*?)(^\s*/)',out)
 if not gg or len(re.findall(r'(?im)^\s*use_input_w\s*=\s*\.true\.',gg.group(1)))!=1:raise ValueError('failed to stage use_input_w=.true.')
 return out
def full_v2_schema(p):
 b=p.read_bytes()
 if len(b)<60:raise ValueError('V2 Full-RHS header truncated')
 ver,=struct.unpack_from('<I',b,0);bounds=struct.unpack_from('<12i',b,4);rdx,rdy=struct.unpack_from('<2f',b,52)
 if ver!=2:raise ValueError(f'expected V2 Full-RHS, got version {ver}')
 _,_,_,_,_,_,ims,ime,jms,jme,kms,kme=bounds;ni=ime-ims+1;nj=jme-jms+1;nk=kme-kms+1
 if min(ni,nj,nk)<=0:raise ValueError(f'invalid bounds {bounds}')
 n3=ni*nj*nk;n2=ni*nj;n1=nk;expected=60+4*(12*n3+11*n2+5*n1)
 if len(b)!=expected:raise ValueError(f'V2 Full-RHS size {len(b)} != {expected}')
 return {'version':ver,'bounds':list(bounds),'rdx':rdx,'rdy':rdy,'memory_shape_jki':[nj,nk,ni],'bytes_expected':expected,'array_dtype':'little-endian float32','v1_prefix_bytes':478488,'v2_append':['rw_tend','ph_tend','t_tend','c1f','c2f']}
def hv_schema(p,name):
 b=p.read_bytes()
 if name in ('wrf_u_hdiff_snapshot.bin','wrf_u_vdiff_before.bin'):
  if len(b)<60:raise ValueError(f'{name} truncated')
  ver,=struct.unpack_from('<I',b,0);bounds=struct.unpack_from('<12i',b,4);_,_,_,_,_,_,ims,ime,jms,jme,kms,kme=bounds
  n3=(ime-ims+1)*(jme-jms+1)*(kme-kms+1);fields=10 if 'hdiff' in name else 5;expected=60+4*fields*n3
  if ver!=1 or len(b)!=expected:raise ValueError(f'{name} schema mismatch')
  return {'version':ver,'bounds':list(bounds),'bytes_expected':expected,'fields_float32':fields}
 if name in ('port_hdiff_u_snapshot.bin','port_vdiff_u_snapshot.bin'):
  if len(b)<16:raise ValueError(f'{name} truncated')
  ver,ny,nz,nxu=struct.unpack_from('<4i',b,0);expected=16+16*ny*nz*nxu
  if ver!=1 or min(ny,nz,nxu)<=0 or len(b)!=expected:raise ValueError(f'{name} schema mismatch')
  return {'version':ver,'shape_jki':[ny,nz,nxu],'bytes_expected':expected,'blocks_float64':2}
 raise ValueError(name)
def artifact_receipt(base,folder,method):
 names=EXPECTED_OUTPUTS[method];old=base.EXPECTED_OUTPUTS[method]
 if method=='RK3':base.EXPECTED_OUTPUTS[method]=tuple(n for n in names if n!='wrf_full_rhs_snapshot.bin')
 else:base.EXPECTED_OUTPUTS[method]=names
 try:items=base.artifact_receipt(folder,method)
 finally:base.EXPECTED_OUTPUTS[method]=old
 if method=='RK3':
  p=folder/'wrf_full_rhs_snapshot.bin';items[p.name]={'expected':True,'present':p.is_file(),'bytes':p.stat().st_size,'sha256':sha(p),'schema':full_v2_schema(p)}
 for n in ('wrf_u_hdiff_snapshot.bin','wrf_u_vdiff_before.bin','port_hdiff_u_snapshot.bin','port_vdiff_u_snapshot.bin'):
  if n in items:items[n]['schema']=hv_schema(folder/n,n)
 return items
def check_build():
 if git('rev-parse','HEAD')!=HEAD or sha(ROOT/'dyn_em/solve_em.F')!=SOLVE_SHA:raise RuntimeError('target source/head changed')
 b=json.loads(BUILD.read_text());live=json.loads(LIVE.read_text())
 if b['target_head']!=HEAD or b['solve_em_expected_source_sha256']!=SOLVE_SHA:raise RuntimeError('build source binding mismatch')
 if live.get('build_gate')!='PASS' or live.get('head')!=HEAD or live.get('exe')!=EXE_SHA or live.get('cpp')!=CPP_SHA:raise RuntimeError('root live build gate failed')
 if b['files']['main/wrf.exe']['sha256']!=EXE_SHA or b['files']['external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a']['sha256']!=CPP_SHA:raise RuntimeError('binary hash mismatch')
 if not all(b['freshness_checks'].values()) or not b['archive_member_matches_object'] or not b['cpp_archive_unchanged'] or not b['module_em_mod_unchanged']:raise RuntimeError('build postconditions incomplete')
 pre=json.loads(PREFLIGHT.read_text())
 if pre['target_head']!=HEAD or pre['frozen_v2_source']['sha256']!=SOLVE_SHA or pre['frozen_v2_source']['schema_sha256']!=SCHEMA_SHA or sha(SCHEMA)!=SCHEMA_SHA:raise RuntimeError('schema/preflight pin mismatch')
 if sha(INPUT)!=INPUT_SHA or sha(INPUT)!=json.loads(FIXTURE.read_text())['output_sha256']:raise RuntimeError('input/fixture hash mismatch')
 if sha(NML)!=NML_SHA or sha(DIAG)!=DIAG_SHA:raise RuntimeError('namelist/diagnostics mismatch')
 if sha(EXE)!=EXE_SHA or sha(CPP)!=CPP_SHA or sha(CONFIG)!=b['files']['configure.wrf']['sha256']:raise RuntimeError('post-build binary/config mismatch')
 pins={k:v['sha256'] for k,v in json.loads(RED.read_text())['source_and_config_match']['source_pins'].items()};pins['dyn_em/solve_em.F']=SOLVE_SHA
 bad={k:(v,sha(ROOT/k)) for k,v in pins.items() if sha(ROOT/k)!=v}
 if bad:raise RuntimeError(f'authoritative source mismatch {bad}')
 return {'target_head':HEAD,'source_pins':pins,'build_receipt':str(BUILD),'build_receipt_sha256':sha(BUILD),'live_gate':str(LIVE),'live_gate_sha256':sha(LIVE),'schema':str(SCHEMA),'schema_sha256':sha(SCHEMA),'exe_sha256':sha(EXE),'cpp_sha256':sha(CPP),'configure_sha256':sha(CONFIG),'input_sha256':sha(INPUT),'fixture_sha256':sha(FIXTURE),'namelist_sha256':sha(NML),'diagnostics_sha256':sha(DIAG)}
def use_input_w_runtime(folder):
 t=(folder/'namelist.input').read_text();g=re.search(r'(?ims)^\s*&dynamics\b(.*?)(^\s*/)',t);out=(folder/'namelist.output').read_text(errors='replace')
 if not g or len(re.findall(r'(?im)^\s*use_input_w\s*=\s*\.true\.',g.group(1)))!=1 or not re.search(r'(?i)USE_INPUT_W\s*=\s*T\b',out):raise RuntimeError('effective use_input_w not true')
 return {'input_true':True,'runtime_true':True,'namelist_output_sha256':sha(folder/'namelist.output')}
def main():
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--timeout',type=int,default=1200);args=ap.parse_args()
 if RUNS.exists() or CAPROOT.exists():raise FileExistsError('refusing existing PR301 captures')
 for p in (EXE,CPP,CONFIG,INPUT,FIXTURE,NML,DIAG,BUILD,LIVE,SCHEMA,PREFLIGHT,RED,BASELINE_FULL,BASE_RUNNER):
  if not p.is_file():raise FileNotFoundError(p)
 build=check_build();base=load_base();before={k:sha(ROOT/k) for k in build['source_pins']}
 CAPROOT.mkdir(parents=True)
 plan={'schema':'pr301_full_rhs_v2_two_call_capture_v1','status':'running','recorded_local_time':datetime.now().astimezone().isoformat(timespec='seconds'),'target_head':HEAD,'build_gate':build,'input_origin':str(INPUT),'input_sha256':sha(INPUT),'run_policy':'exactly two root-authorized calls: FT RK3 and CPP ARK3; h=15 s, one step, 1 MPI rank/thread, debug=2, use_input_w=true, observer env=1; no other calls','native_calls_authorized':2,'step_seconds':15,'run_seconds':15,'mpi_ranks':1,'threads':1,'debug_level':2,'use_input_w':True,'WRF_PARITY_RK_TEND_DUMP':'1','labels':['pr301_v2_fortran_rk3_h15','pr301_v2_cpp_ark3_h15'],'runs':[]}
 RUNS.write_text(json.dumps(plan,indent=2)+'\n')
 env={k:v for k,v in os.environ.items() if not k.startswith(('WRF_SDIRK3_','WRF_PARITY_'))};env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',WRF_PARITY_RK_TEND_DUMP='1')
 try:
  for label,method in (('pr301_v2_fortran_rk3_h15','RK3'),('pr301_v2_cpp_ark3_h15','ARK3')):
   folder=CAPROOT/label;folder.mkdir();shutil.copy2(INPUT,folder/'wrfinput_d01');shutil.copy2(DIAG,folder/'diagnostics.txt')
   nml=NML.read_text()
   for key,val in (('time_step',15),('time_step_fract_num',0),('time_step_fract_den',1),('run_seconds',15),('rk_ord',3),('time_integration_scheme',0 if method=='RK3' else 6),('sdirk3_debug_level',2)):
    nml=set_int(nml,key,val)
   nml=set_input_w(nml);(folder/'namelist.input').write_text(nml)
   if sha(folder/'wrfinput_d01')!=INPUT_SHA:raise RuntimeError('staged input SHA mismatch')
   row={'label':label,'method':method,'workdir':str(folder),'input_sha256':sha(folder/'wrfinput_d01'),'namelist_sha256':sha(folder/'namelist.input'),'diagnostics_sha256':sha(folder/'diagnostics.txt'),'executable_sha256':sha(EXE),'cpp_sha256':sha(CPP),'solve_em_sha256':sha(ROOT/'dyn_em/solve_em.F'),'status':'running'};plan['runs'].append(row);RUNS.write_text(json.dumps(plan,indent=2)+'\n')
   command=['/usr/bin/time','-l','-o',str(folder/'time.log'),'/opt/homebrew/bin/mpirun','-np','1','--bind-to','none',str(EXE)];row['command']=command;t0=time.monotonic()
   with (folder/'run.log').open('wb') as f:proc=subprocess.run(command,cwd=folder,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=args.timeout,check=False)
   out=(folder/'rsl.out.0000').read_text(errors='replace') if (folder/'rsl.out.0000').is_file() else '';err=(folder/'rsl.error.0000').read_text(errors='replace') if (folder/'rsl.error.0000').is_file() else ''
   row.update({'return_code':proc.returncode,'wall_seconds':time.monotonic()-t0,'completion_marker':'SUCCESS COMPLETE' in (out+err),'runtime_route':base.capture_runtime_config(folder,method),'effective_use_input_w':use_input_w_runtime(folder),'artifacts':artifact_receipt(base,folder,method),'rsl_out_sha256':sha(folder/'rsl.out.0000'),'rsl_error_sha256':sha(folder/'rsl.error.0000'),'time_log_sha256':sha(folder/'time.log')})
   if proc.returncode!=0 or not row['completion_marker']:row['status']='failed';RUNS.write_text(json.dumps(plan,indent=2)+'\n');raise RuntimeError(f'native call failed: {label}')
   if method=='RK3':
    p=folder/'wrf_full_rhs_snapshot.bin';new=p.read_bytes();old=BASELINE_FULL.read_bytes();vs=row['artifacts'][p.name]['schema']
    if len(old)!=vs['v1_prefix_bytes'] or new[:4]!=struct.pack('<I',2) or old[:4]!=struct.pack('<I',1) or new[4:len(old)]!=old[4:]:raise RuntimeError('V2 prefix differs from retained v1 source payload')
    row['v1_prefix_parity']={'status':'passed','bytes_compared':len(old)-4,'baseline_sha256':sha(BASELINE_FULL),'v2_sha256':sha(p)}
   row['status']='completed';RUNS.write_text(json.dumps(plan,indent=2)+'\n')
   if sha(EXE)!=EXE_SHA or sha(CPP)!=CPP_SHA or sha(ROOT/'dyn_em/solve_em.F')!=SOLVE_SHA:raise RuntimeError('binary/source changed during calls')
  if {k:sha(ROOT/k) for k in before}!=before:raise RuntimeError('authoritative source hashes changed during calls')
  plan.update({'status':'completed','native_calls_completed':2,'source_sha256_after':before,'completion_note':'Exactly two authorized calls completed; no additional model launches.'});RUNS.write_text(json.dumps(plan,indent=2)+'\n')
  print(json.dumps({'status':'completed','receipt':str(RUNS),'runs':[{'label':r['label'],'status':r['status'],'rc':r['return_code'],'wall_seconds':r['wall_seconds'],'full_sha256':r['artifacts'].get('wrf_full_rhs_snapshot.bin',r['artifacts'].get('port_full_rhs_snapshot.bin'))['sha256']} for r in plan['runs']]},sort_keys=True))
 except Exception as exc:
  plan['status']='failed';plan['failure']=f'{type(exc).__name__}: {exc}';plan['source_sha256_after']={k:sha(ROOT/k) for k in before};RUNS.write_text(json.dumps(plan,indent=2)+'\n');raise
if __name__=='__main__':main()
