#!/usr/bin/env python3
"""Fail-closed analyzer for the paired WRF/C++ full-RHS snapshot format.

This is evidence tooling only.  It does not call either RHS implementation.
The Fortran continuity reconstruction follows module_small_step_em.F's
advance_mu_t loop; source fingerprints are included in the output.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import struct
import subprocess
import sys
from pathlib import Path
from typing import Any

import numpy as np


DEFAULT_ROOT = Path(__file__).resolve().parent
DEFAULT_OUT = Path(__file__).resolve().parent / "full_rhs_analysis.json"

FORTRAN_FIELDS_3D = (
    "u2", "v2", "w2", "ph2", "t2", "ru_tend", "rv_tend", "ru", "rv",
)
FORTRAN_FIELDS_2D = (
    "mu2", "mu_tend", "muu", "muv", "mut",
    "msfux", "msfuy", "msfvx", "msfvy", "msftx", "msfty",
)
FORTRAN_FIELDS_1D = ("dnw", "c1h", "c2h")
FORTRAN_FIELD_ORDER = (
    "u2", "v2", "w2", "ph2", "t2", "mu2", "ru_tend", "rv_tend", "mu_tend",
    "ru", "rv", "muu", "muv", "mut", "dnw", "c1h", "c2h",
    "msfux", "msfuy", "msfvx", "msfvy", "msftx", "msfty",
)
CPP_BLOCKS = ("u", "v", "w", "ph", "t", "mu")

# These are the authoritative formula sources, fingerprinted from the exact
# target worktree at analysis time (including uncommitted diagnostic edits).
SOURCE_PATHS = (
    "dyn_em/solve_em.F",
    "dyn_em/module_implicit_sdirk3.F",
    "dyn_em/module_em.F",
    "dyn_em/module_small_step_em.F",
    "dyn_em/module_big_step_utilities_em.F",
    "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp",
)


class SnapshotError(RuntimeError):
    pass


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def file_receipt(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise SnapshotError(f"snapshot not found: {path}")
    return {"path": str(path), "byte_count": path.stat().st_size, "sha256": sha256_file(path)}


def read_i32s(data: bytes, offset: int, count: int, label: str) -> tuple[tuple[int, ...], int]:
    size = 4 * count
    if len(data) < offset + size:
        raise SnapshotError(f"{label} header truncated: need {offset + size} bytes, have {len(data)}")
    values = struct.unpack_from("<" + "i" * count, data, offset)
    return tuple(int(x) for x in values), offset + size


def read_fortran(path: Path) -> tuple[dict[str, Any], dict[str, np.ndarray]]:
    data = path.read_bytes()
    if len(data) < 60:
        raise SnapshotError(f"Fortran snapshot header truncated: {len(data)} bytes")
    version, = struct.unpack_from("<I", data, 0)
    if version != 1:
        raise SnapshotError(f"unsupported Fortran snapshot version {version}")
    bounds, offset = read_i32s(data, 4, 12, "Fortran bounds")
    if len(data) < offset + 8:
        raise SnapshotError("Fortran rdx/rdy scalars truncated")
    rdx, rdy = struct.unpack_from("<ff", data, offset)
    offset += 8
    ids, ide, jds, jde, kds, kde, ims, ime, jms, jme, kms, kme = bounds
    if min(ide - ids, jde - jds, kde - kds, ime - ims, jme - jms, kme - kms) <= 0:
        raise SnapshotError(f"non-positive Fortran bounds/extents: {bounds}")
    ni, nj, nk = ime - ims + 1, jme - jms + 1, kme - kms + 1
    n3, n2, n1 = ni * nj * nk, ni * nj, nk
    expected = offset + 4 * (len(FORTRAN_FIELDS_3D) * n3 + len(FORTRAN_FIELDS_2D) * n2 + len(FORTRAN_FIELDS_1D) * n1)
    if len(data) != expected:
        raise SnapshotError(f"Fortran byte count mismatch: expected {expected}, got {len(data)}")

    fields: dict[str, np.ndarray] = {}
    for name in FORTRAN_FIELD_ORDER:
        count = n3 if name in FORTRAN_FIELDS_3D else n2 if name in FORTRAN_FIELDS_2D else n1
        raw = np.frombuffer(data, dtype="<f4", count=count, offset=offset)
        if name in FORTRAN_FIELDS_3D:
            # Fortran (i,k,j) memory is equivalent to contiguous C [j,k,i].
            arr = raw.reshape((nj, nk, ni), order="C")
        elif name in FORTRAN_FIELDS_2D:
            arr = raw.reshape((nj, ni), order="C")
        else:
            arr = raw.reshape((nk,), order="C")
        fields[name] = arr
        offset += count * 4
    if offset != len(data):
        raise SnapshotError("internal Fortran parser offset mismatch")
    meta = {
        "version": version,
        "bounds": dict(zip(("ids", "ide", "jds", "jde", "kds", "kde", "ims", "ime", "jms", "jme", "kms", "kme"), bounds)),
        "memory_shape_jki": [nj, nk, ni],
        "dtype": "little-endian float32",
        "array_order": "Fortran i-fastest/k/j; parsed as C [j,k,i] or [j,i]",
        "scalars": {"rdx": float(rdx), "rdy": float(rdy)},
    }
    return meta, fields


def cpp_shapes(dims: tuple[int, ...]) -> dict[str, tuple[int, ...]]:
    nx, ny, nz, nxu, nyv, nzw = dims
    if min(dims) <= 0:
        raise SnapshotError(f"non-positive C++ dimensions: {dims}")
    if (nxu, nyv, nzw) != (nx + 1, ny + 1, nz + 1):
        raise SnapshotError(f"C++ stagger extents are not nx+1/ny+1/nz+1: {dims}")
    return {
        "u": (ny, nz, nxu),
        "v": (nyv, nz, nx),
        "w": (ny, nzw, nx),
        "ph": (ny, nzw, nx),
        "t": (ny, nz, nx),
        "mu": (ny, 1, nx),
    }


def read_cpp(path: Path) -> tuple[dict[str, Any], dict[str, np.ndarray], dict[str, np.ndarray]]:
    data = path.read_bytes()
    if len(data) < 28:
        raise SnapshotError(f"C++ snapshot header truncated: {len(data)} bytes")
    version, = struct.unpack_from("<I", data, 0)
    if version != 1:
        raise SnapshotError(f"unsupported C++ snapshot version {version}")
    dims, offset = read_i32s(data, 4, 6, "C++ dimensions")
    shapes = cpp_shapes(dims)
    state: dict[str, np.ndarray] = {}
    rhs: dict[str, np.ndarray] = {}
    for label, target in (("state", state), ("rhs", rhs)):
        for name in CPP_BLOCKS:
            shape = shapes[name]
            count = int(np.prod(shape))
            end = offset + count * 4
            if end > len(data):
                raise SnapshotError(f"C++ {label}/{name} block truncated: need {end}, have {len(data)}")
            target[name] = np.frombuffer(data, dtype="<f4", count=count, offset=offset).reshape(shape)
            offset = end
    if offset != len(data):
        raise SnapshotError(f"C++ byte count mismatch: parsed {offset}, got {len(data)}")
    meta = {
        "version": version,
        "dims_nx_ny_nz_nxu_nyv_nzw": list(dims),
        "block_shapes_jki": {k: list(v) for k, v in shapes.items()},
        "dtype": "little-endian float32",
        "array_order": "contiguous C [j,k,i]; mu [j,1,i]",
    }
    return meta, state, rhs


def _slice3(a: np.ndarray, b: dict[str, int], *, i0: int, i1: int, k0: int, k1: int, j0: int, j1: int) -> np.ndarray:
    return a[j0 - b["jms"] : j1 - b["jms"], k0 - b["kms"] : k1 - b["kms"], i0 - b["ims"] : i1 - b["ims"]]


def _slice2(a: np.ndarray, b: dict[str, int], *, i0: int, i1: int, j0: int, j1: int) -> np.ndarray:
    return a[j0 - b["jms"] : j1 - b["jms"], i0 - b["ims"] : i1 - b["ims"]]


def logical_fortran_state(meta: dict[str, Any], fields: dict[str, np.ndarray], dims: tuple[int, ...]) -> dict[str, np.ndarray]:
    b = meta["bounds"]
    nx, ny, nz, nxu, nyv, nzw = dims
    # A packed periodic-domain storage shape includes one endpoint in each
    # horizontal mass axis. Keep this full tile storage audit separate from
    # the 16x16 physical operator slices below.
    extents = (b["ide"] - b["ids"] + 1, b["jde"] - b["jds"] + 1, b["kde"] - b["kds"])
    if extents != (nx, ny, nz):
        raise SnapshotError(f"Fortran full-tile extents {extents} disagree with C++ storage {(nx, ny, nz)}")
    i, j, k = b["ids"], b["jds"], b["kds"]
    u = _slice3(fields["u2"], b, i0=i, i1=i + nxu, k0=k, k1=k + nz, j0=j, j1=j + ny)
    v = _slice3(fields["v2"], b, i0=i, i1=i + nx, k0=k, k1=k + nz, j0=j, j1=j + nyv)
    w = _slice3(fields["w2"], b, i0=i, i1=i + nx, k0=k, k1=k + nzw, j0=j, j1=j + ny)
    ph = _slice3(fields["ph2"], b, i0=i, i1=i + nx, k0=k, k1=k + nzw, j0=j, j1=j + ny)
    t = _slice3(fields["t2"], b, i0=i, i1=i + nx, k0=k, k1=k + nz, j0=j, j1=j + ny)
    mu = _slice2(fields["mu2"], b, i0=i, i1=i + nx, j0=j, j1=j + ny)
    extracted = {"u": u, "v": v, "w": w, "ph": ph, "t": t, "mu": mu[:, None, :]}
    for name, arr in extracted.items():
        if arr.shape != dims_shape(name, dims):
            raise SnapshotError(f"Fortran {name} logical shape {arr.shape} != C++ shape {dims_shape(name, dims)}")
    return extracted


def physical_dimensions(dims: tuple[int, ...], meta: dict[str, Any]) -> tuple[int, int, int]:
    """Resolve canonical physical extents for this gated packed periodic layout."""
    nx, ny, nz, _, _, _ = dims
    b = meta["bounds"]
    # isPackedPeriodicDomain() requires a whole-domain periodic-X/symmetric-Y
    # tile; the RHS conversion defines momentum_m=ny_-1, momentum_n=nx_-1.
    if (nx, ny, nz) != (b["ide"] - b["ids"] + 1, b["jde"] - b["jds"] + 1, b["kde"] - b["kds"]):
        raise SnapshotError("C++ storage does not match the full-domain packed periodic contract")
    return nx - 1, ny - 1, nz


def physical_state(storage: dict[str, np.ndarray], dims: tuple[int, ...]) -> dict[str, np.ndarray]:
    nx, ny, nz, _, _, _ = dims
    px, py, _ = nx - 1, ny - 1, nz
    return {
        # State-gate all physical input faces, including the periodic closing
        # U face and both symmetric-wall V faces. RHS metrics use owner-unique
        # masks separately below.
        "u": storage["u"][:py, :, :px + 1],
        "v": storage["v"][:py + 1, :, :px],
        "w": storage["w"][:py, :, :px],
        "ph": storage["ph"][:py, :, :px],
        "t": storage["t"][:py, :, :px],
        "mu": storage["mu"][:py, :, :px],
    }


def periodic_u_seam_audit(ft: dict[str, np.ndarray], cpp: dict[str, np.ndarray], dims: tuple[int, ...]) -> dict[str, Any]:
    nx, ny, _, _, _, _ = dims
    px, py = nx - 1, ny - 1
    ft_u = ft["u"][:py, :, :px + 1]
    cpp_u = cpp["u"][:py, :, :px + 1]
    return {
        "fortran_first_equals_closing_face": bool(np.array_equal(ft_u[:, :, 0], ft_u[:, :, px])),
        "cpp_first_equals_closing_face": bool(np.array_equal(cpp_u[:, :, 0], cpp_u[:, :, px])),
        "fortran_cpp_closing_face_equal": bool(np.array_equal(ft_u[:, :, px], cpp_u[:, :, px])),
        "owned_unique_faces": int(py * dims[2] * px),
    }


def dims_shape(name: str, dims: tuple[int, ...]) -> tuple[int, ...]:
    return cpp_shapes(dims)[name]


def state_audit(ft_state: dict[str, np.ndarray], cpp_state: dict[str, np.ndarray]) -> dict[str, Any]:
    report: dict[str, Any] = {}
    for name in CPP_BLOCKS:
        a, b = ft_state[name], cpp_state[name]
        if a.shape != b.shape:
            report[name] = {"equal": False, "reason": "shape_mismatch", "fortran_shape": list(a.shape), "cpp_shape": list(b.shape)}
            continue
        equal = bool(np.array_equal(a, b))
        # State metrics are only for diagnosing a failed gate; no RHS subtraction
        # is performed unless all six blocks pass exact equality.
        delta = np.subtract(a.astype(np.float64), b.astype(np.float64))
        report[name] = {
            "equal": equal,
            "element_count": int(a.size),
            "mismatch_count": int(np.count_nonzero(a != b)),
            "max_abs_state_mismatch": float(np.max(np.abs(delta))) if delta.size else 0.0,
            "fortran_sha256": hashlib.sha256(a.tobytes(order="C")).hexdigest(),
            "cpp_sha256": hashlib.sha256(b.tobytes(order="C")).hexdigest(),
        }
    return report


def mass_flux_divergence(
    ru: np.ndarray, rv: np.ndarray, dnw: np.ndarray,
    msftx: np.ndarray, msfty: np.ndarray, rdx: float, rdy: float,
) -> np.ndarray:
    """advance_mu_t DMDT from captured total coupled face fluxes."""
    if ru.ndim != 3 or rv.ndim != 3:
        raise SnapshotError("ru/rv fluxes must be rank-3 [j,k,i]")
    ny, nz, nxu = ru.shape
    nyv, nzv, nx = rv.shape
    if nxu != nx + 1 or nyv != ny + 1 or nzv != nz:
        raise SnapshotError(f"invalid staggered flux shapes ru={ru.shape}, rv={rv.shape}")
    if dnw.shape != (nz,) or msftx.shape != (ny, nx) or msfty.shape != (ny, nx):
        raise SnapshotError("dnw/map shapes do not match mass-grid flux divergence")
    delta_u = ru[:, :, 1:] - ru[:, :, :-1]
    delta_v = rv[1:, :, :] - rv[:-1, :, :]
    return np.sum(
        dnw[None, :, None] * (msftx * msfty)[:, None, :]
        * (rdx * delta_u + rdy * delta_v), axis=1,
    )


def fortran_tendency_to_physical(
    coupled_tendency: np.ndarray, velocity: np.ndarray, c1h: np.ndarray,
    face_mu_dot: np.ndarray, map_factor: np.ndarray, layer_mass: np.ndarray,
) -> np.ndarray:
    """Convert coupled d(L*u/m)/dt to physical du/dt on its stagger."""
    return (coupled_tendency * map_factor[:, None, :]
            - velocity * c1h[None, :, None] * face_mu_dot[:, None, :]) / layer_mass


def manufactured_contract_checks() -> dict[str, Any]:
    """Tiny nonzero checks distinguish coupled flux and physical RHS paths."""
    ny, nx, nz = 2, 2, 2
    face_speed = np.array([0.0, 1.0, 2.0], dtype=np.float64)
    # Non-unit layer mass scales the coupled RU flux gradient by eight.
    ru = np.broadcast_to((8.0 * face_speed)[None, None, :], (ny, nz, nx + 1)).copy()
    rv = np.zeros((ny + 1, nz, nx), dtype=np.float64)
    dnw = np.array([-0.25, -0.5], dtype=np.float64)  # retain signed WRF convention
    msftx = np.full((ny, nx), 2.0, dtype=np.float64)
    msfty = np.full((ny, nx), 3.0, dtype=np.float64)
    mu_dot = mass_flux_divergence(ru, rv, dnw, msftx, msfty, rdx=0.5, rdy=0.25)
    if not np.array_equal(mu_dot, np.full((ny, nx), -18.0)):
        raise SnapshotError(f"manufactured coupled-flux DMDT check failed: {mu_dot}")
    wrong_velocity_dmdt = -2.25

    # Nonzero MUdot distinguishes one conversion of Fortran coupled tendency
    # from an erroneous second conversion of the already-physical C++ output.
    c1h = np.array([0.5, 0.75], dtype=np.float64)
    u = np.full((1, nz, 1), 4.0, dtype=np.float64)
    layer = np.broadcast_to(np.array([10.0, 12.0])[None, :, None], (1, nz, 1))
    map_u = np.full((1, 1), 2.0, dtype=np.float64)
    mu_u_dot = np.full((1, 1), 3.0, dtype=np.float64)
    cpp_u_physical = np.full_like(u, 2.5)
    ru_tend_coupled = (layer * cpp_u_physical + u * c1h[None, :, None] * mu_u_dot[:, None, :]) / map_u[:, None, :]
    ft_u_physical = fortran_tendency_to_physical(ru_tend_coupled, u, c1h, mu_u_dot, map_u, layer)
    double_converted_cpp = fortran_tendency_to_physical(cpp_u_physical, u, c1h, mu_u_dot, map_u, layer)
    if not np.array_equal(ft_u_physical, cpp_u_physical) or np.array_equal(double_converted_cpp, cpp_u_physical):
        raise SnapshotError("manufactured CPP physical-RHS conversion check failed")
    v = np.full((2, nz, 1), -3.0, dtype=np.float64)
    layer_v = np.broadcast_to(np.array([9.0, 11.0])[None, :, None], (2, nz, 1))
    map_v = np.full((2, 1), 1.5, dtype=np.float64)
    mu_v_dot = np.full((2, 1), -2.0, dtype=np.float64)
    cpp_v_physical = np.full_like(v, -1.25)
    rv_tend_coupled = (layer_v * cpp_v_physical + v * c1h[None, :, None] * mu_v_dot[:, None, :]) / map_v[:, None, :]
    ft_v_physical = fortran_tendency_to_physical(rv_tend_coupled, v, c1h, mu_v_dot, map_v, layer_v)
    if not np.array_equal(ft_v_physical, cpp_v_physical):
        raise SnapshotError("manufactured V physical-RHS conversion check failed")
    return {
        "coupled_flux_mu_dot": {"passed": True, "expected_pa_per_s": -18.0, "wrong_velocity_flux_pa_per_s": wrong_velocity_dmdt},
        "cpp_already_physical": {"passed": True, "u_expected_m_per_s2": 2.5, "v_expected_m_per_s2": -1.25, "mu_dot_nonzero": True, "double_conversion_differs": True},
    }


def calc_mu_dot(meta: dict[str, Any], f: dict[str, np.ndarray], dims: tuple[int, ...]) -> dict[str, np.ndarray]:
    b = meta["bounds"]
    nx_store, ny_store, nz, nxu_store, nyv_store, _ = dims
    nx, ny, _ = physical_dimensions(dims, meta)
    i0, j0, k0 = b["ids"], b["jds"], b["kds"]
    ru = _slice3(f["ru"], b, i0=i0, i1=i0 + nxu_store, k0=k0, k1=k0 + nz, j0=j0, j1=j0 + ny_store)[:ny, :, :nx + 1].astype(np.float64)
    rv = _slice3(f["rv"], b, i0=i0, i1=i0 + nx_store, k0=k0, k1=k0 + nz, j0=j0, j1=j0 + nyv_store)[:ny + 1, :, :nx].astype(np.float64)
    muu = _slice2(f["muu"], b, i0=i0, i1=i0 + nxu_store, j0=j0, j1=j0 + ny_store)[:ny, :nx + 1].astype(np.float64)
    muv = _slice2(f["muv"], b, i0=i0, i1=i0 + nx_store, j0=j0, j1=j0 + nyv_store)[:ny + 1, :nx].astype(np.float64)
    msfuy = _slice2(f["msfuy"], b, i0=i0, i1=i0 + nxu_store, j0=j0, j1=j0 + ny_store)[:ny, :nx + 1].astype(np.float64)
    msfvx = _slice2(f["msfvx"], b, i0=i0, i1=i0 + nx_store, j0=j0, j1=j0 + nyv_store)[:ny + 1, :nx].astype(np.float64)
    u = _slice3(f["u2"], b, i0=i0, i1=i0 + nxu_store, k0=k0, k1=k0 + nz, j0=j0, j1=j0 + ny_store)[:ny, :, :nx + 1].astype(np.float64)
    v = _slice3(f["v2"], b, i0=i0, i1=i0 + nx_store, k0=k0, k1=k0 + nz, j0=j0, j1=j0 + nyv_store)[:ny + 1, :, :nx].astype(np.float64)
    c1h = f["c1h"][k0 - b["kms"] : k0 - b["kms"] + nz].astype(np.float64)
    c2h = f["c2h"][k0 - b["kms"] : k0 - b["kms"] + nz].astype(np.float64)
    dnw = f["dnw"][k0 - b["kms"] : k0 - b["kms"] + nz].astype(np.float64)
    msftx = _slice2(f["msftx"], b, i0=i0, i1=i0 + nx_store, j0=j0, j1=j0 + ny_store)[:ny, :nx].astype(np.float64)
    msfty = _slice2(f["msfty"], b, i0=i0, i1=i0 + nx_store, j0=j0, j1=j0 + ny_store)[:ny, :nx].astype(np.float64)
    lu = c1h[None, :, None] * muu[:, None, :] + c2h[None, :, None]
    lv = c1h[None, :, None] * muv[:, None, :] + c2h[None, :, None]
    if np.any(lu <= 0.0) or np.any(lv <= 0.0) or np.any(msfuy <= 0.0) or np.any(msfvx <= 0.0):
        raise SnapshotError("non-positive layer mass or map factor prevents flux reconstruction")

    # Pointwise couple_momentum identities from module_big_step_utilities_em.F.
    ru_rebuilt = (u * lu) / msfuy[:, None, :]
    rv_rebuilt = (v * lv) / msfvx[:, None, :]

    # RU/RV are already total mass-coupled face fluxes. advance_mu_t's
    # DMDT loop takes their signed horizontal differences directly.
    dmdt = mass_flux_divergence(ru, rv, dnw, msftx, msfty,
                                meta["scalars"]["rdx"], meta["scalars"]["rdy"])
    mu_tend = _slice2(f["mu_tend"], b, i0=i0, i1=i0 + nx_store, j0=j0, j1=j0 + ny_store)[:ny, :nx].astype(np.float64)
    mu_dot = dmdt + mu_tend

    # calc_mu_uv stencil on tendencies: periodic-x wrap for U, physical-edge
    # copy for symmetric-y V. This mirrors the target boundary contract.
    mu_u_dot = np.empty((ny, nx + 1), dtype=np.float64)
    mu_u_dot[:, 0] = 0.5 * (mu_dot[:, -1] + mu_dot[:, 0])
    mu_u_dot[:, 1:nx] = 0.5 * (mu_dot[:, :-1] + mu_dot[:, 1:])
    mu_u_dot[:, nx] = mu_u_dot[:, 0]
    mu_v_dot = np.empty((ny + 1, nx), dtype=np.float64)
    mu_v_dot[0, :] = mu_dot[0, :]
    mu_v_dot[1:ny, :] = 0.5 * (mu_dot[:-1, :] + mu_dot[1:, :])
    mu_v_dot[ny, :] = mu_dot[-1, :]

    eps = np.finfo(np.float32).eps
    u_resid = np.abs(ru.astype(np.float64) - ru_rebuilt)
    v_resid = np.abs(rv.astype(np.float64) - rv_rebuilt)
    u_scale = np.maximum(1.0, np.abs(ru.astype(np.float64)))
    v_scale = np.maximum(1.0, np.abs(rv.astype(np.float64)))
    result = {
        "mu_dot": mu_dot,
        "mu_u_dot": mu_u_dot,
        "mu_v_dot": mu_v_dot,
        "flux_identity": {
            "u": {"max_abs_residual": float(u_resid.max()), "max_scaled_residual": float((u_resid / u_scale).max()), "within_8_float32_eps": bool(np.all(u_resid <= 8.0 * eps * u_scale)), "count": int(u_resid.size)},
            "v": {"max_abs_residual": float(v_resid.max()), "max_scaled_residual": float((v_resid / v_scale).max()), "within_8_float32_eps": bool(np.all(v_resid <= 8.0 * eps * v_scale)), "count": int(v_resid.size)},
        },
        "mu_components": {"dmdt": dmdt, "mu_tend": mu_tend},
    }
    return result


def metrics(candidate: np.ndarray, reference: np.ndarray, units: str) -> dict[str, Any]:
    if candidate.shape != reference.shape:
        raise SnapshotError(f"metric shape mismatch {candidate.shape} != {reference.shape}")
    delta = candidate.astype(np.float64) - reference.astype(np.float64)
    ref = reference.astype(np.float64)
    rms = float(np.sqrt(np.mean(delta * delta))) if delta.size else 0.0
    signal = float(np.sqrt(np.mean(ref * ref))) if ref.size else 0.0
    return {
        "count": int(delta.size),
        "units": units,
        "absolute_rms": rms,
        "signal_rms": signal,
        "max_abs": float(np.max(np.abs(delta))) if delta.size else 0.0,
        "relative_rms": (rms / signal) if signal != 0.0 else None,
        "relative_rms_status": "defined" if signal != 0.0 else "undefined_zero_signal",
    }


def source_receipts(root: Path) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for rel in SOURCE_PATHS:
        path = root / rel
        result[rel] = {"present": path.is_file(), "sha256": sha256_file(path) if path.is_file() else None}
    return result


def git_receipt(root: Path) -> dict[str, Any]:
    try:
        head = subprocess.run(["git", "-C", str(root), "rev-parse", "HEAD"], check=True,
                              capture_output=True, text=True).stdout.strip()
        dirty = bool(subprocess.run(["git", "-C", str(root), "status", "--porcelain"], check=True,
                                    capture_output=True, text=True).stdout.strip())
        return {"head": head, "working_tree_dirty": dirty}
    except (OSError, subprocess.CalledProcessError):
        return {"head": None, "working_tree_dirty": None}


def analyze(ft_path: Path, cpp_path: Path, root: Path) -> dict[str, Any]:
    ft_receipt, cpp_receipt = file_receipt(ft_path), file_receipt(cpp_path)
    ft_meta, ft = read_fortran(ft_path)
    cpp_meta, cpp_state, cpp_rhs = read_cpp(cpp_path)
    dims = tuple(cpp_meta["dims_nx_ny_nz_nxu_nyv_nzw"])
    ft_state = logical_fortran_state(ft_meta, ft, dims)
    state = state_audit(ft_state, cpp_state)
    report: dict[str, Any] = {
        "schema": "wrf-cpp-full-rhs-same-state-analysis-v1",
        "comparison_available": False,
        "state_exact_match": False,
        "fortran_snapshot": {**ft_receipt, **ft_meta},
        "cpp_snapshot": {**cpp_receipt, **cpp_meta},
        "source_revision": git_receipt(root),
        "source_sha256": source_receipts(root),
        "manufactured_contract_checks": manufactured_contract_checks(),
        "provisional_error_budget": {"status": "not_adopted", "threshold": None},
        "method": {
            "mu_dot": "sum_k(dnw * msftx * msfty * [rdx*delta_i(ru)+rdy*delta_j(rv)]) + mu_tend; signed dnw retained",
            "captured_flux_identity": "ru=u*(c1h*muu+c2h)/msfuy; rv=v*(c1h*muv+c2h)/msfvx, checked only as an input identity",
            "fortran_to_physical_uv": "u_dot=(ru_tend*msfuy-u*c1h*mu_u_dot)/(c1h*muu+c2h); v analog uses msfvx/muv",
            "cpp_full_rhs_uv": "compared as already-physical u_dot/v_dot; no second mass-coordinate conversion",
            "comparison_masks": "physical U faces y<physical_ny,x<physical_nx; interior V faces 1<=y<physical_ny,x<physical_nx; MU physical mass cells",
            "units": {"u": "m/s^2", "v": "m/s^2", "mu": "Pa/s"},
            "source_locations": {
                "fortran_mu_continuity": "dyn_em/module_small_step_em.F:1092-1105",
                "fortran_momentum_coupling": "dyn_em/module_big_step_utilities_em.F:369-384",
                "fortran_combined_uv_tendency": "dyn_em/module_em.F:1063-1083",
                "fortran_snapshot_capture": "dyn_em/solve_em.F:1364-1404",
                "cpp_pack_state": "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp:12705-13020",
                "cpp_full_rhs_physical_uv_export": "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp:24963-25021",
                "cpp_packed_periodic_geometry": "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp:14367-14381,16512-16514",
            },
            "claim_scope": "component RHS diagnostic only; not proof of complete semidiscrete operator parity",
        },
    }
    full_storage_match = all(bool(v.get("equal")) for v in state.values()) and len(state) == 6
    ft_physical_state = physical_state(ft_state, dims)
    cpp_physical_state = physical_state(cpp_state, dims)
    physical_state_gate = state_audit(ft_physical_state, cpp_physical_state)
    physical_state_match = all(bool(v.get("equal")) for v in physical_state_gate.values()) and len(physical_state_gate) == 6
    seam_gate = periodic_u_seam_audit(ft_state, cpp_state, dims)
    seam_match = all(seam_gate[name] for name in (
        "fortran_first_equals_closing_face", "cpp_first_equals_closing_face", "fortran_cpp_closing_face_equal"))
    state_gate_pass = physical_state_match and seam_match
    report["full_storage_exact_match"] = full_storage_match
    report["full_storage_audit"] = state
    report["physical_owned_state_exact_match"] = physical_state_match
    report["physical_owned_state_audit"] = physical_state_gate
    report["periodic_face_gate"] = seam_gate
    report["state_gate"] = {
        "passed": state_gate_pass,
        "physical_owned_six_field_exact": physical_state_match,
        "periodic_u_closing_face_exact": seam_match,
        "full_storage_exact": full_storage_match,
        "full_storage_is_audit_only": True,
    }
    report["state_exact_match"] = state_gate_pass
    report["geometry"] = {
        "cpp_storage_nx_ny_nz": [dims[0], dims[1], dims[2]],
        "physical_operator_nx_ny_nz": list(physical_dimensions(dims, ft_meta)),
        "packed_endpoint_axes_removed": ["periodic X one mass endpoint", "symmetric Y one mass endpoint"],
        "full_storage_comparison": "reported separately; ghost mismatch does not replace the physical owner state gate",
    }
    if not state_gate_pass:
        report["reason"] = "physical owned U/V/W/PH/T/MU states or required periodic U faces differ; RHS differences were not computed"
        return report

    phys_nx, phys_ny, phys_nz = physical_dimensions(dims, ft_meta)
    b = ft_meta["bounds"]
    i0, j0, k0 = b["ids"], b["jds"], b["kds"]
    ft_ru_storage = _slice3(ft["ru"], b, i0=i0, i1=i0 + dims[3], k0=k0, k1=k0 + phys_nz, j0=j0, j1=j0 + dims[1])
    ft_rv_storage = _slice3(ft["rv"], b, i0=i0, i1=i0 + dims[0], k0=k0, k1=k0 + phys_nz, j0=j0, j1=j0 + dims[4])
    ft_ru_tend_storage = _slice3(ft["ru_tend"], b, i0=i0, i1=i0 + dims[3], k0=k0, k1=k0 + phys_nz, j0=j0, j1=j0 + dims[1])
    ft_rv_tend_storage = _slice3(ft["rv_tend"], b, i0=i0, i1=i0 + dims[0], k0=k0, k1=k0 + phys_nz, j0=j0, j1=j0 + dims[4])
    required_finite = {
        "ru": ft_ru_storage[:phys_ny, :, :phys_nx + 1],
        "rv": ft_rv_storage[:phys_ny + 1, :, :phys_nx],
        "ru_tend": ft_ru_tend_storage[:phys_ny, :, :phys_nx + 1],
        "rv_tend": ft_rv_tend_storage[:phys_ny + 1, :, :phys_nx],
        "mu_tend": _slice2(ft["mu_tend"], b, i0=i0, i1=i0 + dims[0], j0=j0, j1=j0 + dims[1])[:phys_ny, :phys_nx],
        **{f"cpp_rhs_{name}": physical_state(cpp_rhs, dims)[name] for name in CPP_BLOCKS},
    }
    nonfinite = {name: int(np.count_nonzero(~np.isfinite(value))) for name, value in required_finite.items()
                 if not np.isfinite(value).all()}
    if nonfinite:
        report["reason"] = "non-finite state/RHS operand; no RHS differences were computed"
        report["nonfinite_counts"] = nonfinite
        return report
    if not (np.isfinite(ft_meta["scalars"]["rdx"]) and np.isfinite(ft_meta["scalars"]["rdy"]) and
            ft_meta["scalars"]["rdx"] > 0.0 and ft_meta["scalars"]["rdy"] > 0.0):
        report["reason"] = "rdx/rdy are non-finite or non-positive; no RHS differences were computed"
        return report

    continuity = calc_mu_dot(ft_meta, ft, dims)
    if not all(continuity["flux_identity"][q]["within_8_float32_eps"] for q in ("u", "v")):
        report["reason"] = "captured ru/rv do not satisfy the pointwise couple_momentum identities within 8 float32 eps; RHS differences were not computed"
        report["flux_identity"] = continuity["flux_identity"]
        return report

    _, _, phys_nz = physical_dimensions(dims, ft_meta)
    muu = _slice2(ft["muu"], b, i0=i0, i1=i0 + dims[3], j0=j0, j1=j0 + dims[1])[:phys_ny, :phys_nx + 1].astype(np.float64)
    muv = _slice2(ft["muv"], b, i0=i0, i1=i0 + dims[0], j0=j0, j1=j0 + dims[4])[:phys_ny + 1, :phys_nx].astype(np.float64)
    msfuy = _slice2(ft["msfuy"], b, i0=i0, i1=i0 + dims[3], j0=j0, j1=j0 + dims[1])[:phys_ny, :phys_nx + 1].astype(np.float64)
    msfvx = _slice2(ft["msfvx"], b, i0=i0, i1=i0 + dims[0], j0=j0, j1=j0 + dims[4])[:phys_ny + 1, :phys_nx].astype(np.float64)
    c1h = ft["c1h"][k0 - b["kms"] : k0 - b["kms"] + phys_nz].astype(np.float64)
    c2h = ft["c2h"][k0 - b["kms"] : k0 - b["kms"] + phys_nz].astype(np.float64)
    lu = c1h[None, :, None] * muu[:, None, :] + c2h[None, :, None]
    lv = c1h[None, :, None] * muv[:, None, :] + c2h[None, :, None]
    u_conv = ft_state["u"][:phys_ny, :, :phys_nx + 1].astype(np.float64)
    v_conv = ft_state["v"][:phys_ny + 1, :, :phys_nx].astype(np.float64)
    ft_ru_tend = ft_ru_tend_storage[:phys_ny, :, :phys_nx + 1].astype(np.float64)
    ft_rv_tend = ft_rv_tend_storage[:phys_ny + 1, :, :phys_nx].astype(np.float64)
    ft_u_physical = fortran_tendency_to_physical(ft_ru_tend, u_conv, c1h, continuity["mu_u_dot"], msfuy, lu)
    ft_v_physical = fortran_tendency_to_physical(ft_rv_tend, v_conv, c1h, continuity["mu_v_dot"], msfvx, lv)
    cpp_u_physical = cpp_rhs["u"][:phys_ny, :, :phys_nx].astype(np.float64)
    cpp_v_physical = cpp_rhs["v"][1:phys_ny, :, :phys_nx].astype(np.float64)
    ft_mu = continuity["mu_dot"]
    cpp_mu = cpp_rhs["mu"][:phys_ny, 0, :phys_nx].astype(np.float64)
    report["flux_identity"] = continuity["flux_identity"]
    report["continuity"] = {
        "mu_dot_units": "Pa/s",
        "dmdt_rms": float(np.sqrt(np.mean(continuity["mu_components"]["dmdt"] ** 2))),
        "mu_tend_rms": float(np.sqrt(np.mean(continuity["mu_components"]["mu_tend"] ** 2))),
        "mu_dot_rms": float(np.sqrt(np.mean(ft_mu ** 2))),
        "owner_cells": int(ft_mu.size),
        "physical_nx_ny_nz": [phys_nx, phys_ny, phys_nz],
        "dmdt_flux_basis": "raw captured coupled RU/RV, not mass-inverted velocity",
    }
    report["comparisons"] = {
        "u": metrics(cpp_u_physical, ft_u_physical[:, :, :phys_nx], "m/s^2"),
        "v": metrics(cpp_v_physical, ft_v_physical[1:phys_ny, :, :], "m/s^2"),
        "mu": metrics(cpp_mu, ft_mu, "Pa/s"),
    }
    report["comparison_available"] = True
    report["reason"] = "all six state blocks match exactly and pointwise flux identities pass"
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fortran", type=Path, default=Path("wrf_full_rhs_snapshot.bin"), help="Fortran binary snapshot")
    parser.add_argument("--cpp", type=Path, default=Path("port_full_rhs_snapshot.bin"), help="C++ binary snapshot")
    parser.add_argument("--source-root", type=Path, default=DEFAULT_ROOT, help="target worktree used for source fingerprints")
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT, help="analysis JSON output")
    parser.add_argument("--self-check", action="store_true", help="run only the tiny manufactured formula checks")
    args = parser.parse_args()
    if args.self_check:
        print(json.dumps(manufactured_contract_checks(), indent=2, sort_keys=True))
        return 0
    try:
        report = analyze(args.fortran, args.cpp, args.source_root)
    except (OSError, SnapshotError, ValueError) as exc:
        report = {
            "schema": "wrf-cpp-full-rhs-same-state-analysis-v1",
            "comparison_available": False,
            "state_exact_match": False,
            "reason": str(exc),
            "provisional_error_budget": {"status": "not_adopted", "threshold": None},
            "inputs": {},
        }
        for label, path in (("fortran", args.fortran), ("cpp", args.cpp)):
            if path.is_file():
                report["inputs"][label] = file_receipt(path)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report.get("comparison_available") else 2


if __name__ == "__main__":
    raise SystemExit(main())
