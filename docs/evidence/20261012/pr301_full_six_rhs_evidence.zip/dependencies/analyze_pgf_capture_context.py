#!/usr/bin/env python3
"""Tie actual PGF captures to Full RHS states and compare captured operands."""
from __future__ import annotations

import argparse
import hashlib
import json
import struct
import sys
from pathlib import Path
from typing import Any

import numpy as np

ANALYZER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(ANALYZER_DIR))
import analyze_snapshots as AS  # noqa: E402

DEFAULT_RUNS = Path(__file__).parent / "captures/pgf_runs.json"
DEFAULT_OUT = Path(__file__).with_name("pgf_capture_context_analysis.json")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_ft_pgf(path: Path) -> tuple[dict[str, Any], dict[str, np.ndarray]]:
    data = path.read_bytes()
    if len(data) < 96:
        raise ValueError(f"truncated Fortran PGF header: {path}")
    header = struct.unpack_from("<I12i2i7f2i", data, 0)
    version, *rest = header
    bounds = tuple(rest[:12])
    rk_step, n_moist = rest[12:14]
    scalars = tuple(float(x) for x in rest[14:21])
    nonhydro, top_lid = rest[21:23]
    _, _, _, _, _, _, ims, ime, jms, jme, kms, kme = bounds
    ni, nj, nk = ime - ims + 1, jme - jms + 1, kme - kms + 1
    n3, n2 = ni * nj * nk, ni * nj
    fields = (
        ("ru_tend_before", 3), ("rv_tend_before", 3), ("u", 3), ("v", 3),
        ("w", 3), ("t", 3), ("ph", 3), ("mu", 2), ("p", 3), ("pb", 3),
        ("al", 3), ("alt", 3), ("php", 3), ("cqu", 3), ("muu", 2),
        ("c1h", 1), ("c2h", 1), ("msfux", 2), ("msfuy", 2), ("rdnw", 1),
        ("fnm", 1), ("fnp", 1), ("ru_tend_after", 3), ("rv_tend_after", 3),
    )
    expected = 96 + 4 * (15 * n3 + 4 * n2 + 5 * nk)
    if version != 1 or rk_step != 1 or min(ni, nj, nk) <= 0 or len(data) != expected:
        raise ValueError(f"invalid Fortran PGF schema: version={version}, rk_step={rk_step}, bytes={len(data)}/{expected}")
    arrays: dict[str, np.ndarray] = {}
    offset = 96
    for name, rank in fields:
        count = n3 if rank == 3 else n2 if rank == 2 else nk
        array = np.frombuffer(data, dtype="<f4", count=count, offset=offset)
        arrays[name] = array.reshape((nj, nk, ni)) if rank == 3 else array.reshape((nj, ni)) if rank == 2 else array
        offset += 4 * count
    bound_names = ("ids", "ide", "jds", "jde", "kds", "kde", "ims", "ime", "jms", "jme", "kms", "kme")
    return ({"path": str(path), "sha256": sha(path), "bytes": len(data), "version": version,
             "bounds": list(bounds), "bounds_dict": dict(zip(bound_names, bounds)), "rk_step": rk_step, "n_moist": n_moist,
             "rdx_rdy_cf1_cf2_cf3_cfn_cfn1": list(scalars),
             "nonhydrostatic": nonhydro, "top_lid": top_lid}, arrays)


def read_cpp_pgf(path: Path) -> tuple[dict[str, Any], dict[str, np.ndarray], dict[str, np.ndarray]]:
    data = path.read_bytes()
    if len(data) < 36:
        raise ValueError(f"truncated C++ PGF header: {path}")
    version, nx, ny, nz, nxu, nyv, nzw, nstate = struct.unpack_from("<8i", data, 0)
    native_nh, = struct.unpack_from("<i", data, 32)
    dims = (nx, ny, nz, nxu, nyv, nzw)
    if version != 2 or (nxu, nyv, nzw) != (nx + 1, ny + 1, nz + 1):
        raise ValueError(f"invalid C++ PGF header: {(version, *dims)}")
    shapes = AS.cpp_shapes(dims)
    expected_state = sum(int(np.prod(shapes[n])) for n in AS.CPP_BLOCKS)
    if nstate != expected_state:
        raise ValueError(f"C++ PGF state count mismatch: {nstate}/{expected_state}")
    offset = 36
    state: dict[str, np.ndarray] = {}
    for name in AS.CPP_BLOCKS:
        count = int(np.prod(shapes[name]))
        state[name] = np.frombuffer(data, dtype="<f8", count=count, offset=offset).reshape(shapes[name])
        offset += 8 * count
    u_shape = (ny, nz, nxu)
    outputs: dict[str, np.ndarray] = {}
    for name in ("coupled_pgf", "velocity_mass_u", "unscaled_pgf", "alpha_u"):
        outputs[name] = np.frombuffer(data, dtype="<f8", count=int(np.prod(u_shape)), offset=offset).reshape(u_shape)
        offset += 8 * int(np.prod(u_shape))
    if offset != len(data):
        raise ValueError(f"C++ PGF byte count mismatch: expected {offset}, got {len(data)}")
    return ({"path": str(path), "sha256": sha(path), "bytes": len(data), "version": version,
             "dimensions": list(dims), "state_count": nstate, "native_nonhydrostatic": native_nh}, state, outputs)


def read_cpp_operands(path: Path) -> tuple[dict[str, Any], dict[str, np.ndarray]]:
    data = path.read_bytes()
    if len(data) < 20:
        raise ValueError(f"truncated C++ PGF operand header: {path}")
    version, ny, nz, nx, nzw = struct.unpack_from("<5i", data, 0)
    if version != 1 or nzw != nz + 1:
        raise ValueError(f"invalid C++ operand header: {(version,ny,nz,nx,nzw)}")
    arrays: dict[str, np.ndarray] = {}
    offset = 20
    for name, shape in (("p_prime", (ny, nz, nx)), ("al_prime", (ny, nz, nx)),
                        ("alt", (ny, nz, nx)), ("ph", (ny, nzw, nx))):
        count = int(np.prod(shape))
        arrays[name] = np.frombuffer(data, dtype="<f8", count=count, offset=offset).reshape(shape)
        offset += 8 * count
    if offset != len(data):
        raise ValueError(f"C++ operand byte count mismatch: expected {offset}, got {len(data)}")
    return ({"path": str(path), "sha256": sha(path), "bytes": len(data), "version": version,
             "shape": [ny, nz, nx, nzw]}, arrays)


def equal_gate(a: dict[str, np.ndarray], b: dict[str, np.ndarray]) -> dict[str, Any]:
    fields = {}
    for name in AS.CPP_BLOCKS:
        x, y = np.asarray(a[name]), np.asarray(b[name])
        fields[name] = {"equal": x.shape == y.shape and bool(np.array_equal(x, y)),
                        "shape_left": list(x.shape), "shape_right": list(y.shape),
                        "mismatch_count": int(np.count_nonzero(x != y)) if x.shape == y.shape else None,
                        "left_sha256": hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest(),
                        "right_sha256": hashlib.sha256(np.ascontiguousarray(y).tobytes()).hexdigest()}
    return fields


def operand_metric(a: np.ndarray, b: np.ndarray) -> dict[str, Any]:
    x, y = np.asarray(a, dtype=np.float64), np.asarray(b, dtype=np.float64)
    if x.shape != y.shape:
        return {"shape_equal": False, "shape_ft": list(x.shape), "shape_cpp": list(y.shape)}
    d = x - y
    xrms = float(np.sqrt(np.mean(x * x)))
    rms = float(np.sqrt(np.mean(d * d)))
    return {"shape_equal": True, "shape": list(x.shape), "element_count": int(x.size),
            "finite_ft": bool(np.isfinite(x).all()), "finite_cpp": bool(np.isfinite(y).all()),
            "exact_equal": bool(np.array_equal(x, y)), "mismatch_count": int(np.count_nonzero(x != y)),
            "ft_rms": xrms, "abs_delta_rms": rms,
            "relative_delta_rms": rms / xrms if xrms else None,
            "relative_delta_status": "defined" if xrms else "undefined_zero_signal",
            "max_abs_delta": float(np.max(np.abs(d))) if d.size else 0.0}


def audit_case(run: dict[str, Any]) -> dict[str, Any]:
    folder = Path(run["workdir"])
    if run["method"] != "ARK3":
        return {"label": run["label"], "status": "native_capture_receipt_validated_by_runner"}
    paired_label = run["label"].replace("cpp_ark3", "fortran_rk3")
    all_runs = json.loads(DEFAULT_RUNS.read_text())["runs"]
    ft_run = next(item for item in all_runs if item["label"] == paired_label)
    ft_folder = Path(ft_run["workdir"])
    ft_full_meta, ft_full = AS.read_fortran(ft_folder / "wrf_full_rhs_snapshot.bin")
    cpp_full_meta, cpp_full_state, _ = AS.read_cpp(folder / "port_full_rhs_snapshot.bin")
    dims = tuple(cpp_full_meta["dims_nx_ny_nz_nxu_nyv_nzw"])
    ft_full_state = AS.logical_fortran_state(ft_full_meta, ft_full, dims)
    ft_pgf_meta, ft_pgf = read_ft_pgf(ft_folder / "wrf_u_pgf_snapshot.bin")
    cpp_pgf_meta, cpp_pgf_state, cpp_pgf_outputs = read_cpp_pgf(folder / "port_u_pgf_snapshot.bin")
    operands_meta, cpp_operands = read_cpp_operands(folder / "port_u_pgf_operands_snapshot.bin")
    # Tie each actual PGF call's saved state back to its same-run Full RHS capture.
    ft_pgf_state = AS.logical_fortran_state(
        {"bounds": ft_pgf_meta["bounds_dict"]},
        {"u2": ft_pgf["u"], "v2": ft_pgf["v"], "w2": ft_pgf["w"],
         "ph2": ft_pgf["ph"], "t2": ft_pgf["t"], "mu2": ft_pgf["mu"]}, dims)
    ft_to_full = equal_gate(ft_pgf_state, ft_full_state)
    cpp_to_full = equal_gate(cpp_pgf_state, cpp_full_state)
    ft_cpp_full_storage = equal_gate(ft_full_state, cpp_full_state)
    dims_tuple = tuple(cpp_pgf_meta["dimensions"])
    ft_owned = AS.physical_state(ft_pgf_state, dims_tuple)
    cpp_owned = AS.physical_state(cpp_pgf_state, dims_tuple)
    ft_cpp_owned = equal_gate(ft_owned, cpp_owned)
    seam = AS.periodic_u_seam_audit(ft_pgf_state, cpp_pgf_state, dims_tuple)

    bnd = ft_pgf_meta["bounds_dict"]
    ims, jms, kms = bnd["ims"], bnd["jms"], bnd["kms"]
    i0, j0, k0 = 1 - ims, 1 - jms, 1 - kms
    nx, ny, nz, nxu, nyv, nzw = dims_tuple
    ft_context = {
        "p_prime": ft_pgf["p"][j0:j0+ny, k0:k0+nz, i0:i0+nx],
        "al_prime": ft_pgf["al"][j0:j0+ny, k0:k0+nz, i0:i0+nx],
        "alt": ft_pgf["alt"][j0:j0+ny, k0:k0+nz, i0:i0+nx],
        "ph": ft_pgf["ph"][j0:j0+ny, k0:k0+nzw, i0:i0+nx],
    }
    context = {name: operand_metric(ft_context[name], cpp_operands[name]) for name in ft_context}
    finite = {
        "fortran_six_state": all(bool(np.isfinite(ft_pgf[name]).all()) for name in AS.CPP_BLOCKS),
        "cpp_six_state": all(bool(np.isfinite(cpp_pgf_state[name]).all()) for name in AS.CPP_BLOCKS),
        "fortran_pressure_context": all(bool(np.isfinite(ft_pgf[name]).all()) for name in ("p", "pb", "al", "alt", "ph", "php", "cqu")),
        "cpp_pressure_context": all(bool(np.isfinite(x).all()) for x in cpp_operands.values()),
        "cpp_pgf_blocks": all(bool(np.isfinite(x).all()) for x in cpp_pgf_outputs.values()),
        "cpp_velocity_mass_u_positive": bool((cpp_pgf_outputs["velocity_mass_u"] > 0).all()),
        "cpp_alpha_u_positive": bool((cpp_pgf_outputs["alpha_u"] > 0).all()),
    }
    state_pass = (
        all(v["equal"] for v in ft_to_full.values()) and
        all(v["equal"] for v in cpp_to_full.values()) and
        all(v["equal"] for v in ft_cpp_owned.values()) and
        all(seam[k] for k in ("fortran_first_equals_closing_face", "cpp_first_equals_closing_face", "fortran_cpp_closing_face_equal")) and
        int(ft_pgf_meta["nonhydrostatic"]) == int(cpp_pgf_meta["native_nonhydrostatic"])
    )
    return {
        "label": run["label"], "paired_fortran_label": paired_label,
        "fortran_pgf_snapshot": {"path": str(ft_folder / "wrf_u_pgf_snapshot.bin"), "sha256": sha(ft_folder / "wrf_u_pgf_snapshot.bin")},
        "cpp_pgf_snapshot": cpp_pgf_meta, "cpp_operand_snapshot": operands_meta,
        "state_gates": {
            "fortran_pgf_vs_fortran_full_rhs": ft_to_full,
            "cpp_pgf_vs_cpp_full_rhs": cpp_to_full,
            "fortran_full_vs_cpp_full": ft_cpp_full_storage,
            "fortran_vs_cpp_physical_owned_state": ft_cpp_owned,
            "periodic_u_seam": seam,
            "all_same_call_state_gates_pass": state_pass
        },
        "same_call_pressure_operand_comparison": context,
        "fortran_pgf_context_header": {
            "rk_step": ft_pgf_meta["rk_step"], "n_moist": ft_pgf_meta["n_moist"],
            "nonhydrostatic": ft_pgf_meta["nonhydrostatic"], "top_lid": ft_pgf_meta["top_lid"],
            "rdx_rdy_cf1_cf2_cf3_cfn_cfn1": ft_pgf_meta["rdx_rdy_cf1_cf2_cf3_cfn_cfn1"],
        },
        "cpp_native_nonhydrostatic": cpp_pgf_meta["native_nonhydrostatic"],
        "finite_and_mass_checks": finite,
        "status": "state_gates_pass" if state_pass and all(finite.values()) else "state_or_finite_gate_failed",
        "scope_note": "Offline state/context audit only. Operand differences are reported, not required to be zero; no PGF numerical parity or causal conclusion is made here.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, default=DEFAULT_RUNS)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()
    runs = json.loads(args.runs.read_text())
    if runs.get("status") != "completed" or len(runs.get("runs", [])) != 4:
        raise ValueError("expected completed four-run capture plan")
    results = [audit_case(run) for run in runs["runs"] if run["method"] == "ARK3"]
    out = {"schema": "pr298-same-state-pgf-context-audit-v1", "runs_receipt": str(args.runs),
           "runs_receipt_sha256": sha(args.runs), "source_head": runs["head"],
           "cases": results, "all_state_gates_pass": all(x["state_gates"]["all_same_call_state_gates_pass"] for x in results),
           "no_new_model_runs": True}
    args.out.write_text(json.dumps(out, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": "passed" if out["all_state_gates_pass"] else "failed",
                      "out": str(args.out), "cases": [x["label"] for x in results]}, sort_keys=True))
    return 0 if out["all_state_gates_pass"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
