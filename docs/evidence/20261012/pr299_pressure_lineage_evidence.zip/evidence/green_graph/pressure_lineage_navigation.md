# PR299 first-PG pressure lineage

Target `583e2a64c1879372c2e0a1b9f4770298a05ffd75` (tree `40ae0d116c8ab474e8481cf425b76f4bf2b868f5`) matches PR298 HEAD `622b43f`; 61 existing graph sources hash-match. Added only the six missing authoritative init/input/start files listed in the receipt; total pinned graph sources: 67.

For a normal nonrestart start, `med_initialdata_input` reads the initial `wrfinput` grid state, then calls `start_domain`; `start_domain_em` recalculates `grid%p` inside its nonrestart startup block at L846/L856 from `t_1`, `al+alb`, `pb`, and QV (or QVF=1 for moist-theta). That is the last explicit `grid%p` producer before the first `rk_tendency` call (`solve_em.F:L1159`, passing `grid%p` at L1170). For an idealized B-wave initial file, `main/ideal_em.F` calls `init_domain` and writes the resulting `wrfinput`; `module_initialize_ideal.F:init_domain_rk` initializes grid%p by the hydrostatic top value and downward recurrence at L1114/L1125. For a restart, the `start_domain_em` recomputation is skipped and the latest P comes from restart I/O via `input_restart -> input_wrf`; the exact P field mapping uses generated Registry metadata not added here.

Within a multi-stage RK call, `calc_p_rho_phi` at `solve_em.F:L3467` writes pressure after acoustic substeps before the next stage's `rk_tendency`; `calc_p_rho` at L1511/L2080 is an intermediate acoustic pressure/filter update that is overwritten. The later L4765 `calc_p_rho_phi` is the post-loop producer for following model time and is represented as a separate graph edge. The `module_em.F:L778` RK PGF call consumes the mass-level p′ with pb/ph/al/alt/php/cqu operands; the output accumulates into U-staggered `ru_tend`.

The Registry-generated `fine_stream_input.inc` and P-specific field mapping are omitted and marked as a graph gap. All edges remain navigation aids, not numerical proof; no tests, builds, or models were run.


## Registry T versus THM

`Registry/Registry.EM_COMMON:L220-L222` maps `th_phy_m_t0` to I/O name `T` (dry theta−T0) and prognostic `t` to I/O name `THM` (moist or dry theta by `use_theta_m`). `module_initialize_ideal.F:L1809` saves the dry field, then L1823 may convert `t_2` to moist theta. On first nonrestart startup, `start_em.F:L669` copies `t_2` to `t_1`; its P′ EOS at L846/L856 reads `t_1`. The only source path from T back to t_2 is the old-data fallback at L614 when t_2 is exactly zero and use_theta_m is off. Therefore updating T while retaining baseline THM does not by itself change the normal first-PG pressure input. The Registry file is manually bound; generated input mapping remains a gap.
