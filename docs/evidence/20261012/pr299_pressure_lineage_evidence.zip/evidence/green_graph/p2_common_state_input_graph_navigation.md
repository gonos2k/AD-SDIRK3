# PR299 common-state input P2 graph addition

Target `583e2a64c1879372c2e0a1b9f4770298a05ffd75` has no tracked diff from the pinned base. All 74 existing source hashes were verified; only `tools/make_wrf_common_state_input.py` (SHA-256 `81a4215a1a08712b6a3b162e7cbf0e85703c3659f253a30c5acd9638a18ddf6f`) and `tools/test_make_wrf_common_state_input.py` (SHA-256 `0b6ea3eaec821eaf8a04e45547dfc0ee8cae54cf0721c18d7f95f9ac468bbc68`) were copied and AST-extracted. The graph now has 76 exact target/mirror bindings; prior pressure-lineage and Registry mapping content were reused unchanged.

The utility and focused test are navigation additions only. No test, build, native executable, or model was run here. The previously saved test log is separate evidence and is not a result of this AST refresh.
