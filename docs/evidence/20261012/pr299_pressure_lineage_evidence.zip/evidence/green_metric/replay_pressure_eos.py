#!/usr/bin/env python3
"""Offline FP32/FP64 EOS replay from the two existing same-state PGF captures."""
from __future__ import annotations
import ctypes, ctypes.util, hashlib, json, sys
from pathlib import Path
import subprocess
import numpy as np
from netCDF4 import Dataset

ROOT=Path('/private/tmp/pr299-pressure-lineage-20261012')
EVIDENCE=Path('/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012')
CAPTURE=EVIDENCE/'green_build/captures/pgf'
RUNS=EVIDENCE/'green_build/captures/pgf_runs.json'
OUT=Path('/Users/yhlee/AD-SDIRK3-review-evidence/pressure-lineage-20261012/green_metric')
ORACLE_DIR=Path('/Users/yhlee/AD-SDIRK3-review-evidence/pressure-lineage-20261012/red_precision')
sys.path.insert(0,str(EVIDENCE/'green_build'))
import analyze_pgf_capture_context as CAP

RD=np.float32(287.0); CP=np.float32(np.float32(7.0)*RD/np.float32(2.0)); CV=np.float32(CP-RD)
P0=np.float32(100000.0); T0=np.float32(300.0)
CVPM_F=np.float32(-CV/CP); CP_OV_CV_F=np.float32(CP/CV)
CVPM_CPP64=-float(CV)/float(CP)
CP_OV_CV_CPP64=float(CP)/float(CV)
COEFF_F=np.float32(RD/P0); COEFF_CPP64=float(RD)/float(P0)


def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()
def rms(x):
    a=np.asarray(x,dtype=np.float64); return float(np.sqrt(np.mean(a*a)))
def stat(x):
    a=np.asarray(x,dtype=np.float64)
    return {'rms':rms(a),'max_abs':float(np.max(np.abs(a))),'mean':float(np.mean(a))}
def exact(a,b):
    x=np.asarray(a);y=np.asarray(b)
    return {'exact_count':int(np.count_nonzero(x==y)),'count':int(x.size),'fraction':float(np.mean(x==y)),'mismatch_count':int(np.count_nonzero(x!=y))}
def ordered_f32(a):
    u=np.asarray(a,dtype=np.float32).view(np.uint32).astype(np.int64)
    return np.where((u&0x80000000)!=0,0x80000000-(u&0x7fffffff),0x80000000+u)
def ulp_f32(a,b):
    d=np.abs(ordered_f32(a)-ordered_f32(b))
    return {'median':float(np.median(d)),'p95':float(np.percentile(d,95)),'max':int(d.max()),'exact_fraction':float(np.mean(d==0))}
def fadd(a,b):return np.add(np.asarray(a,dtype=np.float32),np.asarray(b,dtype=np.float32),dtype=np.float32)
def fsub(a,b):return np.subtract(np.asarray(a,dtype=np.float32),np.asarray(b,dtype=np.float32),dtype=np.float32)
def fmul(a,b):return np.multiply(np.asarray(a,dtype=np.float32),np.asarray(b,dtype=np.float32),dtype=np.float32)
def fdiv(a,b):return np.divide(np.asarray(a,dtype=np.float32),np.asarray(b,dtype=np.float32),dtype=np.float32)
def fpow(a,b):return np.asarray(np.power(np.asarray(a,dtype=np.float32),np.asarray(b,dtype=np.float32)),dtype=np.float32)
def powf_host(a,b):
    lib=ctypes.CDLL(ctypes.util.find_library('m') or None); fn=lib.powf
    fn.argtypes=(ctypes.c_float,ctypes.c_float);fn.restype=ctypes.c_float
    vec=np.vectorize(lambda x,y:fn(ctypes.c_float(float(x)),ctypes.c_float(float(y))),otypes=[np.float32])
    return vec(np.asarray(a,dtype=np.float32),np.asarray(b,dtype=np.float32))
def pressure_f32(t,al,alb,pb,pow_impl=fpow):
    # start_em.F:856 source grouping, qvf=1 for use_theta_m=1. This is the
    # scalar REAL32 EOS expression; all operators are explicitly rounded to F32.
    theta=fadd(T0,t); numerator=fmul(fmul(RD,theta),np.float32(1.0)); alt=fadd(al,alb); denominator=fmul(P0,alt)
    arg=fdiv(numerator,denominator); powered=np.asarray(pow_impl(arg,CP_OV_CV_F),dtype=np.float32)
    full=fmul(P0,powered); pprime=fsub(full,pb)
    return {'theta':theta,'alt':alt,'denominator':denominator,'eos_arg':arg,'p_full':full,'p_prime':pprime}
def pressure_f64(t,alt,pb,exponent=float(CP_OV_CV_F)):
    return float(P0)*np.power((float(RD)*(float(T0)+np.asarray(t,dtype=np.float64)))/(float(P0)*np.asarray(alt,dtype=np.float64)),exponent)-np.asarray(pb,dtype=np.float64)
def alb_f32(t_init,pb):
    # start_em.F:697 / module_initialize_ideal base-state formula, F32 operation order.
    theta=fadd(T0,t_init); ratio=fdiv(pb,P0); power=fpow(ratio,CVPM_F)
    return fmul(fmul(COEFF_F,theta),power)
def alb_f32_host_powf(t_init,pb):
    theta=fadd(T0,t_init); ratio=fdiv(pb,P0); power=powf_host(ratio,CVPM_F)
    return fmul(fmul(COEFF_F,theta),power)
def alb_cpp_tensor_f32(t_init,pb):
    # C++ shared EOS runs on F32 base tensors; wrapped double scalars cast to F32.
    theta=fadd(T0,t_init); ratio=fdiv(pb,P0); power=fpow(ratio,np.float32(CVPM_CPP64))
    coeff=np.float32(COEFF_CPP64)
    return fmul(fmul(coeff,theta),power)
def alb_f64(t_init,pb):
    theta=np.asarray(t_init,dtype=np.float64)+float(T0);ratio=np.asarray(pb,dtype=np.float64)/float(P0)
    return (float(RD)/float(P0))*theta*np.power(ratio,float(CVPM_F))
def alb_cpp_f64(t_init,pb):
    theta=np.asarray(t_init,dtype=np.float64)+float(T0);ratio=np.asarray(pb,dtype=np.float64)/float(P0)
    return (float(RD)/float(P0))*theta*np.power(ratio,CVPM_CPP64)
def pb_startem_f32(c3h,c4h,mub,ptop):
    return fadd(fadd(fmul(c3h,mub),c4h),ptop)
def grad_x(a):
    x=np.asarray(a,dtype=np.float64)
    return x-np.roll(x,1,axis=2)
def neighbor_sum_x(a):
    x=np.asarray(a,dtype=np.float64)
    return x+np.roll(x,1,axis=2)
def alt_dp_rate(delta_p,alt,msfux,rdx):
    # Physical U acceleration contribution from the source ALT*delta(P') term,
    # keeping ALT fixed: -1/2 rdx MSFUX (ALT_i+ALT_{i-1}) delta(P'_i-P'_{i-1}).
    return -0.5*float(rdx)*np.asarray(msfux,dtype=np.float64)*neighbor_sum_x(alt)*grad_x(delta_p)
def crop_ft(meta,fields,name):
    b=meta['bounds_dict'];j0=1-b['jms'];k0=1-b['kms'];i0=1-b['ims']
    return np.asarray(fields[name][j0:j0+16,k0:k0+16,i0:i0+16],dtype=np.float32)
def read_input(path):
    with Dataset(path) as ds:
        def get(name):
            a=np.asarray(ds.variables[name][0],dtype=np.float32)
            return a.transpose(1,0,2) if a.ndim==3 else a
        a={name:get(name) for name in ('PB','ALB','T_INIT','T','MUB','PHB','QVAPOR') if name in ds.variables}
        for name in ('C3H','C4H'):
            a[name]=np.asarray(ds.variables[name][0],dtype=np.float32)
        scalars={name:np.asarray(ds.variables[name][0]).item() for name in ('P_TOP','P00','T00') if name in ds.variables}
        attrs={name:ds.getncattr(name) for name in ('DX','DY') if name in ds.ncattrs()}
        return a,scalars,attrs

def run_case(name):
    pair='initial' if name=='initial' else 'stored'
    ft_dir=CAPTURE/f'{pair}_fortran_rk3_h15';cpp_dir=CAPTURE/f'{pair}_cpp_ark3_h15'
    ft_meta,ft=CAP.read_ft_pgf(ft_dir/'wrf_u_pgf_snapshot.bin')
    cpp_meta,cpp_state,cpp_outputs=CAP.read_cpp_pgf(cpp_dir/'port_u_pgf_snapshot.bin')
    op_meta,op=CAP.read_cpp_operands(cpp_dir/'port_u_pgf_operands_snapshot.bin')
    inp,scalars,attrs=read_input(ft_dir/'wrfinput_d01')
    ft_t=crop_ft(ft_meta,ft,'t'); ft_p=crop_ft(ft_meta,ft,'p'); ft_al=crop_ft(ft_meta,ft,'al'); ft_alt=crop_ft(ft_meta,ft,'alt'); ft_pb=crop_ft(ft_meta,ft,'pb')
    alb_input=inp['ALB']; pb_input=inp['PB']; t_init=inp['T_INIT']; qv=inp['QVAPOR']
    ny,nz,nx=16,16,16
    cpp_t=np.asarray(cpp_state['t'][:ny,:nz,:nx],dtype=np.float32)
    cpp_p=np.asarray(op['p_prime'][:ny,:nz,:nx],dtype=np.float64)
    cpp_al=np.asarray(op['al_prime'][:ny,:nz,:nx],dtype=np.float64)
    cpp_alt=np.asarray(op['alt'][:ny,:nz,:nx],dtype=np.float64)
    cpp_alb_effective=cpp_alt-cpp_al
    oracle_input_path=ORACLE_DIR/f'{name}_oracle_input.bin'
    oracle_output_path=ORACLE_DIR/f'{name}_oracle_output.bin'
    oracle_raw=np.fromfile(oracle_input_path,dtype='<f4').reshape(3,16,16,16)
    oracle_t,oracle_alt,oracle_pb=oracle_raw
    oracle_p=np.fromfile(oracle_output_path,dtype='<f4').reshape(16,16,16)
    oracle_inputs_exact={'T':exact(oracle_t,ft_t),'ALT':exact(oracle_alt,ft_alt),'PB':exact(oracle_pb,ft_pb)}
    oracle_pressure_exact=exact(oracle_p,ft_p)
    if not all(v['fraction']==1.0 for v in oracle_inputs_exact.values()) or oracle_pressure_exact['fraction']!=1.0:
        raise ValueError(f'{name}: compiler-compiled scalar oracle input/output mismatch')
    ft_formula=pressure_f32(ft_t,ft_al,alb_input,pb_input)
    ft_powf=pressure_f32(ft_t,ft_al,alb_input,pb_input,powf_host)
    ft_f64_same=pressure_f64(ft_t,ft_alt.astype(np.float64),pb_input.astype(np.float64),float(CP_OV_CV_F))
    cpp_f64_same=pressure_f64(cpp_t,cpp_alt,pb_input.astype(np.float64),CP_OV_CV_CPP64)
    # Startup source-state ALB/PB reconstruction, using stored T_INIT and grid fields.
    c3h=inp['C3H'][None,:,None];c4h=inp['C4H'][None,:,None];mub=inp['MUB'][:,None,:];ptop=np.float32(scalars['P_TOP'])
    pb_rebuilt=pb_startem_f32(c3h,c4h,mub,ptop)
    alb_startem=alb_f32(t_init,pb_input)
    alb_startem_powf=alb_f32_host_powf(t_init,pb_input)
    alb_cpp_base=alb_cpp_tensor_f32(t_init,pb_input)
    alb_double=alb_f64(t_init,pb_input)
    alb_cpp_double=alb_cpp_f64(t_init,pb_input)
    # Exact call operand checks and source-route facts.
    alt_from_ft_al=fadd(ft_al,alb_input)
    al_ft_effective=ft_alt.astype(np.float64)-ft_al.astype(np.float64)
    input_checks={
        'wrfinput_sha256':sha(ft_dir/'wrfinput_d01'),'input_base_PB_equals_capture_PB':exact(pb_input,ft_pb),
        'FT_captured_ALT_equals_F32_AL_plus_WRFINPUT_ALB':exact(ft_alt,alt_from_ft_al),
        'same_call_CPP_T_equals_FT_T':exact(cpp_t,ft_t),
        'WRFINPUT_PB_rebuilt_from_C3H_MUB_C4H_PTOP_F32':exact(pb_input,pb_rebuilt),
        'WRFINPUT_ALB_rebuilt_from_T_INIT_PB_F32':exact(alb_input,alb_startem),
        'WRFINPUT_ALB_rebuilt_by_host_powf_F32':exact(alb_input,alb_startem_powf),
        'QVAPOR_all_zero':bool(np.all(qv==0.0)),
        'n_moist_capture_header':ft_meta['n_moist'],'use_theta_m_namelist_output':1,
        'nonhydrostatic_capture_header':ft_meta['nonhydrostatic'],'top_lid_capture_header':ft_meta['top_lid'],
    }
    # Direct cross-path decomposition using double EOS replay, no fitted offset.
    p_ft_t_ft_alt_ft=pressure_f64(ft_t,ft_alt,pb_input.astype(np.float64),CP_OV_CV_CPP64)
    p_cpp_t_ft_alt_ft=pressure_f64(cpp_t,ft_alt,pb_input.astype(np.float64),CP_OV_CV_CPP64)
    p_ft_t_cpp_alt=pressure_f64(ft_t,cpp_alt,pb_input.astype(np.float64),CP_OV_CV_CPP64)
    p_cpp_t_cpp_alt=pressure_f64(cpp_t,cpp_alt,pb_input.astype(np.float64),CP_OV_CV_CPP64)
    delta_total=cpp_p-ft_p.astype(np.float64)
    # For CPP vs FT, split T and ALT substitutions in a fixed order; report cross term explicitly.
    delta_t=p_cpp_t_ft_alt_ft-p_ft_t_ft_alt_ft
    delta_alt=p_ft_t_cpp_alt-p_ft_t_ft_alt_ft
    delta_interaction=(p_cpp_t_cpp_alt-p_ft_t_ft_alt_ft)-delta_t-delta_alt
    # Exact pointwise telescope from captured cross-path pressures through the
    # fixed-order operand substitutions and same-FT-input precision contrast.
    delta_cpp_replay=cpp_p-cpp_f64_same
    delta_input_path=cpp_f64_same-p_ft_t_ft_alt_ft
    delta_exponent=p_ft_t_ft_alt_ft-ft_f64_same
    delta_precision=ft_f64_same-oracle_p.astype(np.float64)
    delta_ft_oracle=oracle_p.astype(np.float64)-ft_p.astype(np.float64)
    telescope=delta_cpp_replay+delta_input_path+delta_exponent+delta_precision+delta_ft_oracle
    telescope_residual=(cpp_p-ft_p.astype(np.float64))-telescope
    # Decompose effective ALT into dynamic AL and base ALB, holding FT T and PB.
    delta_alb_input=cpp_alb_effective-alb_input.astype(np.float64)
    delta_alb_call=cpp_alb_effective-al_ft_effective
    delta_al_pert=cpp_al-ft_al.astype(np.float64)
    p0=pressure_f64(ft_t,ft_alt.astype(np.float64),pb_input.astype(np.float64),CP_OV_CV_CPP64)
    p_baseonly=pressure_f64(ft_t,ft_alt.astype(np.float64)+delta_alb_call,pb_input.astype(np.float64),CP_OV_CV_CPP64)
    p_alonly=pressure_f64(ft_t,ft_alt.astype(np.float64)+delta_al_pert,pb_input.astype(np.float64),CP_OV_CV_CPP64)
    p_both=pressure_f64(ft_t,ft_alt.astype(np.float64)+delta_alb_call+delta_al_pert,pb_input.astype(np.float64),CP_OV_CV_CPP64)
    # Spatial pressure-gradient influence uses unique periodic U owners, including face 0.
    rdx=float(ft_meta['rdx_rdy_cf1_cf2_cf3_cfn_cfn1'][0])
    b=ft_meta['bounds_dict'];j0=1-b['jms'];i0=1-b['ims'];msfux=np.asarray(ft['msfux'][j0:j0+16,i0:i0+16],dtype=np.float32)
    alt_eos_error=ft_formula['p_prime'].astype(np.float64)-ft_p.astype(np.float64)
    cpp_ft_pressure_delta=cpp_p-ft_p.astype(np.float64)
    accel_f32_error=alt_dp_rate(alt_eos_error,ft_alt,msfux,rdx)
    accel_compiled_oracle_error=alt_dp_rate(oracle_p.astype(np.float64)-ft_p.astype(np.float64),ft_alt,msfux,rdx)
    accel_cross_pressure=alt_dp_rate(cpp_ft_pressure_delta,ft_alt,msfux,rdx)
    pressure_components={'cpp_replay_residual':delta_cpp_replay,'captured_operand_path':delta_input_path,
                         'cpp_exponent_vs_fortran_exponent':delta_exponent,'f64_vs_compiled_ft32':delta_precision,
                         'compiled_ft32_oracle_residual':delta_ft_oracle}
    gradient_components={name:{'pressure_gradient':stat(grad_x(delta)),
                               'FT_ALT_fixed_U_acceleration':stat(alt_dp_rate(delta,ft_alt,msfux,rdx))}
                         for name,delta in pressure_components.items()}
    sum_component_pressure=np.zeros_like(delta_total,dtype=np.float64)
    sum_component_gradient=np.zeros_like(delta_total,dtype=np.float64)
    sum_component_rate=np.zeros_like(delta_total,dtype=np.float64)
    for delta in pressure_components.values():
        sum_component_pressure+=delta
        sum_component_gradient+=grad_x(delta)
    component_rates={name:alt_dp_rate(delta,ft_alt,msfux,rdx) for name,delta in pressure_components.items()}
    for rate in component_rates.values():sum_component_rate+=rate
    full_pressure_gradient=grad_x(delta_total)
    full_pressure_accel=alt_dp_rate(delta_total,ft_alt,msfux,rdx)
    alpha_components={'base_ALB':p_baseonly-p0,'perturbation_AL_prime':p_alonly-p0,
                      'ALxALB_interaction':p_both-p_baseonly-p_alonly+p0}
    alpha_gradient_components={name:{'pressure_gradient':stat(grad_x(delta)),
                                     'FT_ALT_fixed_U_acceleration':stat(alt_dp_rate(delta,ft_alt,msfux,rdx))}
                               for name,delta in alpha_components.items()}
    # Save only bounded, pointwise arrays needed to reproduce the summary.
    arrays={
        f'{name}_ft_p_actual':ft_p,f'{name}_ft_p_f32_source_emulation':ft_formula['p_prime'],
        f'{name}_ft_p_host_powf_emulation':ft_powf['p_prime'],f'{name}_ft_p_f64_same_inputs':ft_f64_same,
        f'{name}_ft_p_compiled_start_em_oracle':oracle_p,
        f'{name}_cpp_p_actual':cpp_p,f'{name}_cpp_p_f64_replay':cpp_f64_same,
        f'{name}_ft_al':ft_al,f'{name}_ft_alt':ft_alt,f'{name}_cpp_al':cpp_al,f'{name}_cpp_alt':cpp_alt,
        f'{name}_alb_input':alb_input,f'{name}_alb_startem_f32':alb_startem,f'{name}_alb_cpp_f32_tensor':alb_cpp_base,
        f'{name}_alb_cpp_effective_capture':cpp_alb_effective,f'{name}_pgrad_f32_emulation_error_m_s2':accel_f32_error,
        f'{name}_pgrad_cpp_minus_ft_m_s2':accel_cross_pressure,
    }
    run_files=['wrf_u_pgf_snapshot.bin','wrf_full_rhs_snapshot.bin','wrf_rk_tend_dump.bin','wrfinput_d01']
    provenance={
        'fortran_run':{'label':f'{pair}_fortran_rk3_h15','input_sha256':sha(ft_dir/'wrfinput_d01'),'files':{f:sha(ft_dir/f) for f in run_files if (ft_dir/f).is_file()}},
        'cpp_run':{'label':f'{pair}_cpp_ark3_h15','input_sha256':sha(cpp_dir/'wrfinput_d01'),'files':{f:sha(cpp_dir/f) for f in ['port_u_pgf_snapshot.bin','port_u_pgf_operands_snapshot.bin','port_full_rhs_snapshot.bin'] if (cpp_dir/f).is_file()}},
        'source_lineage':{'fortran_actual_pressure':'dyn_em/start_em.F:814-862; archived ideal startup uses hypsometric option 1 and scalar REAL32 pressure assignment at :856, qvf=1. Separate gfortran oracle reproduces captured FT P bitwise on the exact call operands.','fortran_base_alpha':'dyn_em/start_em.F:690-703 (max_dom=1: PB from C3H*MUB+C4H+PTOP, then ALB from T_INIT/PB);','input_wrf_option':'share/input_wrf.F:1033-1038 forces hypsometric_opt=1 for ideal runs; archived RSL notes the effective option.','cpp_base_alpha':'external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp:30090-30112 and 19431-19432; external/libtorch_wrf/sdirk3/wrf_hydrostatic_pressure.cpp:205-227','constants':'share/module_model_constants.F:19-41; p0=100000, t0=300, rd=287, cp=1004.5, cv=717.5, cvpm=-cv/cp;'},
    }
    return {
      'label':name,'shape':[16,16,16],'owned_count':4096,'input_and_call_operand_checks':input_checks,
      'fortran_eos_source_order_f32_emulation':{
        'numpy_float32_operator':{'actual_capture_vs_emulation':stat(alt_eos_error),'exact_reproduction':exact(ft_formula['p_prime'],ft_p),'ulp':ulp_f32(ft_formula['p_prime'],ft_p)},
        'host_libm_powf_emulation':{'actual_capture_vs_emulation':stat(ft_powf['p_prime']-ft_p),'exact_reproduction':exact(ft_powf['p_prime'],ft_p),'ulp':ulp_f32(ft_powf['p_prime'],ft_p),'note':'host libm powf emulation; not the compiler-observable result'},
        'standalone_gfortran_start_em_scalar_oracle':{
          'source':str(ORACLE_DIR/'start_em_scalar_eos_oracle.f90'),'source_sha256':sha(ORACLE_DIR/'start_em_scalar_eos_oracle.f90'),
          'oracle_receipt':str(ORACLE_DIR/'oracle_comparison.json'),'oracle_receipt_sha256':sha(ORACLE_DIR/'oracle_comparison.json'),
          'inputs_exact_to_captured_FT':oracle_inputs_exact,'output_exact_to_captured_FT_P':oracle_pressure_exact,
          'compiler':'GNU Fortran 15.2.0','flags':['-O2','-ftree-vectorize','-funroll-loops']},
        'same_formula_f64_from_actual_FT_inputs':{'actual_capture_minus_replay':stat(ft_p.astype(np.float64)-ft_f64_same),'f64_minus_f32_source_emulation':stat(ft_f64_same-ft_formula['p_prime'].astype(np.float64)),'units':'Pa'},
        'operation_sequence':'start_em.F: p=p0*((rd*(t0+T)*qvf)/(p0*ALT))**cpovcv-PB, with qvf=1 and default REAL32. The separate gfortran scalar oracle uses this source grouping and matches actual captured pressure bitwise.',
      },
      'base_state_ALB_replay':{
        'Fortran_start_em_numpy_pow_f32_vs_WRFINPUT_ALB':{'difference':stat(alb_startem.astype(np.float64)-alb_input.astype(np.float64)),'exact_reproduction':exact(alb_startem,alb_input),'ulp':ulp_f32(alb_startem,alb_input)},
        'Fortran_start_em_host_powf_vs_WRFINPUT_ALB':{'difference':stat(alb_startem_powf.astype(np.float64)-alb_input.astype(np.float64)),'exact_reproduction':exact(alb_startem_powf,alb_input),'ulp':ulp_f32(alb_startem_powf,alb_input)},
        'C++_tensor_f32_replay_vs_effective_captured_ALB':{'difference':stat(alb_cpp_base.astype(np.float64)-cpp_alb_effective),'exact_reproduction':exact(alb_cpp_base,cpp_alb_effective),'ulp':ulp_f32(alb_cpp_base,cpp_alb_effective)},
        'C++_effective_ALB_minus_WRFINPUT_ALB':stat(cpp_alb_effective-alb_input.astype(np.float64)),
        'C++_effective_ALB_minus_FT_effective_ALT_minus_AL':stat(cpp_alb_effective-al_ft_effective),
        'F64_formula_from_same_WRFINPUT_operands_vs_FT_ALB':stat(alb_double-alb_input.astype(np.float64)),
        'C++_F64_base_formula_from_WRFINPUT_vs_effective_capture':stat(alb_cpp_double-cpp_alb_effective),
        'Fortran_actual_ALT_minus_AL_plus_base_ALB':stat(al_ft_effective-alb_input.astype(np.float64)),
        'CPP_minus_FT_call_operand_decomposition':{
          'AL_prime_difference_CPP_minus_FT':stat(cpp_al-ft_al.astype(np.float64)),
          'effective_ALB_difference_CPP_minus_FT':stat(cpp_alb_effective-alb_input.astype(np.float64)),
          'ALT_difference_CPP_minus_FT':stat(cpp_alt-ft_alt.astype(np.float64)),
          'ALT_difference_identity_residual':stat((cpp_alt-ft_alt.astype(np.float64))-(cpp_al-ft_al.astype(np.float64))-(cpp_alb_effective-alb_input.astype(np.float64)))},
      },
      'same_state_CPP_vs_FT_pressure_decomposition_f64':{
        'CPP_actual_minus_FT_actual':stat(cpp_p-ft_p.astype(np.float64)),
        'T_only_CPP_minus_FT_on_FT_ALT':stat(delta_t),
        'ALT_only_CPP_minus_FT_on_FT_T':stat(delta_alt),
        'T_ALT_interaction':stat(delta_interaction),
        'replay_total_on_actual_operands':stat((p_cpp_t_cpp_alt-p_ft_t_ft_alt_ft)),
        'CPP_actual_minus_own_source_replay':stat(cpp_p-cpp_f64_same),
        'FT_actual_minus_own_f64_replay':stat(ft_p.astype(np.float64)-ft_f64_same)},
      'exact_cross_pressure_telescope':{
        'sum_of_components':stat(telescope),'actual_CPP_minus_FT':stat(cpp_p-ft_p.astype(np.float64)),
        'identity_residual':stat(telescope_residual),
        'components':{
          'CPP_actual_minus_own_F64_replay':stat(delta_cpp_replay),
          'captured_operand_path_CPP_replay_minus_FT_operands_on_CPP_formula':stat(delta_input_path),
          'CPP_scalar_exponent_minus_Fortran_F32_exponent_on_same_FT_operands':stat(delta_exponent),
          'same_FT_operands_F64_minus_compiled_FT32_oracle':stat(delta_precision),
          'compiled_FT32_oracle_minus_captured_FT_pressure':stat(delta_ft_oracle)},
        'note':'Exact pointwise telescope; components depend on the stated replacement order.'},
      'AL_and_ALT_input_effects_at_fixed_FT_T_PB':{
        'base_ALB_change_only_CPP_minus_FT_call_effective':stat(p_baseonly-p0),
        'perturbation_AL_change_only_CPP_minus_FT':stat(p_alonly-p0),
        'combined_base_and_perturbation_interaction':stat(p_both-p_baseonly-p_alonly+p0),
        'full_ALT_change_CPP_minus_FT_at_FT_T':stat(p_ft_t_cpp_alt-p0),
        'full_T_and_ALT_change_CPP_minus_FT_on_common_F64_formula':stat(p_cpp_t_cpp_alt-p_ft_t_ft_alt_ft),
        'units':'Pa; counterfactual EOS evaluations on captured operands, not fitted shifts'},
      'spatial_gradient_effect':{
        'pressure_prime_CPP_minus_FT_gradient':stat(grad_x(cpp_p-ft_p.astype(np.float64))),'units_gradient':'Pa per x-face difference',
        'ALT_deltaP_physical_U_accel_CPP_minus_FT_with_FT_ALT_fixed':stat(accel_cross_pressure),'units':'m/s^2',
        'NumPy_F32_emulation_pressure_error_gradient':stat(grad_x(alt_eos_error)),
        'NumPy_F32_emulation_pressure_error_U_accel_with_FT_ALT_fixed':stat(accel_f32_error),
        'compiled_start_em_oracle_pressure_error_gradient':stat(grad_x(oracle_p.astype(np.float64)-ft_p.astype(np.float64))),
        'compiled_start_em_oracle_pressure_error_U_accel':stat(accel_compiled_oracle_error),
        'exact_telescope_component_gradients_and_U_accelerations':gradient_components,
        'telescope_gradient_identity':{'component_pressure_sum_minus_total':stat(sum_component_pressure-delta_total),
          'component_pressure_gradient_sum_minus_total_gradient':stat(sum_component_gradient-full_pressure_gradient),
          'component_U_acceleration_sum_minus_full':stat(sum_component_rate-full_pressure_accel),
          'sum_component_U_acceleration':stat(sum_component_rate),'full_CPP_minus_FT_U_acceleration':stat(full_pressure_accel)},
        'AL_ALT_input_change_gradients_and_U_accelerations':alpha_gradient_components,
        'rdx_m_inv':rdx,
        'owner_policy':'16x16x16 unique physical U owners; periodic x-gradient uses roll, retaining west face 0 and excluding duplicated close face'},
      'arrays':arrays,'provenance':provenance,
    }

def main():
    receipt=json.loads(RUNS.read_text())
    binding=json.loads((EVIDENCE/'producer_source_binding.json').read_text())
    cpp_run=next(r for r in receipt['runs'] if r['method']=='ARK3')
    producer_commit=binding['producer_commit']; producer_worktree=Path(receipt['worktree'])
    source_paths=('dyn_em/start_em.F','dyn_em/module_big_step_utilities_em.F','share/input_wrf.F',
                  'share/module_model_constants.F','external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp',
                  'external/libtorch_wrf/sdirk3/wrf_hydrostatic_pressure.cpp')
    source_hashes={}
    for rel in source_paths:
        captured=subprocess.check_output(['git','-C',str(producer_worktree),'show',f'{producer_commit}:{rel}'])
        current=(ROOT/rel).read_bytes()
        source_hashes[rel]={'captured_run_commit_sha256':hashlib.sha256(captured).hexdigest(),
                            'current_pr299_base_sha256':hashlib.sha256(current).hexdigest(),
                            'byte_identical':captured==current}
    cases={name:run_case(name) for name in ('initial','stored')}
    arrays={}
    for name,case in cases.items():arrays.update(case.pop('arrays'))
    npz=OUT/'pressure_eos_replay_arrays.npz';np.savez_compressed(npz,**arrays)
    out={
      'schema':'pressure-lineage-offline-eos-replay-v1','worktree_base':'583e2a64c1879372c2e0a1b9f4770298a05ffd75',
      'scope':'Two existing initial/stored same-state captures only; no model run, WRF build, source edit, or new compiler microkernel. NumPy/host-powf are labeled emulations; an already archived standalone gfortran scalar oracle compiled at the same recorded flags matches the 8192 captured FT P values bitwise.',
      'analysis_script':{'path':str(Path(__file__).resolve()),'sha256':sha(Path(__file__).resolve())},
      'capture_receipt':{'path':str(RUNS),'sha256':sha(RUNS),'captured_producer_head':receipt['head'],'producer_source_binding':str(EVIDENCE/'producer_source_binding.json'),'producer_source_binding_sha256':sha(EVIDENCE/'producer_source_binding.json')},
      'source_hash_binding':{'captured_producer_commit':producer_commit,'current_analysis_worktree':str(ROOT),'files':source_hashes,'all_files_match_producer_commit':all(x['byte_identical'] for x in source_hashes.values())},
      'constants':{'rd_f32':float(RD),'cp_f32':float(CP),'cv_f32':float(CV),'p0_f32':float(P0),'t0_f32':float(T0),'cvpm_f32':float(CVPM_F),'cpovcv_f32':float(CP_OV_CV_F),'cvpm_cpp64':CVPM_CPP64,'coefficient_f32':float(COEFF_F),'coefficient_cpp64':COEFF_CPP64},
      'actual_route_evidence':{'effective_hypsometric_opt':1,'source':'share/input_wrf.F:1033-1038 ideal-run override and archived initial RSL note; start_em.F:814-862 option-1 AL and scalar pressure initialization. The archived standalone gfortran scalar oracle exactly matches captured FT P using the same captured T/ALT/PB arrays for both states.','start_em_alb_route':'start_em.F:690-703 for max_dom=1 reconstructs PB and ALB from T_INIT/PB before the option-1 AL and pressure assignment.','cpp_runtime_precision':cpp_run['effective_runtime_config']['effective_cpp_flags'],'cpp_runtime_precision_note':'Captured C++ route logs internal_fp64=true and internal_fp64_state_carry=true; the C++ base-alpha and pressure captures match their FP64 replays to numerical precision.'},
      'interpretation_limits':['NumPy float32 and host libm powf rows are software emulations; the separately archived gfortran scalar oracle provides compiler-observable expression output and matches the captured FT P bitwise, but does not expose a full-WRF internal pre-subtraction Pfull intermediate.','The F64 replay uses the same captured FP32 operands and source algebra; it is a precision contrast, not an exact-solution estimate.','The C++-versus-FT ALT decomposition distinguishes captured AL-prime and effective ALB call inputs. Differences between effective CPP ALB and raw WRFINPUT ALB are compared against the source-derived base-state replay; any remaining torch/system-power implementation detail is not attributed.','No full forecast or WRF build was performed; this EOS replay does not claim total PGF/RHS closure.'],
      'cases':cases,
      'arrays':{'path':str(npz),'sha256':sha(npz),'count':len(arrays),'dtype':'float32/float64 as labeled by variable name'},
    }
    path=OUT/'pressure_eos_replay.json';path.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'out':str(path),'npz':str(npz),'cases':{k:{'compiled_start_em_oracle_exact_fraction':v['fortran_eos_source_order_f32_emulation']['standalone_gfortran_start_em_scalar_oracle']['output_exact_to_captured_FT_P']['fraction'],'numpy_f32_exact_fraction':v['fortran_eos_source_order_f32_emulation']['numpy_float32_operator']['exact_reproduction']['fraction'],'host_powf_exact_fraction':v['fortran_eos_source_order_f32_emulation']['host_libm_powf_emulation']['exact_reproduction']['fraction'],'alb_startem_numpy_exact_fraction':v['base_state_ALB_replay']['Fortran_start_em_numpy_pow_f32_vs_WRFINPUT_ALB']['exact_reproduction']['fraction'],'cpp_alb_minus_input_rms':v['base_state_ALB_replay']['C++_effective_ALB_minus_WRFINPUT_ALB']['rms'],'cpp_ft_p_rms':v['same_state_CPP_vs_FT_pressure_decomposition_f64']['CPP_actual_minus_FT_actual']['rms'],'u_accel_pressure_path':v['spatial_gradient_effect']['ALT_deltaP_physical_U_accel_CPP_minus_FT_with_FT_ALT_fixed']['rms']} for k,v in cases.items()}},indent=2))
if __name__=='__main__':main()
