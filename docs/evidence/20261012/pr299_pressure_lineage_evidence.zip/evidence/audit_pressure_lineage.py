#!/usr/bin/env python3
"""Read-only audit of WRFINPUT pressure fields versus actual captured FT U-PGF inputs."""
from __future__ import annotations
import hashlib, json, struct
from pathlib import Path
import numpy as np
from netCDF4 import Dataset

E=Path('/Users/yhlee/AD-SDIRK3-review-evidence/pressure-lineage-20261012')
OLD=Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-rhs-contract-20261011')
CAP=Path('/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012/green_build/captures/pgf')
RUNS=OLD/'initial_snapshot_runs.json'
OUT=E/'pressure_lineage_audit.json'

def sha(p:Path)->str:
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1<<20),b''):h.update(block)
 return h.hexdigest()
def stats(d):
 x=np.asarray(d,dtype=np.float64)
 return {'count':int(x.size),'rms':float(np.sqrt(np.mean(x*x))) if x.size else 0.,'max_abs':float(np.max(np.abs(x))) if x.size else 0.}
def digest_array(a):return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()

def read_ft_pgf(path:Path):
 data=path.read_bytes()
 if len(data)<96:raise ValueError('short FT PGF header')
 ver,=struct.unpack_from('<i',data,0)
 if ver!=1:raise ValueError(f'FT PGF schema {ver}')
 bounds=struct.unpack_from('<12i',data,4)
 ids,ide,jds,jde,kds,kde,ims,ime,jms,jme,kms,kme=map(int,bounds)
 ni,nj,nk=ime-ims+1,jme-jms+1,kme-kms+1
 n3=ni*nj*nk;n2=ni*nj;off=96;fields={};shape3=(nj,nk,ni)
 # Exact source WRITE order in dyn_em/module_em.F:768-770.
 for name in ('ru_before','rv_before','u','v','w','t','ph'):
  fields[name]=np.frombuffer(data,dtype='<f4',count=n3,offset=off).reshape(shape3).copy();off+=4*n3
 fields['mu']=np.frombuffer(data,dtype='<f4',count=n2,offset=off).reshape((nj,ni)).copy();off+=4*n2
 for name in ('p','pb','al','alt','php','cqu'):
  fields[name]=np.frombuffer(data,dtype='<f4',count=n3,offset=off).reshape(shape3).copy();off+=4*n3
 fields['muu']=np.frombuffer(data,dtype='<f4',count=n2,offset=off).reshape((nj,ni)).copy();off+=4*n2
 for name in ('c1h','c2h'):
  off+=4*nk
 for name in ('msfux','msfuy'):
  off+=4*n2
 for name in ('rdnw','fnm','fnp'):
  off+=4*nk
 off+=2*n3*4
 if off!=len(data):raise ValueError(f'FT PGF parse ended at {off}, file length={len(data)}')
 b=dict(zip(('ids','ide','jds','jde','kds','kde','ims','ime','jms','jme','kms','kme'),bounds))
 return {'bounds':b,'fields':fields,'receipt':{'path':str(path),'bytes':len(data),'sha256':sha(path)}}

VAR_MAP={'P':'p','PB':'pb','AL':'al','ALT':'alt','THM':'t','PH':'ph','MU':'mu'}

def input_var(ds,name):
 if name not in ds.variables:return None
 v=ds.variables[name]
 return {'dimensions':list(v.dimensions),'shape':list(v.shape),'dtype':str(v.dtype),
         'attrs':{a:str(getattr(v,a)) for a in ('units','description','stagger','coordinates') if a in v.ncattrs()},
         'values':np.asarray(v[0])}
def actual_phys(ft,name):
 b=ft['bounds'];a=ft['fields'];nx,ny,nz=b['ide']-b['ids'],b['jde']-b['jds'],b['kde']-b['kds']
 i0=b['ids']-b['ims'];j0=b['jds']-b['jms'];k0=b['kds']-b['kms']
 if name=='MU':return a['mu'][j0:j0+ny,i0:i0+nx]
 nlev=nz+1 if name=='PH' else nz
 return a[VAR_MAP[name].lower()][j0:j0+ny,k0:k0+nlev,i0:i0+nx]
def input_phys(raw,name):
 x=raw['values']
 return np.transpose(x,(1,0,2)) if x.ndim==3 else x

def main():
 record=json.loads(RUNS.read_text())
 gen=record['stored_state_input']
 source=Path(gen['source_path']); stored=OLD/'initial_snapshot_runs/stored_state_input/wrfinput_d01'
 initial=OLD/'initial_snapshot_runs/sdirk_h15_dump_off/wrfinput_d01'
 source_run=CAP/'stored_fortran_rk3_h15/wrfinput_d01'
 record_sha=sha(RUNS)
 if not source.is_file() or sha(source)!=gen['source_sha256']:
  raise ValueError('recorded archived 60-s WRFOUT source is absent or its hash differs')
 if not stored.is_file() or sha(stored)!=gen['input_sha256']:
  raise ValueError('recorded stored WRF input is absent or its hash differs')
 if not initial.is_file() or sha(initial)!=record['original_input_sha256']:
  raise ValueError('baseline WRF input copy is absent or its recorded hash differs')
 # Confirm each stored input field designated as replaced matches its archived source frame.
 replaced_check={}
 with Dataset(source) as src, Dataset(stored) as dst:
  times=[b''.join(row.tolist()).decode('ascii') for row in src['Times'][:]]
  if times.count(gen['source_timestamp'])!=1:raise ValueError('stored source time is not unique in source WRFOUT')
  ti=times.index(gen['source_timestamp'])
  for name,meta in gen['replaced_arrays'].items():
   a=np.asarray(src[name][ti]);b=np.asarray(dst[name][0])
   equal=(a.dtype==b.dtype and a.shape==b.shape and np.array_equal(a,b))
   if not equal:raise ValueError(f'stored input replacement failed source match: {name}')
   replaced_check[name]={'source_time_index':ti,'dtype':str(a.dtype),'shape':list(a.shape),
    'source_sha256':digest_array(a),'input_sha256':digest_array(b),'exact_equal':True,
    'generation_record_source_hash_equal':digest_array(a)==meta['source_array_sha256'],
    'generation_record_input_hash_equal':digest_array(b)==meta['input_array_sha256']}
  for name,expected in gen['preserved_arrays_sha256'].items():
   if name not in dst.variables:raise ValueError(f'preserved variable missing in stored input: {name}')
   if digest_array(np.asarray(dst[name][:]))!=expected:raise ValueError(f'preserved variable changed from generator record: {name}')
 # Verify the WRFOUT used to build the input and preserved source record independently.
 source_var_receipt={}
 with Dataset(source) as src:
  ti=times.index(gen['source_timestamp'])
  for name in ('P','PB','AL','ALT','THM','T','PH','MU'):
   if name not in src.variables:
    source_var_receipt[name]={'present':False,'status':'not present in archived source frame'}
   else:
    v=src.variables[name];arr=np.asarray(v[ti])
    source_var_receipt[name]={'present':True,'dtype':str(v.dtype),'dimensions':list(v.dimensions),
      'shape':list(arr.shape),'units':getattr(v,'units',None),'data_sha256':digest_array(arr)}
 with Dataset(source) as src, Dataset(stored) as dst:
  source_thm=np.asarray(src['THM'][ti]);stored_thm=np.asarray(dst['THM'][0])
  thm_delta=source_thm.astype(np.float64)-stored_thm.astype(np.float64)
  gen_preserved_thm=gen['preserved_arrays_sha256'].get('THM')
  preserved_thm_sha=digest_array(np.asarray(dst['THM'][:]))
  source_thm_vs_input={'source_time_index':ti,'shape':list(source_thm.shape),'dtype':str(source_thm.dtype),
   'source_array_sha256':digest_array(source_thm),'stored_input_array_sha256':digest_array(stored_thm),
   'exact_equal':bool(source_thm.dtype==stored_thm.dtype and np.array_equal(source_thm,stored_thm)),
   'mismatch_count':int(np.count_nonzero(source_thm!=stored_thm)),'difference_source_minus_stored':stats(thm_delta),
   'stored_input_THM_is_preserved_base_field':gen_preserved_thm is not None,
   'stored_input_THM_full_variable_sha_matches_generation_record':preserved_thm_sha==gen_preserved_thm,
   'generation_record_preserved_THM_sha256':gen_preserved_thm}

 cases={}
 for label,run_label,input_path in (('initial','initial_fortran_rk3_h15',initial),('stored','stored_fortran_rk3_h15',stored)):
  ftdir=CAP/run_label;pgf=read_ft_pgf(ftdir/'wrf_u_pgf_snapshot.bin');actual={};raw_meta={}
  with Dataset(input_path) as ds:
   diag_t=input_var(ds,'T')
   diagnostic_t={'present':diag_t is not None}
   if diag_t is not None:
    diagnostic_t={'present':True,'dimensions':diag_t['dimensions'],'shape':diag_t['shape'],'dtype':diag_t['dtype'],
     'attrs':diag_t['attrs'],'time0_array_sha256':digest_array(diag_t['values']),
     'role':'WRF diagnostic th_phy_m_t0 mapped to NetCDF T; not the dynamic state t field used in the PGF capture'}
   for name in ('P','PB','AL','ALT','THM','PH','MU'):
    raw=input_var(ds,name)
    if raw is None:
     raw_meta[name]={'present':False,'status':'not present in WRFINPUT'};continue
    x=input_phys(raw,name);y=actual_phys(pgf,name)
    if x.shape!=y.shape:raise ValueError(f'{label} {name} physical shape differs: input={x.shape}, capture={y.shape}')
    d=x.astype(np.float64)-y.astype(np.float64)
    actual[name]={'input_vs_ft_call_exact':bool(x.dtype==y.dtype and np.array_equal(x,y)),
      'element_count':int(x.size),'dtype_input':str(x.dtype),'dtype_ft_capture':str(y.dtype),
      'input_array_sha256':digest_array(x),'ft_capture_array_sha256':digest_array(y),
      'input_minus_ft_capture':stats(d)}
    raw_meta[name]={'present':True,'dimensions':raw['dimensions'],'shape':raw['shape'],'dtype':raw['dtype'],'attrs':raw['attrs']}
  cases[label]={'input':{'path':str(input_path),'bytes':input_path.stat().st_size,'sha256':sha(input_path),
      'matches_capture_run_input_bytes':input_path.read_bytes()==(ftdir/'wrfinput_d01').read_bytes()},
    'actual_ft_pgf_capture':pgf['receipt'],'physical_mask':{'mass_shape_jki':[16,16,16],'mass_element_count':4096,'mask':'j=0..15,k=0..15,i=0..15; variables on PH use 17 vertical levels and MU is 2-D'},
    'wrfinput_variable_metadata':raw_meta,'input_vs_actual_ft_call':actual,'wrfinput_diagnostic_T':diagnostic_t}
 runtime_theta_m={}
 for run_label in ('initial_fortran_rk3_h15','stored_fortran_rk3_h15'):
  nmlout=CAP/run_label/'namelist.output';text=nmlout.read_text(errors='replace')
  matched='USE_THETA_M=1' in text
  if not matched:raise ValueError(f'captured namelist output does not record USE_THETA_M=1: {nmlout}')
  runtime_theta_m[run_label]={'namelist_output_path':str(nmlout),'sha256':sha(nmlout),'effective_namelist_output_has_use_theta_m_1':True}
 stored_run_labels=('stored_fortran_rk3_h15','stored_cpp_ark3_h15')
 stored_capture_input_checks={label:{'path':str(CAP/label/'wrfinput_d01'),
   'sha256':sha(CAP/label/'wrfinput_d01'),
   'exact_file_match_to_generator_output':(CAP/label/'wrfinput_d01').read_bytes()==stored.read_bytes()} for label in stored_run_labels}

 out={'schema':'wrfinput-pressure-lineage-v1','scope':'Read-only raw-input/call-capture comparison; no EOS producer inference.',
  'worktree':{'path':'/private/tmp/pr299-pressure-lineage-20261012','head':'583e2a64c1879372c2e0a1b9f4770298a05ffd75','status':'clean at inspection'},
  'source_lineage':{'generator_record':{'path':str(RUNS),'sha256':record_sha},
    'generator_recipe':{'path':str(OLD/'run_snapshot_validation.py'),'sha256':sha(OLD/'run_snapshot_validation.py')},
    'baseline_input':{'recorded_original_path':record['original_input_path'],'recorded_sha256':record['original_input_sha256'],
      'available_copy':str(initial),'available_copy_sha256':sha(initial),'matches_recorded_original':sha(initial)==record['original_input_sha256']},
    'stored_source_wrfout':{'path':str(source),'sha256':sha(source),'recorded_sha256':gen['source_sha256'],
      'timestamp':gen['source_timestamp'],'time_index':1,'time_zero_reinitialized':gen['reinitialized_time_zero'],
      'source_variables':source_var_receipt},
    'stored_modified_input':{'path':str(stored),'sha256':sha(stored),'recorded_sha256':gen['input_sha256'],
      'capture_run_input_file_checks':stored_capture_input_checks,
      'replaced_arrays_exact_to_source_frame':replaced_check,
      'generation_record_preserved_array_count':len(gen['preserved_arrays_sha256']),
      'preserved_hashes_revalidated':True,'unavailable_optional_arrays_recorded':gen['unavailable_optional_arrays']},
    'input_generation_record_copy':{'path':str(E/'stored_input_generation_record.json'),'sha256':sha(E/'stored_input_generation_record.json'),
      'byte_identical_to_source_record':(E/'stored_input_generation_record.json').read_bytes()==RUNS.read_bytes()},
    'generation_recipe_copy':{'path':str(E/'stored_input_generation_recipe.py'),'sha256':sha(E/'stored_input_generation_recipe.py')}},
  'source_mapping':{'registry_bindings':{'Registry/Registry.EM_COMMON:220':'th_phy_m_t0 writes NetCDF T (diagnostic perturbation theta)','Registry/Registry.EM_COMMON:221':'dynamic state t writes NetCDF THM (theta_m field, conditional on use_theta_m)'},'runtime_namelist_receipts':runtime_theta_m,'start_em':'dyn_em/start_em.F:602-614 contains the old-input guard and loads grid%t_2 from grid%th_phy_m_t0 only for old zero-T input; this is not the regular THM mapping.','source_sha256':{'Registry/Registry.EM_COMMON':sha(Path('/private/tmp/pr299-pressure-lineage-20261012/Registry/Registry.EM_COMMON')),'dyn_em/start_em.F':sha(Path('/private/tmp/pr299-pressure-lineage-20261012/dyn_em/start_em.F'))}},
  'cases':cases,
  'stored_THM_source_vs_preserved_input':source_thm_vs_input,
  'interpretation_limits':['WRFINPUT P is not bitwise equal to the actual first-call FT p capture in either case; PB is bitwise equal.',
    'Stored THM, the runtime field corresponding to captured dynamic t, is preserved from the initial base input; it is exact to the stored FT capture but differs from the 60-s source WRFOUT THM. The generation script replaces diagnostic T, not THM. This is a mixed-time stored input fixture, not a production-code defect conclusion.',
    'Stored P/diagnostic T/PH/MU are source-replaced variables from the recorded 60-s WRFOUT; PB/AL/THM are preserved base-input variables; ALT is absent in WRFINPUT.',
    'The field comparisons establish equality/non-equality only. They do not identify the Fortran P or AL producer expression, operation order, or pressure history.']}
 OUT.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
 print(OUT)
if __name__=='__main__':main()
