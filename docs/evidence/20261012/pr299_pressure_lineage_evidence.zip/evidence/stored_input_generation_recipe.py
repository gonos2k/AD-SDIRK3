#!/usr/bin/env python3
"""Run and compare full-RHS diagnostic controls on the archived em_b_wave input."""
from __future__ import annotations

import hashlib, json, math, os, re, shutil, subprocess, sys, time
from pathlib import Path
import numpy as np
from netCDF4 import Dataset

ROOT = Path("/private/tmp/pr295-full-rhs-20261011")
BASE = Path("/Users/yhlee/Documents/AD-SDIRK3-worktree-archive/20261005/native_wave_refinement/wrf_runs/signfix_fp64_carry_on15_240")
EVIDENCE = Path("/Users/yhlee/AD-SDIRK3-review-evidence/full-rhs-contract-20261011")
OUT = EVIDENCE / "initial_snapshot_runs"
REF = Path("/Users/yhlee/AD-SDIRK3-review-evidence/same-state-rhs-20261011/wrf_validation/reference_snapshots")
ANALYSIS = Path("/Users/yhlee/AD-SDIRK3-review-evidence/same-state-rhs-20261011")
INPUT_SHA = "e71b730a12e5a16d181f404f6314e7904e0165eefa622ffd0c508bf8c00dd2a9"
SOURCES = ("dyn_em/solve_em.F", "dyn_em/module_em.F", "dyn_em/module_small_step_em.F",
           "dyn_em/module_implicit_sdirk3.F", "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp")
INITIAL_CASES = (("rk3_h3p75_dump_on", 3.75, "RK3", 1),
                 ("sdirk_h15_dump_on", 15.0, "SDIRK3", 1),
                 ("sdirk_h15_dump_off", 15.0, "SDIRK3", 0))
STORED_CASES = (("stored_rk3_h15_dump_on", "RK3"), ("stored_sdirk_h15_dump_on", "SDIRK3"))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def set_int(text: str, key: str, value: int) -> str:
    text, count = re.subn(r"(\b" + re.escape(key) + r"\s*=\s*)[-+0-9]+",
                          lambda m: m[1] + str(value), text, count=1, flags=re.I)
    if count != 1:
        raise ValueError(f"missing namelist key {key}")
    return text


def prepare_stored_input(manifest: dict, input_path: Path) -> dict:
    """Copy the archived 60-s RK3 state into a time-zero input; keep static fields."""
    spec = manifest["snapshots"]["pr292_rk3_h3p75"]
    source_item = next((row for row in spec["wrfout_files"] if "00:00:00" in row["name"]), None)
    source = REF / "pr292_rk3_h3p75" / source_item["name"] if source_item else None
    if source is None or not source.is_file() or sha(source) != source_item["sha256"]:
        raise ValueError("archived RK3 snapshot containing 60 s is missing or changed")
    state_names = ("U", "V", "W", "PH", "T", "MU", "P")
    receipt = {"source_path": str(source), "source_sha256": sha(source),
               "source_timestamp": "0001-01-01_00:01:00", "reinitialized_time_zero": True,
               "replaced_arrays": {}, "preserved_arrays_sha256": {}}
    shutil.copy2(BASE / "wrfinput_d01", input_path)
    with Dataset(source) as old, Dataset(input_path, "r+") as new:
        times = [b"".join(row.tolist()).decode("ascii") for row in old["Times"][:]]
        if times.count(receipt["source_timestamp"]) != 1: raise ValueError("60-s archived frame not unique")
        ti = times.index(receipt["source_timestamp"])
        names = list(state_names) + [n for n in ("AL", "ALT") if n in old.variables and n in new.variables]
        if any(n not in old.variables or n not in new.variables for n in state_names):
            raise ValueError("archived frame or wrfinput lacks one of U,V,W,PH,T,MU,P")
        for name in new.variables:
            if name not in names:
                receipt["preserved_arrays_sha256"][name] = hashlib.sha256(
                    np.ascontiguousarray(new[name][:]).tobytes()).hexdigest()
        for name in names:
            src, dst = np.asarray(old[name][ti]), new[name]
            if src.shape != dst.shape[1:]: raise ValueError(f"{name}: snapshot/input stagger shape differs")
            dst[0] = src
            receipt["replaced_arrays"][name] = {"shape": list(src.shape), "dtype": str(src.dtype),
                "units": getattr(old[name], "units", None),
                "source_dimensions": list(old[name].dimensions),
                "input_dimensions": list(dst.dimensions), "source_variable": name,
                "source_time_index": ti, "source_array_sha256": hashlib.sha256(src.tobytes()).hexdigest(),
                "input_array_sha256": hashlib.sha256(np.asarray(dst[0]).tobytes()).hexdigest(),
                "exact_source_match": bool(np.array_equal(src, dst[0]))}
        receipt["unavailable_optional_arrays"] = [n for n in ("AL", "ALT") if n not in names]
        for name, expected in receipt["preserved_arrays_sha256"].items():
            actual = hashlib.sha256(np.ascontiguousarray(new[name][:]).tobytes()).hexdigest()
            if actual != expected: raise ValueError(f"static input array unexpectedly changed: {name}")
    receipt["input_path"], receipt["input_sha256"] = str(input_path), sha(input_path)
    if not all(item["exact_source_match"] for item in receipt["replaced_arrays"].values()):
        raise ValueError("stored-state input did not exactly match archived RK3 60-s arrays")
    return receipt


def compare_entry_states(a: Path, b: Path, fields: tuple[str, ...]) -> dict:
    result = {}
    with Dataset(a) as left, Dataset(b) as right:
        for name in fields:
            x, y = np.asarray(left[name][0]), np.asarray(right[name][0])
            exact = x.shape == y.shape and x.dtype == y.dtype and np.array_equal(x, y)
            result[name] = {"shape": list(x.shape), "dtype": str(x.dtype),
                            "exact_equal": bool(exact),
                            "sha256": hashlib.sha256(x.tobytes()).hexdigest()}
            if not exact: raise ValueError(f"stored RK3/CPP entry state differs for {name}")
    return result


def stage_case(label: str, h: float, method: str, dump: int, duration: int,
               input_src: Path, nml_src: Path, diag_src: Path, exe: Path, env: dict,
               plan: dict, plan_path: Path) -> tuple[dict, dict, list[str]]:
    folder = OUT / label
    folder.mkdir()
    shutil.copy2(input_src, folder / "wrfinput_d01")
    shutil.copy2(diag_src, folder / "diagnostics.txt")
    for table in ("LANDUSE.TBL", "VEGPARM.TBL", "SOILPARM.TBL", "GENPARM.TBL"):
        source = ROOT / "run" / table
        if source.exists(): (folder / table).symlink_to(source)
    whole, frac = math.floor(h), round((h - math.floor(h)) * 8)
    text = nml_src.read_text()
    for key, value in (("time_step", whole), ("time_step_fract_num", frac),
                       ("time_step_fract_den", 8 if frac else 1), ("run_seconds", duration),
                       ("rk_ord", 3), ("time_integration_scheme", 0 if method == "RK3" else 6),
                       ("sdirk3_debug_level", 2)):
        text = set_int(text, key, value)
    (folder / "namelist.input").write_text(text)
    command = ["/usr/bin/time", "-l", "-o", str(folder / "time.log"),
               "/opt/homebrew/bin/mpirun", "-np", "1", "--bind-to", "none", str(exe)]
    row = {"label": label, "path": str(folder), "h_seconds": h, "method": method,
           "duration_seconds": duration, "reinitialized_from_stored_state": duration == 15,
           "input_sha256": sha(folder / "wrfinput_d01"), "namelist_sha256": sha(folder / "namelist.input"),
           "diagnostics_sha256": sha(folder / "diagnostics.txt"),
           "static_table_sha256": {t: sha(ROOT / "run" / t) for t in ("LANDUSE.TBL", "VEGPARM.TBL", "SOILPARM.TBL", "GENPARM.TBL") if (ROOT / "run" / t).is_file()},
           "executable_path": str(exe), "executable_sha256": plan["executable_sha256"],
           "source_revision": plan["revision"], "source_sha256": plan["source_sha256"],
           "sdirk3_debug_level": 2, "dump_flag": dump, "mpi_ranks": 1, "omp_threads": 1,
           "diagnostic_env": "WRF_PARITY_RK_TEND_DUMP=1" if dump else "unset",
           "command": command, "status": "staged"}
    plan["runs"].append(row); plan_path.write_text(json.dumps(plan, indent=2) + "\n")
    run_env = dict(env)
    if dump: run_env["WRF_PARITY_RK_TEND_DUMP"] = "1"
    return row, run_env, command


def run_case(row: dict, run_env: dict, command: list[str], plan: dict, plan_path: Path) -> None:
    folder = Path(row["path"]); row["status"] = "running"
    plan_path.write_text(json.dumps(plan, indent=2) + "\n")
    start = time.monotonic()
    with (folder / "run.log").open("wb") as log:
        result = subprocess.run(command, cwd=folder, env=run_env, stdout=log,
                                 stderr=subprocess.STDOUT, timeout=1800)
    row.update(return_code=result.returncode, wall_seconds=time.monotonic() - start)
    err = (folder / "rsl.error.0000").read_text(errors="replace") if (folder / "rsl.error.0000").exists() else ""
    out = (folder / "rsl.out.0000").read_text(errors="replace") if (folder / "rsl.out.0000").exists() else ""
    route = "SDIRK3 Zero-Copy: Calling actual solver" in (err + out) or "SDIRK3 implicit time integration" in (err + out)
    row["actual_cpp_sdirk_route"] = route
    expect = {"wrf_rk_tend_dump.bin": bool(row["dump_flag"] and row["method"] == "RK3"),
              "wrf_full_rhs_snapshot.bin": bool(row["dump_flag"] and row["method"] == "RK3"),
              "port_full_rhs_snapshot.bin": bool(row["dump_flag"] and row["method"] == "SDIRK3"),
              "port_k_slow_dump.bin": False}  # split-explicit dump is absent in ARK mode 3
    row["trace_artifacts"] = {n: {"expected": yes, "present": (folder / n).is_file(),
        "sha256": sha(folder / n) if (folder / n).is_file() else None} for n, yes in expect.items()}
    row["namelist_output_sha256"] = sha(folder / "namelist.output") if (folder / "namelist.output").is_file() else None
    row["rsl_out_sha256"] = sha(folder / "rsl.out.0000") if (folder / "rsl.out.0000").is_file() else None
    row["rsl_error_sha256"] = sha(folder / "rsl.error.0000") if (folder / "rsl.error.0000").is_file() else None
    row["time_log_sha256"] = sha(folder / "time.log") if (folder / "time.log").is_file() else None
    row["status"] = "completed" if result.returncode == 0 and "SUCCESS COMPLETE" in err and route == (row["method"] == "SDIRK3") and all(v["expected"] == v["present"] for v in row["trace_artifacts"].values()) else "failed"
    plan_path.write_text(json.dumps(plan, indent=2) + "\n")
    if row["status"] != "completed": raise RuntimeError(f"native WRF run/trace check failed: {row['label']}")
    print(row["label"], row["status"], row["wall_seconds"], flush=True)


def main() -> int:
    exe, input_src = ROOT / "main/wrf.exe", BASE / "wrfinput_d01"
    nml_src, diag_src = BASE / "namelist.input", BASE / "diagnostics.txt"
    manifest_path, plan_path = REF / "reference_snapshots.json", EVIDENCE / "initial_snapshot_runs.json"
    labels = [c[0] for c in INITIAL_CASES] + [c[0] for c in STORED_CASES]
    if not exe.is_file() or sha(input_src) != INPUT_SHA or not nml_src.is_file():
        raise ValueError("built wrf.exe or exact archived input/namelist is missing")
    if not manifest_path.is_file() or OUT.exists() or plan_path.exists():
        raise FileExistsError("snapshot output/receipt already exists or archive manifest is missing")
    if any((OUT / label).exists() for label in labels):
        raise FileExistsError("a case folder already exists; refusing partial/old results")
    manifest = json.loads(manifest_path.read_text())
    if manifest["source_plan_input_sha256"] != INPUT_SHA:
        raise ValueError("archived field snapshots do not use the required initial input")
    sys.path.insert(0, str(ROOT / "tools"))
    import benchmark_wrf_accuracy_cost as benchmark
    sys.path.insert(0, str(ANALYSIS))
    import analyze_wrf_wind_base_validation as analysis

    status = subprocess.check_output(["git", "status", "--short", "--untracked-files=no"], cwd=ROOT, text=True)
    diff = subprocess.check_output(["git", "diff", "--binary", "HEAD", "--", *SOURCES], cwd=ROOT)
    plan = {"schema": "full-rhs-snapshot-validation-v1", "status": "running",
            "target_worktree": str(ROOT), "revision": subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
            "worktree_status_tracked_only": status, "tracked_source_diff_sha256": hashlib.sha256(diff).hexdigest(),
            "source_sha256": {p: sha(ROOT / p) for p in SOURCES},
            "build_config_path": str(ROOT / "configure.wrf"),
            "build_config_sha256": sha(ROOT / "configure.wrf"),
            "executable_path": str(exe), "executable_sha256": sha(exe),
            "diagnostics_sha256": sha(diag_src),
            "original_input_path": str(input_src), "original_input_sha256": sha(input_src),
            "source_namelist_sha256": sha(nml_src), "debug_level": 2,
            "initial_duration_seconds": 240, "stored_snapshot_duration_seconds": 15,
            "omp_threads": 1, "mpi_ranks": 1,
            "environment_prefixes_removed": ["WRF_SDIRK3_", "WRF_PARITY_"], "runs": []}
    OUT.mkdir(parents=True)
    plan_path.write_text(json.dumps(plan, indent=2) + "\n")
    env = {k: v for k, v in os.environ.items()
           if not k.startswith(("WRF_SDIRK3_", "WRF_PARITY_"))}
    env.update(OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1",
               VECLIB_MAXIMUM_THREADS="1")
    try:
        staged = []
        for label, h, method, dump in INITIAL_CASES:
            staged.append(stage_case(label, h, method, dump, 240, input_src,
                                     nml_src, diag_src, exe, env, plan, plan_path))
        for row, run_env, command in staged: run_case(row, run_env, command, plan, plan_path)

        stored_path = OUT / "stored_state_input" / "wrfinput_d01"
        stored_path.parent.mkdir()
        plan["stored_state_input"] = prepare_stored_input(manifest, stored_path)
        staged = []
        for label, method in STORED_CASES:
            staged.append(stage_case(label, 15.0, method, 1, 15, stored_path,
                                     nml_src, diag_src, exe, env, plan, plan_path))
        fields = ("U", "V", "W", "PH", "T", "MU")
        gate = compare_entry_states(Path(staged[0][0]["path"]) / "wrfinput_d01",
                                    Path(staged[1][0]["path"]) / "wrfinput_d01", fields)
        plan["stored_state_entry_gate"] = {"fields": gate, "all_six_exact": True,
            "origin": "archived Fortran RK3 h=3.75 at 60 s copied into a time-zero wrfinput",
            "interpretation": "separate reinitialized diagnostic with autonomous coefficients; not a warm trajectory"}
        plan_path.write_text(json.dumps(plan, indent=2) + "\n")
        for row, run_env, command in staged: run_case(row, run_env, command, plan, plan_path)

        _, _, rk, _ = analysis._run_by_label(plan_path, "rk3_h3p75_dump_on", benchmark)
        _, _, on, _ = analysis._run_by_label(plan_path, "sdirk_h15_dump_on", benchmark)
        _, _, off, _ = analysis._run_by_label(plan_path, "sdirk_h15_dump_off", benchmark)
        _, _, archived, _ = analysis._snapshot_run(manifest_path, "pr292_rk3_h3p75", benchmark)
        comparison = {"rk3_h3p75_vs_archived": analysis._compare_runs(
                          rk, archived, benchmark.VARIABLE_UNITS, ("new RK3", "archived RK3")),
                      "sdirk_dump_on_vs_off": analysis._compare_runs(
                          on, off, benchmark.VARIABLE_UNITS, ("dump on", "dump off"))}
        if any(len(c["times"]) != 5 for c in comparison.values()) or not all(c["all_fields_all_times_exact_equal"] for c in comparison.values()):
            raise RuntimeError("six-field/five-time exact parity check failed")
        plan["comparisons"] = comparison
        plan["status"] = "completed"
        plan_path.write_text(json.dumps(plan, indent=2) + "\n")
        print(json.dumps({"status": plan["status"], "plan": str(plan_path),
            "initial_comparisons": {k: v["all_fields_all_times_exact_equal"] for k, v in comparison.items()},
            "stored_entry_gate": plan["stored_state_entry_gate"]["all_six_exact"]}, sort_keys=True))
        return 0
    except Exception as exc:
        plan["status"], plan["failure"] = "failed", f"{type(exc).__name__}: {exc}"
        plan_path.write_text(json.dumps(plan, indent=2) + "\n")
        raise


if __name__ == "__main__":
    raise SystemExit(main())
