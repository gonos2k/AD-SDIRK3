# PR299 actual Full U-PGF pressure lineage audit

Target: `/private/tmp/pr299-pressure-lineage-20261012` at `583e2a64c1879372c2e0a1b9f4770298a05ffd75`. This audit is read-only. It adds no build, test, or model run.

## Effective Fortran pressure path

The nominal `namelist.output` records `HYPSOMETRIC_OPT=2` at line 1210. WRF overrides that setting for ideal input: `share/input_wrf.F:1032-1039` sets both `grid%hypsometric_opt` and `config_flags%hypsometric_opt` to 1, and the paired run logs the same note at `rsl.out.0000:77` and `rsl.error.0000:78`. Therefore option 1 is the effective first-RK path.

For the single-domain ideal case, `start_em.F:690-701` constructs base pressure and base inverse density from `MUB`, `T_INIT`, `t0`, and the base EOS. It then sets the first prognostic state to `t_1=t_2`, `ph_1=ph_2`, and `MU_1=MU_2` at `:660-688`. The startup diagnostic at `:813-862` uses option 1 to compute `grid%al`, then computes `grid%p` with the nonlinear equation of state and sets `grid%alt=grid%al+grid%alb`. This first-call `start_em` pressure uses Fortran `**cpovcv`; the later `calc_p_rho_phi` path uses `VPOW` in its moist-array loop. The actual first PGF therefore compares the C++ tensor `torch::pow` path with the startup expression, not the later VPOW producer.

The first `rk_tendency` call is at `solve_em.F:1158-1170`. Between startup and that call, `rk_phys_bc_dry_1` may update `p` halos (`solve_em.F:1002-1009`, `module_bc_em.F:960-1021`); the called physical-boundary helper updates periodic/symmetric halo indices, not the physical interior EOS pressure. `rk_step_prep` takes `p` as `INTENT(IN)` (`solve_em.F:933-947`, `module_em.F:90-91`). The later `calc_p_rho_phi` update occurs after that stage at `solve_em.F:3465-3477`; for subsequent large-step stages it uses the same effective option-1 family in `module_big_step_utilities_em.F:1023-1032,1061-1080`. The first PGF operand is not the small-step, temporally linearized `module_small_step_em.calc_p_rho` pressure/filter state, which starts after this PGF (`solve_em.F:1470-1523`).

The relevant option-1 equations are

```text
L       = c1h * (MUB + MU') + c2h
alpha'  = -[ALB * c1h * MU' + RDNW * (PH'(k+1)-PH'(k))] / L
ALT     = alpha' + ALB
P'      = P0 * [RD * (T0 + T') / (P0 * ALT)]^(CP/CV) - PB
```

WRF's `RDNW` is negative. `QVAPOR` is all zero in both paired input files, so the Fortran moisture factor is exactly 1 here. The actual PGF capture also has `cqu==1` and records `n_moist=2`, `non_hydrostatic=true`, and `top_lid=false`.

## C++ Full-mode path and base-state source

`computeUnifiedRHS` Step 5 computes the PGF pressure inputs at the actual RK-stage state. At [wrf_sdirk3_tile_unified_impl.cpp](/private/tmp/pr299-pressure-lineage-20261012/external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp:19431), it builds `alb_mass` from `th_base_` and `p_base_`, then calls `calc_p_rho_wrf(ph,t,mu,mu_base_,alb_mass,p_base_,...)` and uses its `p_pert`, `al_pert`, and `alt` at `:19433-19438`.

The same-call base setter receives WRF `PB`, `T_INIT`, `PHB`, and `MUB` in `module_implicit_sdirk3.F:870-875`. The paired namelist has `CYCLING=F` and `REBALANCE=0` (`namelist.output:40,1205`), so `start_em` executes its ordinary startup diagnosis branch before the first RK tendency. C++ copies PB/MUB and forms absolute base theta as `T_INIT+300` in `setBaseState` (`wrf_sdirk3_tile_unified_impl.cpp:29975-30038,30090-30112,30163-30187`). The base-alpha helper is an EOS over theta and pressure in `wrf_hydrostatic_pressure.cpp:205-227`; this Full-PGF path does not derive base alpha geometrically from PHB and does not receive the Fortran `ALB` pointer. PHB is a separate input for the nonhydrostatic `PHP` term.

`calc_p_rho_wrf` (`wrf_hydrostatic_pressure.h:83-112`) uses `muts=mu_base+mu`, the same option-1 geometric alpha-prime equation, `ALT=alpha'+ALB`, and the dry nonlinear EOS. It converts WRF's positive stored reciprocal metric back to negative `rdnw_wrf`. The helper takes its output dtype from PH, uses differentiable tensor casts to float64 scratch, and casts its outputs back to that input dtype. The source has no detach on this production path. Physical constants are `RD=287`, `CP=1004.5`, `CV=717.5`, `P0=100000` (`wrf_sdirk3_tile_unified.h:1500-1505`) and `T0=300` (`wrf_sdirk3_tile_unified_impl.cpp:609`).

## Actual captured operands

The PR298 captures are paired by the exact six-field input gate; both call-local state vectors match their Full-RHS snapshots. The runs read the preserved `wrfinput_d01` (`mediation_wrfmain.f90:54-90,228-235` → `start_domain.F:132`); they did not execute `ideal.exe`. Source order attributes the physical interior `p` to `start_em`; `rk_phys_bc_dry_1` supplies only boundary halos before the first PGF. The runtime capture is the direct evidence for the actual call-time values. The C++ run reports `SDIRK3_IMEX_SPLIT_MODE=3` in `namelist.output:1862` and `[IMEX MODE=3]` in `rsl.error.0000:1013`; the PGF observer itself is gated to the first eligible `RhsMode::Full` call. The Fortran capture is immediately around the actual `horizontal_pressure_gradient` call (`module_em.F:749-796`); the C++ sidecar is from the actual Full U-PGF call.

| Capture | C++ P′ vs Fortran P′ RMS | Max absolute difference | C++ alpha′ vs Fortran alpha′ RMS | C++ ALT vs Fortran ALT RMS | PH equality |
|---|---:|---:|---:|---:|---|
| Initial | 0.00480874 Pa | 0.0192626 Pa | 2.7760e-9 | 1.5020e-7 | bitwise exact |
| Stored | 0.00514604 Pa | 0.0242311 Pa | 2.8597e-9 | 1.6451e-7 | bitwise exact |

These measurements are from `red_arrays/initial_u_pgf_delta_analysis.json` and `stored_u_pgf_delta_analysis.json`, under their exact same-call state gates. Captured C++ p′ values are the actual `p_pert_mass` produced by `calc_p_rho_wrf`; they are not reconstructed from a forecast.

## Open numerical attribution

The effective source equations are the same option-1 family in this ideal dry case. The actual captured p′ arrays are close but not bitwise equal, and the ALT discrepancy is materially larger than the alpha-prime discrepancy. This leaves a plausible base-alpha recomputation/addition sensitivity to check, but this source audit does not prove it is the producer. The C++ base-alpha path is an EOS recomputation from PB/T_INIT; the WRF startup stores ALB using its own default-REAL expression. GreenMetric is independently replaying those exact startup inputs. The remaining p′ difference also needs the separate dtype/power/rounding audit before attributing it to a specific arithmetic operation. The source-order last-writer trace does not include a runtime log of the assignment itself; the PGF snapshot supplies the call-time p/al values.

This conclusion is specific to the effective option-1 ideal run. It does not establish equivalence when option 2 is effective in a nonideal case.

## Evidence pins

- PR298 capture/run plan: `green_build/captures/pgf_runs.json`, SHA-256 `1aa3941d591dbcd6f8f18858c83b6b2b1eaf1a04e97ee25cf9d68d5e8c00606a`.
- Captured-operand analysis: `red_arrays/initial_u_pgf_delta_analysis.json`, SHA-256 `120db960c051b8f1f041fbe1421fead596f776ff314ba6181101996e030f1b3a`; stored analysis SHA-256 `01e2adee82a8aecbc5f7cb11ec34f875c3cb0ed893c0c1c42269dde10e263d32`.
- C++ implementation used by the capture: `wrf_sdirk3_tile_unified_impl.cpp` SHA-256 `473a9b5affe2e1251a85fa113bb4beb9087dce81a6860a594276ece0a347d3e8`.
- Initial/stored `wrfinput_d01` hashes: `e71b730a12e5a16d181f404f6314e7904e0165eefa622ffd0c508bf8c00dd2a9` / `90bec3e95b2b98c9281d5b0ffbd7a16124e9611273b8a7318056ef8337b8aea4`.
