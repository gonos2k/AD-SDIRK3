# Red source audit: first-PGF pressure lineage

Target: `/private/tmp/pr299-pressure-lineage-20261012`, base `583e2a64c1879372c2e0a1b9f4770298a05ffd75`. Read-only review; no builds or model runs. Scope is the actual first RK1 U-PGF call and its pressure history, not later-stage or alternate physics generalization.

## Finding

For the captured initial ideal `em_b_wave` input, the effective startup branch is `hypsometric_opt=1`, even though `namelist.output` prints `HYPSOMETRIC_OPT=2`. This is an intentional input-control override: `share/input_wrf.F:1020-1044` checks the input file's ideal-run metadata, sets both `grid%hypsometric_opt` and `config_flags%hypsometric_opt` to 1, publishes the value through `nl_set_hypsometric_opt`, and logs “Ideal cases always use hypsometric_opt=1”. The captured run logs contain that exact note (for example `u-pgf-same-state-20261012/green_build/captures/pgf/initial_fortran_rk3_h15/rsl.out.0000:77`); the same run's `namelist.output:1210` retains the requested value 2. Therefore the namelist value alone is not evidence of the formula branch. The input file's `SIMULATION_INITIALIZATION_TYPE` metadata and actual runtime note settle it as ideal/option 1.

`start_em.F:814-852` is the final startup writer for perturbation pressure on the ordinary first-trip path. After the initial/input state and base fields are available, the option-1 branch diagnoses `grid%al` from geopotential and base/moisture terms; it then writes

`grid%p = p1000mb * ( Rd*(t0+T)*qvf / (p1000mb*(al+alb)) )**(cpovcv) - pb`,

where `qvf=1+rvovrd*QV` when `use_theta_m==0`, otherwise 1. The subsequent `p_hyd`/`alt` assignments do not modify `grid%p`. Even if Registry input has populated `P`, this first-trip startup formula supersedes it for this ideal initial run. This is a single-precision Fortran `REAL` path in the archived build/capture schema, so the last-writer calculation is not an FP64 EOS evaluation.

The first `rk_tendency` call occurs in `solve_em.F:1159`; its `horizontal_pressure_gradient` is invoked from `module_em.F:778`. Before that call, there is no `calc_p_rho` in the first RK iteration. The first such pressure writer is `solve_em.F:1511`, `small_step_prep`'s `calc_p_rho(...,step=0)`, which is reached only after `rk_tendency`; later acoustic passes call it at about :2080 and apply the configured `smdiv` pressure filter (`module_small_step_em.F:548-567`). Thus the first PGF operand is the pressure left by startup, not the current stage's acoustic recomputation/filter. This review found no pre-PGF hidden `grid%p` writer in the first-RK path. That statement is scoped to the ordinary, non-restart first-timestep run represented by the captures; pressure history for a resumed restart or later RK stage is different.

The captured Fortran PGF files are actual call-site `grid%p`, not a reconstructed `calc_p_rho` result. Existing run receipts identify the first calls as `rk_step=1` under RK3 and matching input hashes. On the same physical call, archived cross-language analysis reports pressure operands differ by about `4.81e-3 Pa RMS` initially and `5.15e-3 Pa RMS` for the stored input, while `ph` is bitwise equal. The Fortran startup's REAL precision and the C++ FP64 internal route are therefore relevant when interpreting these small operand deltas, but this audit does not attribute the residual to EOS/precision. The PR298 same-call state and whole-PGF component checks remain the evidence for their limited cold-start scope; this review does not reopen or broaden those conclusions.

## Source/evidence anchors

- `share/input_wrf.F:1020-1044`: ideal-run detection and effective `hypsometric_opt=1` override.
- `dyn_em/start_em.F:814-852`: option-controlled startup `al` and final `grid%p` formula.
- `dyn_em/solve_em.F:1159`, `dyn_em/module_em.F:778`: first-RK PGF call path.
- `dyn_em/solve_em.F:1511`, `:2080`; `dyn_em/module_small_step_em.F:548-567`: later pressure recomputation and filtering.
- Actual captures: `u-pgf-same-state-20261012/green_build/captures/pgf/{initial_fortran_rk3_h15,stored_fortran_rk3_h15}/wrf_u_pgf_snapshot.bin`; run/input/config receipts in `green_build/captures/pgf_runs.json`; actual hypsometric override note in the corresponding `rsl.out.0000` and requested namelist value in `namelist.output`.

Verdict: no hidden pre-first-PGF pressure-history/control path contradicts the actual call-site capture. The meaningful correction is that the configured namelist value 2 is overridden to effective option 1 for these ideal inputs; pressure at first PGF is the startup reconstruction above. Later RK stages, restart history, and a pure EOS explanation remain outside this finding.
