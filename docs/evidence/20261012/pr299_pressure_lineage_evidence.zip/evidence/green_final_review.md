# Green final review of PR299 pressure-lineage report

Reviewed `/private/tmp/pr299-pressure-lineage-20261012/docs/(202610121247)_pr299_pressure_lineage_and_state_input.md` against the frozen source, captured call data, scalar-oracle/telescope records, and the final Red math review. This was read-only; no new tests, native calls, or source changes.

No concrete errors found in the report's central claims:

- The first-call startup route and effective ideal-input override agree with `input_wrf.F:1022-1039`, `start_em.F:690-703, 814-864`, and the archived RSL log. The scalar Fortran EOS oracle reproduces the two captured Fortran pressure fields exactly, while its stated operand limitation is clear.
- The option-1 EOS family is distinguished from bitwise/operator parity: captured C++ and Fortran pressure differ, their arithmetic and operand paths are identified separately, and the report does not treat a pressure replay as full PGF/RHS closure or as proof that every AL/ALB intermediate matches.
- The exact telescope is supported by the preserved vectors and reports zero identity residual. Its component RMS values are appropriately not summed as if they were additive scalars. The fixed-ALT acceleration decomposition is labeled as a sensitivity, not as the complete changed PGF.
- “No production equation correction is justified” is appropriately scoped to this evidence: same formula family, reproduced Fortran startup pressure, and unresolved full-RHS/stage/forecast questions. It does not claim bitwise equivalence or overall solver correctness.
- The mixed-time stored input is explicitly downgraded as a complete 60-second prognostic checkpoint; the old stored-call residual is preserved and interpreted only for that actual call state. The new helper creates a separate cold input and is not presented as a warm restart or a new native result.

No remaining blocking correction is identified. Existing separate scopes remain open as the report states: full six-equation parity, integrated derivatives, later-stage pressure/history, and forecast qualification.
