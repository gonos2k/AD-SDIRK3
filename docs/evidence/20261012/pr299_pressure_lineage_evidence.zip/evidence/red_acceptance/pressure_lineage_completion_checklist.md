# PR299 narrow pressure-lineage completion checklist

Local timestamp: 2026-10-12 12:31:38 JST (+0900)

## Fixed scope

This checklist closes only pressure provenance/reproduction and the captured
same-state U-PGF contribution for the two preserved dry 16³ em_b_wave inputs.
It does not select a forecast goal, certify the complete spatial operator,
explain the RK3 reference failure, or assert forecast improvement. Frozen V3
remains unchanged: its h=0.9375 versus h=1.875 reference gate fails all 24
field/checkpoint rows; the global project target remains unadopted.

## Evidence gates

1. **Bind the state and call.** For each initial/stored input, retain exact
   input SHA, source/config/executable receipts, effective mode/flags, stage
   and call identity. Require exact six physical state fields plus shared
   base/geometry fields used by pressure and PGF at the two paired calls.
   The existing PGF capture/review reports these actual-call state gates as
   passing for all four short runs; reuse those records rather than inferring
   equality from stage labels.

2. **Identify the actual pressure producer and last writer.** Record which
   runtime branch last wrote the `grid%p`/`grid%al` values consumed by the
   specific `horizontal_pressure_gradient` call, the producer's exact input
   state, effective pressure flags, bounds/halo ownership, and every
   intervening write (or prove there was none). In `rk_tendency`, `p` and
   `al` are inputs; `rk_step_prep` does not produce them. For the first large
   step, the same-step `small_step_prep -> calc_p_rho(step=0)` and the
   stage-end `calc_p_rho_phi` happen after the first PGF call and cannot be
   named as that call's last writer. Likewise, a later acoustic pressure
   sample is a different context. If pressure came from initialization or a
   preceding stage, pin that route/branch explicitly. Do not infer producer
   identity from a numerically similar array or a later dump.

3. **Reproduce pressure from the same formula and operands.** Given the
   identified producer branch, evaluate its source formula from the exact
   captured operands with the correct dimensions, maps, vertical metrics,
   base fields, moisture convention and boundary coefficients. Compare
   reproduced `p'`/`al` with the captured producer output and with the exact
   pressure arrays at the PGF call. Report absolute residuals and final
   FP32 storage intervals separately. An FP64 replay from FP32 operands is
   an operation replay; it does not bound internal FP32 intermediate or
   accumulation error. Keep the Fortran EOS branch, C++ EOS recomputation,
   and any pressure-history/filter branch distinct.

4. **Compare the actual PGF operator in common units.** Use the Fortran
   before/after `RU` increment and the C++ captured same-call PGF increment.
   Convert each PGF-only component once to physical `m/s²` with its actual
   face mass/map normalization; omit the `mu_dot` product-rule term because
   this isolated component does not update column mass. Compare the same
   owned 4,096 U faces, retaining physical west face x=0 and omitting only
   the duplicated closing face. Reconstruct and report the source A–D terms
   separately (PH/ALT·P'/AL·PB/NH PHP–dpn–MU) where their operands are
   available. Use vector subtraction for remainders; never subtract RMS
   values or add component norms as if vectors were collinear.

5. **State the narrow conclusion and remainder.** If gates 1–4 pass, a
   defensible closeout is: the identified pressure producer/branch is
   reproduced from its call inputs to the measured residual, and the
   measured U-PGF delta accounts for the specified share of the existing
   post-H/V-diffusion U remainder on those two states. Keep the residual
   explicit and unassigned. Do not promote this to full `F_Δ` parity,
   complete U/V/W/PH/T/MU RHS closure, internal-roundoff certification, a
   pressure-only causal claim, or trajectory/forecast accuracy.

## Existing evidence versus remaining proof

PR298 already supplies four actual same-state call captures, a bounded
Fortran/C++ source comparison, an A–D formula replay from actual operands,
pressure/EOS differences, and an elementwise comparison against the current
U remainder. The archived precision review says the measured PGF difference
accounts for essentially all of the initial remainder and most of the stored
remainder; the stored residual remains visible. This is component accounting,
not proof that the pressure arithmetic is the exclusive source or that the
source-level A–D reconstruction equals every internal FP32 operation.

The new `pressure-lineage-20261012` evidence directory was empty at this
checklist's preparation. That was the historical pre-evidence state; the
follow-up below closes that missing-evidence note without changing the scope.

## Timestamped follow-up: evidence review

Local timestamp: 2026-10-12 12:50:03 JST (+0900).

Reviewed the current PR299 draft
`docs/(202610121247)_pr299_pressure_lineage_and_state_input.md` against the
Red scalar EOS oracle, Red source-route audit, independent lineage review,
Registry mapping, and the corrected-input final receipt. The prior “evidence
directory empty / await report” status is closed. This remains a documentary
review of existing/offline evidence; no WRF run, build, or repository-code
change was performed.

The pressure conclusion is properly narrow if phrased as two linked but
distinct findings: source-order and active-run gates identify startup
`start_em` as the physical-interior pressure producer for these cold,
non-restart first-PGF calls (with the physical boundary routine only updating
halos); separately, the standalone REAL32 scalar EOS reproduces captured FT
`P` bitwise for both preserved cases when given captured `T`, `ALT`, and `PB`.
The oracle is an EOS-value reproduction from observed operands, not a complete
independent replay of startup's construction of `ALB`, `AL`, and `ALT`, nor an
instrumented assignment trace. Source review and the Green check that
`ALT == float32(AL_capture + WRFINPUT.ALB)` at all owners strengthen the
producer linkage, but do not justify attributing the entire C++/FT pressure
delta to final subtraction or any one rounding operation. Keep the separate
C++ Full PGF operator measurement and its unassigned residual separate from
pressure-value reproduction.

Registry semantics support the mixed-time correction: NetCDF `T` is the
diagnostic `th_phy_m_t0`; `THM` is prognostic `t` read by the tendency. The
archived stored probe replaced `T` but retained initial `THM`, so it remains a
valid paired call-state result only for that mixed-time cold input, not a full
60-second prognostic state. The final corrected fixture receipt confirms an
offline time-zero file whose eight replaced fields (`U,V,W,PH,T,THM,MU,P`)
come from the same archived 60-second source output, with `PB/PHB/MUB` and 169
preserved variables exact. It is still only an input fixture: it supplies no
new model call or corrected-state PGF result, and it does not preserve a warm
trajectory, acoustic history, or Newton predictors.

Acceptance remains limited to the two already captured first-PGF calls and
the offline corrected fixture. The frozen V3 reference qualification still
fails all 24 rows; no global or forecast acceptance target has been adopted.
Do not infer complete initialization proof, full-RHS parity, forecast
improvement, or a resolution of the RK3 timestep-sensitivity issue. A future
corrected-state comparison would need an actual call-local capture and fresh
producer/operator comparison; no such run is part of this evidence.
