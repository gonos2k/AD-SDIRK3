#!/usr/bin/env python3
"""Prepare captured FT inputs, run the standalone scalar oracle, compare raw FP32 P."""
import hashlib,json,struct,subprocess
from pathlib import Path
import numpy as np
import sys
sys.path.insert(0,'/Users/yhlee/AD-SDIRK3-review-evidence/u-pgf-same-state-20261012/red_precision')
import compare_actual_pgf_captures as capture
OUT=Path(__file__).parent
E=capture.E
CASES={'initial':'initial_fortran_rk3_h15','stored':'stored_fortran_rk3_h15'}
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def metric(d):
 d=np.asarray(d,dtype=np.float64)
 return {'count':int(d.size),'rms_pa':float(np.sqrt(np.mean(d*d))), 'max_abs_pa':float(np.max(np.abs(d))),
         'nonzero_mismatch_count':int(np.count_nonzero(d))}
def main():
 exe=OUT/'start_em_scalar_eos_oracle'
 subprocess.run(['/opt/homebrew/bin/gfortran','-O2','-ftree-vectorize','-funroll-loops','-Wl,-syslibroot,/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk',
   str(OUT/'start_em_scalar_eos_oracle.f90'),'-o',str(exe)],check=True)
 cases={}
 for label,run in CASES.items():
  ft=capture.parse_ft(E/run/'wrf_u_pgf_snapshot.bin')
  f=capture.extract_ft_physical(ft)
  # Fortran source-order arrays on physical owners, C-order flatten means i-fastest.
  t=f['t'].astype('<f4'); alt=f['alt'].astype('<f4'); pb=f['pb'].astype('<f4'); target=f['p'].astype('<f4')
  inp=OUT/f'{label}_oracle_input.bin'; out=OUT/f'{label}_oracle_output.bin'
  inp.write_bytes(t.tobytes(order='C')+alt.tobytes(order='C')+pb.tobytes(order='C'))
  subprocess.run([str(exe),str(inp),str(out)],check=True)
  pred=np.fromfile(out,dtype='<f4').reshape(target.shape)
  d=pred.astype(np.float64)-target.astype(np.float64)
  cases[label]={'run_label':run,'shape_jki':list(target.shape),'input_sha256':sha(inp),
   'target_pressure_sha256':hashlib.sha256(target.tobytes(order='C')).hexdigest(),
   'oracle_output_sha256':sha(out),'comparison_oracle_minus_captured_FT_P':metric(d),
   'bitwise_equal_elements':int(np.count_nonzero(pred==target)),
   'source_state':{'T_sha256':hashlib.sha256(t.tobytes(order='C')).hexdigest(),
    'ALT_sha256':hashlib.sha256(alt.tobytes(order='C')).hexdigest(),
    'PB_sha256':hashlib.sha256(pb.tobytes(order='C')).hexdigest()}}
 payload={'schema':'standalone-start-em-scalar-eos-oracle-v1','source_file':str(OUT/'start_em_scalar_eos_oracle.f90'),
  'source_sha256':sha(OUT/'start_em_scalar_eos_oracle.f90'),'executable_sha256':sha(exe),
  'compiler':'GNU Fortran 15.2.0 (/opt/homebrew/bin/gfortran)','compiler_binary_sha256':sha('/opt/homebrew/bin/gfortran'),
  'flags':['-O2','-ftree-vectorize','-funroll-loops'],
  'floating_point_flags_sha256':hashlib.sha256(b'-O2 -ftree-vectorize -funroll-loops').hexdigest(),
  'compile_command':'/opt/homebrew/bin/gfortran -O2 -ftree-vectorize -funroll-loops -Wl,-syslibroot,/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk start_em_scalar_eos_oracle.f90 -o start_em_scalar_eos_oracle',
  'linker_environment_note':'The installed gfortran specs referenced missing CLT MacOSX15.sdk; explicit current Xcode SDK linker sysroot was used. This is link-only and does not alter floating-point options.',
  'formula':'p0*((rd*(t0+t)*qvf)/(p0*ALT))**cpovcv-PB with qvf=1 and source grouping; all operands/default REAL are REAL32',
  'cases':cases}
 (OUT/'oracle_comparison.json').write_text(json.dumps(payload,indent=2,sort_keys=True)+'\n')
 print(json.dumps(payload,indent=2))
if __name__=='__main__': main()
