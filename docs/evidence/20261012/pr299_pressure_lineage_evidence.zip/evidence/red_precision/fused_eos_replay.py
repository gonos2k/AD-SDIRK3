"""Compare separate FP32 rounding and fused multiply-subtract on observed EOS inputs."""
import ctypes,ctypes.util,hashlib,json
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
lib=ctypes.CDLL(ctypes.util.find_library('m') or None)
powf=lib.powf;powf.argtypes=(ctypes.c_float,ctypes.c_float);powf.restype=ctypes.c_float
fmaf=lib.fmaf;fmaf.argtypes=(ctypes.c_float,ctypes.c_float,ctypes.c_float);fmaf.restype=ctypes.c_float

def stats(x,target):
 d=x.astype('f8')-target.astype('f8')
 return {'rms_pa':float(np.sqrt(np.mean(d*d))),'max_abs_pa':float(np.max(np.abs(d))),
         'bitwise_equal':int(np.count_nonzero(x.view('u4')==target.view('u4'))),'count':int(x.size)}
def main():
 cases={}
 for case in ('initial','stored'):
  src=ROOT/f'{case}_oracle_input.bin';dst=ROOT/f'{case}_oracle_output.bin'
  t,alt,pb=np.fromfile(src,dtype='<f4').reshape(3,4096)
  arg=np.divide(np.multiply(np.float32(287),np.add(np.float32(300),t,dtype='f4'),dtype='f4'),
                np.multiply(np.float32(100000),alt,dtype='f4'),dtype='f4')
  gamma=np.float32(np.float32(1004.5)/np.float32(717.5))
  power=np.array([powf(float(a),float(gamma)) for a in arg],dtype='<f4')
  separate=np.subtract(np.multiply(np.float32(100000),power,dtype='f4'),pb,dtype='f4')
  fused=np.array([fmaf(float(np.float32(100000)),float(a),-float(b)) for a,b in zip(power,pb)],dtype='<f4')
  target=np.fromfile(dst,dtype='<f4')
  assert np.array_equal(fused.view('u4'),target.view('u4')),case
  cases[case]={'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),
    'compiled_output_sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),
    'separate_FP32_multiply_then_subtract':stats(separate,target),'host_powf_then_fmaf':stats(fused,target)}
 report={'scope':'Existing captured T/ALT/PB inputs; no compile or WRF run. Host powf+fmaf comparison against recorded compiled oracle outputs. No full-WRF instruction trace claim.',
         'formula':'fmaf(p0, powf(Rd*float32(t0+THM)/(p0*ALT),cpovcv_f32),-PB)',
         'cases':cases,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 (ROOT/'fused_eos_replay.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()
