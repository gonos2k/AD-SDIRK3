program start_em_scalar_eos_oracle
  implicit none
  integer, parameter :: n=4096
  ! Same default-REAL constants and definitions as share/module_model_constants.F.
  real, parameter :: r_d=287., cp=7.*r_d/2., cv=cp-r_d
  real, parameter :: cpovcv=cp/(cp-r_d), p1000mb=100000., t0=300.
  real :: t(n), alt(n), pb(n), p(n), qvf
  integer :: i, ios
  character(len=4096) :: input_path, output_path
  call get_command_argument(1,input_path)
  call get_command_argument(2,output_path)
  open(10,file=trim(input_path),access='stream',form='unformatted',status='old',action='read',iostat=ios)
  if (ios/=0) error stop 'open input failed'
  read(10) t,alt,pb
  close(10)
  do i=1,n
    qvf=1.
    p(i)=p1000mb*((r_d*(t0+t(i))*qvf)/(p1000mb*alt(i)))**cpovcv-pb(i)
  end do
  open(20,file=trim(output_path),access='stream',form='unformatted',status='replace',action='write',iostat=ios)
  if (ios/=0) error stop 'open output failed'
  write(20) p
  close(20)
end program start_em_scalar_eos_oracle
