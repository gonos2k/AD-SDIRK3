# Final red review: bounded startup EOS FMA evidence

Local time: 2026-10-12 13:12 JST. Read-only review of existing oracle, disassembly, and replay artifacts; no new compile, WRF build, native object disassembly, or model run.

The actual startup pressure expression in `start_em.F` ends with `p0*pow(eos_arg,cpovcv)-PB`, with `qvf=1` for these captures. The compiled standalone REAL32 oracle uses the captured Fortran `t_1`/THM, ALT, and PB values. Its per-case input hashes are exactly the same as the fused-replay artifact (`2739f22d…6879ea` initial, `78fc9f3e…b7355` stored); the compiled oracle output hashes are exactly the target captured FT pressure hashes (`fa29a3f7…098c53`, `8d55eded…52d0e1c`). Both oracle cases are bitwise exact on 4,096/4,096 owners.

The existing standalone disassembly (`standalone_eos_disassembly.txt`, oracle executable SHA-256 `91b7a2a7…03e9ae8`) shows a call to `_powf` at `0x100000988` and an ARM64 `fnmsub` at `0x1000009b0`, with additional `fnmsub` instructions in the loop body. This is bounded evidence for the isolated oracle binary only; it is not a disassembly or instruction trace of WRF’s `start_em.o`.

The host replay uses the same REAL32 EOS-argument grouping, REAL32 exponent, `powf`, and the source-signed negative pressure base through `fmaf(p0,powf(arg,gamma),-PB)`. On the exact saved inputs it matches the compiled oracle output bitwise for both states. A separately rounded REAL32 multiply then subtract does not: 18/4,096 initial and 8/4,096 stored values match, with RMS residual `1.2246667e-3` / `1.2018990e-3 Pa` and maximum `3.8986206e-3 Pa` in both. This directly explains why a per-operation REAL32 emulator differs from the compiled scalar oracle on these inputs: the fused final multiply-subtract retains product precision until subtracting PB.

The source-sign, qvf, and input/output bindings are therefore consistent across the captured Fortran pressure, the standalone compiled oracle, and the independent host `powf+fmaf` replay. The evidence supports contraction in the isolated oracle’s EOS expression and its numeric effect on these captured states. It does not establish the exact instruction sequence of WRF’s compiled startup object or make final subtraction cancellation the exclusive source of the C++/Fortran pressure difference; AL/ALT path differences remain a separate contributor.

Artifacts: [`oracle_comparison.json`](oracle_comparison.json), [`standalone_eos_disassembly.txt`](standalone_eos_disassembly.txt), [`fused_eos_replay.py`](fused_eos_replay.py), and [`fused_eos_replay.json`](fused_eos_replay.json).
