from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys,tempfile
import numpy as np
from netCDF4 import Dataset
B=Path(__file__).resolve().parent
manifest=json.loads((B/'manifest.json').read_text())
for rel,digest in manifest.items(): assert hashlib.sha256((B/rel).read_bytes()).hexdigest()==digest,rel
sys.path.insert(0,str(B/'prior/parsers'));import compare_actual_pgf_captures as cap
cases={}
for case in ('initial','stored'):
 ft=cap.parse_ft(B/f'prior/captures/{case}_fortran_rk3_h15/wrf_u_pgf_snapshot.bin');a=cap.extract_ft_physical(ft)
 raw=np.fromfile(B/f'evidence/red_precision/{case}_oracle_input.bin',dtype='<f4').reshape(3,16,16,16)
 for i,k in enumerate(('t','alt','pb')): assert np.array_equal(raw[i].view('u4'),a[k].astype('<f4').view('u4')),(case,k)
 oracle=np.fromfile(B/f'evidence/red_precision/{case}_oracle_output.bin',dtype='<f4').reshape(16,16,16)
 assert np.array_equal(oracle.view('u4'),a['p'].astype('<f4').view('u4')),case
 with Dataset(B/f'prior/captures/{case}_fortran_rk3_h15/wrfinput_d01') as ds:
  thm=np.asarray(ds['THM'][0],dtype='f4').transpose(1,0,2)
  assert np.array_equal(thm.view('u4'),a['t'].astype('<f4').view('u4')),case
 cpp=cap.parse_cpp(B/f'prior/captures/{case}_cpp_ark3_h15/port_u_pgf_snapshot.bin',B/f'prior/captures/{case}_cpp_ark3_h15/port_u_pgf_operands_snapshot.bin')
 t=a['t'].astype('f8');alt=a['alt'].astype('f8');pb=a['pb'].astype('f8');cp=cpp['operands']['p'][:16,:16,:16];ca=cpp['operands']['alt'][:16,:16,:16]
 g64=1004.5/717.5;g32=float(np.float32(g64))
 eos=lambda al,g:100000.*np.power(287.*(300.+t)/(100000.*al),g)-pb
 own=eos(ca,g64);ft64=eos(alt,g32);common=eos(alt,g64)
 components=[cp-own,own-common,common-ft64,ft64-oracle.astype('f8'),oracle.astype('f8')-a['p'].astype('f8')]
 err=(cp-a['p'].astype('f8'))-sum(components)
 assert np.max(np.abs(err))<1e-14,case
 cases[case]={'recorded_oracle_pressure_bits_equal':4096,'input_THM_equals_call_t':True,'pressure_telescope_identity_max_pa':float(np.max(np.abs(err)))}
sys.path.insert(0,str(B/'source/tools'));from make_wrf_common_state_input import make_input,STATE_FIELDS
with tempfile.TemporaryDirectory(prefix='pr299-cold-input-') as td:
 out=Path(td)/'new.nc';r=make_input(B/'prior/captures/initial_fortran_rk3_h15/wrfinput_d01',B/'inputs/source_wrfout.nc','0001-01-01_00:01:00',out)
 assert r['output_sha256']==hashlib.sha256((B/'inputs/corrected_wrfinput.nc').read_bytes()).hexdigest()
 assert r['preserved_variable_count']==169 and len(r['copied_fields'])==8
 subprocess.run([sys.executable,str(B/'source/tools/test_make_wrf_common_state_input.py')],check=True)
print(json.dumps({'payload_hashes_valid':len(manifest),'no_new_compiler_or_model_execution':True,'cases':cases,'corrected_input_same_bytes':True,'copied_fields':list(STATE_FIELDS),'preserved_variables':169,'focused_tests':6},indent=2))
