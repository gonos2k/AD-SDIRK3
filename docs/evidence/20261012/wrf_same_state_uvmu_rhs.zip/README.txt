This bundle records bounded same-state U/V/MU component RHS comparisons, not equality of all WRF equations. Executable/library bytes are preserved locally; distributed receipts record hashes only. Full build source is main 3e707c05 plus records/diagnostic_changes.patch. Numerical equations were unchanged. All six states match before comparison; packed storage 17x17 and physical cells 16x16 are distinct.

Offline reproduction (Python + numpy):
python3 records/analyze_snapshots.py --self-check
python3 records/analyze_snapshots.py --source-root sources --fortran records/initial_snapshot_runs/rk3_h3p75_dump_on/wrf_full_rhs_snapshot.bin --cpp records/initial_snapshot_runs/sdirk_h15_dump_on/port_full_rhs_snapshot.bin --out initial_reanalysis.json
python3 records/analyze_snapshots.py --source-root sources --fortran records/initial_snapshot_runs/stored_rk3_h15_dump_on/wrf_full_rhs_snapshot.bin --cpp records/initial_snapshot_runs/stored_sdirk_h15_dump_on/port_full_rhs_snapshot.bin --out stored_reanalysis.json

Native runner/localization scripts retain original producer paths; they are audit companions and need path adaptation to rerun elsewhere. Superseded parser reports/startup syntax failure are retained and are not production numerical failures. No forecast accuracy budget was adopted and no performance advantage is asserted.
