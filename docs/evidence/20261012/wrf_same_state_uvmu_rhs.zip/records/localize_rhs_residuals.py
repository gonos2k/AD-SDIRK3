"""Export the already validated, common-unit metric arrays for localization."""
from pathlib import Path
import json
import numpy as np
import analyze_snapshots as a
E = Path(__file__).resolve().parent
root = Path('/private/tmp/pr295-full-rhs-20261011')
original = a.metrics
for name, ft, cpp in [('initial','rk3_h3p75_dump_on','sdirk_h15_dump_on'),('stored','stored_rk3_h15_dump_on','stored_sdirk_h15_dump_on')]:
    captured=[]
    def observe(candidate,reference,units):
        captured.append((np.array(candidate,dtype=np.float64),np.array(reference,dtype=np.float64),units))
        return original(candidate,reference,units)
    a.metrics=observe
    report=a.analyze(E/'initial_snapshot_runs'/ft/'wrf_full_rhs_snapshot.bin',E/'initial_snapshot_runs'/cpp/'port_full_rhs_snapshot.bin',root)
    if not report['comparison_available'] or len(captured)!=3:
        raise RuntimeError('validated three-field metric arrays unavailable')
    arrays={}; summary={}
    for var,(candidate,reference,units) in zip(('u','v','mu'),captured):
        delta=candidate-reference
        arrays[var+'_candidate']=candidate;arrays[var+'_reference']=reference;arrays[var+'_delta']=delta
        ind=np.unravel_index(np.argmax(np.abs(delta)),delta.shape)
        per_level=np.sqrt(np.mean(delta*delta,axis=(0,2))).tolist() if delta.ndim==3 else None
        summary[var]={'units':units,'owner_array_shape':list(delta.shape),'max_location_zero_based_jki' if delta.ndim==3 else 'max_location_zero_based_ji':list(map(int,ind)), 'candidate_at_max':float(candidate[ind]),'reference_at_max':float(reference[ind]),'delta_at_max':float(delta[ind]),'rms_by_k':per_level,'nonzero_delta_count':int(np.count_nonzero(delta))}
    np.savez_compressed(E/(name+'_common_unit_arrays.npz'),**arrays)
    (E/(name+'_residual_localization.json')).write_text(json.dumps(summary,indent=2)+'\n')
    print(name,json.dumps({v:(s.get('max_location_zero_based_jki',s.get('max_location_zero_based_ji')),s['delta_at_max']) for v,s in summary.items()}))
a.metrics=original
