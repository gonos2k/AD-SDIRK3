# PR295 U-vector endpoint relationship (draft)

Local timestamp: 2026-10-11 23:52:35 JST (+0900)

## Context

This is an offline calculation from saved 240-second WRF output for the archived after-theta SDIRK h=15 run, the new wind-base SDIRK h=15 run, and the PR292 RK3 h=3.75 reference. It is separate from the five PR295 full-RHS snapshot pairs, which are not yet available. All three run plans use the same `wrfinput_d01` SHA-256 `e71b730a12e5a16d181f404f6314e7904e0165eefa622ffd0c508bf8c00dd2a9`. The new run is source revision `35037bd2093e17beb23d27857a6d9c81ce08aed0`, executable SHA-256 `d8319a09c5eb879afd7a5946e3420373988c1a59bd37bfe3b3cff56931734ff6`.

## Method and result

The calculation read `U` directly from the NetCDF frame at `0001-01-01_00:04:00`, checked the WRF dimensions, and excluded the duplicate periodic x face, leaving 4,096 owned values per vector. Source values are float32; norms and inner products accumulate in float64. The script and machine-readable result are [`u_vector_endpoint_relationship.py`](/Users/yhlee/AD-SDIRK3-review-evidence/full-rhs-contract-20261011/u_vector_endpoint_relationship.py) and [`u_vector_240_relationship.json`](/Users/yhlee/AD-SDIRK3-review-evidence/full-rhs-contract-20261011/u_vector_240_relationship.json).

For each raw endpoint vector, `||U||₂ = sqrt(sum(Uᵢ²))`; pairwise cosine is `dot(Uₐ,Uᵦ)/(||Uₐ||₂ ||Uᵦ||₂)`.

| Vector | L2 norm |
|---|---:|
| Old after-theta SDIRK h=15 | 111.680252203 |
| New wind-base SDIRK h=15 | 111.688125073 |
| RK3 h=3.75 reference | 111.668040091 |

| Pair | Inner product | Cosine | Difference L2 | Bitwise equal |
|---|---:|---:|---:|---|
| Old SDIRK / new SDIRK | 12473.357771 | 0.999999983544 | 0.021737135 | No |
| Old SDIRK / RK3 reference | 12470.994650 | 0.999990359316 | 0.490519420 | No |
| New SDIRK / RK3 reference | 12471.874185 | 0.999990390969 | 0.489990779 | No |

The old/new U errors relative to RK3 h=3.75 have L2 norms `0.490519420` and `0.489990779`, respectively (RMS `0.007664366` and `0.007656106`). This is a small descriptive change in this U component. No causal attribution follows from the vector relationship.

For the change-vector relation, define `e_old=U_old-U_ref`, `e_new=U_new-U_ref`, and `delta=U_new-U_old`, with each raw float32 operand promoted before subtraction. At 240 seconds, their RMS values are `0.007664366`, `0.007656106`, and `0.000339643`; `e_old·delta=-0.000495420443`, and `cos(e_old,delta)=-0.046463874`. The identity `e_new=e_old+delta` holds exactly in the float64 calculation. The L2 error norm decreases by `0.107772%` (`1-||e_new||₂/||e_old||₂`). This direction statistic describes these saved U arrays only and is not a cause attribution.

## Limits and next action

This calculation compares one owned state component at one saved endpoint. RK3 h=3.75 is a comparison reference, not exact truth. The result does not establish U-tendency or full-RHS parity, identify an endpoint cause, or close the broader PR295 full-RHS investigation. Continue with the planned paired initial-state RHS analysis when those snapshots are available.
