from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
E=Path(__file__).resolve().parent
R=Path('/private/tmp/pr295-full-rhs-20261011')
sha=lambda b:hashlib.sha256(b).hexdigest()
(E/'diagnostic_changes.patch').write_bytes(subprocess.check_output(['git','diff','HEAD','--','dyn_em/solve_em.F','external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp'],cwd=R))
B=E/'build';B.mkdir(exist_ok=True)
for name in ('main/wrf.exe','external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a','configure.wrf'):
 src=R/name;dst=B/src.name
 if not dst.exists():shutil.copy2(src,dst)
 if sha(src.read_bytes())!=sha(dst.read_bytes()):raise RuntimeError('preserved build differs: '+name)
files={}
for p in sorted(E.rglob('*')):
 if p.is_file() and 'build' not in p.relative_to(E).parts and '__pycache__' not in p.parts and p.name not in ('pack_receipt.json',):
  # Table links are recorded by hashes in run receipts; byte copies are included when readable.
  files['records/'+str(p.relative_to(E))]=p.read_bytes()
source_pin=json.loads((E/'build_receipt.json').read_text())['source_hashes']
for name in (*source_pin,'external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified.h','external/libtorch_wrf/sdirk3/wrf_sdirk3_config.h','tools/benchmark_wrf_accuracy_cost.py'):
 files['sources/'+name]=(R/name).read_bytes()
files['sources/configure.wrf']=(R/'configure.wrf').read_bytes()
files['README.txt']=b'''This bundle records bounded same-state U/V/MU component RHS comparisons, not equality of all WRF equations. Executable/library bytes are preserved locally; distributed receipts record hashes only. Full build source is main 3e707c05 plus records/diagnostic_changes.patch. Numerical equations were unchanged. All six states match before comparison; packed storage 17x17 and physical cells 16x16 are distinct.

Offline reproduction (Python + numpy):
python3 records/analyze_snapshots.py --self-check
python3 records/analyze_snapshots.py --source-root sources --fortran records/initial_snapshot_runs/rk3_h3p75_dump_on/wrf_full_rhs_snapshot.bin --cpp records/initial_snapshot_runs/sdirk_h15_dump_on/port_full_rhs_snapshot.bin --out initial_reanalysis.json
python3 records/analyze_snapshots.py --source-root sources --fortran records/initial_snapshot_runs/stored_rk3_h15_dump_on/wrf_full_rhs_snapshot.bin --cpp records/initial_snapshot_runs/stored_sdirk_h15_dump_on/port_full_rhs_snapshot.bin --out stored_reanalysis.json

Native runner/localization scripts retain original producer paths; they are audit companions and need path adaptation to rerun elsewhere. Superseded parser reports/startup syntax failure are retained and are not production numerical failures. No forecast accuracy budget was adopted and no performance advantage is asserted.
'''
manifest={'schema':'sha256-payload-manifest-v1','payload_count':len(files),'files':{n:{'sha256':sha(b),'bytes':len(b)} for n,b in files.items()}}
files['manifest.json']=json.dumps(manifest,indent=2).encode()+b'\n'
out=R/'docs/evidence/20261012/wrf_same_state_uvmu_rhs.zip';out.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 assert all(sha(z.read(n))==m['sha256'] for n,m in manifest['files'].items())
receipt={'path':str(out),'zip_sha256':sha(out.read_bytes()),'bytes':out.stat().st_size,'payload_count':manifest['payload_count'],'crc_pass':True,'all_payload_sha256_pass':True,'distributed_executable_bytes':False,'locally_preserved_build_dir':str(B)}
(E/'pack_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
