# First Full-RHS diagnostic: read-only Green audit

Timestamp: 2026-10-11T23:51:43+09:00

Target: `/private/tmp/pr295-full-rhs-20261011` at `3e707c05a93283ce8043344251ec14dcce36524c`. Relevant current source hashes are in [postedit-graph-verification-receipt.json](postedit-graph-verification-receipt.json). This is a read-only source review; no production files, configuration, build outputs, or model results were changed by the audit.

The first IMEX split-check block in `external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp:6920` runs when `split_mode >= 2` and debug level is at least 2. Its static atomic counter admits the first two calls. The first admitted call evaluates `computeUnifiedRHS(U_n, RhsMode::Full)`, followed by fast and slow RHS evaluations. The `WRF_PARITY_RK_TEND_DUMP=1` setting gates writing `port_full_rhs_snapshot.bin`; it does not gate entry into the split diagnostic or its RHS evaluations.

No direct assignment to `g_sdirk3_config` was found in the diagnostic block or in the `computeUnifiedRHS` implementation. The diagnostic does mutate solver reference state (`U_ref_stage_ = U_n.detach().clone()`), increments its diagnostic counter, and may exercise RHS counters/capture metadata. When the dump is enabled, it also checks the single-rank/full-domain geometry and zero `F_phys`, then writes a snapshot. “No config mutation” therefore describes the configuration object specifically; it does not mean the diagnostic has no solver-state or file side effects.

This is static source evidence only. It does not establish runtime behavior or numerical parity.
