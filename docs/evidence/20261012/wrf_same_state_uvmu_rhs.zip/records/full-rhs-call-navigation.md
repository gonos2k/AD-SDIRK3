# Full RHS caller navigation and graph check

Timestamp: 2026-10-11 23:33:45 JST

Target: `/private/tmp/pr295-full-rhs-20261011` at `3e707c05a93283ce8043344251ec14dcce36524c`. The reused graph is `/private/tmp/pr294-rhs-graph-20261011/graphify-out/graph.json`. All 53 files pinned by its source bindings SHA-256 match the target; see [graph-verification-receipt.json](graph-verification-receipt.json). The graph was reused without refresh.

## Caller paths confirmed in source

- `dyn_em/solve_em.F:1159` calls `rk_tendency`; its definition is `dyn_em/module_em.F:190-981`. Graphify contains this definition and its internal callees, though its recorded start line (`L146`) is offset from the authoritative source.
- `dyn_em/solve_em.F:1279` calls `rk_addtend_dry`; its definition is `dyn_em/module_em.F:985-1118`. The routine combines the forward-step tendency with the accumulated slow tendency, as described in its source comments. Graphify contains the definition (recorded at `L817`) but not the caller edge from `solve_em.F`.
- `dyn_em/solve_em.F:1784` calls `advance_mu_t`, defined in `dyn_em/module_small_step_em.f90:969-1175`, within the acoustic substep after the halo/communication section. Neither `solve_em.F` nor `module_small_step_em.f90` is included in the 53-file graph corpus, so this edge and node are manually traced.
- The exact symbol `compute_rhs_tile_autograd` does not occur anywhere in the target worktree. The relevant implementation is a local `compute_rhs_inner` lambda in `external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp:13220-13242`, wrapped by `compute_rhs` at `:13245-13278`; the stage passes `compute_rhs` to the solver at `:13614`. `compute_rhs_inner` selects `computeUnifiedRHSFullHalo` when exchanged halos are available, otherwise `computeUnifiedRHS`. The separate custom reverse-mode code in `wrf_sdirk3_implicit_autograd.h` is not named `compute_rhs_tile_autograd`.

## Graph coverage and limits

The graph contains nodes for `rk_tendency()` and `rk_addtend_dry()` from the hash-matched `module_em.F`, but it omits the `solve_em.F` caller and `advance_mu_t` because those source files were outside the pinned corpus. It has no node for `compute_rhs_tile_autograd`, consistent with the absence of that exact symbol; lambda-level `compute_rhs_inner` navigation is confirmed from source. Fixed-form Fortran source locations in the graph differ from current file line numbers, so use the source citations above. These graph edges are navigation aids; this check did not establish numerical equivalence or run tests/model validation.
