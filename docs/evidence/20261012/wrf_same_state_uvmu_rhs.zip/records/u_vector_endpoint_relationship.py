#!/usr/bin/env python3
"""Read exact 240 s owned-U vectors from three archived WRF NetCDF snapshots."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from netCDF4 import Dataset

TIMESTAMP = "0001-01-01_00:04:00"
GRID = (16, 16, 16)
OWNED_U_COUNT = 16 * 16 * 16


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def time_text(value) -> str:
    arr = np.asarray(value)
    if arr.dtype.kind == "S":
        return b"".join(arr.tolist()).decode("ascii").rstrip("\x00 ")
    if arr.dtype.kind == "U":
        return "".join(arr.tolist()).rstrip("\x00 ")
    raise ValueError(f"unsupported Times dtype {arr.dtype}")


def read_owned_u(run_dir: Path) -> tuple[np.ndarray, dict]:
    matches = []
    files = []
    for path in sorted(run_dir.glob("wrfout_d01*")):
        if not path.is_file():
            continue
        with Dataset(path, "r") as ds:
            dims = (ds.dimensions["west_east"].size,
                    ds.dimensions["south_north"].size,
                    ds.dimensions["bottom_top"].size)
            if dims != GRID:
                raise ValueError(f"{path}: grid {dims} != {GRID}")
            if "U" not in ds.variables or "Times" not in ds.variables:
                raise ValueError(f"{path}: missing U or Times")
            if tuple(ds.variables["U"].dimensions) != (
                    "Time", "bottom_top", "south_north", "west_east_stag"):
                raise ValueError(f"{path}: unexpected U dimension order")
            times = [time_text(row) for row in ds.variables["Times"][:]]
            files.append({"path": str(path), "sha256": sha(path), "timestamps": times})
            for i, t in enumerate(times):
                if t == TIMESTAMP:
                    raw = np.ma.asarray(ds.variables["U"][i])
                    if np.ma.isMaskedArray(raw):
                        raw = raw.filled(np.nan)
                    raw = np.asarray(raw)
                    if raw.dtype != np.dtype("float32"):
                        raise ValueError(f"{path}: expected raw float32 U, found {raw.dtype}")
                    owned = np.ascontiguousarray(raw[:, :, :-1])
                    if owned.shape != (16, 16, 16) or owned.size != OWNED_U_COUNT:
                        raise ValueError(f"{path}: unexpected owned U shape {owned.shape}")
                    if not np.isfinite(owned).all():
                        raise ValueError(f"{path}: non-finite U at {TIMESTAMP}")
                    matches.append((owned, path, i))
    if len(matches) != 1:
        raise ValueError(f"{run_dir}: expected one {TIMESTAMP} frame, found {len(matches)}")
    owned, path, index = matches[0]
    return owned, {"run_dir": str(run_dir), "timestamp": TIMESTAMP,
                   "source_file": str(path), "source_file_sha256": sha(path),
                   "frame_index_in_file": index, "raw_dtype": "float32",
                   "raw_shape": [16, 16, 17], "owned_shape": list(owned.shape),
                   "owned_point_count": int(owned.size),
                   "owned_policy": "exclude U periodic duplicate x face",
                   "all_run_output_files": files}


def vector_metrics(a: np.ndarray, b: np.ndarray | None = None) -> dict:
    raw_left = np.asarray(a)
    left = np.asarray(a, dtype=np.float64).reshape(-1)
    out = {"l2_norm": float(np.linalg.norm(left)),
           "rms": float(np.sqrt(np.mean(left * left))),
           "finite": bool(np.isfinite(left).all())}
    if b is None:
        return out
    raw_right = np.asarray(b)
    right = np.asarray(b, dtype=np.float64).reshape(-1)
    delta = left - right
    dot = float(np.dot(left, right))
    denom = float(np.linalg.norm(left) * np.linalg.norm(right))
    out.update({"dot_product": dot,
                "cosine": dot / denom if denom > 0.0 else None,
                "difference_l2_norm": float(np.linalg.norm(delta)),
                "difference_rms": float(np.sqrt(np.mean(delta * delta))),
                "difference_max_abs": float(np.max(np.abs(delta))),
                "exact_array_equal": bool(np.array_equal(left, right)),
                "array_identity_precision": (
                    "raw float32 bitwise" if raw_left.dtype == np.float32 and
                    raw_right.dtype == np.float32 else "float64 accumulator values"),
                "raw_float32_bitwise_equal": (
                    bool(np.array_equal(np.ascontiguousarray(raw_left).view(np.uint32),
                                        np.ascontiguousarray(raw_right).view(np.uint32)))
                    if raw_left.dtype == np.float32 and raw_right.dtype == np.float32 else None)})
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--new-plan", type=Path, required=True,
                    help="same-state run plan with sdirk_h15")
    ap.add_argument("--reference-manifest", type=Path, required=True,
                    help="saved NetCDF snapshot manifest")
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    plan_path = args.new_plan.resolve()
    plan = json.loads(plan_path.read_text())
    row = next(r for r in plan["runs"] if r["label"] == "sdirk_h15")
    new_dir = Path(row["path"])
    manifest_path = args.reference_manifest.resolve()
    manifest = json.loads(manifest_path.read_text())
    def snap_path(key):
        spec = manifest["snapshots"][key]
        p = Path(spec["snapshot_path"])
        return p if p.is_absolute() else (manifest_path.parent / p).resolve()
    runs = {
        "old_after_theta_sdirk_h15": snap_path("after_theta_sdirk_h15"),
        "new_wind_base_sdirk_h15": new_dir,
        "reference_rk3_h3p75": snap_path("pr292_rk3_h3p75"),
    }
    vectors, receipts = {}, {}
    for label, directory in runs.items():
        vectors[label], receipts[label] = read_owned_u(directory)
    old = vectors["old_after_theta_sdirk_h15"]
    new = vectors["new_wind_base_sdirk_h15"]
    ref = vectors["reference_rk3_h3p75"]
    # Promote each raw float32 operand before all subtraction, dot, and norm work.
    old64, new64, ref64 = (x.astype(np.float64) for x in (old, new, ref))
    e_old = old64 - ref64
    e_new = new64 - ref64
    delta = new64 - old64
    identity_residual = e_new - (e_old + delta)
    e_old_l2 = float(np.linalg.norm(e_old.reshape(-1)))
    e_new_l2 = float(np.linalg.norm(e_new.reshape(-1)))
    delta_l2 = float(np.linalg.norm(delta.reshape(-1)))
    e_old_delta_dot = float(np.dot(e_old.reshape(-1), delta.reshape(-1)))
    e_old_delta_denominator = e_old_l2 * delta_l2
    pairs = {}
    for x, y in (("old_after_theta_sdirk_h15", "new_wind_base_sdirk_h15"),
                 ("old_after_theta_sdirk_h15", "reference_rk3_h3p75"),
                 ("new_wind_base_sdirk_h15", "reference_rk3_h3p75")):
        pairs[f"{x}_vs_{y}"] = vector_metrics(vectors[x], vectors[y])
    out = {
        "schema": "pr295-u-endpoint-vector-relationship-v1",
        "scope": "Raw owned U endpoint vectors at exactly 240 s; no causal attribution.",
        "timestamp": TIMESTAMP,
        "input_sha256": row.get("input_sha256"),
        "new_run_source_revision": plan.get("revision"),
        "new_run_executable_sha256": row.get("executable_sha256"),
        "new_run_namelist_sha256": row.get("namelist_sha256"),
        "grid": list(GRID), "owned_policy": "U[:, :, :-1], excluding duplicate periodic x face",
        "storage_precision": "raw NetCDF float32; norms and inner products accumulated in float64",
        "vectors": {k: vector_metrics(v) for k, v in vectors.items()},
        "pairwise_raw_vectors": pairs,
        "reference_error_vectors": {
            "old_after_theta_minus_reference": vector_metrics(e_old),
            "new_wind_base_minus_reference": vector_metrics(e_new),
            "old_error_vs_new_error": vector_metrics(e_old, e_new)},
        "change_vector_relationship": {
            "definitions": "e_old=U_old-U_ref; e_new=U_new-U_ref; delta=U_new-U_old; subtract after promotion from raw float32 to float64",
            "e_old_rms": float(np.sqrt(np.mean(e_old * e_old))),
            "e_new_rms": float(np.sqrt(np.mean(e_new * e_new))),
            "delta_rms": float(np.sqrt(np.mean(delta * delta))),
            "e_old_l2": e_old_l2, "e_new_l2": e_new_l2, "delta_l2": delta_l2,
            "e_old_dot_delta": e_old_delta_dot,
            "cosine_e_old_delta": e_old_delta_dot / e_old_delta_denominator
                if e_old_delta_denominator > 0.0 else None,
            "delta_l2_over_e_old_l2": delta_l2 / e_old_l2 if e_old_l2 > 0.0 else None,
            "one_minus_e_new_over_e_old_l2": 1.0 - e_new_l2 / e_old_l2
                if e_old_l2 > 0.0 else None,
            "identity_e_new_equals_e_old_plus_delta": {
                "residual_l2": float(np.linalg.norm(identity_residual.reshape(-1))),
                "residual_max_abs": float(np.max(np.abs(identity_residual))),
                "exact_array_equal": bool(np.array_equal(e_new, e_old + delta))}},
        "source_receipts": receipts,
        "interpretation_limits": [
            "U is one state component, not a full tendency or RHS comparison.",
            "PR292 h=3.75 is the comparison reference, not exact truth.",
            "Results do not attribute the SDIRK endpoint difference to the wind-base term."],
    }
    out_path = args.out.resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps({"status": "written", "out": str(out_path),
                      "timestamp": TIMESTAMP,
                      "vectors": {k: v["l2_norm"] for k, v in out["vectors"].items()},
                      "pairwise_cosines": {k: v["cosine"] for k, v in pairs.items()}}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
