PR297 archive-only investigation. No model or build was run. Executable/library bytes are excluded; historical producer hashes are recorded, not rehashed by the portable analyzer. Frozen V3 and metadata erratum are unchanged. Numeric ratios/cosines describe whole-path differences, not order, truth, or acceptance. Current criteria still fail reference qualification.

From the extracted root, install/use NumPy and netCDF4 and run:

    python3 tools/analyze_wrf_reference_refinement.py --plan rk3_reference_runs.json --contract contract.json --out reproduced.json
    python3 records/green_rhs/analyze_remainder.py

The first draft metric source/plan is superseded and excluded. Primary analysis is records/green_metric/portable_cli_run. The copied remainder script changes only its two local input-path constants; original execution source hashes remain in its historic report. Spectral, plot, provenance, and Red audit scripts are retained as execution records and may contain original machine paths; the two commands above are standalone numeric reproduction paths.

Primary d1=middle−coarse,d2=fine−middle. Independent Red precision uses both signs reversed; norm/cosine values are invariant to that shared reversal. Max-index axes for the RHS report are explicitly stated: full arrays [j,k,i], fixed-y slices [k,i], seam slices [k]. Saved Fortran W/PH/theta arrays are pre-add, not paired Full RHS.
