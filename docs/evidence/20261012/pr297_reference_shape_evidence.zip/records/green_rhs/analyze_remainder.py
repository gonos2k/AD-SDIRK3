#!/usr/bin/env python3
"""Reconcile archived final full-RHS snapshots with captured H/V diffusion terms.

Read-only evidence analysis. It never calls a model kernel or writes outside the
specified evidence directory. Arrays use physical owner masks and common units.
"""
from __future__ import annotations
import importlib.util, json
from pathlib import Path
import numpy as np

OUT = Path(__file__).resolve().parent
EVID = Path(__file__).resolve().parents[2] / 'rhs_inputs'
SRCROOT = Path(__file__).resolve().parents[2] / 'source'
spec = importlib.util.spec_from_file_location('snapshot_contract', EVID/'analyze_snapshots.py')
contract = importlib.util.module_from_spec(spec); spec.loader.exec_module(contract)

CASES = {
 'initial': (EVID/'red_provenance/fixed_xy/initial_fortran_rk3_h15/wrf_full_rhs_snapshot.bin',
             EVID/'red_provenance/fixed_xy/initial_cpp_ark3_h15/port_full_rhs_snapshot.bin',
             EVID/'final_initial_term_arrays.npz'),
 'stored': (EVID/'red_provenance/fixed_xy/stored_fortran_rk3_h15/wrf_full_rhs_snapshot.bin',
            EVID/'red_provenance/fixed_xy/stored_cpp_ark3_h15/port_full_rhs_snapshot.bin',
            EVID/'final_stored_term_arrays.npz'),
}

def stats(a, units, j_offset=0):
    a=np.asarray(a,dtype=np.float64)
    if not a.size: return {'count':0,'units':units}
    ix=np.unravel_index(np.argmax(np.abs(a)),a.shape)
    return {'count':int(a.size),'units':units,'rms':float(np.sqrt(np.mean(a*a)),),'max_abs':float(np.max(np.abs(a))), 'max_index':([] if not ix else [int(ix[0])+j_offset,*map(int,ix[1:])])}

def region_stats(a, units, j_offset=0):
    # Canonical array axes are [j,k,i], except MU [j,i].
    if a.ndim == 3:
        if j_offset == 1:  # V comparison excludes the lower symmetric wall face.
            yregions={'physical_y1_first_owner_face':stats(a[0,:,:],units),
                      'physical_y15_last_owner_face':stats(a[-1,:,:],units),
                      'physical_y2_to_y14_interior':stats(a[1:-1,:,:],units,2),
                      'seam_physical_y1':stats(a[0,:,0],units),
                      'seam_physical_y15':stats(a[-1,:,0],units)}
        else:
            yregions={'y0':stats(a[0,:,:],units), 'y15':stats(a[-1,:,:],units),
                      'y1_to_y14_interior':stats(a[1:-1,:,:],units),
                      'seam_y0':stats(a[0,:,0],units), 'seam_y15':stats(a[-1,:,0],units)}
        return {'all_owner':stats(a,units,j_offset), 'u_x0_seam':stats(a[:,:,0],units,j_offset),
          'u_x1_to_x15_interior':stats(a[:,:,1:],units,j_offset), **yregions,
          'per_k':{str(k):stats(a[:,k,:],units,j_offset) for k in range(a.shape[1])}}
    return {
      'all_owner':stats(a,units), 'x0_seam':stats(a[:,0],units),
      'x1_to_x15_interior':stats(a[:,1:],units), 'y0':stats(a[0,:],units),
      'y15':stats(a[-1,:],units), 'y1_to_y14_interior':stats(a[1:-1,:],units),
      'seam_y0':stats(a[0,0],units), 'seam_y15':stats(a[-1,0],units)}

def full_arrays(ftpath, cpppath):
    validation=contract.analyze(ftpath,cpppath,SRCROOT)
    if not validation['comparison_available'] or not validation['state_gate']['passed']:
        raise RuntimeError('same-state contract failed: '+str(validation.get('reason')))
    fm, f=contract.read_fortran(ftpath); cm,cs,cr=contract.read_cpp(cpppath)
    dims=tuple(cm['dims_nx_ny_nz_nxu_nyv_nzw']); nx,ny,nz,_,_,_=dims; px,py=nx-1,ny-1
    b=fm['bounds']; i0,j0,k0=b['ids'],b['jds'],b['kds']
    mu=contract.calc_mu_dot(fm,f,dims)
    fs=contract.logical_fortran_state(fm,f,dims)
    def sl3(a,i1,j1,k1): return contract._slice3(a,b,i0=i0,i1=i1,k0=k0,k1=k1,j0=j0,j1=j1)
    ru=sl3(f['ru_tend'],i0+nx+1,j0+ny,k0+nz)[:py,:,:px+1].astype(np.float64)
    rv=sl3(f['rv_tend'],i0+nx,j0+ny+1,k0+nz)[:py+1,:,:px].astype(np.float64)
    muu=contract._slice2(f['muu'],b,i0=i0,i1=i0+nx+1,j0=j0,j1=j0+ny)[:py,:px+1].astype(np.float64)
    muv=contract._slice2(f['muv'],b,i0=i0,i1=i0+nx,j0=j0,j1=j0+ny+1)[:py+1,:px].astype(np.float64)
    msfuy=contract._slice2(f['msfuy'],b,i0=i0,i1=i0+nx+1,j0=j0,j1=j0+ny)[:py,:px+1].astype(np.float64)
    msfvx=contract._slice2(f['msfvx'],b,i0=i0,i1=i0+nx,j0=j0,j1=j0+ny+1)[:py+1,:px].astype(np.float64)
    c1=f['c1h'][k0-b['kms']:k0-b['kms']+nz].astype(np.float64)
    c2=f['c2h'][k0-b['kms']:k0-b['kms']+nz].astype(np.float64)
    lu=c1[None,:,None]*muu[:,None,:]+c2[None,:,None]
    lv=c1[None,:,None]*muv[:,None,:]+c2[None,:,None]
    ft_u=contract.fortran_tendency_to_physical(ru,fs['u'][:py,:,:px+1].astype(np.float64),c1,mu['mu_u_dot'][:py,:px+1],msfuy,lu)[:,:,:px]
    ft_v=contract.fortran_tendency_to_physical(rv,fs['v'][:py+1,:,:px].astype(np.float64),c1,mu['mu_v_dot'][:py+1,:px],msfvx,lv)[1:py,:,:]
    cpp_u=cr['u'][:py,:,:px].astype(np.float64)
    cpp_v=cr['v'][1:py,:,:px].astype(np.float64)
    cpp_mu=cr['mu'][:py,0,:px].astype(np.float64)
    return {'u':cpp_u-ft_u,'v':cpp_v-ft_v,'mu':cr['mu'][:py,0,:px].astype(np.float64)-mu['mu_dot'][:py,:px]},validation

def main():
    payload={'schema':'rk3-reference-shape-green-rhs-remainder-v1','source_worktree':str(SRCROOT),
      'source_head':contract.git_receipt(SRCROOT),'scope':'exact-state instantaneous physical RHS; initial and stored h15 captures; no model evaluation',
      'units':{'u':'m/s^2','v':'m/s^2','mu':'Pa/s'},'max_index_coordinate_note':'Indices are zero-based. Full 3-D U and V owner maxima are [physical_j,k,i]; V fixed-y region maxima are [k,i], and V seam maxima are [k]. Per-k maxima are [physical_j,i]. The remaining 2-D MU maxima are [j,i].','cases':{},'limitations':{}}
    out_arrays={}
    for label,(fp,cp,npzp) in CASES.items():
        full,gate=full_arrays(fp,cp); z=np.load(npzp)
        # All U arrays include the periodic closing face (17 faces); the common
        # unique-owner comparison is x=0..15, i.e. the leading 16 faces.
        whole=z['whole_delta'][...,:16]
        hd=z['hd_delta'][...,:16]
        vd=(z['cpp_vdiff_u_component_physical']-z['ft_vdiff_u_component_physical'])[...,:16]
        rem=whole-hd-vd
        # Cross-check producer's saved closure residual on the same owner mask.
        saved=z['delta_full_minus_hd_minus_vdiff'][...,:16]
        closure=float(np.max(np.abs(rem-saved)))
        if closure>1e-12: raise RuntimeError(f'{label}: saved remainder closure mismatch {closure}')
        if not np.allclose(whole,full['u'],rtol=0,atol=5e-13):
            raise RuntimeError(f'{label}: term/full U mismatch {np.max(np.abs(whole-full["u"]))}')
        out_arrays[f'{label}_u_whole_delta']=whole
        out_arrays[f'{label}_u_hd_delta']=hd
        out_arrays[f'{label}_u_vd_delta']=vd
        out_arrays[f'{label}_u_remainder']=rem
        for name,a in full.items(): out_arrays[f'{label}_{name}_full_delta']=a
        payload['cases'][label]={
          'inputs':{'fortran_full_snapshot':contract.file_receipt(fp),'cpp_full_snapshot':contract.file_receipt(cp),'term_arrays':contract.file_receipt(npzp),'full_analysis_json':contract.file_receipt(EVID/f'final_{label}_full_rhs_analysis.json'),'term_analysis_json':contract.file_receipt(EVID/f'final_{label}_term_analysis.json')},
          'full_snapshot_state_gate':gate['state_gate'],
          'full_snapshot_comparison':gate['comparisons'],
          'u_term_closure_max_abs':closure,
          'u':{'whole':region_stats(whole,'m/s^2'),'horizontal_diffusion_delta':region_stats(hd,'m/s^2'),
               'vertical_diffusion_delta':region_stats(vd,'m/s^2'),'remainder_after_hdiff_and_vdiff':region_stats(rem,'m/s^2')},
          'v':region_stats(full['v'],'m/s^2',j_offset=1),'mu':region_stats(full['mu'],'Pa/s'),
          'u_max_component_contributions_at_full_hotspot':{},
        }
        idx=np.unravel_index(np.argmax(np.abs(whole)),whole.shape)
        payload['cases'][label]['u_max_component_contributions_at_full_hotspot']={
          'j_k_i':list(map(int,idx)),'whole':float(whole[idx]),'hd_delta':float(hd[idx]),
          'vd_delta':float(vd[idx]),'remainder':float(rem[idx])}
    np.savez_compressed(OUT/'remainder_arrays.npz',**out_arrays)
    payload['artifacts']={'remainder_arrays_npz':contract.file_receipt(OUT/'remainder_arrays.npz'),'analysis_script_sha256':contract.sha256_file(Path(__file__))}
    payload['limitations']={
      'w_ph_theta_full_rhs':'Not paired/derivable from this capture: Fortran full-RHS snapshot stores physical state plus ru_tend, rv_tend, mu_tend, and fluxes, but no rw_tend, ph_tend, or t_tend. The old wrf_rk_tend_dump is pre-rk_addtend_dry and is not a substitute.',
      'cause_attribution':'Remainder is an algebraic residual after only captured U horizontal/vertical diffusion increments. It is not assigned to PGF, EOS, advection, or another term by subtraction alone.',
      'pressure_eos_replay':'Existing pressure/EOS replay targets an earlier hotspot; it is not a bound on the current final stored U maximum at [j,k,i]=[14,3,15].',
      'mask':'U uses x=0..15 unique periodic owner faces (4096); V uses y=1..15 and x=0..15 (3840), omitting symmetric wall faces; MU uses 16x16 owners (256). Term U arrays carry a duplicated periodic x=16 face, cropped consistently before subtracting.'}
    (OUT/'remainder_analysis.json').write_text(json.dumps(payload,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'output':str(OUT),'cases':{k:{q:(payload['cases'][k][q]['remainder_after_hdiff_and_vdiff']['all_owner'] if q=='u' else payload['cases'][k][q]['all_owner']) for q in ('u','v','mu')} for k in payload['cases']}},indent=2))
if __name__=='__main__': main()
