# Red review plan for RK3 reference-shape analysis

Local timestamp: 2026-10-12 07:17:17 JST (+0900)

## Current evidence and scope

This is a read-only math/scope review for the named dry 16³ `em_b_wave`,
240-second case. The frozen V3 candidate contract and its PH metadata erratum
remain unchanged. No new numerical run, threshold, percentage, or acceptance
goal is introduced here.

The initial scan found no metric script/results; a follow-up scan found Green
metric outputs and a worktree analysis script. Their results and the later
script version are reviewed in [green_metric_final_review.md](green_metric_final_review.md). The initial note below fixes d1/d2 conventions and mathematical interpretation; it does not certify any order or acceptance status. No model was rerun.

## Fixed definitions for d1/d2

Use one named, same-setup halving triplet at a time. The current triplet is RK3
`h=3.75, 1.875, 0.9375 s`; `h=3.75` and `h=0.9375` use the same executable,
while `h=1.875` is archived from a different executable. The exact h=3.75
stock control matches its archived output at all five times, which helps bound
the source-path concern but does not prove the h=0.9375 and h=1.875 maps are
identical. Thus the triplet supports descriptive reference-shape analysis; a
formal Richardson claim still requires source/operator equivalence. The
`h=7.5 s` result is a separate coarse diagnostic because it was produced by a
pre-fix executable.
For each owned field X and checkpoint t, promote the stored arrays to float64
before subtraction and define

`d1_X(t) = X_h(t) - X_(h/2)(t)`

`d2_X(t) = X_(h/2)(t) - X_(h/4)(t)`.

Use each field's frozen owned physical mask and units: U unique periodic faces;
V both physical Y walls; W/PH exclude the fixed lower face; T all mass points;
MU all mass points. For PH, use one consistent representation: either raw
perturbation geopotential in m²/s² or physical height difference in m using
the exact common PHB. Ratios/cosines are dimensionless either way, but mixed
representations invalidate them. Record exact input, namelist, executable and
source lineage, all five checkpoint times, raw initial-state equality, and
the archived h=3.75 control equality before interpreting shape.

For each field/time, report the absolute norms and the dimensionless shape
statistics together:

`r_X = ||d1_X||_2 / ||d2_X||_2`

`c_X = (d1_X · d2_X) / (||d1_X||_2 ||d2_X||_2)`.

Also report RMS and max absolute differences and a representation-resolution
diagnostic from the raw FP32 ULPs. If a norm is zero or at the stored-output
floor, report ratio/cosine as undefined or numerically unresolved rather than
dividing by it. Do not combine fields with different units into one aggregate.

For a smooth, asymptotic, third-order global error expansion
`X_h = X_* + C h³ + O(h⁴)`, the signed halving differences above satisfy
`d1 ≈ 8 d2` in magnitude and direction: `r → 8` and `c → +1`. The ratio
`p_eff=log2(r)` can be reported as a descriptive observed difference-order
indicator. It is not a measured method order unless the asymptotic expansion
and common operator/time map assumptions are supported. A ratio near eight
alone is insufficient; cancellation or non-collinear error components can
produce a misleading norm ratio. A cosine near one alone is also insufficient
without the norm scaling. Use multiple fields and checkpoints to describe
where the pattern is or is not present; don't call every deviation “phase” as
if it were a proven cause.

Richardson extrapolation for p=3 gives
`X_* ≈ X_(h/2) - d1/7` under that asymptotic expansion. Treat this only as a
conditional estimate when successive differences are consistent in scale and
direction and the compared runs share the same equations, source/configuration,
input, and output interpretation. Non-asymptotic ratios, poor alignment,
different operators/build paths, or output-floor-dominated differences make
the extrapolation unsupported. It cannot make the RK3 h=1.875 reference
qualified under frozen V3, whose h=0.9375 versus h=1.875 epsilon/3 gate failed
all 24 field/checkpoint rows. No further refinement ladder is authorized by
that contract.

## Triangle-inequality interpretation

For any common true state Q and the same norm, if candidate A and reference B
both satisfy `||A-Q|| <= epsilon` and `||B-Q|| <= epsilon`, then
`||A-B|| <= 2*epsilon`. Therefore an observed `||A-B|| > 2*epsilon` proves
that at least one of the pair misses that same epsilon goal. It does not
identify which one. A difference at or below `2*epsilon` proves neither one
passes. Apply this only when the comparison is between estimates of the same
Q, at the same time, with the same field transformation/mask/norm and the
same epsilon. Do not treat this bound as a reference-error estimate.

The frozen reference qualification uses the stricter empirical test
`||X_0.9375-X_1.875|| <= epsilon/3`; failure means V3 withholds candidate
acceptance. That failure alone does not imply either RK3 solution exceeds the
candidate epsilon relative to truth. The `2*epsilon` bound is a separate
logical falsifier, not a replacement acceptance rule.

## Phase-classification limits

Shape diagnostics can say whether successive observed difference vectors are
aligned and shrink by a ratio consistent with a proposed asymptotic order.
They cannot establish the exact-solution direction, continuum accuracy,
causality, or project-wide forecast quality. With only two successive bands,
an apparent ratio/cosine pattern may be accidental or field/time specific.
Keep any classification descriptive and per field/checkpoint, report raw
values, and keep the frozen V3 pass/fail state separate. The 1% V3 budget
remains a root-proposed named-case target awaiting user selection; this shape
analysis neither selects nor relaxes it.

## Audit status

The superseded first draft had a script/plan mismatch. The final
`green_metric/portable_cli_run` package resolves it: current script, list-based
plan and frozen V3 hashes match; all 24 metrics and 48 Float64 arrays exactly
match the first-draft values, with no native run/build. See
[`green_metric_final_review.md`](green_metric_final_review.md). Frozen V3 and
the PH erratum remain unchanged.
