# Red final review: RK3 reference-shape metrics

Local timestamp: 2026-10-12 07:17:17 JST (+0900)

## Verdict

The final portable CLI package matches the current analysis script and plan; its 24 metrics and 48 delta arrays exactly match the earlier saved result. These remain shape diagnostics, not acceptance evidence. They show no third-order asymptotic pattern and do not support Richardson extrapolation. They do not alter frozen V3 or qualify h=1.875: its h=0.9375 versus h=1.875 epsilon/3 gate still fails all 24 rows. No new tolerance or acceptance target is proposed. This was a read-only audit; no model run or build was performed.

## Formula and result audit

The final analysis is [rk3_reference_shape_analysis.json](../green_metric/portable_cli_run/rk3_reference_shape_analysis.json), using [rk3_reference_runs.json](../green_metric/portable_cli_run/rk3_reference_runs.json). It compares owned arrays at 60/120/180/240 s using h=3.75, h=1.875 and h=0.9375 outputs. Its convention is `d1 = X_1.875 - X_3.75`, `d2 = X_0.9375 - X_1.875`, so reported `||d2||/||d1||` tends to `1/8` with cosine `+1` in a smooth asymptotic third-order regime. The inverse convention `||d1||/||d2||` tends to 8. The final CLI uses the V3 owned masks, exact five checkpoint times, exact raw eight-field t=0 equality, common input SHA and matching grid. All 24 d1 and 24 d2 RMS values agree with V3 evaluation within 4.24e-13 absolute; independent recomputation from its Float64 delta arrays matches all reported norm ratios and cosines to roundoff. The current V3 contract SHA remains `77bc4dcc7b8e0bde91d6089e9aaa11a67a49311f824d88c97919bbbb8e64fe3f`.

| Time (s) | U ratio/cos | V ratio/cos | W ratio/cos | PH ratio/cos | T ratio/cos | MU ratio/cos |
|---:|---:|---:|---:|---:|---:|---:|
| 60 | 1.803 / 0.999 | 1.398 / 0.971 | 0.993 / -0.426 | 1.564 / -0.170 | 2.094 / -0.227 | 1.415 / 0.980 |
| 120 | 1.647 / 0.999 | 1.256 / 0.976 | 0.916 / -0.260 | 0.840 / 0.296 | 2.373 / -0.248 | 1.498 / 0.977 |
| 180 | 1.512 / 0.999 | 1.127 / 0.983 | 1.503 / 0.144 | 1.137 / 0.830 | 2.724 / -0.233 | 1.481 / 0.983 |
| 240 | 1.395 / 0.999 | 1.014 / 0.988 | 1.188 / 0.401 | 1.400 / 0.954 | 2.774 / -0.191 | 1.432 / 0.988 |

Every reported `d2/d1` ratio is at least 0.84, well above the `1/8` asymptotic prediction; most exceed 1, so the finer difference is larger. Cosines range from negative values to nearly one. The magnitudes and directions do not support the p=3 error expansion needed for Richardson. This is descriptive evidence of non-asymptotic reference behavior, not a cause or exact-solution estimate.

## Triangle bound under frozen V3 epsilon

For a common true field and identical norm, if both resolutions are within epsilon, their difference cannot exceed 2 epsilon. The ratios below are `||X_0.9375-X_1.875||/epsilon_X(240)`; entries above 2 imply at least one of that pair misses the same epsilon, but do not identify which. The stricter frozen V3 qualification test is epsilon/3 and already fails all rows.

| Time (s) | U | V | W | PH | T | MU | Fields with d2 > 2 epsilon |
|---:|---:|---:|---:|---:|---:|---:|---|
| 60 | 1.16 | 2.40 | 8.72 | 0.51 | 2.49 | 0.59 | V, W, T |
| 120 | 3.83 | 5.97 | 11.97 | 1.44 | 5.04 | 3.55 | U, V, W, T, MU |
| 180 | 7.13 | 9.24 | 22.73 | 5.83 | 7.17 | 9.93 | U, V, W, PH, T, MU |
| 240 | 10.56 | 11.79 | 24.79 | 14.40 | 8.96 | 20.11 | U, V, W, PH, T, MU |

This implication assumes a common target field/time and the same mask, transformation and norm. It cannot identify which resolution is wrong. A difference below `2 epsilon` proves neither passes.

## Provenance and phase limits

- The final CLI receipt records current script SHA `aa5fa81a...`, portable plan SHA `99df09d3...`, and frozen V3 SHA `77bc4dcc...`; all independently recheck. The portable JSON has 24 metrics; its 48 Float64 delta arrays are elementwise equal to the first-draft delta arrays, and all 24 metrics are exactly equal to the earlier JSON. The CLI receipt records no native run or build.
- The earlier label-keyed `green_metric/input_runs.json` and its result are superseded first-draft artifacts. Use the `portable_cli_run` package for the final source/result pair; the first draft's source/plan mismatch is resolved in the final CLI output and plan.
- Exact initial checks and all five output times pass. All nine selected output frame hashes and three archived-reference manifest hashes match.
- h=3.75 and h=0.9375 use executable SHA `f7c4e1...`; archived h=1.875 uses `2b6294...`. The stock h=3.75 control is bitwise identical to its archived five-time control, but that does not prove identical source/operator behavior at every step size. Avoid formal order claims.
- The separate X-spectrum audit covers U/PH/W/MU at 60 and 240 s only. Its cross-phase is spatial Fourier phase between difference fields, not temporal phase or frequency. Low-coherence mode phase is unstable, classifier cutoffs are descriptive only, and small high-k components can approach FP32 output spacing.
- The Green script guards exact zero norms but does not add a near-ULP guard. Bulk metrics reproduce V3 RMS values; treat low-amplitude spectral modes cautiously.
- Efficiency remains optional. Neither shape analysis nor the triangle bound establishes complete FΔ parity, continuum truth or a project-wide forecast target.

Machine-readable review: [green_metric_final_review.json](green_metric_final_review.json).
