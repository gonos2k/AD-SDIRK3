#!/usr/bin/env python3
"""Read the three RK3 reference runs from the PR296 evidence archive.

This script only reads the archive/worktree and writes a compact manifest into
this directory. It never extracts or rewrites NetCDF payloads.
"""
from __future__ import annotations

import difflib
from datetime import datetime
import hashlib
import json
import re
import subprocess
import zipfile
from fractions import Fraction
from pathlib import Path

import numpy as np
from netCDF4 import Dataset


OUT = Path(__file__).resolve().parent
EVIDENCE = Path("/Users/yhlee/AD-SDIRK3-review-evidence/seam-cause-acceptance-20261012")
WORKTREE = Path("/private/tmp/pr296-seam-cause-20261012")
ZIP_PATH = WORKTREE / "docs/evidence/20261012/pr296_seam_cause_acceptance_evidence.zip"
ZIP_INDEX = EVIDENCE / "pr296_seam_cause_acceptance_evidence.manifest.json"
BASE_REV = "de23ed32509ada2c90fbf7dabbf261da480c78ed"
RUN_RECEIPT_REV = "3c8ef9c26d6caf9b3a54876d0caa19db361e5dc9"
CURRENT_SOURCE_COMMIT = "78255e14ad4f2d8e07e9e764b47b9eb24266dd53"
H1_ARCH = "records/green_acceptance/native_qualification_v3/archived_h1p875_reference"
CURRENT_RUNS = "records/green_acceptance/native_qualification_v3/runs"
TIMESTEPS = {"time_step", "time_step_fract_num", "time_step_fract_den"}
INITIAL_FIELDS = ["U", "V", "W", "PH", "T", "MU", "PHB", "MUB"]
OUTPUT_NAMES = [
    "wrfout_d01_0001-01-01_00:00:00",
    "wrfout_d01_0001-01-01_00:02:00",
    "wrfout_d01_0001-01-01_00:04:00",
]
CASE_SPECS = [
    {
        "label": "rk3_h3p75_stock_control",
        "dt": Fraction(15, 4),
        "base": f"{CURRENT_RUNS}/rk3_h3p75_stock_control",
        "out_base": f"{CURRENT_RUNS}/rk3_h3p75_stock_control",
        "receipt_source": "current_runs",
    },
    {
        "label": "fortran_rk3_h1p875",
        "dt": Fraction(15, 8),
        "base": f"{H1_ARCH}/producer_run",
        "out_base": f"{H1_ARCH}/reference",
        "receipt_source": "historical_h1p875",
    },
    {
        "label": "rk3_h0p9375_reference_qualification",
        "dt": Fraction(15, 16),
        "base": f"{CURRENT_RUNS}/rk3_h0p9375_reference_qualification",
        "out_base": f"{CURRENT_RUNS}/rk3_h0p9375_reference_qualification",
        "receipt_source": "current_runs",
    },
]


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_json_member(zf: zipfile.ZipFile, member: str) -> dict:
    return json.loads(zf.read(member))


def parse_namelist(text: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for line in text.splitlines():
        clean = line.split("!", 1)[0]
        match = re.match(r"\s*([A-Za-z][A-Za-z0-9_]*)\s*=\s*(.*?)\s*,?\s*$", clean)
        if match:
            result[match.group(1).lower()] = match.group(2).strip().rstrip(",").strip()
    return result


def netcdf_times(raw: bytes) -> list[str]:
    ds = Dataset("pr296-archive-member", mode="r", memory=raw)
    try:
        rows = np.asarray(ds.variables["Times"][:])
        return [b"".join(row.tolist()).decode("ascii").rstrip("\x00 ") for row in rows]
    finally:
        ds.close()


def hash_git_blob(rev: str, path: str) -> str:
    raw = subprocess.check_output(["git", "show", f"{rev}:{path}"], cwd=WORKTREE)
    return sha256(raw)


def hash_value(value):
    return value.get("sha256") if isinstance(value, dict) else value


with ZIP_PATH.open("rb") as f:
    zip_sha256 = sha256(f.read())
external_manifest = json.loads(ZIP_INDEX.read_text())
with zipfile.ZipFile(ZIP_PATH) as zf:
    inner_manifest = read_json_member(zf, "manifest.json")
    payload_manifest = inner_manifest.get("payload_manifest", inner_manifest.get("files"))
    if not isinstance(payload_manifest, dict):
        raise AssertionError("missing payload hash map in PR296 ZIP manifest")

    current_runs_doc = read_json_member(zf, f"{CURRENT_RUNS}/runs.json")
    current_rows = {r["label"]: r for r in current_runs_doc["runs"]}
    h1_runs = read_json_member(zf, f"{H1_ARCH}/producer_receipts/after_fix_runs.json")
    h1_row = next(r for r in h1_runs["runs"] if r["label"] == "fortran_rk3_h1p875")
    h1_archive = read_json_member(zf, f"{H1_ARCH}/archive_manifest.json")
    h1_source = read_json_member(zf, f"{H1_ARCH}/producer_receipts/production_source_pin.json")
    red_control_path = Path("/Users/yhlee/AD-SDIRK3-review-evidence/WRF-accuracy-cost-20261011/final_red_wrf_fix_closure_audit.json")
    red_control = json.loads(red_control_path.read_text())
    red_payload_audit_path = Path("/Users/yhlee/AD-SDIRK3-review-evidence/rk3-reference-shape-20261012/red_provenance/pr296_rk3_reference_payload_audit.json")
    red_payload_audit = json.loads(red_payload_audit_path.read_text())

    def file_record(member: str, kind: str) -> dict:
        raw = zf.read(member)
        actual_hash = sha256(raw)
        advertised = payload_manifest.get(member)
        if advertised is None:
            raise AssertionError(f"missing from PR296 package manifest: {member}")
        if actual_hash != advertised["sha256"] or len(raw) != advertised["bytes"]:
            raise AssertionError(f"archive manifest mismatch: {member}")
        return {"kind": kind, "archive_member": member,
                "bytes": len(raw), "sha256": actual_hash}

    cases = []
    input_member_hashes: set[str] = set()
    input_field_hashes: dict[str, dict] | None = None
    nml_texts: dict[str, str] = {}

    for spec in CASE_SPECS:
        label = spec["label"]
        row = h1_row if spec["receipt_source"] == "historical_h1p875" else current_rows[label]
        members = {
            "wrfinput": f"{spec['base']}/wrfinput_d01",
            "namelist_input": f"{spec['base']}/namelist.input",
            "namelist_output": f"{spec['base']}/namelist.output",
            "diagnostics": f"{spec['base']}/diagnostics.txt",
            "rsl_out": f"{spec['base']}/rsl.out.0000",
            "rsl_error": f"{spec['base']}/rsl.error.0000",
            "run_log": f"{spec['base']}/run.log",
            "time_log": f"{spec['base']}/time.log",
        }
        file_hashes = [file_record(member, kind) for kind, member in members.items()]
        input_raw = zf.read(members["wrfinput"])
        input_sha = sha256(input_raw)
        input_member_hashes.add(input_sha)
        nml_text = zf.read(members["namelist_input"]).decode("utf-8")
        nml_texts[label] = nml_text
        nml = parse_namelist(nml_text)
        exact_dt = Fraction(int(nml["time_step"]) * int(nml["time_step_fract_den"]) +
                             int(nml["time_step_fract_num"]), int(nml["time_step_fract_den"]))
        if exact_dt != spec["dt"]:
            raise AssertionError(f"unexpected time step for {label}: {exact_dt}")

        # Hash the original eight WRF initial-condition fields directly from
        # the immutable NetCDF input payload, preserving dtype and array order.
        ds = Dataset(f"{label}-wrfinput", mode="r", memory=input_raw)
        try:
            fields = {}
            for field in INITIAL_FIELDS:
                arr = np.ascontiguousarray(ds.variables[field][:])
                fields[field] = {
                    "shape": list(arr.shape),
                    "dtype": str(arr.dtype),
                    "sha256_c_order_bytes": sha256(arr.tobytes(order="C")),
                }
        finally:
            ds.close()
        if input_field_hashes is None:
            input_field_hashes = fields
        elif fields != input_field_hashes:
            raise AssertionError(f"initial eight-field payload differs in {label}")

        data_files = []
        observed_times = []
        for filename in OUTPUT_NAMES:
            member = f"{spec['out_base']}/{filename}"
            entry = file_record(member, "raw_wrfout_netcdf")
            observed = netcdf_times(zf.read(member))
            entry["times_attribute"] = observed
            observed_times.extend(observed)
            data_files.append(entry)
        if observed_times != [f"0001-01-01_00:0{i}:00" for i in range(5)]:
            raise AssertionError(f"noncanonical or incomplete WRF Times for {label}: {observed_times}")

        if spec["receipt_source"] == "historical_h1p875":
            source_version = {
                "revision": h1_runs["revision"],
                "source_pin_base_revision": h1_source["base_revision"],
                "source_pin_hashes": h1_source["authoritative_production_sources"],
                "executable_sha256": row["executable_sha256"],
                "solver_route": row["actual_cpp_sdirk_route"],
            }
            steps = red_control["runs"][0]["integrator_step_count"]
        else:
            source_version = {
                "revision": current_runs_doc["git_revision"],
                "source_pin_hashes": current_runs_doc["source_pins"],
                "executable_sha256": hash_value(row["executable_sha256"]),
                "solver_library_sha256": hash_value(row["solver_library_sha256"]),
                "solver_route": row["actual_cpp_sdirk_route"],
            }
            steps = row.get("main_timing_count")
        cases.append({
            "label": label,
            "method": row["method"],
            "dt_seconds_exact": f"{exact_dt.numerator}/{exact_dt.denominator}",
            "dt_seconds_decimal": float(exact_dt),
            "time_integration_scheme": int(nml.get("time_integration_scheme", "0")),
            "rk_ord": int(nml.get("rk_ord", "3")),
            "run_duration_seconds": 240,
            "integrator_main_step_count": steps,
            "actual_cpp_sdirk_route": row["actual_cpp_sdirk_route"],
            "run_status": row.get("status"),
            "return_code": row.get("return_code"),
            "success_complete": row.get("success_complete"),
            "input_sha256": input_sha,
            "namelist_input_sha256": sha256(zf.read(members["namelist_input"])),
            "namelist_time_fields": {key: nml.get(key) for key in sorted(TIMESTEPS)},
            "namelist_output_sha256": sha256(zf.read(members["namelist_output"])),
            "rsl_out_sha256": sha256(zf.read(members["rsl_out"])),
            "rsl_error_sha256": sha256(zf.read(members["rsl_error"])),
            "source_version": source_version,
            "genuine_times": observed_times,
            "files": data_files + file_hashes,
        })

    if len(input_member_hashes) != 1:
        raise AssertionError(f"three runs do not share one exact wrfinput hash: {input_member_hashes}")

    # The h1.875 case is historical. Compare NML text exactly after removing
    # the three exact rational time-step keys; no other setting may differ.
    normalized = {}
    for label, text in nml_texts.items():
        normalized[label] = "\n".join(
            line for line in text.splitlines()
            if not re.match(r"\s*time_step(?:_fract_(?:num|den))?\s*=", line, re.IGNORECASE)
        )
    nml_non_dt_equal = len(set(normalized.values())) == 1

source_changes = subprocess.check_output(
    ["git", "diff", "--name-only", f"{BASE_REV}..{CURRENT_SOURCE_COMMIT}", "--",
     "dyn_em/module_first_rk_step_part2.F", "dyn_em/module_implicit_sdirk3.F", "dyn_em/solve_em.F"],
    cwd=WORKTREE, text=True).splitlines()
fortran_changes = [p for p in source_changes if p.lower().endswith(".f") or p.lower().endswith(".f90")]
changed_fortran = []
for path in fortran_changes:
    old = subprocess.check_output(["git", "show", f"{BASE_REV}:{path}"], cwd=WORKTREE)
    current = (WORKTREE / path).read_bytes()
    diff = subprocess.check_output(["git", "diff", f"{BASE_REV}..{CURRENT_SOURCE_COMMIT}", "--", path], cwd=WORKTREE)
    changed_fortran.append({"path": path, "base_sha256": sha256(old),
                            "current_sha256": sha256(current),
                            "current_mtime_local": datetime.fromtimestamp(
                                (WORKTREE / path).stat().st_mtime).astimezone().isoformat(),
                            "diff_sha256": sha256(diff),
                            "diff_added_lines": sum(1 for line in diff.splitlines()
                                                     if line.startswith(b"+") and not line.startswith(b"+++")),
                            "diff_removed_lines": sum(1 for line in diff.splitlines()
                                                       if line.startswith(b"-") and not line.startswith(b"---"))})

red_control_sha = sha256(Path("/Users/yhlee/AD-SDIRK3-review-evidence/WRF-accuracy-cost-20261011/final_red_wrf_fix_closure_audit.json").read_bytes())
red_control_bitwise = red_control["raw_array_audits"]["pre_vs_post_fix_RK3_h3p75_owned_arrays_bitwise_equal_at_all_five_minutes"]
red_payload_audit_sha = sha256(red_payload_audit_path.read_bytes())
red_h375_all8 = all(x["all_8_exact"] for x in
                    red_payload_audit["fresh_v3"]["h375_exact_all_8_raw_fields_5_times"])
zip_sha = sha256(ZIP_PATH.read_bytes())

manifest = {
    "schema": "pr296-rk3-reference-shape-provenance-v1",
    "created_at_local": "2026-10-12",
    "scope": "read-only provenance audit of coarse/mid/fine classical RK3 whole-WRF references; no model runs",
    "source_archive": {
        "zip_path": str(ZIP_PATH),
        "zip_sha256": zip_sha,
        "external_manifest_path": str(ZIP_INDEX),
        "external_manifest_sha256": sha256(ZIP_INDEX.read_bytes()),
        "archive_payload_crc_verification": external_manifest["crc_verification"],
        "portable_paths": "archive_member values are relative to the zip root; no absolute source-run paths are required to identify payloads",
    },
    "common_case": {
        "model": "em_b_wave",
        "grid": [16, 16, 16],
        "run_duration_seconds": 240,
        "mpi_ranks": 1,
        "omp_threads": 1,
        "original_wrfinput_sha256_all_three": next(iter(input_member_hashes)),
        "original_eight_input_fields": input_field_hashes,
        "initial_eight_field_payloads_equal_across_all_three": True,
    },
    "cases": cases,
    "configuration_diff": {
        "all_non_timestep_namelist_lines_identical": nml_non_dt_equal,
        "differing_fields_only": sorted(TIMESTEPS),
        "exact_timestep_values_seconds": {
            c["label"]: {"time_step": c["namelist_time_fields"]["time_step"],
                         "time_step_fract_num": c["namelist_time_fields"]["time_step_fract_num"],
                         "time_step_fract_den": c["namelist_time_fields"]["time_step_fract_den"],
                         "derived": c["dt_seconds_exact"]}
            for c in cases
        },
    },
    "rk3_route_proof": {
        "all_three_namelist_time_integration_scheme": 0,
        "all_three_rk_ord": 3,
        "all_three_actual_cpp_sdirk_route": False,
        "verified_step_counts": {c["label"]: c["integrator_main_step_count"] for c in cases},
        "source_guard": {
            "file": "dyn_em/solve_em.F",
            "sdirk_branch_condition": "config_flags%time_integration_scheme == 6",
            "branch_lines_current": [601, 4024],
            "rk3_controls_scheme_value": 0,
            "meaning": "The SDIRK initialization/advance branch is not selected for these runs; run receipts also report actual_cpp_sdirk_route=false.",
        },
    },
    "source_versions_and_limits": {
        "historical_h1p875_base_revision": BASE_REV,
        "current_h3p75_h0p9375_run_receipt_revision": RUN_RECEIPT_REV,
        "current_source_commit_after_run": CURRENT_SOURCE_COMMIT,
        "current_executable_same_for_coarse_and_fine": cases[0]["source_version"]["executable_sha256"] == cases[2]["source_version"]["executable_sha256"],
        "middle_executable_sha256": cases[1]["source_version"]["executable_sha256"],
        "coarse_fine_executable_sha256": cases[0]["source_version"]["executable_sha256"],
        "executable_hashes_differ_for_mid_vs_coarse_fine": cases[1]["source_version"]["executable_sha256"] != cases[0]["source_version"]["executable_sha256"],
        "changed_fortran_sources_base_to_current": changed_fortran,
        "fortran_change_semantics": [
            "module_first_rk_step_part2.F additions only capture U vertical/horizontal diffusion diagnostics when WRF_PARITY_RK_TEND_DUMP is present and exactly 1; otherwise the added blocks perform no writes and the existing diffusion calls remain in place.",
            "solve_em.F adds an optional rk_tendency dump when WRF_PARITY_RK_TEND_DUMP exists, plus a full-RHS snapshot only when it equals 1; those blocks only write snapshots, and the current-run receipts confirm the variable was unset.",
            "module_implicit_sdirk3.F additions set SDIRK-only theta/wind base profiles from the SDIRK solver initialization route, guarded by time_integration_scheme == 6.",
        ],
        "fortran_gate_proof": {
            "module_first_rk_step_part2.F": {
                "added_capture_lines": [1074, 1149],
                "guard": "WRF_PARITY_RK_TEND_DUMP status==0 and TRIM(value)==1, plus first RK step/tile and geometry conditions",
                "diffusion_call_order": "the existing vertical_diffusion_2 and horizontal_diffusion_2 calls remain after their capture blocks; only snapshot I/O is conditional",
            },
            "solve_em.F": {
                "sdirk_branch_lines": [601, 4024],
                "sdirk_branch_guard": "config_flags%time_integration_scheme == 6",
                "rk_tendency_snapshot_line": 1205,
                "rk_tendency_snapshot_guard": "WRF_PARITY_RK_TEND_DUMP environment variable must be present and stage must match; the run environment has no WRF variables",
                "full_rhs_snapshot_line": 1379,
                "full_rhs_snapshot_guard": "WRF_PARITY_RK_TEND_DUMP status==0 and TRIM(value)==1",
                "snapshot_blocks_write_only": True,
            },
            "module_implicit_sdirk3.F": {
                "added_setter_lines": [889, 904],
                "caller_guard": "sdirk3_initialize_solvers is called only inside solve_em.F time_integration_scheme==6 branch",
            },
            "current_rk3_run_environment": "all WRF environment variables removed; diagnostic capture flags unset",
            "historical_h1p875_source": "base revision predates these diagnostic capture additions; historical run receipt reports RK3 and actual_cpp_sdirk_route=false",
            "empirical_control": "independent PR296 payload audit verifies old/new h3.75 exact equality for U,V,W,PH,T,MU,PHB,MUB at all five timestamps",
        },
        "unmodified_rk3_physics_sources": [
            {"path": p, "base_sha256": hash_git_blob(BASE_REV, p),
             "current_sha256": sha256((WORKTREE / p).read_bytes()),
             "unchanged_from_historical_source": hash_git_blob(BASE_REV, p) == sha256((WORKTREE / p).read_bytes())}
            for p in ("dyn_em/module_diffusion_em.F", "dyn_em/module_advect_em.F", "dyn_em/module_em.F")
        ],
        "current_runs_environment_receipt": {
            "all_WRF_environment_variables_removed": current_runs_doc["run_policy"]["all_WRF_environment_variables_removed"],
            "diagnostic_capture_flags_unset": current_runs_doc["run_policy"]["diagnostic_capture_flags_unset"],
        },
        "run_source_pin_limit": "The run plan records revision 3c8ef and pins seven authoritative sources; it does not list module_first_rk_step_part2.F or solve_em.F. Their current source hashes and mtimes are recorded, but the run receipt does not independently embed those two Fortran file hashes.",
        "historical_h1p875_environment_limit": "The archived historical runner receipt does not independently attest a sanitized environment; its source predates the later RK snapshot gates, and its route receipt still reports actual_cpp_sdirk_route=false.",
        "h375_pre_post_control": {
            "receipt_path": str(red_control_path),
            "receipt_sha256": red_control_sha,
            "owned_six_fields_bitwise_equal_at_all_five_minutes": red_control_bitwise,
        },
        "h375_old_vs_new_control": {
            "receipt_path": str(red_payload_audit_path),
            "receipt_sha256": red_payload_audit_sha,
            "all_eight_raw_fields_bitwise_equal_at_all_five_minutes": red_h375_all8,
            "fields": ["U", "V", "W", "PH", "T", "MU", "PHB", "MUB"],
        },
        "identity_limit": "Do not claim exact operators across the three runs: the h1.875 executable/source differs from the current coarse/fine executable. The references are an empirical whole-WRF RK3 timestep sequence; the h3.75 pre/post bitwise control is reused separately.",
    },
    "raw_payload_copy": {
        "copied_members": [],
        "reason": "All three WRFout triplets, wrfinput, namelist.input/output, diagnostics, run/time logs, and RSL logs are already present and hash-verified in the PR296 evidence ZIP.",
    },
}

if not nml_non_dt_equal:
    raise AssertionError("namelist has differences beyond timestep fields")
if not red_control_bitwise:
    raise AssertionError("reused h3.75 bitwise control receipt does not pass")
if not all(c["method"] == "RK3" and c["actual_cpp_sdirk_route"] is False for c in cases):
    raise AssertionError("a reference case is not verified as RK3-only route")

out_path = OUT / "rk3_reference_provenance_manifest.json"
out_path.write_text(json.dumps(manifest, indent=2) + "\n")
print(out_path)
