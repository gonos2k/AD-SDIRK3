# RK3 Fractional-Time and Acoustic-Staging Source Audit

Target worktree: `/private/tmp/pr297-reference-shape-20261012`, revision `14f330dd4028118a7c135aa16330c15e4c474410`. Review is read-only; no model execution or source edits.

## Three matched RK3 runs

All three use the same 240 s dry em_b_wave input (SHA-256 `e71b730a12e5a16d181f404f6314e7904e0165eefa622ffd0c508bf8c00dd2a9`), one MPI rank/thread, `rk_ord=3`, and `time_step_sound=4`. Their namelist fractions and observed clocks agree:

| Run | Namelist step | Exact h | Main steps in 240 s | RSL clock samples |
|---|---:|---:|---:|---|
| `rk3_h3p75_stock_control` | 3 + 6/8 | 15/4 s | 64 | 0, 3+3/4, 7+1/2 s |
| archived `fortran_rk3_h1p875` | 1 + 7/8 | 15/8 s | 128 | 0, 1+7/8, 3+3/4 s |
| `rk3_h0p9375_reference_qualification` | 0 + 15/16 | 15/16 s | 256 | 0, 15/16, 1+7/8 s |

`share/set_timekeeping.F:339-359` builds the real `dt` as `real(time_step)+real(fract_num)/real(fract_den)` and stores it in `grid%dt`; `dyn_em/start_em.F:296-298` uses the same fractional value. Thus h=0.9375 is not silently reduced to zero seconds. The integer `time_step` also reaches advection as a direction sign only (`dyn_em/module_advect_em.F:209,217`); Fortran `SIGN(1,0)` is positive, so the subsecond case keeps the same positive-flow sign convention.

The current RSL files are under [the qualification runs](</Users/yhlee/AD-SDIRK3-review-evidence/seam-cause-acceptance-20261012/green_acceptance/native_qualification_v3>). The archived 1.875 s namelist/RSL predates the current executable, but the relevant numerical-source SHA-256 values match current exactly for `module_em.F`, `module_small_step_em.F`, `module_diffusion_em.F`, `module_advect_em.F`, and `module_ieva_em.F`; the current `solve_em.F` difference from that source base is gated diagnostic capture code.

## RK and acoustic staging

`solve_em.F:467-483` sets `num_sound_steps=grid%time_step_sound=4`, then `dts=grid%dt/4`. The RK3 branch at `solve_em.F:877-890` uses:

| RK stage | Outer coefficient `dt_rk` | Acoustic `dts_rk` | Acoustic substeps |
|---|---:|---:|---:|
| 1 | h/3 | h/3 | 1 |
| 2 | h/2 | h/4 | 2 |
| 3 | h | h/4 | 4 |

So the acoustic `dts_rk` values are `[1.25, 0.9375, 0.9375]` s at h=3.75; `[0.625, 0.46875, 0.46875]` s at h=1.875; and `[0.3125, 0.234375, 0.234375]` s at h=0.9375. These are RK-stage update coefficients, not three sequential clock intervals.

The logs corroborate the source schedule: each case repeats stage acoustic substep groups `[1,2,4]`; total acoustic loop markers (`HALO_EM_C2_inline.inc` inside `solve_em.F:1699-1700,2123-2124`) are 448, 896, and 1,792. RSL counts for `rk_step_prep`, `rk_tendency`, `small_step_prep`, and `rk_small_finish` are 192, 384, and 768, or three per main step. Horizontal and vertical diffusion calls are 64, 128, and 256, or once per main step. These match the run receipts.

`rk_tendency` receives `grid%dt` each RK stage and computes local `dt_step=dt/(rk_order-rk_step+1)` (`module_em.F:430-433`); scalar tendency code reverses this to the full large-step `dt` where appropriate (`module_em.F:1239-1240`). The acoustic update routines receive `dts_rk` directly (`solve_em.F:1714-1731,1833-1851,1949-1968`). `WW_SPLIT` receives full h, but `zadvect_implicit` defaults to 0 and `CHK_IEVA` therefore returns false; that path sets `wwE=ww, wwI=0` without using its dt-dependent split calculation (`module_ieva_em.F:13-43,294-303`). I found no fractional parsing or integer-sign defect in this path.

## Source-grounded timestep sensitivity candidate

The strongest source-based candidate is the frequency of per-acoustic-step damping/filter operations:

- `smdiv=0.1` in all three namelists; `calc_p_rho` applies `p = p + smdiv*(p-pm1)` for every noninitial acoustic iteration without multiplying the correction by `dts` (`module_small_step_em.F:548-567`).
- `epssm=0.1` is applied each `advance_mu_t` call in the `muave` old/new blend (`module_small_step_em.F:1102-1107`) and enters the acoustic W solve (`module_small_step_em.F:624`, `:1314-1318`).
- `emdiv=0.01` feeds the per-step `MUDF_XY` correction in `advance_uv` (`module_small_step_em.F:809,868,880,942`).
- The main-step substep schedule is fixed at 7 acoustic calls per RK3 step, while main-step counts double at each h refinement. Thus these fixed-coefficient operations occur 448, 896, and 1,792 times over 240 s.

This is a plausible source of a changed reference shape, not a proven cause. The current RSL/nml evidence verifies operation counts and coefficients but has no per-substep pressure-filter, MUDF, or epssm increment capture. A discriminating diagnostic would record their before/after increments at each of the 1/2/4 stage substeps for one matched initial step, then compare summed contributions across the three h schedules. A one-filter-at-a-time counterfactual would be needed to attribute the resulting endpoint shift.

## Diffusion and forcing staging

The namelists agree on `diff_opt=2`, `km_opt=1`, `khdif=1000`, `kvdif=10`, and `damp_opt=0`; the tracked default is `diff_6th_opt=0`. `first_rk_step_part2` (including `vertical_diffusion_2` and `horizontal_diffusion_2`) is invoked under the RK-step-1 guard in `solve_em.F:1061-1151`; the RSL call counts confirm one invocation of each per main step. `rk_addtend_dry` carries `ru_tendf/rv_tendf) into each stage and only adds the saved boundary term to those arrays at RK stage 1 (`module_em.F:1063-1080)). This is the fixed slow-tendency part of the RK3 split, rather than an acoustic-substep diffusion call.

Physics flags for microphysics, radiation, surface, PBL, and cumulus are zero in all three namelists. `h_diabatic` is added to the theta tendency in `rk_addtend_dry` and the stage-3 small-step finish removes `dts_rk*number_of_small_timesteps=h) from the small-step theta state (`module_em.F:1102-1105`; `module_small_step_em.F:408-422)). This staging is algebraically tied to the full h. The archived run does not include a direct `h_diabatic` value capture, so I do not claim its runtime value is exactly zero from flags alone.

Polar `pxft` calls are guarded by `config_flags%polar` in `solve_em.F:1748,1868,1985`; the case uses Cartesian `map_proj=0` and the config default is nonpolar. The polar filter is therefore not a likely timestep-dependent difference in these runs.

## Conclusion

Fractional h values and RK/acoustic counts are represented consistently in namelists, RSL clocks, source, and run receipts. The strongest unresolved mechanism is repeated per-acoustic-step filtering/damping with fixed coefficients as the small-step count scales with h. Existing artifacts do not decompose those increments, so no source-only cause attribution is warranted.

