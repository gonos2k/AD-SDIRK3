# Green final document review

Reviewed `docs/(202610120720)_pr297_rk3_reference_shape_and_rhs_remainder.md` read-only against the E2 metric, runtime, precision, payload, residual-closure, and acceptance receipts.

**Blocking inaccuracies:** None found. The first-stage physics/diffusion tendency reuse matches `rk_addtend_dry`; the fixed `time_step_sound=4` schedule gives the 1/2/4 stage small-step counts; pairwise namelist comparison shows only the three fractional timestep fields differ; and the exact five-frame masks, initial-state checks, and saved-output half-ULP ratios agree with the evidence. The current worktree has no production C++/Fortran edits.

**Nonblocking corrections/clarifications:**

- Line 22 gives the earlier-checkpoint ratio range upper endpoint as 2.77. The metric rows for 60/120/180 s give a maximum of 2.7240, so report about 2.72; 2.77 is the 240 s endpoint maximum in the table.
- Line 9 could call PH “perturbation geopotential” explicitly, matching the frozen field definition and precision audit; the current unit is correct but could be read as total PH+PHB.
- Line 54 says no remaining pressure term has a comparable isolated capture. E2 includes a pressure/EOS source replay at the original U hotspot, which predicts only +2.88e-8 m/s² (opposite sign and far smaller than the observed residual). Clarify that no full-owned-array/stagewise pressure or advection contribution capture exists; that preserves the valid open-remainder conclusion.
