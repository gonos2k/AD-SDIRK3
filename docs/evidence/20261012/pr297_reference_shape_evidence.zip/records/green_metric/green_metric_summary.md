# Green metric: RK3 reference-difference shape

Source base revision: `14f330dd4028118a7c135aa16330c15e4c474410`. Archived outputs only; no model run or build.

The chain is RK3 h=3.75 → 1.875 → 0.9375 s on the same input and exact five timestamps. All eight raw initial arrays are bitwise equal across the three runs. The middle h=1.875 archive uses a different executable hash from the coarse/fine runs; the h=3.75 control was independently verified to match its archived control output exactly in the V3 evidence. Treat these as observed whole-run refinement differences, not a controlled operator-only order study. Field metrics use the existing `benchmark_wrf_accuracy_cost.py::_load_run` and `_owned` crop; the raw float64 d1/d2 arrays and per-file SHA-256 receipts are in the JSON/NPZ.

At t=240 s, the successive RMS ratio RMS(d2)/RMS(d1), cosine, and residual fraction after best-scale projection are:

| Field | d2/d1 RMS ratio | cosine | residual fraction | boundary-shell energy fractions (d1,d2) |
|---|---:|---:|---:|---:|
| U (m/s) | 1.395 | 0.999 | 0.050 | 0.208, 0.224 |
| V (m/s) | 1.014 | 0.988 | 0.153 | 0.327, 0.325 |
| W (m/s) | 1.188 | 0.401 | 0.916 | 0.431, 0.422 |
| PH (m²/s²) | 1.400 | 0.954 | 0.299 | 0.413, 0.440 |
| T (K) | 2.774 | -0.191 | 0.982 | 0.546, 0.436 |
| MU (Pa) | 1.432 | 0.988 | 0.158 | 0.240, 0.235 |

All six endpoint RMS ratios exceed 1: the finer h=0.9375−1.875 difference is larger than h=1.875−3.75. U, V, PH, and MU differences point mostly in the same direction; W alignment is weak, and T is poorly aligned/opposed. Across earlier checkpoints ratios vary and sometimes fall below 1 for W/PH, so the differences do not show a consistent halving trend.

This is shape and scale evidence only. It does not establish observed temporal order, an asymptotic regime, or distance to exact truth. The JSON contains all 24 field/time metric rows, mean changes, vertical RMS profiles, ownership-shell concentration, hashes, and timestamp/initial-state checks.
