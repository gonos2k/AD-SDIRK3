#!/usr/bin/env python3
"""Red-team verification of Green's PR296 U/V/MU remainder arrays and masks."""
from __future__ import annotations
import hashlib, importlib.util, json
from pathlib import Path
import numpy as np
E=Path('/Users/yhlee/AD-SDIRK3-review-evidence')
R=E/'rk3-reference-shape-20261012/green_rhs'
OUT=E/'rk3-reference-shape-20261012/red_rhs'
P=E/'seam-cause-acceptance-20261012'
MOD=E/'seam-cause-acceptance-20261012/analyze_snapshots.py'
spec=importlib.util.spec_from_file_location('contract',MOD);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rms(a):return float(np.sqrt(np.mean(np.asarray(a,dtype=np.float64)**2)))
def norm2(a):return float(np.sum(np.asarray(a,dtype=np.float64)**2))
def metric(a):
 a=np.asarray(a,dtype=np.float64)
 return {'count':int(a.size),'rms':rms(a),'max_abs':float(np.max(np.abs(a))) if a.size else 0.,'l2_norm':float(np.linalg.norm(a.ravel()))}
def partition_report(a,axis,parts):
 total=norm2(a); subs=[np.take(a,idx,axis=axis) for idx in parts]
 return {'parent_count':int(a.size),'part_counts':[int(x.size) for x in subs],
   'count_sum_exact':sum(x.size for x in subs)==a.size,
   'parent_squared_norm':total,'parts_squared_norm_sum':sum(norm2(x) for x in subs),
   'squared_norm_residual':total-sum(norm2(x) for x in subs),
   'parent_rms':rms(a),'count_weighted_parts_rms':float(np.sqrt(sum(x.size*rms(x)**2 for x in subs)/a.size))}
def raw_full_deltas(phase):
 d=P/'red_provenance/fixed_xy';fp=d/f'{phase}_fortran_rk3_h15/wrf_full_rhs_snapshot.bin';cp=d/f'{phase}_cpp_ark3_h15/port_full_rhs_snapshot.bin'
 gate=c.analyze(fp,cp,Path('/private/tmp/pr296-seam-cause-20261012'))
 if not (gate.get('comparison_available') and gate.get('state_gate',{}).get('passed') and gate.get('full_storage_exact_match')): raise ValueError(f'{phase} full state gate failed')
 fm,f=c.read_fortran(fp);cm,fs,cr=c.read_cpp(cp);dims=tuple(cm['dims_nx_ny_nz_nxu_nyv_nzw']);nx,ny,nz,nxu,nyv,nzw=dims;px,py,pz=c.physical_dimensions(dims,fm);b=fm['bounds'];i0,j0,k0=b['ids'],b['jds'],b['kds']
 mudot=c.calc_mu_dot(fm,f,dims);logical=c.logical_fortran_state(fm,f,dims)
 def sl3(a,i1,j1,k1):return c._slice3(a,b,i0=i0,i1=i1,k0=k0,k1=k1,j0=j0,j1=j1)
 c1=f['c1h'][k0-b['kms']:k0-b['kms']+pz].astype(np.float64);c2=f['c2h'][k0-b['kms']:k0-b['kms']+pz].astype(np.float64)
 ru=sl3(f['ru_tend'],i0+nx+1,j0+ny,k0+nz)[:py,:,:px+1].astype(np.float64)
 muu=c._slice2(f['muu'],b,i0=i0,i1=i0+nx+1,j0=j0,j1=j0+ny)[:py,:px+1].astype(np.float64)
 msfuy=c._slice2(f['msfuy'],b,i0=i0,i1=i0+nx+1,j0=j0,j1=j0+ny)[:py,:px+1].astype(np.float64)
 lu=c1[None,:,None]*muu[:,None,:]+c2[None,:,None]
 ftu=c.fortran_tendency_to_physical(ru,logical['u'][:py,:,:px+1].astype(np.float64),c1,mudot['mu_u_dot'][:py,:px+1],msfuy,lu)[:,:,:px]
 cppu=cr['u'][:py,:,:px].astype(np.float64);udelta=cppu-ftu
 rv=sl3(f['rv_tend'],i0+nx,j0+ny+1,k0+nz)[:py+1,:,:px].astype(np.float64)
 muv=c._slice2(f['muv'],b,i0=i0,i1=i0+nx,j0=j0,j1=j0+ny+1)[:py+1,:px].astype(np.float64)
 msfvx=c._slice2(f['msfvx'],b,i0=i0,i1=i0+nx,j0=j0,j1=j0+ny+1)[:py+1,:px].astype(np.float64)
 lv=c1[None,:,None]*muv[:,None,:]+c2[None,:,None]
 ftv=c.fortran_tendency_to_physical(rv,logical['v'][:py+1,:,:px].astype(np.float64),c1,mudot['mu_v_dot'][:py+1,:px],msfvx,lv)[1:py,:,:]
 cppv=cr['v'][1:py,:,:px].astype(np.float64);vdelta=cppv-ftv
 mudelta=cr['mu'][:py,0,:px].astype(np.float64)-mudot['mu_dot'][:py,:px]
 return {'gate':gate,'u':udelta,'v':vdelta,'mu':mudelta,'files':{'fortran':str(fp),'cpp':str(cp),'fortran_sha256':sha(fp),'cpp_sha256':sha(cp)}}
def main():
 jp=R/'remainder_analysis.json';npz=R/'remainder_arrays.npz';green=json.loads(jp.read_text());z=np.load(npz)
 green_script=R/'analyze_remainder.py'
 out={'schema':'red-green-full-rhs-remainder-review-v1','inputs':{'green_json':{'path':str(jp),'sha256':sha(jp)},'green_script':{'path':str(green_script),'sha256':sha(green_script)},'green_npz':{'path':str(npz),'sha256':sha(npz),'keys':z.files}},'cases':{},
   'findings':{'green_u_y_masks':'Correct; U array retains physical j=0..15.',
      'green_v_y_mask_labels':'Current Green output labels V physical y=1, y=15, and y=2..14 correctly; independent review checks global-j offsets for 3-D owner/interior/per-k indices and local 2-D boundary/seam indices.',
      'green_u_remainder_scope':'Algebraic residual after only captured U horizontal and vertical diffusion component differences; do not assign it to pressure, transport, or another term.',
      'w_ph_theta':'Frozen WRF rk_tend dump includes raw pre-rk_addtend_dry rw_tend/ph_tend/t_tend; complete post-add Full RHS counterparts are absent. No matched full comparison or isolated pressure/transport attribution.'}}
 for phase in ('initial','stored'):
  g=green['cases'][phase];gz={k:z[f'{phase}_{k}'] for k in ('u_whole_delta','u_hd_delta','u_vd_delta','u_remainder','u_full_delta','v_full_delta','mu_full_delta')}
  final=np.load(P/f'final_{phase}_term_arrays.npz')
  uD=gz['u_whole_delta'];uH=gz['u_hd_delta'];uV=gz['u_vd_delta'];uR=gz['u_remainder'];uT=uH+uV
  raw=raw_full_deltas(phase)
  checks={
   'u_whole_equals_pr296_final_whole_unique_x':bool(np.array_equal(uD,final['whole_delta'][...,:16])),
   'u_hd_equals_pr296_final_hd_unique_x':bool(np.array_equal(uH,final['hd_delta'][...,:16])),
   'u_vd_equals_pr296_cpp_minus_ft_vdiff_unique_x':bool(np.array_equal(uV,(final['cpp_vdiff_u_component_physical']-final['ft_vdiff_u_component_physical'])[...,:16])),
   'u_whole_equals_independent_full_snapshot_delta':bool(np.array_equal(uD,raw['u'])),
   'v_array_equals_independent_raw_snapshot_recompute':bool(np.array_equal(gz['v_full_delta'],raw['v'])),
   'mu_array_equals_independent_raw_snapshot_recompute':bool(np.array_equal(gz['mu_full_delta'],raw['mu'])),
   'u_remainder_equals_sequential_whole_minus_hd_minus_vd':bool(np.array_equal(uR,uD-uH-uV)),
   'u_remainder_equals_pr296_saved_remainder_within_roundoff':float(np.max(np.abs(uR-final['delta_full_minus_hd_minus_vdiff'][...,:16])))}
  if not all(v for k,v in checks.items() if isinstance(v,bool)):raise ValueError(f'{phase} cross-source check failed: {checks}')
  # Verify the U component/remainder region summaries and all full-channel metrics.
  summary_specs=[('whole',uD),('horizontal_diffusion_delta',uH),('vertical_diffusion_delta',uV),('remainder_after_hdiff_and_vdiff',uR)]
  green_term_summary_checks={}
  for term_name,array in summary_specs:
   got=g['u'][term_name]['all_owner']; want=metric(array)
   green_term_summary_checks[term_name]=all(got[k]==want[{'rms':'rms','max_abs':'max_abs','count':'count'}[k]] for k in ('rms','max_abs','count'))
   if not green_term_summary_checks[term_name]: raise ValueError(f'{phase}/{term_name} Green all-owner metrics differ from NPZ')
  comp=g['full_snapshot_comparison'];
  for name,array,units in [('u',uD,'m/s^2'),('v',gz['v_full_delta'],'m/s^2'),('mu',gz['mu_full_delta'],'Pa/s')]:
   m=metric(array);reported=comp[name]
   for key in ('count','absolute_rms','max_abs'):
    src={'count':m['count'],'absolute_rms':m['rms'],'max_abs':m['max_abs']}[key]
    if key in reported and not np.isclose(float(reported[key]),float(src),rtol=2e-15,atol=0):raise ValueError(f'{phase}/{name} report metric {key} differs')
  # U is [j,k,i], owner x=0..15. Check disjoint horizontal, vertical and level masks.
  masks={
   'u_x_partition':partition_report(uD,2,[np.arange(0,1),np.arange(1,16)]),
   'u_y_partition':partition_report(uD,0,[np.arange(0,1),np.arange(1,15),np.arange(15,16)]),
   'u_level_partition':partition_report(uD,1,[np.arange(k,k+1) for k in range(uD.shape[1])]),
   'v_x_partition':partition_report(gz['v_full_delta'],2,[np.arange(0,1),np.arange(1,16)]),
   'v_global_y_partition':partition_report(gz['v_full_delta'],0,[np.arange(0,1),np.arange(1,14),np.arange(14,15)]),
   'mu_x_partition':partition_report(gz['mu_full_delta'],1,[np.arange(0,1),np.arange(1,16)]),
   'mu_y_partition':partition_report(gz['mu_full_delta'],0,[np.arange(0,1),np.arange(1,15),np.arange(15,16)])}
  # Closure uses whole - hd - vd order; exact in float64. Reverse sum is shown separately.
  ident={'whole_minus_hd_minus_vd_equals_remainder_bitwise':bool(np.array_equal(uD-uH-uV,uR)),
    'reverse_sum_whole_vs_hd_plus_vd_plus_remainder':{'bitwise_equal':bool(np.array_equal(uD,uH+uV+uR)),
       'nonzero_count':int(np.count_nonzero(uD-(uH+uV+uR))),'max_abs_roundoff':float(np.max(np.abs(uD-(uH+uV+uR))))},
    'corrected_term_sum_stats':metric(uT),'remainder_stats':metric(uR),'whole_stats':metric(uD),
    'naive_sum_of_hd_vd_remainder_rms':rms(uH)+rms(uV)+rms(uR),
    'whole_squared_norm_identity_residual':norm2(uD)-(norm2(uT)+norm2(uR)+2*float(np.sum(uT*uR)))}
  # Catch the concrete physical-vs-local Y naming: first V row is global j=1.
  va=gz['v_full_delta']
  def argmax_ix(a,offset=0):
   ix=list(map(int,np.unravel_index(np.argmax(np.abs(a)),a.shape)))
   if offset and a.ndim>=2: ix[0]+=offset
   return ix
  vchecks={
    'all_owner':argmax_ix(va,1)==g['v']['all_owner']['max_index'],
    'x0_seam':argmax_ix(va[:,:,0],1)==g['v']['u_x0_seam']['max_index'],
    'x1_to_x15':argmax_ix(va[:,:,1:],1)==g['v']['u_x1_to_x15_interior']['max_index'],
    'physical_y1_first_owner_face':argmax_ix(va[0])==g['v']['physical_y1_first_owner_face']['max_index'],
    'physical_y15_last_owner_face':argmax_ix(va[-1])==g['v']['physical_y15_last_owner_face']['max_index'],
    'physical_y2_to_y14_interior':argmax_ix(va[1:-1],2)==g['v']['physical_y2_to_y14_interior']['max_index'],
    'seam_physical_y1':argmax_ix(va[0,:,0])==g['v']['seam_physical_y1']['max_index'],
    'seam_physical_y15':argmax_ix(va[-1,:,0])==g['v']['seam_physical_y15']['max_index']}
  vchecks['per_k_global_j_offsets']=all(argmax_ix(va[:,k,:],1)==g['v']['per_k'][str(k)]['max_index'] for k in range(va.shape[1]))
  if not all(vchecks.values()):raise ValueError(f'{phase}: Green V max coordinate mismatch: {vchecks}')
  vmask={'array_shape_jki':list(va.shape),'global_physical_j_indices':list(range(1,16)),
    'green_physical_y1_count':g['v']['physical_y1_first_owner_face']['count'],
    'green_physical_y2_to_y14_count':g['v']['physical_y2_to_y14_interior']['count'],
    'green_physical_y15_count':g['v']['physical_y15_last_owner_face']['count'],
    'correct_partition_count':int(va[0].size+va[1:-1].size+va[-1].size),
    'expected_total_count':int(va.size),'labels_match_physical_global_indices':True,
    'max_index_coordinates_match_independent_argmax':vchecks,
    'checked_reported_max_indices':{k:g['v'][k]['max_index'] for k in ('all_owner','u_x0_seam','u_x1_to_x15_interior','physical_y1_first_owner_face','physical_y15_last_owner_face','physical_y2_to_y14_interior','seam_physical_y1','seam_physical_y15')}}
  out['cases'][phase]={'full_state_gate':g['full_snapshot_state_gate'],'cross_source_checks':checks,
    'u_closure':ident,'masks':masks,'green_u_term_summary_metrics_exact':green_term_summary_checks,'v_physical_y_labels':vmask,
    'direct_channel_metrics':{name:metric(gz[f'{name}_full_delta']) for name in ('u','v','mu')},
    'green_full_snapshot_comparison':comp,'raw_snapshot_files':raw['files']}
 out['acceptance']={'all_state_gates_passed':all(q['full_state_gate']['passed'] for q in out['cases'].values()),
   'all_cross_source_checks_passed':True,'all_mask_counts_partition':all(x['count_sum_exact'] for q in out['cases'].values() for x in q['masks'].values()),
   'no_pressure_or_transport_causality_claim':True,'u_residual_is_partial':True}
 op=OUT/'green_remainder_independent_review.json';op.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(op)
if __name__=='__main__':main()
