#!/usr/bin/env python3
"""Independent algebra/mask audit of PR296 final U RHS component arrays.

Consumes frozen NPZ and binary captures only. No WRF/C++ operator, run, build,
or repository file is touched.
"""
from __future__ import annotations
import hashlib, importlib.util, json, struct
from pathlib import Path
import numpy as np

EVIDENCE=Path('/Users/yhlee/AD-SDIRK3-review-evidence')
PR296=EVIDENCE/'seam-cause-acceptance-20261012'
OUT=EVIDENCE/'rk3-reference-shape-20261012/red_rhs'
FULL_PARSER=EVIDENCE/'seam-cause-acceptance-20261012/analyze_snapshots.py'
spec=importlib.util.spec_from_file_location('full_snapshot_parser',FULL_PARSER)
full=importlib.util.module_from_spec(spec);spec.loader.exec_module(full)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rms(a):return float(np.sqrt(np.mean(np.asarray(a,dtype=np.float64)**2)))
def norm2(a):return float(np.sum(np.asarray(a,dtype=np.float64)**2))
def stats(a):
 a=np.asarray(a,dtype=np.float64)
 return {'count':int(a.size),'rms':rms(a),'max_abs':float(np.max(np.abs(a))) if a.size else 0.0,'l2_norm':float(np.linalg.norm(a.ravel()))}
def closure(D,T,R):
 # The defining remainder is computed from D-T; check this exact subtraction
 # and separately disclose roundoff in the reverse floating-point addition.
 rem_calc=D-T; recon=T+R; diff=D-recon
 nd=norm2(D); nt=norm2(T); nr=norm2(R); cross=float(np.sum(T.astype(np.float64)*R.astype(np.float64)))
 return {'remainder_equals_whole_minus_corrected_term_bitwise':bool(np.array_equal(R,rem_calc)),
   'max_abs_whole_minus_term_minus_remainder':float(np.max(np.abs(D-T-R))),
   'reverse_addition_reconstruction':{'bitwise_equal':bool(np.array_equal(D,recon)),'nonzero_count':int(np.count_nonzero(diff)),'max_abs_roundoff':float(np.max(np.abs(diff)))},
   'norms':{'whole':stats(D),'corrected_term_sum':stats(T),'remainder':stats(R),
      'naive_rms_sum_term_plus_remainder':rms(T)+rms(R),
      'rms_sum_is_not_used_as_whole_rms':True,
      'whole_squared_norm':nd,'term_squared_norm':nt,'remainder_squared_norm':nr,'twice_cross_term':2*cross,
      'squared_norm_identity_residual':nd-(nt+nr+2*cross)}}
def read_rk_dump(path,expected_bounds):
 data=Path(path).read_bytes()
 if len(data)<24:raise ValueError(f'{path}: short RK dump')
 bounds=struct.unpack_from('>6i',data,0)
 if bounds!=expected_bounds:raise ValueError(f'{path}: bounds {bounds} != Full snapshot {expected_bounds}')
 ims,ime,jms,jme,kms,kme=bounds;ni=ime-ims+1;nj=jme-jms+1;nk=kme-kms+1
 n3=ni*nj*nk;n2=ni*nj
 fields={};off=24
 order=('ru_tend','rv_tend','rw_tend','ph_tend','t_tend','mu_tend','p','al')
 for name in order:
  count=n2 if name=='mu_tend' else n3
  arr=np.frombuffer(data,dtype='>f4',count=count,offset=off).copy()
  arr=arr.reshape((nj,ni),order='C') if name=='mu_tend' else arr.reshape((nj,nk,ni),order='C')
  fields[name]=arr;off+=count*4
 if off!=len(data):raise ValueError(f'{path}: parsed {off} bytes, file has {len(data)}')
 return {'path':str(path),'sha256':sha(path),'byte_count':len(data),'header_endian':'big-endian as observed in frozen stream',
   'bounds_ims_ime_jms_jme_kms_kme':list(bounds),'memory_shape_jki':[nj,nk,ni],
   'payload_order':list(order),'payload_arrays':fields}
def masked_report(D,T,R):
 px=D.shape[-1]-1
 masks={'west_x0':slice(0,1),'internal_owner_x1_to15':slice(1,px),'owner_unique_x0_to15':slice(0,px),
        'closing_duplicate_x16':slice(px,px+1),'all_physical_x0_to16':slice(0,px+1),'seam_pair_x0_x16_duplicate_counted':np.array([0,px])}
 rr={}
 for name,x in masks.items():rr[name]={'closure':closure(D[:,:,x],T[:,:,x],R[:,:,x]),'x_count':int(D[:,:,x].shape[-1])}
 # Verify disjoint cover accounting for whole physical face array and owner partition.
 rr['mask_count_closure']={'west_plus_internal_equals_owner':int(D[:,:,0:1].size+D[:,:,1:px].size)==int(D[:,:,:px].size),
   'owner_plus_closing_equals_full_faces':int(D[:,:,:px].size+D[:,:,px:px+1].size)==int(D.size),
   'counts':{'west':int(D[:,:,0:1].size),'internal':int(D[:,:,1:px].size),'owner_unique':int(D[:,:,:px].size),
      'closing_duplicate':int(D[:,:,px:px+1].size),'full_faces':int(D.size),'seam_pair_duplicate_counted':int(D[:,:,[0,px]].size)}}
 # Global squared-norm closure by disjoint owner + closing domains; not sum of RMS values.
 for name,A in [('whole',D),('term',T),('remainder',R)]:
  total=norm2(A); parts=norm2(A[:,:,:px])+norm2(A[:,:,px:px+1])
  rr['mask_count_closure'][f'{name}_squared_norm_partition_residual']=total-parts
  rr['mask_count_closure'][f'{name}_rms_global_vs_count_weighted_mask_rms']=rms(A)-float(np.sqrt((A[:,:,:px].size*rms(A[:,:,:px])**2+A[:,:,px:px+1].size*rms(A[:,:,px:px+1])**2)/A.size))
 return rr

def run():
 report={'schema':'independent-pr296-final-full-rhs-closure-audit-v1','evidence_only':True,
   'source_root':'/private/tmp/pr296-seam-cause-20261012','source_head':'3c8ef9c26d6caf9b3a54876d0caa19db361e5dc9',
   'inputs':{},'cases':{},'fortran_pre_add_tendency_payload':{},
   'interpretation':{'units':'U RHS decomposition m/s^2; raw pre-add Fortran rk_tendency payload units are not normalized here.',
     'no_norm_additivity':'Corrected term and remainder are fields; RMS magnitudes are not additive. The squared-norm cross term is shown explicitly.',
     'claim_scope':'U component closure only; not attribution of remaining residual to pressure, transport, or any unisolated term.'}}
 extracted={}
 for phase in ('initial','stored'):
  npz=PR296/f'final_{phase}_term_arrays.npz';jpath=PR296/f'final_{phase}_term_analysis.json'
  z=np.load(npz);j=json.loads(jpath.read_text())
  if not (j.get('comparison_available') and j.get('full_rhs_state_gate',{}).get('passed') and j.get('full_rhs_state_gate',{}).get('full_storage_exact')):
   raise ValueError(f'{phase}: full-RHS state gate failed')
  D=np.asarray(z['whole_delta']);H=np.asarray(z['hd_delta']);V=np.asarray(z['delta_vdiff_cpp_minus_fortran']);T=H+V;R=np.asarray(z['delta_full_minus_hd_minus_vdiff'])
  if D.shape!=(16,16,17) or any(a.shape!=D.shape for a in (H,V,T,R)):raise ValueError(f'{phase}: unexpected U field shapes')
  if not all(np.isfinite(a).all() for a in (D,H,V,T,R)):raise ValueError(f'{phase}: non-finite array')
  # Verify analyzer definitions against arrays directly.
  if not np.array_equal(H,z['cpp_hd_phys']-z['ft_hd_phys']):raise ValueError(f'{phase}: HD delta does not match raw components')
  if not np.array_equal(V,z['cpp_vdiff_u_component_physical']-z['ft_vdiff_u_component_physical']):raise ValueError(f'{phase}: VDiff delta does not match raw components')
  case={'term_arrays_npz':{'path':str(npz),'sha256':sha(npz),'byte_count':npz.stat().st_size},
     'term_analysis_json':{'path':str(jpath),'sha256':sha(jpath)},
     'full_state_gate':j['full_rhs_state_gate'],'global_closure':closure(D,T,R),
     'components':{'whole_delta_cpp_minus_ft':stats(D),'hd_delta_cpp_minus_ft':stats(H),'vdiff_delta_cpp_minus_ft':stats(V),
                   'corrected_term_hd_plus_vdiff':stats(T),'remainder_after_terms':stats(R)},
     'masks':masked_report(D,T,R),
     'regional_cpp_minus_fortran_channels':json.loads((PR296/f'final_{phase}_full_rhs_analysis.json').read_text())['comparisons']}
  report['cases'][phase]=case
  fullfile=PR296/'red_provenance'/'fixed_xy'/f'{phase}_fortran_rk3_h15'/'wrf_full_rhs_snapshot.bin'
  meta,rawfields=full.read_fortran(fullfile)
  rkpath=fullfile.parent/'wrf_rk_tend_dump.bin'
  rk=read_rk_dump(rkpath,tuple(meta['bounds'][k] for k in ('ims','ime','jms','jme','kms','kme')))
  raw_stats={}
  for name,a in rk['payload_arrays'].items():
   aa=np.asarray(a,dtype=np.float64)
   raw_stats[name]={'shape':list(a.shape),'finite_fraction':float(np.isfinite(a).mean()),'rms_finite':float(np.sqrt(np.mean(aa[np.isfinite(aa)]**2))) if np.isfinite(aa).any() else None,
                    'max_abs_finite':float(np.max(np.abs(aa[np.isfinite(aa)]))) if np.isfinite(aa).any() else None}
   extracted[f'{phase}_{name}']=a
  report['fortran_pre_add_tendency_payload'][phase]={k:v for k,v in rk.items() if k!='payload_arrays'}
  report['fortran_pre_add_tendency_payload'][phase]['stats']=raw_stats
  report['fortran_pre_add_tendency_payload'][phase]['source_scope']={
    'capture':'solve_em.F:1198-1219, after rk_tendency and before rk_addtend_dry',
    'following_additive_call':'solve_em.F:1279-1292',
    'comparison_limit':'Contains raw pre-add W, PH, theta and MU tendencies plus P/AL payloads; these are not the complete post-add Full RHS. No term-level pressure/transport attribution is supported.'}
 report['source_capture_contract']={
  'fortran_full_rhs':'dyn_em/solve_em.F:1364-1404 writes states, ru_tend/rv_tend/mu_tend, coupled ru/rv, mass/metrics; it does not serialize post-add rw_tend, ph_tend, or t_tend.',
  'fortran_rk_tend':'dyn_em/solve_em.F:1192-1219 serializes ru_tend,rv_tend,rw_tend,ph_tend,t_tend,mu_tend,p,al immediately after rk_tendency and before rk_addtend_dry at 1279-1292.',
  'cpp_full_rhs':'external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp:6946-6978 serializes F_full in packed U,V,W,PH,T,MU block order with its state.',
  'next_measurable_gap':'For complete cross-language W/PH/theta RHS comparison, capture Fortran rw_tend, ph_tend, t_tend after rk_addtend_dry (and at the same boundary stage as current full snapshot). For attributing any remaining U residual to pressure, transport, or other physics, add isolated bracketing captures for the selected term and its required operands; current full and pre-add snapshots do not isolate those terms.'}
 # Store the frozen raw tendency payload too so reviewers can rederive the descriptive stats.
 npzout=OUT/'frozen_fortran_rk_tend_payload.npz';np.savez_compressed(npzout,**extracted)
 report['frozen_payload_npz']={'path':str(npzout),'sha256':sha(npzout),'byte_count':npzout.stat().st_size,'fields':sorted(extracted)}
 out=OUT/'pr296_full_rhs_residual_closure_audit.json';out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 return out
if __name__=='__main__':print(run())
