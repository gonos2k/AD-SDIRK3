# Red review: remaining full-RHS lane

**Scope:** Read-only numerical audit of PR296 final initial/stored H/V and full-RHS snapshots. No build or model run was performed. Numeric RHS units are U/V m/s² and MU Pa/s.

## Algebra and masks

Green’s U arrays use the 4,096-point unique periodic-owner mask (`x=0..15`). For both initial and stored cases, its whole/H/V arrays match the PR296 final NPZ exactly. U/V/MU residual arrays independently recomputed from the raw paired Full snapshots also match Green’s arrays bitwise.

Green’s stored U remainder is exactly the sequential float64 subtraction `whole − Hdelta − Vdelta`. Reversing the operation to add Hdelta, Vdelta, and remainder reconstructs whole within at most `5.3e-23 m/s²`; PR296’s alternative `whole − (Hdelta + Vdelta)` remainder differs from Green’s by at most `5.3e-23`. The squared-norm identity closes to float64 summation roundoff. RMS norms are not additive: stored U whole / corrected H+V / remainder RMS values are `7.49228e-8 / 6.52200e-10 / 7.49192e-8 m/s²`.

The disjoint U x partitions (west 256 + internal 3,840 = owner 4,096), U y partitions (256 + 3,584 + 256), and all 16 per-level masks close. V has 3,840 owner points and MU has 256. Their x/y partitions and count-weighted RMS checks close as well. The U term captures include a physical closing face at x=16, but Green crops it before the 4,096-point owner comparison.

Green now labels V rows as physical `y1`, `y15`, and `y2_to_y14`. The final coordinate audit verifies all-owner, x-seam/interior, y-region, seam-y, and per-level maximum indices against direct array argmaxes; 3-D/per-level indices carry the physical-j offset while y-slice and seam indices remain local `[k,i]` or `[k]`. Counts (256, 256, and 3,328) partition the 3,840-point V mask. Green JSON SHA-256 is `11f1c3b22572bb3a406016fbff7d3d94b3f89a261f9e86c37b127a804281b83c`; the NPZ is unchanged at `8170ad460956e9ab1e755697228c69fae907ad1cb733b3b53711652e1267846b`.

## Remaining channels

The stored U residual after the captured H/V component deltas is `7.49192e-8 m/s²` RMS, `2.65139e-7 m/s²` max. This is a partial algebraic remainder. The evidence does not identify it as pressure, EOS, transport, or another term. Stored V and MU full-comparison residuals are `7.62176e-8 m/s²` RMS and `3.36932e-8 Pa/s`; initial MU residual is zero.

The Fortran full-RHS snapshot at `dyn_em/solve_em.F:1364-1404` contains combined U/V/MU tendencies and native mass/flux operands, but omits post-add `rw_tend`, `ph_tend`, and `t_tend`. A separate frozen `wrf_rk_tend_dump.bin` does contain those three arrays before `rk_addtend_dry` (`solve_em.F:1192-1219`; additive call at `1279-1292`). It is not a complete Full-RHS substitute. The raw payload is extracted and hash-pinned in `frozen_fortran_rk_tend_payload.npz` and described in `pr296_full_rhs_residual_closure_audit.json`.

A next complete W/PH/theta comparison needs those Fortran tendencies captured after `rk_addtend_dry` at a state-matched point. Attribution of remaining U error needs isolated term bracketing and operands for the candidate term; subtraction alone does not support pressure or transport claims.

## Artifacts

- `green_remainder_independent_review.json` and `review_green_remainder.py`: independent recomputation, algebra, mask, and source-array checks.
- `pr296_full_rhs_residual_closure_audit.json` and `audit_full_rhs_residual_closure.py`: all-face U closure plus frozen Fortran pre-add tendency payload extraction.
- `frozen_fortran_rk_tend_payload.npz`: extracted initial/stored stream payload arrays.
