#!/usr/bin/env python3
"""Independent FP32-output/mask audit for three archived RK3 NetCDF ladders."""
from __future__ import annotations
import hashlib, json
from pathlib import Path
import numpy as np
from netCDF4 import Dataset

ROOT = Path("/Users/yhlee/AD-SDIRK3-review-evidence/seam-cause-acceptance-20261012/green_acceptance/native_qualification_v3")
OUT = Path(__file__).with_name("red_precision_metrics.json")
GREEN = ROOT / "analysis_v3.json"
GREEN_METRIC = ROOT / "evaluation_v3.json"
RUNS = {
    "coarse_h3p75": ROOT / "runs/rk3_h3p75_stock_control",
    "mid_h1p875": ROOT / "archived_h1p875_reference/reference",
    "fine_h0p9375": ROOT / "runs/rk3_h0p9375_reference_qualification",
}
TIMES = ("0001-01-01_00:01:00", "0001-01-01_00:04:00")
G = 9.81

def sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1<<20),b""): h.update(b)
    return h.hexdigest()

def times_from(ds):
    return [b"".join(row).decode("ascii") for row in ds.variables["Times"][:]]

def read_run(label: str, directory: Path):
    out={}; receipts=[]; time_paths={}
    files=sorted(directory.glob("wrfout_d01_*"))
    if not files: raise RuntimeError(f"no raw wrfout files under {directory}")
    for p in files:
        with Dataset(p) as ds:
            ts=times_from(ds)
            receipts.append({"path":str(p),"sha256":sha(p),"times":ts})
            for time in TIMES + ("0001-01-01_00:00:00",):
                if time not in ts: continue
                n=ts.index(time)
                time_paths[time]=p
                U=np.asarray(ds.variables["U"][n],dtype=np.float32)
                T=np.asarray(ds.variables["T"][n],dtype=np.float32)
                PH=np.asarray(ds.variables["PH"][n],dtype=np.float32)
                # Owner masks: U face 0 is physical and retained; closing duplicate is removed.
                q={"U":U[:,:,:-1], "T":T, "PH":PH[1:,:,:]}
                if time in out: raise RuntimeError(f"duplicate timestamp {label}/{time}")
                out[time]=q
    for t in TIMES + ("0001-01-01_00:00:00",):
        if t not in out: raise RuntimeError(f"missing timestamp {label}/{t}")
    return out,receipts,time_paths

def f64_rms(a): return float(np.sqrt(np.mean(np.asarray(a,dtype=np.float64)**2)))
def cosine(a,b):
    a=np.asarray(a,dtype=np.float64).ravel(); b=np.asarray(b,dtype=np.float64).ravel()
    den=np.linalg.norm(a)*np.linalg.norm(b)
    return float(np.dot(a,b)/den) if den else None
def summarize_delta(a,b):
    d=np.asarray(a,dtype=np.float64)-np.asarray(b,dtype=np.float64)
    return {"rms":f64_rms(d),"max_abs":float(np.max(np.abs(d))),"count":int(d.size)}
def rounding_bound(a,b):
    # Output-storage quantization only: independent +/- half-ULP for each saved FP32 value.
    ua=np.abs(np.spacing(np.asarray(a,dtype=np.float32))).astype(np.float64)
    ub=np.abs(np.spacing(np.asarray(b,dtype=np.float32))).astype(np.float64)
    bound=0.5*(ua+ub)
    return {"rms_bound":f64_rms(bound),"max_pointwise_bound":float(np.max(bound)),
            "rms_bound_over_delta_rms":None}
def main():
    runs={}; receipts={}; time_paths={}
    for label,directory in RUNS.items(): runs[label],receipts[label],time_paths[label]=read_run(label,directory)
    green=json.loads(GREEN.read_text())
    green_metric=json.loads(GREEN_METRIC.read_text())
    green_metric_rows={(r["time"],r["field"]):r for r in green_metric["reference_qualification_rows"]}
    # Verify common initial saved values and U's stored closing-face closure.
    initial={name:runs[name]["0001-01-01_00:00:00"] for name in RUNS}
    initial_equal={f:all(np.array_equal(initial["coarse_h3p75"][f],initial[n][f]) for n in ("mid_h1p875","fine_h0p9375")) for f in ("U","T","PH")}
    closure={}
    for label,directory in RUNS.items():
        row={}
        for time in TIMES:
            p=time_paths[label][time]
            # Read raw U separately because owned q intentionally dropped the duplicate face.
            if p is None: raise RuntimeError(f"cannot locate timestamp {label}/{time}")
            with Dataset(p) as ds:
                ts=times_from(ds); u=np.asarray(ds.variables["U"][ts.index(time)],dtype=np.float32)
                row[time]={"max_abs_closing_minus_face0":float(np.max(np.abs(u[:,:,-1].astype(np.float64)-u[:,:,0].astype(np.float64)))),
                           "owned_face_count":int(u[:,:,:-1].size),"stored_face_count":int(u.size)}
        closure[label]=row
    report={
      "schema":"red-rk3-output-precision-ladder-v1",
      "scope":"Independent read-only recomputation from preserved raw NetCDF; U,T,PH only; no model run/build/source edit.",
      "times_seconds":{"60":"0001-01-01_00:01:00","240":"0001-01-01_00:04:00"},
      "ladders":{"coarse":"RK3 h=3.75s","mid":"archived RK3 h=1.875s","fine":"RK3 h=0.9375s"},
      "field_units":{"U":"m s-1","T":"stored WRF perturbation K (theta=T+300K; differences are unchanged)","PH":"m2 s-2 geopotential perturbation; equivalent height difference=PH/g m with g=9.81 m s-2"},
      "masks":{"U":"retain physical faces x=0..15; include face 0, exclude duplicate closing x=16","T":"all 16x16x16 mass points","PH":"PH[1:] ; exclude fixed lower face, include top; 16x16x16 points","counts":{"U":4096,"T":4096,"PH":4096}},
      "common_initial_state_exact":initial_equal,
      "u_periodic_closure":closure,
      "d_definitions":{"d1":"coarse h3.75 minus mid h1.875","d2":"mid h1.875 minus fine h0.9375","d1_increment":"(coarse(t)-coarse(0))-(mid(t)-mid(0))","d2_increment":"(mid(t)-mid(0))-(fine(t)-fine(0))"},
      "measurements":{},
      "raw_files":receipts,
      "green_scalar_check":{"source":str(GREEN_METRIC),"analysis_source":str(GREEN),"checks":[]},
      "precision_scope":"Roundoff bounds cover only half-ULP storage rounding of the saved FP32 endpoint arrays. They do not bound internal Fortran arithmetic, integration error, NetCDF transforms, or model truncation error."
    }
    green_sens=green.get("reference_step_sensitivity",{}).get("times",{})
    for time in TIMES:
        frame={"fields":{}}
        for field in ("U","T","PH"):
            c=runs["coarse_h3p75"][time][field]; m=runs["mid_h1p875"][time][field]; f=runs["fine_h0p9375"][time][field]
            c0=initial["coarse_h3p75"][field];m0=initial["mid_h1p875"][field];f0=initial["fine_h0p9375"][field]
            d1=c.astype(np.float64)-m.astype(np.float64); d2=m.astype(np.float64)-f.astype(np.float64)
            i1=(c.astype(np.float64)-c0.astype(np.float64))-(m.astype(np.float64)-m0.astype(np.float64))
            i2=(m.astype(np.float64)-m0.astype(np.float64))-(f.astype(np.float64)-f0.astype(np.float64))
            b1=rounding_bound(c,m); b2=rounding_bound(m,f)
            r1=f64_rms(d1);r2=f64_rms(d2);b1["rms_bound_over_delta_rms"]=b1["rms_bound"]/r1 if r1 else None;b2["rms_bound_over_delta_rms"]=b2["rms_bound"]/r2 if r2 else None
            item={
              "shape":list(c.shape),"dtype_raw":"float32",
              "coarse_total_rms":f64_rms(c),"mid_total_rms":f64_rms(m),"fine_total_rms":f64_rms(f),
              "coarse_initial_removed_rms":f64_rms(c.astype(np.float64)-c0.astype(np.float64)),
              "mid_initial_removed_rms":f64_rms(m.astype(np.float64)-m0.astype(np.float64)),
              "fine_initial_removed_rms":f64_rms(f.astype(np.float64)-f0.astype(np.float64)),
              "d1_total":summarize_delta(c,m),"d1_initial_removed":summarize_delta(c.astype(np.float64)-c0.astype(np.float64),m.astype(np.float64)-m0.astype(np.float64)),
              "d2_total":summarize_delta(m,f),"d2_initial_removed":summarize_delta(m.astype(np.float64)-m0.astype(np.float64),f.astype(np.float64)-f0.astype(np.float64)),
              "d1_initial_removed_equals_total_exact":bool(np.array_equal(d1,i1)),
              "d2_initial_removed_equals_total_exact":bool(np.array_equal(d2,i2)),
              "d1_d2_cosine":cosine(d1,d2),"d1_output_rounding_bound":b1,"d2_output_rounding_bound":b2,
              "d1_geopotential_height_rms_m":r1/G if field=="PH" else None,
              "d2_geopotential_height_rms_m":r2/G if field=="PH" else None,
            }
            # Green v3's frozen scalar computes mid-minus-fine for the same owned fields and time.
            if time in green_sens and field in green_sens[time]:
                expected=float(green_sens[time][field]["rms"])
                item["green_mid_minus_fine_rms"] = expected
                item["green_mid_minus_fine_rms_abs_diff"] = abs(r2-expected)
            metric_row=green_metric_rows.get((time,field))
            if metric_row:
                expected_metric=float(metric_row["rms_h09375_minus_h1875"])
                item["green_metric_rms_h09375_minus_h1875"] = expected_metric
                item["green_metric_rms_abs_diff"] = abs(r2-expected_metric)
                report["green_scalar_check"]["checks"].append({"time":time,"field":field,"red_d2_rms":r2,"green_metric_rms":expected_metric,"abs_diff":abs(r2-expected_metric)})
            frame["fields"][field]=item
        report["measurements"][time]=frame
    report["green_scalar_check"]["all_match_with_1e-12_abs"] = all(x["abs_diff"]<1e-12 for x in report["green_scalar_check"]["checks"])
    OUT.write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
    print(json.dumps({"output":str(OUT),"green_scalar_check":report["green_scalar_check"],"measurements":{t:{k:{"d1_rms":v["d1_total"]["rms"],"d2_rms":v["d2_total"]["rms"],"d1_round_ratio":v["d1_output_rounding_bound"]["rms_bound_over_delta_rms"],"d2_round_ratio":v["d2_output_rounding_bound"]["rms_bound_over_delta_rms"]} for k,v in x["fields"].items()} for t,x in report["measurements"].items()}},indent=2))
if __name__=="__main__": main()
