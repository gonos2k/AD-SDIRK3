#!/usr/bin/env python3
"""Plot fieldwise RK3 successive-difference RMS from the frozen metric JSON."""
from __future__ import annotations
import hashlib, json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

E2=Path('/Users/yhlee/AD-SDIRK3-review-evidence/rk3-reference-shape-20261012')
SOURCE=E2/'green_metric/portable_cli_run/rk3_reference_shape_analysis.json'
OUT=E2/'green_pressure/rk3_successive_difference_rms.png'
FIELDS=('U','V','W','PH','T','MU')
TICKS=(60,120,180,240)
LABELS={
 'd1_middle_minus_coarse':'d1: mid h=1.875 s − coarse h=3.75 s',
 'd2_fine_minus_middle':'d2: fine h=0.9375 s − mid h=1.875 s',
}

def seconds(stamp:str)->int:
    return int(stamp[-2:])+60*int(stamp[-5:-3])

def main():
    raw=SOURCE.read_bytes()
    data=json.loads(raw)
    rows=data['metrics']
    units={r['field']:r['units'] for r in rows}
    if len(rows)!=24 or set(r['field'] for r in rows)!=set(FIELDS):
        raise ValueError('Expected the frozen 24 field/checkpoint metric rows')
    times=sorted({seconds(r['time']) for r in rows})
    if tuple(times)!=TICKS:
        raise ValueError(f'Expected 60, 120, 180, 240 second checkpoints, found {times}')
    lookup={(r['field'],seconds(r['time'])):r for r in rows}

    plt.rcParams.update({
        'font.size': 9, 'axes.titlesize': 11, 'axes.labelsize': 9,
        'legend.fontsize': 8, 'xtick.labelsize': 8, 'ytick.labelsize': 8,
        'figure.titlesize': 13, 'savefig.facecolor': 'white',
    })
    fig,axes=plt.subplots(3,2,figsize=(9.2,8.3),sharex=True,constrained_layout=True)
    fig.suptitle('RK3 successive-difference RMS by elapsed time',y=1.015)
    styles={
      'd1_middle_minus_coarse':{'color':'#2864a5','marker':'o','linestyle':'-'},
      'd2_fine_minus_middle':{'color':'#d27620','marker':'s','linestyle':'--'},
    }
    for ax,field in zip(axes.ravel(),FIELDS):
        for key,label in LABELS.items():
            values=[lookup[(field,t)][key]['rms'] for t in times]
            ax.plot(times,values,label=label,linewidth=1.8,markersize=4.5,**styles[key])
        ax.set_title(field)
        ax.set_ylabel(f'RMS difference ({units[field]})')
        ax.set_yscale('log')
        ax.set_xticks(TICKS,labels=[str(t) for t in TICKS])
        ax.set_xlim(52,248)
        ax.grid(True,which='major',color='#d9dee6',linewidth=.7)
        ax.grid(True,which='minor',axis='y',color='#edf0f4',linewidth=.45)
        ax.set_axisbelow(True)
    for ax in axes[-1,:]:ax.set_xlabel('Elapsed time (s)')
    axes[0,0].legend(loc='upper left',frameon=True,framealpha=.94)
    fig.text(.5,-.012,'Each panel has its own physical units and logarithmic RMS scale. Descriptive trajectory differences; no truth-bound or order claim.',ha='center',fontsize=8,color='#444')
    fig.savefig(OUT,dpi=160,bbox_inches='tight')
    plt.close(fig)
    import struct
    with OUT.open('rb') as f:
        header=f.read(24)
    # PNG width/height are big endian uint32 at bytes 16..24.
    width,height=struct.unpack('>II',header[16:24])
    receipt={
      'schema':'rk3-successive-rms-figure-v1',
      'source_json':str(SOURCE),'source_json_sha256':hashlib.sha256(raw).hexdigest(),
      'figure':str(OUT),'figure_sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),
      'figure_bytes':OUT.stat().st_size,'png_dimensions_px':[width,height],
      'fields':list(FIELDS),'checkpoints_seconds':list(TICKS),
      'axes':'3 rows x 2 columns; independent y-axis per field, logarithmic scale; no cross-unit axis.'
    }
    (OUT.parent/'figure_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
