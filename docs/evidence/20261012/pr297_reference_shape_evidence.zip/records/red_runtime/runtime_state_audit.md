# RK3 runtime and initial-state audit

Scope: read archived namelists, RSL timing logs, manifests, and relevant Fortran source only. No rebuild, model run, or production edit.

The three RK3 cases use exact requested steps 3.75 s (3 + 6/8), 1.875 s (1 + 7/8), and 0.9375 s (0 + 15/16). Their archived RSL main-timing counts are 64, 128, and 256, respectively; all end at 0001-01-01 00:04:00. Each namelist has `run_seconds=240`, `restart=.false.`, the same start date, RK3 (`time_integration_scheme=0`, `rk_ord=3`), and the same `wrfinput_d01` SHA. A textual diff of the three namelists found only the three timestep fields differ.

The source in `share/set_timekeeping.F` computes physics `dt` as `REAL(time_step)+REAL(fract_num)/REAL(fract_den)` and separately passes integer seconds and fractional numerator/denominator into `WRFU_TimeIntervalSet` for the model clock. The selected fractions are exactly representable in binary. The observed step counts and final RSL times support the expected 240-second totals, but RSL timestamps are integer seconds and there is no per-step clock trace to prove the adapter's fractional increments independently.

There is a provenance asymmetry: h=3.75 and h=0.9375 share executable SHA `f7c4e1db…f413b64`; the archived h=1.875 run uses `2b629416…fcc2de` built from revision `de23ed32509ada2c90fbf7dabbf261da480c78ed`. Comparing relevant authoritative sources to current revision `3c8ef9c26` found no changes in timekeeping, configuration, or diffusion/advection sources. The only diff in `dyn_em/solve_em.F` is an opt-in snapshot writer gated by `WRF_PARITY_RK_TEND_DUMP=1`; current coarse/fine receipts say environment overrides were removed and capture flags were unset. The middle archive has no explicit runtime environment receipt. Thus the RK3 control path appears unchanged, but exact same-executable G-family equivalence across all three archived points is not proven.

All three namelists contain `end_day=2` (next day) alongside `run_seconds=240`. Since each RSL ends at 00:04, the observed run duration follows `run_seconds`; the inconsistent end date is recorded as a configuration quirk, not evidence of a changed control path.

No production fix is indicated by this audit. Evidence and exact hashes/paths are recorded in `runtime_state_audit.json`. Limits: no new native run/build, no per-step fractional-clock trace, no saved restart state, and no new field-accuracy/convergence assessment.
