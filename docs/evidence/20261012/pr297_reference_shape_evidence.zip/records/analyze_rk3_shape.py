#!/usr/bin/env python3
"""Bounded X-spectrum and phase analysis of three archived RK3 NetCDF outputs."""
from __future__ import annotations
import hashlib, json
from pathlib import Path
import numpy as np
from netCDF4 import Dataset

OUTDIR=Path('/Users/yhlee/AD-SDIRK3-review-evidence/rk3-reference-shape-20261012')
V3=Path('/Users/yhlee/AD-SDIRK3-review-evidence/seam-cause-acceptance-20261012/green_acceptance/native_qualification_v3')
PLAN=json.loads((V3/'analysis_runs.json').read_text())
TIMES=('0001-01-01_00:01:00','0001-01-01_00:04:00')
RUNS={
 'coarse_h3p75': V3/'runs/rk3_h3p75_stock_control',
 'mid_h1p875_archived': V3/'archived_h1p875_reference/reference',
 'fine_h0p9375': V3/'runs/rk3_h0p9375_reference_qualification',
}
INPUTS={
 'coarse_h3p75': RUNS['coarse_h3p75'],
 'mid_h1p875_archived': Path('/Users/yhlee/AD-SDIRK3-review-evidence/WRF-accuracy-cost-20261011/after_fix/fortran_rk3_h1p875'),
 'fine_h0p9375': RUNS['fine_h0p9375'],
}
FIELDS=('U','PH','W','MU')

def sha(p:Path)->str:
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def tstr(row):return b''.join(np.asarray(row).tolist()).decode('ascii').rstrip('\0 ')

def read_fields(root:Path):
 frames={}; receipts=[]
 for p in sorted(root.glob('wrfout_d01*')):
  with Dataset(p) as ds:
   for n,row in enumerate(ds.variables['Times'][:]):
    t=tstr(row)
    if t not in TIMES:continue
    if t in frames:raise ValueError(f'duplicate {t} at {root}')
    raw={k:np.asarray(ds.variables[k][n]) for k in FIELDS}
    units={k:str(ds.variables[k].getncattr('units')) if 'units' in ds.variables[k].ncattrs() else None for k in FIELDS}
    # Match the established shared physical owner mask: remove duplicate periodic U face,
    # bottom W and PH face; retain all physical mass points and MU cells.
    frames[t]={'U':raw['U'][:,:,:-1], 'PH':raw['PH'][1:,:,:], 'W':raw['W'][1:,:,:], 'MU':raw['MU']}
    frames[t]['_units']=units
    receipts.append({'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'selected_time':t})
 if set(frames)!=set(TIMES):raise ValueError(f'{root}: times found {sorted(frames)}')
 return frames,receipts

def mode_rms(a):
 """RMS contribution of each real X Fourier mode; Parseval-normalized."""
 a=np.asarray(a,dtype=np.float64); n=a.shape[-1]
 z=np.fft.rfft(a,axis=-1)
 factor=np.full(z.shape[-1],2.0);factor[0]=1.0
 if n%2==0:factor[-1]=1.0
 power=(np.abs(z)**2)*factor
 # Mean over all non-X samples and N^2 for the transform normalization.
 power_sum=np.sum(power,axis=tuple(range(a.ndim-1)))/(float(np.prod(a.shape[:-1]))*n*n)
 return np.sqrt(np.maximum(power_sum,0.0)), z

def describe_difference(d1,d2):
 d1=np.asarray(d1,dtype=np.float64);d2=np.asarray(d2,dtype=np.float64)
 r1=float(np.sqrt(np.mean(d1*d1)));r2=float(np.sqrt(np.mean(d2*d2)))
 mean1=float(np.mean(d1));mean2=float(np.mean(d2))
 den=float(np.linalg.norm(d1.ravel())*np.linalg.norm(d2.ravel()))
 corr=float(np.sum(d1*d2)/den) if den else None
 mode1,F1=mode_rms(d1);mode2,F2=mode_rms(d2)
 m=len(mode1)
 p1=mode1*mode1;p2=mode2*mode2
 total1=float(np.sum(p1));total2=float(np.sum(p2))
 def fraction(p,lo,hi,total):return float(np.sum(p[lo:hi])/total) if total else 0.0
 xband={
  'x_invariant_k0_fraction_d1':fraction(p1,0,1,total1), 'x_invariant_k0_fraction_d2':fraction(p2,0,1,total2),
  'low_k1_2_fraction_d1':fraction(p1,1,min(3,m),total1), 'low_k1_2_fraction_d2':fraction(p2,1,min(3,m),total2),
  'middle_k3_5_fraction_d1':fraction(p1,3,min(6,m),total1), 'middle_k3_5_fraction_d2':fraction(p2,3,min(6,m),total2),
  'high_k6_nyquist_fraction_d1':fraction(p1,6,m,total1), 'high_k6_nyquist_fraction_d2':fraction(p2,6,m,total2),
 }
 def top_share(d):
  q=(d.ravel()**2); n=max(1,int(np.ceil(.05*q.size)));return float(np.sort(q)[-n:].sum()/q.sum()) if q.sum() else 0.0
 top1,top2=top_share(d1),top_share(d2)
 mf1=abs(mean1)/r1 if r1 else 0.0;mf2=abs(mean2)/r2 if r2 else 0.0
 def classify(meanfrac,xf,low,high,top):
  if meanfrac>=.5 and xf>=.5:return 'mean_or_x_invariant_component_dominates'
  if low>=.5:return 'low_x_wavenumber_structure_dominates'
  if high>=.5 and top>=.25:return 'high_x_wavenumber_and_spatially_concentrated'
  if high>=.5:return 'high_x_wavenumber_but_spatially_distributed'
  return 'mixed_x_scales'
 # Cross-spectral coherence and phase of d1 against d2 by X mode.
 cross=[]
 for k in range(m):
  f1=F1[...,k].ravel();f2=F2[...,k].ravel()
  cross_sum=np.sum(f1*np.conj(f2))
  norm=float(np.sqrt(np.sum(abs(f1)**2)*np.sum(abs(f2)**2)))
  cross.append({'k':k,'coherence':float(abs(cross_sum)/norm) if norm else None,
                'phase_d1_vs_d2_rad':float(np.angle(cross_sum)) if norm else None})
 def top_modes(mr):return [{'k':int(k),'mode_rms':float(mr[k])} for k in np.argsort(mr)[::-1][:min(4,len(mr))]]
 return {
  'd1_mid_minus_coarse':{'mean':mean1,'rms':r1,'max_abs':float(np.max(np.abs(d1))),'abs_mean_over_rms':mf1,
    'spatial_top_5pct_energy_share':top1,'x_mode_rms':mode1.tolist(),'top_x_modes':top_modes(mode1),
    'classification':classify(mf1,xband['x_invariant_k0_fraction_d1'],xband['low_k1_2_fraction_d1'],xband['high_k6_nyquist_fraction_d1'],top1)},
  'd2_fine_minus_mid':{'mean':mean2,'rms':r2,'max_abs':float(np.max(np.abs(d2))),'abs_mean_over_rms':mf2,
    'spatial_top_5pct_energy_share':top2,'x_mode_rms':mode2.tolist(),'top_x_modes':top_modes(mode2),
    'classification':classify(mf2,xband['x_invariant_k0_fraction_d2'],xband['low_k1_2_fraction_d2'],xband['high_k6_nyquist_fraction_d2'],top2)},
  'd1_d2_spatial_correlation':corr,'d2_over_d1_rms':r2/r1 if r1 else None,
  'power_fractions':xband,'mode_cross_spectrum_d1_vs_d2':cross,
 }

run_data={};receipts={}
for label,path in RUNS.items():run_data[label],receipts[label]=read_fields(path)
result={'schema':'rk3-reference-shape-spectrum-phase-v1','scope':'Archived raw WRF NetCDF only; no native reruns, no truth/frequency claim.',
 'times':list(TIMES),'runs':{k:{'path':str(v),'method':('RK3' if k.startswith(('coarse','mid','fine')) else None),
   'frame_receipts':receipts[k],
   'input_wrfinput_sha256':sha(INPUTS[k]/'wrfinput_d01'),
   'input_namelist_sha256':sha(INPUTS[k]/'namelist.input'),
   'input_source_path':str(INPUTS[k])} for k,v in RUNS.items()},
 'owned_mask':'Same as frozen V3 evaluator: U[:,:, :-1] (exclude periodic duplicate face), PH[1:,:,:], W[1:,:,:], MU unchanged.',
 'analysis_conventions':{'d1':'mid h=1.875 minus coarse h=3.75','d2':'fine h=0.9375 minus mid h=1.875','x_fourier':'rFFT on final (west_east) axis, Parseval-normalized mode RMS; k0 is x-invariant, k1-2 low, k3-5 middle, k6..Nyquist high.','cross_phase':'phase of sum(F(d1)*conj(F(d2))) per X mode; coherence is normalized magnitude.','classification_heuristic':'mean/x-invariant if abs(global mean)/RMS >= 0.5 and k0 power >= 0.5; low-X if k1-2 power >= 0.5; high-X localized if k6..Nyquist power >= 0.5 and top 5% spatial squared-energy share >= 0.25; high-X distributed if high power >= 0.5 otherwise mixed. These labels describe this finite sample only.'},
 'fields':{}}
for t in TIMES:
 result['fields'][t]={}
 for fld in FIELDS:
  arrays={r:run_data[r][t][fld].astype(np.float64) for r in RUNS}
  shapes={r:list(a.shape) for r,a in arrays.items()}
  if len({tuple(s) for s in shapes.values()})!=1:raise ValueError(f'{t}/{fld} shape mismatch {shapes}')
  coarse,mid,fine=(arrays[k] for k in ('coarse_h3p75','mid_h1p875_archived','fine_h0p9375'))
  d1=mid-coarse;d2=fine-mid
  result['fields'][t][fld]={
   'units':run_data['coarse_h3p75'][t]['_units'][fld],'owned_shape':shapes['coarse_h3p75'],
   'run_means':{k:float(np.mean(a)) for k,a in arrays.items()},
   'run_x_mode_rms':{k:mode_rms(a)[0].tolist() for k,a in arrays.items()},
   'd1_d2':describe_difference(d1,d2),
  }
# Compact bounded interpretation for the paired 60 s and 240 s records.
classes=[(t,f,result['fields'][t][f]['d1_d2']) for t in TIMES for f in FIELDS]
result['observations']={
 'all_run_differences_are_state_space_only':'The spectrum and correlation results describe differences among these three archived RK3 trajectories. The h=0.9375 run is not assumed to be truth.',
 '240s':'All four d1 and d2 fields are low-X-wavenumber dominated: k=1-2 contains about 68% (W) to >99% (U/MU) of difference power. Mean offsets are small relative to difference RMS. d1-d2 spatial correlation ranges from 0.40 (W) to 0.999 (U/MU).',
 '60s':'U and MU increments are strongly aligned (correlations 0.999 and 0.980) and >99% in k=1-2. PH and W are mixed across X modes; their d1-d2 correlations are -0.170 and -0.426. PH d2 places about 54% of its squared difference energy in the top 5% of spatial points, while high X modes remain a minority.',
 'refinement_spacing':'d2 RMS exceeds d1 RMS for U, PH, MU at 60 s and all four fields at 240 s; W at 60 s is nearly equal. This does not show a monotone difference decrease over this sampled step-size ladder.',
 'high_frequency_classifications':[{'time':t,'field':f,'d1':q['d1_mid_minus_coarse']['classification'],'d2':q['d2_fine_minus_mid']['classification']} for t,f,q in classes]
}
out=OUTDIR/'rk3_spectral_phase_audit.json'
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'out':str(out),'times':list(TIMES),'fields':{t:{f:{'d1_d2_corr':result['fields'][t][f]['d1_d2']['d1_d2_spatial_correlation'],'d2_d1_rms':result['fields'][t][f]['d1_d2']['d2_over_d1_rms'],'d1_class':result['fields'][t][f]['d1_d2']['d1_mid_minus_coarse']['classification'],'d2_class':result['fields'][t][f]['d1_d2']['d2_fine_minus_mid']['classification']} for f in FIELDS} for t in TIMES}},indent=2))
