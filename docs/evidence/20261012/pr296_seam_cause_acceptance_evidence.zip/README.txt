PR296 packed-U option-2 diffusion seam evidence

This bundle contains raw 15-second same-state captures, source/build receipts,
offline analysis arrays and targeted C++/Fortran source. It does not contain
compiled executables, static libraries, objects, generated Fortran, or build
directories. The fixed executable bytes remain on the producer machine and
are identified only by SHA-256 in the receipts.

The comparison applies to dry, flat `test/em_b_wave`, 16x16x16 physical cells,
periodic X and symmetric nonperiodic Y, `diff_opt=2`, `khdif=1000`, `kvdif=10`,
`mix_full_fields=false`, one MPI rank and one thread. Each baseline/fixed/fixed_xy
phase has paired 15-second h=15 Fortran RK3 and ARK mode-3 captures from both
the original input and the same saved 60-second RK3 state. The reports record
effective `hypsometric_opt=1` for the ideal case despite nominal
`HYPSOMETRIC_OPT=2` in `namelist.output`.

Packed horizontal storage (17x17x16) is distinct from the physical domain
(16x16x16). Full-RHS U norms use 4,096 unique owner faces, V uses 3,840 interior
faces and MU uses 256 cells; the periodic closing U face is checked but not
double-counted. Term-array analyses preserve 4,352 saved U rows including the
Y storage endpoint; do not substitute those term-analysis norms for the
canonical full-RHS owner metrics.

The fixed_xy same-state captures reduce the isolated option-2 vertical-U
diffusion mismatch to about 1.5e-12 m/s^2 RMS. The full U RHS residual remains
about 6.5e-8 m/s^2 at the initial frame and 7.5e-8 at the stored frame; V/MU
residuals remain. This is targeted first-stage component evidence, not complete
F-delta parity, an integrated VJP check, or a forecast-accuracy acceptance.
The named-case v3 reference qualification fails; its candidate differences are
provisional, and no efficiency advantage is claimed. The report explicitly
excludes the superseded startup failures and preliminary baseline analysis
JSONs; old baseline raw snapshots/run receipts are retained for comparison.
The original V3 contract JSON is preserved byte-for-byte. Its PH sampling-label
erratum is a separate metadata-only file; no frozen numeric criterion changed.
The executed PH gate uses geopotential in m^2/s^2; the V3 sampling-label text
described height in metres. `metadata_erratum.json` documents the distinction.
The archived h=1.875 reference package includes its raw NetCDF outputs and
producer receipts, verified against its archive manifest. The three named-case
v3 qualification runs also include their raw WRF inputs/outputs and run logs;
their executable bytes remain local and are hash-pinned.

Portable NumPy reanalysis from the extracted bundle root:

```sh
python3 records/analyze_snapshots.py \
  --source-root records/sources \
  --fortran records/runs/fixed_xy/initial_fortran_rk3_h15/wrf_full_rhs_snapshot.bin \
  --cpp records/runs/fixed_xy/initial_cpp_ark3_h15/port_full_rhs_snapshot.bin \
  --out /tmp/pr296_initial_full_rhs.json

python3 records/analyze_snapshots.py \
  --source-root records/sources \
  --fortran records/runs/fixed_xy/stored_fortran_rk3_h15/wrf_full_rhs_snapshot.bin \
  --cpp records/runs/fixed_xy/stored_cpp_ark3_h15/port_full_rhs_snapshot.bin \
  --out /tmp/pr296_stored_full_rhs.json

python3 records/red_arrays/analyze_hdiff_capture.py \
  --source-root records/sources --case fixed_xy_initial \
  --fortran-hdiff records/runs/fixed_xy/initial_fortran_rk3_h15/wrf_u_hdiff_snapshot.bin \
  --cpp-hdiff records/runs/fixed_xy/initial_cpp_ark3_h15/port_hdiff_u_snapshot.bin \
  --fortran-full records/runs/fixed_xy/initial_fortran_rk3_h15/wrf_full_rhs_snapshot.bin \
  --cpp-full records/runs/fixed_xy/initial_cpp_ark3_h15/port_full_rhs_snapshot.bin \
  --fortran-vdiff-before records/runs/fixed_xy/initial_fortran_rk3_h15/wrf_u_vdiff_before.bin \
  --cpp-vdiff records/runs/fixed_xy/initial_cpp_ark3_h15/port_vdiff_u_snapshot.bin \
  --out /tmp/pr296_initial_terms.json --npz /tmp/pr296_initial_terms.npz
```

`records/green_pressure/replay_vdiff_y0.py` reproduces the stencil-local D13
counterfactual with NumPy and netCDF4 using the archived input coefficients.
The local C++ regression source and final validation logs are in
`records/local_contract/`; historical superseded compile receipts remain under
`records/local_contract/superseded_old_source_compile/`.

Run/source/executable receipts:
{
  "baseline": {
    "executable_sha256": "86608a7636eaed8747d4361ce75691b72a8c89936eed5dff90ef6fe6cc5ec86d",
    "head": "3c8ef9c26d6caf9b3a54876d0caa19db361e5dc9",
    "library_sha256": "95b314d5d0897bb35490a7743efd826fdd60c4af5ecff98fe3654462497a4e31",
    "run_count": 4,
    "source_sha256": {
      "dyn_em/module_big_step_utilities_em.F": "0c18cf55d444de1dff1b7b45a88156934718525df483ae516e916708c939bf71",
      "dyn_em/module_em.F": "fb424486dbf9c903f77da6a15baf35e6772847e786b18d0297139eb48f0d586e",
      "dyn_em/module_first_rk_step_part2.F": "9cf4cb7fddfee2f85d280fe6fa23c4fdf855ad4362e027dafd251a49cbbe189e",
      "dyn_em/module_implicit_sdirk3.F": "041c49f0e03b6f998fd120cdd0dbe6e7068aa68f39af9c027967324b88ddb11a",
      "dyn_em/module_small_step_em.F": "cabf1a177d50fb0096db79644af20cfe6d75217dbe63ab406a7e29bb54c17634",
      "dyn_em/solve_em.F": "859883043a3af98a05ac682afec63a680cc3e0b7a17623dddd7f4e126260ba8c",
      "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp": "95e63bf0db0c48ae9e41487b91d6f7bbcf66e481ce3b449b4af8f8944d295e3a"
    }
  },
  "fixed": {
    "executable_sha256": "7400668504fcf23d365f612ebc4354a4249ba1e6a8451c06335671289e4e94a6",
    "head": "3c8ef9c26d6caf9b3a54876d0caa19db361e5dc9",
    "library_sha256": "9122c84a3015901fe41216802cccf935b0bb349125101cf6d89e002ae1b77046",
    "run_count": 4,
    "source_sha256": {
      "dyn_em/module_big_step_utilities_em.F": "0c18cf55d444de1dff1b7b45a88156934718525df483ae516e916708c939bf71",
      "dyn_em/module_em.F": "fb424486dbf9c903f77da6a15baf35e6772847e786b18d0297139eb48f0d586e",
      "dyn_em/module_first_rk_step_part2.F": "f7b8dc143d1621d55508828fb1adc81ad056980cc2f5768bfea1707c49f9646c",
      "dyn_em/module_implicit_sdirk3.F": "041c49f0e03b6f998fd120cdd0dbe6e7068aa68f39af9c027967324b88ddb11a",
      "dyn_em/module_small_step_em.F": "cabf1a177d50fb0096db79644af20cfe6d75217dbe63ab406a7e29bb54c17634",
      "dyn_em/solve_em.F": "859883043a3af98a05ac682afec63a680cc3e0b7a17623dddd7f4e126260ba8c",
      "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp": "61679c7ea7aba1e2921c4792342a3ab437a8eda1c2780e6710fb51bb213f0fb3"
    }
  },
  "fixed_xy": {
    "executable_sha256": "f7c4e1dbb69a3ec68e5376294e326cbaff339531f31dac13ed47e0fcbf413b64",
    "head": "3c8ef9c26d6caf9b3a54876d0caa19db361e5dc9",
    "library_sha256": "5f28e24cc3019c59c45ed8942e9ad104fc6a8a2c62f59416fe0d04fec317556f",
    "run_count": 4,
    "source_sha256": {
      "dyn_em/module_big_step_utilities_em.F": "0c18cf55d444de1dff1b7b45a88156934718525df483ae516e916708c939bf71",
      "dyn_em/module_em.F": "fb424486dbf9c903f77da6a15baf35e6772847e786b18d0297139eb48f0d586e",
      "dyn_em/module_first_rk_step_part2.F": "f7b8dc143d1621d55508828fb1adc81ad056980cc2f5768bfea1707c49f9646c",
      "dyn_em/module_implicit_sdirk3.F": "041c49f0e03b6f998fd120cdd0dbe6e7068aa68f39af9c027967324b88ddb11a",
      "dyn_em/module_small_step_em.F": "cabf1a177d50fb0096db79644af20cfe6d75217dbe63ab406a7e29bb54c17634",
      "dyn_em/solve_em.F": "859883043a3af98a05ac682afec63a680cc3e0b7a17623dddd7f4e126260ba8c",
      "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp": "ff722deccd094ac507a16eb4940423b4a60a11ce124df11fd20be78b5bb4f2c3"
    }
  }
}

Committed producer source binding: `78255e14ad4f2d8e07e9e764b47b9eb24266dd53`.
The seven run sources and the compiled scalar-contract test match committed
blobs. The bundle carries a diff from the pinned base and source hashes; it does
not claim a fresh clean-checkout native rerun.
