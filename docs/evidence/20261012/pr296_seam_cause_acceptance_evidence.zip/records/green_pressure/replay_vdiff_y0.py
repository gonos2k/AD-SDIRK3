#!/usr/bin/env python3
"""Independent replay of the symmetric-Y U vertical-diffusion boundary response."""
from __future__ import annotations
import hashlib
import importlib.util
import json
import struct
from pathlib import Path
import numpy as np
from netCDF4 import Dataset

E = Path(__file__).resolve().parents[1]
ROOT = E / 'sources'
CAPDIR = E / 'runs/fixed/stored_fortran_rk3_h15'
CPPDIR = E / 'runs/fixed/stored_cpp_ark3_h15'
INITIAL = E / 'runs/fixed/initial_fortran_rk3_h15/wrfinput_d01'
TERM_NPZ = E / 'fixed_stored_term_arrays.npz'
TERM_JSON = E / 'fixed_stored_term_analysis.json'
OUT = E / 'green_pressure/vdiff_y0_replay.json'


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def receipt(path: Path) -> dict:
    return {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}


def metric(a: np.ndarray) -> dict:
    q = np.asarray(a, dtype=np.float64)
    if q.size == 0:
        return {'count': 0}
    idx = np.unravel_index(np.argmax(np.abs(q)), q.shape)
    return {'count': int(q.size), 'rms': float(np.sqrt(np.mean(q*q))),
            'max_abs': float(np.max(np.abs(q))), 'argmax': [int(i) for i in idx]}

# Reuse the established strict decoders, without invoking model/operator code.
sys_path = E / 'red_arrays/analyze_hdiff_capture.py'
spec = importlib.util.spec_from_file_location('capture_decoder', sys_path)
cap = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(cap)
full_path = E / 'analyze_snapshots.py'
spec_full = importlib.util.spec_from_file_location('full_decoder', full_path)
full = importlib.util.module_from_spec(spec_full)
assert spec_full and spec_full.loader
spec_full.loader.exec_module(full)

ft_path = CAPDIR / 'wrf_u_vdiff_before.bin'
cpp_path = CPPDIR / 'port_vdiff_u_snapshot.bin'
meta, ft = cap.read_vdiff_fortran(ft_path)
b = meta['bounds']
j0, i0, k0 = b['jds']-b['jms'], b['ids']-b['ims'], b['kds']-b['kms']
# 16 physical mass rows, 16 mass levels, 17 U faces/W levels as appropriate.
D = ft['defor13'][j0:j0+16, k0:k0+17, i0:i0+17].copy()
R = ft['rho'][j0:j0+16, k0:k0+16, i0:i0+16].copy()
K = ft['xkmv'][j0:j0+16, k0:k0+16, i0:i0+16].copy()
with Dataset(INITIAL) as nc:
    fnm = np.asarray(nc['FNM'][0], dtype=np.float32)
    fnp = np.asarray(nc['FNP'][0], dtype=np.float32)
    dnw = np.asarray(nc['DNW'][0], dtype=np.float32)
# Verify coefficients were taken from the pinned initial file and use the actual physical profiles.
if fnm.shape != (16,) or fnp.shape != (16,) or dnw.shape != (16,):
    raise ValueError(f'unexpected WRF vertical coefficient shapes: {fnm.shape}, {fnp.shape}, {dnw.shape}')

# C++ compute_defor13 copies the y=1 row onto y=0 for symmetric nonperiodic Y.
# Reconstruct just that boundary substitution over captured FT operands.
D_cpp_copy = D.copy()
D_cpp_copy[0, :, :] = D[1, :, :]

def stress(defor: np.ndarray) -> np.ndarray:
    # Fortran cal_titau_13_31: weighted rho and xkmv averages are separate,
    # and each horizontal neighbor pair is summed before fnm/fnp weighting.
    rho = R.astype(np.float32, copy=False)
    xkmv = K.astype(np.float32, copy=False)
    out = np.zeros((16, 17, 17), dtype=np.float32)
    for k in range(1, 16):  # W interfaces k=2..16 in Fortran indexing
        rho_upper = rho[:, k, :]
        rho_lower = rho[:, k-1, :]
        km_upper = xkmv[:, k, :]
        km_lower = xkmv[:, k-1, :]
        rho_sum_upper = rho_upper + np.roll(rho_upper, 1, axis=1)
        rho_sum_lower = rho_lower + np.roll(rho_lower, 1, axis=1)
        km_sum_upper = km_upper + np.roll(km_upper, 1, axis=1)
        km_sum_lower = km_lower + np.roll(km_lower, 1, axis=1)
        rhoavg = np.float32(0.5) * (fnm[k]*rho_sum_upper + fnp[k]*rho_sum_lower)
        kmavg = np.float32(0.5) * (fnm[k]*km_sum_upper + fnp[k]*km_sum_lower)
        out[:, k, :16] = -(rhoavg*kmavg*defor[:, k, :16])
        out[:, k, 16] = out[:, k, 0]
    # k=0 and k=16 stresses remain zero, as in cal_titau_13_31.
    return out

def vertical_increment(tau: np.ndarray) -> np.ndarray:
    # Fortran vertical_diffusion_u_2 signed dnw flux divergence, all mass levels.
    out = np.zeros((16, 16, 17), dtype=np.float32)
    for k in range(16):
        rdzu = -np.float32(9.81) / dnw[k]
        out[:, k, :16] = -rdzu*(tau[:, k+1, :16] - tau[:, k, :16])
        out[:, k, 16] = out[:, k, 0]
    return out

ft_increment_replay = vertical_increment(stress(D))
copy_increment_replay = vertical_increment(stress(D_cpp_copy))
delta_coupled = copy_increment_replay - ft_increment_replay
terms = np.load(TERM_NPZ)
captured_delta = np.asarray(terms['delta_vdiff_cpp_minus_fortran'], dtype=np.float64)
cpp_mass = np.asarray(terms['cpp_vdiff_velocity_mass_u'], dtype=np.float64)[:16, :, :17]
predicted_physical_delta = delta_coupled.astype(np.float64) / cpp_mass
# Compare the denominator against WRF's c1h*muu+c2h from the exact captured full-RHS frame.
full_meta, full_ft = full.read_fortran(CAPDIR / 'wrf_full_rhs_snapshot.bin')
fb = full_meta['bounds']
mu_u = full._slice2(full_ft['muu'], fb, i0=fb['ids'], i1=fb['ids']+17,
                    j0=fb['jds'], j1=fb['jds']+16)[:16, :17].astype(np.float64)
c1h = full_ft['c1h'][:16].astype(np.float64)
c2h = full_ft['c2h'][:16].astype(np.float64)
ft_mass = c1h[None, :, None]*mu_u[:, None, :] + c2h[None, :, None]

# Owner U columns exclude the duplicated closing face; y=0 contains 16*16 values.
pred_y0 = predicted_physical_delta[0, :, :16]
cap_y0 = captured_delta[0, :, :16]
res_y0 = cap_y0 - pred_y0
flat_idx = np.unravel_index(np.argmax(np.abs(cap_y0)), cap_y0.shape)
correlation = float(np.sum(pred_y0*cap_y0) /
                    (np.linalg.norm(pred_y0)*np.linalg.norm(cap_y0)))

provenance = json.loads(TERM_JSON.read_text())['hdiff_source_provenance']
summary = {
  'schema': 'sdirk3-vdiff-y0-boundary-replay-v1',
  'source': {'worktree': str(ROOT), 'head': provenance['head'],
             'working_tree_dirty_at_capture': provenance['working_tree_dirty'],
             'cpp_source_sha256_at_capture': provenance['files']['external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp']['sha256'],
             'fortran_diffusion_source_sha256_at_capture': provenance['files']['dyn_em/module_diffusion_em.F']['sha256']},
  'inputs': {'fortran_vdiff_capture': receipt(ft_path), 'cpp_vdiff_capture': receipt(cpp_path),
             'initial_netcdf_for_fnm_fnp_dnw': receipt(INITIAL),
             'term_array_npz': receipt(TERM_NPZ),
             'paired_fortran_full_rhs_snapshot': receipt(CAPDIR/'wrf_full_rhs_snapshot.bin')},
  'method': {
    'boundary_substitution': 'D_cpp[Y0] = D_fortran[Y1], all other D13 rows unchanged, reproducing compute_defor13 nonperiodic-Y boundary assignment.',
    'stress': 'tau13=-rhoavg*xkmvavg*D13; rhoavg=0.5*(fnm(k)*(rho_left+rho_right)+fnp(k)*(rho_lower_left+rho_lower_right)); xkmvavg uses the same separate weighted horizontal-pair average.',
    'tendency': 'delta_ru=-(-g/dnw(k))*(tau(k+1)-tau(k)), including zero lower/upper W-face stresses; then divide by captured C++ U velocity mass to compare physical acceleration.',
    'operands': 'Captured Fortran D13, rho and xkmv; FNM/FNP/DNW from the hash-pinned original wrfinput; state-matched captured C++ mass denominator.'
  },
  'captured_d13_boundary': {
    'fortran_D13_y0_max_abs': float(np.max(np.abs(D[0,:,:16]))),
    'fortran_D13_y1_max_abs': float(np.max(np.abs(D[1,:,:16]))),
    'fortran_D13_y0_minus_y1_max_abs': float(np.max(np.abs(D[0,:,:16]-D[1,:,:16]))),
    'rho_and_xkmv_provenance': 'rho and xkmv are directly decoded from the same pre-vertical-diffusion Fortran snapshot; xkmv y0/y1 happen to be identical.'
  },
  'replay_vs_captured_cpp_minus_fortran_vdiff': {
    'owner_face_domain': 'physical y=0, mass levels k=0..15, owner U faces i=0..15',
    'predicted_y0_physical_delta': metric(pred_y0),
    'captured_y0_physical_delta': metric(cap_y0),
    'captured_minus_predicted_y0_residual': metric(res_y0),
    'prediction_captured_correlation': correlation,
    'prediction_over_capture_rms': float(np.sqrt(np.mean(pred_y0**2))/np.sqrt(np.mean(cap_y0**2))),
    'hot_y0_index_zero_based_ki': [int(flat_idx[0]), int(flat_idx[1])],
    'predicted_at_hot_m_per_s2': float(pred_y0[flat_idx]),
    'captured_at_hot_m_per_s2': float(cap_y0[flat_idx]),
    'y1_predicted_max_abs': float(np.max(np.abs(predicted_physical_delta[1,:,:16]))),
    'y1_captured_max_abs': float(np.max(np.abs(captured_delta[1,:,:16]))),
    'cpp_vs_fortran_velocity_mass_max_abs': float(np.max(np.abs(cpp_mass-ft_mass)))
  },
  'conclusion': 'The D13 Y0<-Y1 substitution predicts the captured owner-y0 VDiff difference to numerical roundoff (float32 operation replay). This numerically attributes the y0 VDiff discrepancy to the boundary-copy rule. It does not by itself quantify the full-RHS post-diffusion remainder.'
}
OUT.write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps(summary['replay_vs_captured_cpp_minus_fortran_vdiff'],indent=2))
