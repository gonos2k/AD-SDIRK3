#!/usr/bin/env python3
"""Build a hash-verified, source-only/raw-data PR296 evidence ZIP.

The script deliberately does not run models, build code, or copy compiled
objects/executables/libraries. It is prepared for the final packaging pass;
invoke it only after the remaining report/metadata review is complete.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path
from typing import Any


EVIDENCE = Path(__file__).resolve().parent
ROOT = Path("/private/tmp/pr296-seam-cause-20261012")
DEFAULT_ZIP = ROOT / "docs/evidence/20261012/pr296_seam_cause_acceptance_evidence.zip"
DEFAULT_EXTERNAL_MANIFEST = EVIDENCE / "pr296_seam_cause_acceptance_evidence.manifest.json"

PRODUCTION_SOURCES = (
    "dyn_em/solve_em.F",
    "dyn_em/module_em.F",
    "dyn_em/module_small_step_em.F",
    "dyn_em/module_big_step_utilities_em.F",
    "dyn_em/module_implicit_sdirk3.F",
    "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp",
    "dyn_em/module_first_rk_step_part2.F",
)
TEST_SOURCE = "external/libtorch_wrf/sdirk3/tests/test_scalar_diffusion_contract.cpp"
SUPPORT_SOURCES = ("dyn_em/module_diffusion_em.F",)
RUN_LABELS = ("baseline", "fixed", "fixed_xy")
SOURCE_BASE = "3c8ef9c26d6caf9b3a54876d0caa19db361e5dc9"

FORBIDDEN_SUFFIXES = {".o", ".a", ".so", ".dylib", ".pyc", ".d"}
FORBIDDEN_PARTS = {"__pycache__", ".git", "build", "build_baseline", "build_fixed", "build_final_xy"}


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def safe_archive_path(name: str) -> str:
    p = Path(name)
    if p.is_absolute() or ".." in p.parts:
        raise ValueError(f"unsafe archive member: {name}")
    if any(part in FORBIDDEN_PARTS or part.startswith("build_") for part in p.parts[:-1]):
        raise ValueError(f"compiled/build path is not packageable: {name}")
    if p.suffix.lower() in FORBIDDEN_SUFFIXES:
        raise ValueError(f"compiled artifact is not packageable: {name}")
    return p.as_posix()


def copy_file(src: Path, stage: Path, archive_name: str, included: dict[str, dict[str, Any]]) -> None:
    rel = safe_archive_path(archive_name)
    if not src.is_file() or src.is_symlink():
        raise FileNotFoundError(f"required regular file is missing or symlinked: {src}")
    dst = stage / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    included[rel] = {"sha256": sha_file(dst), "bytes": dst.stat().st_size}


def write_bytes(data: bytes, stage: Path, archive_name: str, included: dict[str, dict[str, Any]]) -> None:
    rel = safe_archive_path(archive_name)
    dst = stage / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(data)
    included[rel] = {"sha256": sha_bytes(data), "bytes": len(data)}


def portable_script(src: Path, rewrites: tuple[tuple[str, str], ...]) -> bytes:
    text = src.read_text()
    for old, new in rewrites:
        if old not in text:
            raise ValueError(f"portable rewrite anchor not found in {src}: {old}")
        text = text.replace(old, new)
    return text.encode()


def add_run_cases(stage: Path, included: dict[str, dict[str, Any]]) -> dict[str, Any]:
    receipts: dict[str, Any] = {}
    allowed_fixed = {
        "diagnostics.txt", "namelist.input", "namelist.output", "rsl.error.0000",
        "rsl.out.0000", "run.log", "time.log", "wrfinput_d01",
        "wrf_rk_tend_dump.bin", "wrf_full_rhs_snapshot.bin",
        "port_full_rhs_snapshot.bin", "wrf_u_hdiff_snapshot.bin",
        "port_hdiff_u_snapshot.bin", "wrf_u_vdiff_before.bin",
        "port_vdiff_u_snapshot.bin",
    }
    for label in RUN_LABELS:
        manifest_path = EVIDENCE / "red_provenance" / f"{label}_runs.json"
        manifest = json.loads(manifest_path.read_text())
        if manifest.get("status") != "completed":
            raise RuntimeError(f"run plan is not complete: {manifest_path}")
        if manifest.get("source_sha256_before") != manifest.get("source_sha256_after"):
            raise RuntimeError(f"source hashes changed during {label} capture")
        if len(manifest.get("source_sha256_after", {})) != 7:
            raise RuntimeError(f"expected seven pinned production files in {label} receipt")
        copy_file(manifest_path, stage, f"records/run_receipts/{label}_runs.json", included)
        for row in manifest["runs"]:
            if row.get("status") != "completed" or row.get("return_code") != 0:
                raise RuntimeError(f"incomplete native case in {label}: {row.get('label')}")
            case_dir = Path(row["workdir"])
            archived_case = f"records/runs/{label}/{row['label']}"
            if not case_dir.is_dir():
                raise FileNotFoundError(case_dir)
            for item in sorted(case_dir.iterdir()):
                if item.is_symlink():
                    continue
                if item.is_file() and (item.name in allowed_fixed or item.name.startswith("wrfout_d01_")):
                    copy_file(item, stage, f"{archived_case}/{item.name}", included)
                elif item.is_file() and item.name not in {"LANDUSE.TBL", "VEGPARM.TBL", "SOILPARM.TBL", "GENPARM.TBL"}:
                    raise ValueError(f"unclassified native artifact; add explicit handling: {item}")
        receipts[label] = {
            "head": manifest["head"],
            "source_sha256": manifest["source_sha256_after"],
            "executable_sha256": manifest["build_receipt"]["executable"]["sha256"],
            "library_sha256": manifest["build_receipt"]["library"]["sha256"],
            "run_count": len(manifest["runs"]),
        }
    return receipts


def add_analysis_outputs(stage: Path, included: dict[str, dict[str, Any]]) -> None:
    # Only current fixed/fixed_xy reanalyses and the raw arrays used by the
    # final old-seam counterfactual are published. Startup failures and the
    # pre-correction baseline analysis JSONs are intentionally excluded.
    root_names = (
        "analyze_snapshots.py",
        "final_initial_full_rhs_analysis.json", "final_initial_full_rhs_analysis.log",
        "final_stored_full_rhs_analysis.json", "final_stored_full_rhs_analysis.log",
        "final_initial_term_analysis.json", "final_initial_term_analysis.log", "final_initial_term_arrays.npz",
        "final_stored_term_analysis.json", "final_stored_term_analysis.log", "final_stored_term_arrays.npz",
        "fixed_initial_full_rhs_analysis.json", "fixed_initial_full_rhs_analysis.log",
        "fixed_stored_full_rhs_analysis.json", "fixed_stored_full_rhs_analysis.log",
        "fixed_initial_term_analysis.json", "fixed_initial_term_analysis.log", "fixed_initial_term_arrays.npz",
        "fixed_stored_term_analysis.json", "fixed_stored_term_analysis.log", "fixed_stored_term_arrays.npz",
        "baseline_initial_term_arrays.npz", "baseline_stored_term_arrays.npz",
        "acceptance_candidate_v3.json",
        "compile_baseline_capture.log", "compile_fixed_seam.log", "compile_fixed_xy.log",
        "run_baseline_capture.log", "run_fixed_capture.log", "run_fixed_xy_capture.log",
        "build_reuse_receipt.json",
        "acceptance_candidate_v3_metadata_erratum.json",
        "pr296_committed_source_binding.json",
        "team_final_audit_summary.json",
    )
    for name in root_names:
        copy_file(EVIDENCE / name, stage, f"records/{name}", included)

    for sub, names in {
        "red_provenance": (
            "final_provenance_and_context_audit.json",
            "final_fixed_xy_independent_audit.json",
        ),
        "red_arrays": (
            "analyze_hdiff_capture.py", "final_causality_audit.py", "final_causality_audit.json",
            "fixed_xy_initial_hd_vd_audit.json", "fixed_xy_initial_hd_vd_arrays.npz",
            "fixed_xy_stored_hd_vd_audit.json", "fixed_xy_stored_hd_vd_arrays.npz",
            "seam_cause_review.md", "seam_invariants.json", "headline_fix_rerun_receipt.json",
        ),
        "green_mass": (
            "u_hdiff_snapshot_schema.json", "u_vdiff_before_snapshot_schema.json",
            "u_periodic_face0_mass_normalization.json",
        ),
        "green_pressure": ("vdiff_y0_replay.json",),
        "green_graph_diffusion": (
            "final_cpp_only_graph_refresh_receipt.json", "final_cpp_graph_navigation.md",
            "scalar_diffusion_test_graph_refresh_receipt.json",
            "scalar_diffusion_test_graph_navigation.md",
        ),
        "red_acceptance": (
            "Redfinalcriterion_audit.json", "Redfinalcriterion_audit.md",
            "final_current_docs_audit.md",
        ),
        "green_transport": ("final_doc_review.md",),
        "red_transport": ("final_code_audit.md",),
    }.items():
        for name in names:
            copy_file(EVIDENCE / sub / name, stage, f"records/{sub}/{name}", included)

    # Include the supporting counterfactual arrays separately so both final
    # term parsers and the counterfactual audit can be rerun offline.
    copy_file(EVIDENCE / "red_arrays" / "u_seam_rates.npz", stage,
              "records/red_arrays/u_seam_rates.npz", included)

    # Fixed V3 acceptance material, without caches, build trees, or binaries.
    v3 = EVIDENCE / "green_acceptance/native_qualification_v3"
    for item in sorted(v3.rglob("*")):
        if not item.is_file() or item.is_symlink():
            continue
        if "archived_h1p875_reference" in item.parts:
            continue
        rel = item.relative_to(EVIDENCE).as_posix()
        if item.suffix.lower() in {".json", ".md", ".py", ".log"} and "__pycache__" not in item.parts:
            copy_file(item, stage, f"records/{rel}", included)
    v3_run_root = v3 / "runs"
    v3_run_files = {
        "diagnostics.txt", "namelist.input", "namelist.output", "rsl.error.0000",
        "rsl.out.0000", "run.log", "time.log", "wrfinput_d01",
    }
    for case_dir in sorted(v3_run_root.iterdir()):
        if not case_dir.is_dir():
            continue
        for item in sorted(case_dir.iterdir()):
            if item.is_symlink() or not item.is_file():
                continue
            if item.name in v3_run_files or item.name.startswith(("wrfout_d01_", "wrfrst_d01_")):
                rel = item.relative_to(EVIDENCE).as_posix()
                copy_file(item, stage, f"records/{rel}", included)
    refdir = v3 / "archived_h1p875_reference"
    ref_manifest_path = refdir / "archive_manifest.json"
    ref_manifest = json.loads(ref_manifest_path.read_text())
    copy_file(ref_manifest_path, stage,
              "records/green_acceptance/native_qualification_v3/archived_h1p875_reference/archive_manifest.json",
              included)
    for row in ref_manifest["files"]:
        rel = row["relative_path"]
        src = refdir / rel
        if sha_file(src) != row["sha256"] or src.stat().st_size != row["size_bytes"]:
            raise RuntimeError(f"archived h1.875 reference changed: {rel}")
        copy_file(src, stage,
                  f"records/green_acceptance/native_qualification_v3/archived_h1p875_reference/{rel}",
                  included)
    copy_file(EVIDENCE / "build_final_xy/receipt.json", stage,
              "records/final_binary_hashes.json", included)
    for name in ("pr296_acceptance_candidate_v3.json", "pr296_acceptance_candidate_v3_metadata_erratum.json",
                 "pr296_committed_source_binding.json"):
        copy_file(ROOT / "docs/evidence/20261012" / name, stage,
                  f"records/committed_docs_evidence/{name}", included)


def add_local_contract(stage: Path, included: dict[str, dict[str, Any]]) -> None:
    base = EVIDENCE / "local_contract"
    for item in sorted(base.rglob("*")):
        if not item.is_file() or item.is_symlink():
            continue
        if item.suffix.lower() in {".json", ".log", ".md", ".cpp"} and "__pycache__" not in item.parts:
            rel = item.relative_to(base).as_posix()
            if any(part.startswith("superseded") for part in Path(rel).parts):
                archive_rel = f"records/local_contract/{rel}"
            else:
                archive_rel = f"records/local_contract/{rel}"
            copy_file(item, stage, archive_rel, included)


def add_sources_and_patch(stage: Path, included: dict[str, dict[str, Any]], root: Path) -> dict[str, Any]:
    for rel in PRODUCTION_SOURCES:
        copy_file(root / rel, stage, f"records/sources/{rel}", included)
    copy_file(root / TEST_SOURCE, stage, f"records/sources/{TEST_SOURCE}", included)
    for rel in SUPPORT_SOURCES:
        copy_file(root / rel, stage, f"records/sources/{rel}", included)
    copy_file(root / "configure.wrf", stage, "records/configure.wrf", included)

    git_head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
    binding_path = EVIDENCE / "pr296_committed_source_binding.json"
    binding = json.loads(binding_path.read_text())
    if binding.get("producer_commit") != git_head or not binding.get("all_source_bytes_equal"):
        raise RuntimeError("committed source-binding receipt does not match current HEAD")
    run_manifest = json.loads((EVIDENCE / "red_provenance/fixed_xy_runs.json").read_text())
    for rel in PRODUCTION_SOURCES:
        if run_manifest["source_sha256_after"].get(rel) != binding["files"].get(rel, {}).get("run_source_sha256"):
            raise RuntimeError(f"final source pin differs from fixed_xy run bytes: {rel}")
    if binding["files"][TEST_SOURCE]["compiled_test_source_sha256"] != sha_file(root / TEST_SOURCE):
        raise RuntimeError("current scalar contract test does not match committed-source receipt")
    tracked = [*PRODUCTION_SOURCES, TEST_SOURCE]
    subprocess.run(["git", "merge-base", "--is-ancestor", SOURCE_BASE, git_head], cwd=root, check=True)
    diff = subprocess.run(["git", "diff", "--binary", SOURCE_BASE, git_head, "--", *tracked], cwd=root,
                          check=True, capture_output=True).stdout
    write_bytes(diff, stage, "records/source_patch/pr296_source_and_test.patch", included)
    pin = {
        "schema": "pr296-source-pin-manifest-v1",
        "base": SOURCE_BASE,
        "head": git_head,
        "authoritative_production_sources": {p: sha_file(root / p) for p in PRODUCTION_SOURCES},
        "current_test_source": {TEST_SOURCE: sha_file(root / TEST_SOURCE)},
        "supporting_formula_source": {p: sha_file(root / p) for p in SUPPORT_SOURCES},
        "configure_wrf_sha256": sha_file(root / "configure.wrf"),
        "patch_sha256": sha_bytes(diff),
        "committed_source_binding_receipt_sha256": sha_file(binding_path),
        "note": "Generated Fortran *.f90, objects, archives, and executables are excluded; *.F remains authoritative.",
    }
    write_bytes((json.dumps(pin, indent=2, sort_keys=True) + "\n").encode(),
                stage, "records/source_pins.json", included)
    return pin


def add_package_scripts(stage: Path, included: dict[str, dict[str, Any]]) -> None:
    # The full-RHS analyzer is invoked with explicit --source-root/--out paths,
    # so its producer-machine defaults are never used in the portable examples.
    copy_file(EVIDENCE / "analyze_snapshots.py", stage, "records/analyze_snapshots.py", included)
    copy_file(EVIDENCE / "red_arrays/analyze_hdiff_capture.py", stage,
              "records/red_arrays/analyze_hdiff_capture.py", included)
    copy_file(EVIDENCE / "green_mass/u_hdiff_snapshot_schema.json", stage,
              "records/green_mass/u_hdiff_snapshot_schema.json", included)
    copy_file(EVIDENCE / "green_mass/u_vdiff_before_snapshot_schema.json", stage,
              "records/green_mass/u_vdiff_before_snapshot_schema.json", included)

    # Package-local versions of the two targeted replays. Rewrite only path
    # constants; the arithmetic/source code remains byte-identical otherwise.
    final_cause_src = EVIDENCE / "red_arrays/final_causality_audit.py"
    final_cause = portable_script(final_cause_src, (
        ("BASE = Path('/Users/yhlee/AD-SDIRK3-review-evidence/seam-cause-acceptance-20261012')",
         "BASE = Path(__file__).resolve().parents[1]"),
        ("PROV = BASE/'red_provenance'", "PROV = BASE/'runs'"),
        ("FULL_PY = Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-rhs-contract-20261011/analyze_snapshots.py')",
         "FULL_PY = BASE/'analyze_snapshots.py'"),
    ))
    write_bytes(final_cause, stage, "records/red_arrays/final_causality_audit.py", included)

    replay_src = EVIDENCE / "green_pressure/replay_vdiff_y0.py"
    replay = portable_script(replay_src, (
        ("E = Path('/Users/yhlee/AD-SDIRK3-review-evidence/seam-cause-acceptance-20261012')",
         "E = Path(__file__).resolve().parents[1]"),
        ("ROOT = Path('/private/tmp/pr296-seam-cause-20261012')", "ROOT = E / 'sources'"),
        ("E / 'red_provenance/fixed/", "E / 'runs/fixed/"),
        ("Path('/Users/yhlee/AD-SDIRK3-review-evidence/full-rhs-contract-20261011/analyze_snapshots.py')",
         "E / 'analyze_snapshots.py'"),
    ))
    write_bytes(replay, stage, "records/green_pressure/replay_vdiff_y0.py", included)


def portable_hdiff_script() -> None:
    """The copied analyzer already resolves schema/parser relative to EVIDENCE.

    It is staged under records/red_arrays, making parents[1] equal records/;
    README passes --source-root explicitly and avoids producer defaults.
    """


def make_readme(run_receipts: dict[str, Any]) -> str:
    return f"""PR296 packed-U option-2 diffusion seam evidence

This bundle contains raw 15-second same-state captures, source/build receipts,
offline analysis arrays and targeted C++/Fortran source. It does not contain
compiled executables, static libraries, objects, generated Fortran, or build
directories. The fixed executable bytes remain on the producer machine and
are identified only by SHA-256 in the receipts.

The comparison applies to dry, flat `test/em_b_wave`, 16x16x16 physical cells,
periodic X and symmetric nonperiodic Y, `diff_opt=2`, `khdif=1000`, `kvdif=10`,
`mix_full_fields=false`, one MPI rank and one thread. Each baseline/fixed/fixed_xy
phase has paired 15-second h=15 Fortran RK3 and ARK mode-3 captures from both
the original input and the same saved 60-second RK3 state. The reports record
effective `hypsometric_opt=1` for the ideal case despite nominal
`HYPSOMETRIC_OPT=2` in `namelist.output`.

Packed horizontal storage (17x17x16) is distinct from the physical domain
(16x16x16). Full-RHS U norms use 4,096 unique owner faces, V uses 3,840 interior
faces and MU uses 256 cells; the periodic closing U face is checked but not
double-counted. Term-array analyses preserve 4,352 saved U rows including the
Y storage endpoint; do not substitute those term-analysis norms for the
canonical full-RHS owner metrics.

The fixed_xy same-state captures reduce the isolated option-2 vertical-U
diffusion mismatch to about 1.5e-12 m/s^2 RMS. The full U RHS residual remains
about 6.5e-8 m/s^2 at the initial frame and 7.5e-8 at the stored frame; V/MU
residuals remain. This is targeted first-stage component evidence, not complete
F-delta parity, an integrated VJP check, or a forecast-accuracy acceptance.
The named-case v3 reference qualification fails; its candidate differences are
provisional, and no efficiency advantage is claimed. The report explicitly
excludes the superseded startup failures and preliminary baseline analysis
JSONs; old baseline raw snapshots/run receipts are retained for comparison.
The original V3 contract JSON is preserved byte-for-byte. Its PH sampling-label
erratum is a separate metadata-only file; no frozen numeric criterion changed.
The executed PH gate uses geopotential in m^2/s^2; the V3 sampling-label text
described height in metres. `metadata_erratum.json` documents the distinction.
The archived h=1.875 reference package includes its raw NetCDF outputs and
producer receipts, verified against its archive manifest. The three named-case
v3 qualification runs also include their raw WRF inputs/outputs and run logs;
their executable bytes remain local and are hash-pinned.

Portable NumPy reanalysis from the extracted bundle root:

```sh
python3 records/analyze_snapshots.py \\
  --source-root records/sources \\
  --fortran records/runs/fixed_xy/initial_fortran_rk3_h15/wrf_full_rhs_snapshot.bin \\
  --cpp records/runs/fixed_xy/initial_cpp_ark3_h15/port_full_rhs_snapshot.bin \\
  --out /tmp/pr296_initial_full_rhs.json

python3 records/analyze_snapshots.py \\
  --source-root records/sources \\
  --fortran records/runs/fixed_xy/stored_fortran_rk3_h15/wrf_full_rhs_snapshot.bin \\
  --cpp records/runs/fixed_xy/stored_cpp_ark3_h15/port_full_rhs_snapshot.bin \\
  --out /tmp/pr296_stored_full_rhs.json

python3 records/red_arrays/analyze_hdiff_capture.py \\
  --source-root records/sources --case fixed_xy_initial \\
  --fortran-hdiff records/runs/fixed_xy/initial_fortran_rk3_h15/wrf_u_hdiff_snapshot.bin \\
  --cpp-hdiff records/runs/fixed_xy/initial_cpp_ark3_h15/port_hdiff_u_snapshot.bin \\
  --fortran-full records/runs/fixed_xy/initial_fortran_rk3_h15/wrf_full_rhs_snapshot.bin \\
  --cpp-full records/runs/fixed_xy/initial_cpp_ark3_h15/port_full_rhs_snapshot.bin \\
  --fortran-vdiff-before records/runs/fixed_xy/initial_fortran_rk3_h15/wrf_u_vdiff_before.bin \\
  --cpp-vdiff records/runs/fixed_xy/initial_cpp_ark3_h15/port_vdiff_u_snapshot.bin \\
  --out /tmp/pr296_initial_terms.json --npz /tmp/pr296_initial_terms.npz
```

`records/green_pressure/replay_vdiff_y0.py` reproduces the stencil-local D13
counterfactual with NumPy and netCDF4 using the archived input coefficients.
The local C++ regression source and final validation logs are in
`records/local_contract/`; historical superseded compile receipts remain under
`records/local_contract/superseded_old_source_compile/`.

Run/source/executable receipts:
{json.dumps(run_receipts, indent=2, sort_keys=True)}

Committed producer source binding: `78255e14ad4f2d8e07e9e764b47b9eb24266dd53`.
The seven run sources and the compiled scalar-contract test match committed
blobs. The bundle carries a diff from the pinned base and source hashes; it does
not claim a fresh clean-checkout native rerun.
"""


def build_bundle(output_zip: Path, external_manifest: Path, root: Path) -> dict[str, Any]:
    if output_zip.exists() or external_manifest.exists():
        raise FileExistsError(f"refusing to overwrite existing package: {output_zip} or {external_manifest}")
    output_zip.parent.mkdir(parents=True, exist_ok=True)
    external_manifest.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="pr296-evidence-") as temp:
        stage = Path(temp) / "stage"
        stage.mkdir()
        included: dict[str, dict[str, Any]] = {}
        source_pin = add_sources_and_patch(stage, included, root)
        receipts = add_run_cases(stage, included)
        add_analysis_outputs(stage, included)
        add_local_contract(stage, included)
        add_package_scripts(stage, included)

        # Preserve the final report as documentation, but repair its explicit
        # placeholder only in the packaged copy (the worktree doc is untouched).
        docs = root / "docs/(202610120157)_pr296_packed_u_diffusion_cause_and_criteria.md"
        doc_text = docs.read_text()
        doc_text = doc_text.replace("__EVIDENCE_ZIP__", output_zip.name)
        write_bytes(doc_text.encode(), stage,
                    "records/docs/(202610120157)_pr296_packed_u_diffusion_cause_and_criteria.md", included)

        readme = make_readme(receipts).encode()
        write_bytes(readme, stage, "README.txt", included)
        # Include the package script itself for a reproducible future refresh.
        write_bytes(Path(__file__).read_bytes(), stage,
                    "records/package_pr296_evidence.py", included)

        manifest = {
            "schema": "sha256-payload-manifest-v1",
            "payload_count": len(included),
            "files": dict(sorted(included.items())),
            "excluded_binaries": {
                "executables": [v["executable_sha256"] for v in receipts.values()],
                "libraries": [v["library_sha256"] for v in receipts.values()],
                "note": "build_final_xy/receipt.json records final executable/library hashes; bytes are intentionally not distributed",
            },
            "authoritative_source_pins": source_pin["authoritative_production_sources"],
        }
        (stage / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")

        with zipfile.ZipFile(output_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
            for item in sorted(stage.rglob("*")):
                if item.is_file():
                    zf.write(item, item.relative_to(stage).as_posix())
        with zipfile.ZipFile(output_zip, "r") as zf:
            bad_member = zf.testzip()
            if bad_member is not None:
                raise RuntimeError(f"ZIP CRC failure in {bad_member}")
            verified = json.loads(zf.read("manifest.json"))
            for name, expected in verified["files"].items():
                data = zf.read(name)
                if len(data) != expected["bytes"] or sha_bytes(data) != expected["sha256"]:
                    raise RuntimeError(f"ZIP member hash/length mismatch: {name}")
            if len(verified["files"]) != verified["payload_count"]:
                raise RuntimeError("manifest payload count mismatch")
        zip_sha = sha_file(output_zip)
        external = {
            "schema": "pr296-evidence-external-sha256-manifest-v1",
            "zip_path": str(output_zip),
            "zip_sha256": zip_sha,
            "payload_count": len(manifest["files"]),
            "crc_verification": "passed",
            "payload_sha256_verification": "all members passed",
            "source_head": source_pin["head"],
            "source_pins_sha256": sha_bytes(json.dumps(source_pin, sort_keys=True).encode()),
            "manifest_path_in_zip": "manifest.json",
            "payload_manifest": manifest["files"],
            "excluded_binaries": manifest["excluded_binaries"],
        }
        external_manifest.write_text(json.dumps(external, indent=2, sort_keys=True) + "\n")
        output_zip.with_suffix(output_zip.suffix + ".sha256").write_text(f"{zip_sha}  {output_zip.name}\n")
        return external


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--zip", type=Path, default=DEFAULT_ZIP)
    parser.add_argument("--external-manifest", type=Path, default=DEFAULT_EXTERNAL_MANIFEST)
    args = parser.parse_args()
    result = build_bundle(args.zip.resolve(), args.external_manifest.resolve(), args.root.resolve())
    print(json.dumps({k: result[k] for k in ("zip_path", "zip_sha256", "payload_count", "crc_verification", "payload_sha256_verification")}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
