# Final Red Code Audit: Packed U Stress Boundary Closure

Target: `/private/tmp/pr296-seam-cause-20261012`, producer revision `78255e14ad4f2d8e07e9e764b47b9eb24266dd53` (same reviewed source bytes).

## Verdict

No blocking finding in the requested scope. The option-2 packed U closure is gated to `diffusion_option == 2 && isPackedPeriodicDomain()`. That predicate encodes periodic X, symmetric nonperiodic Y, a full-domain single tile, and the expected packed extents. The D13 change preserves the owned south row for this case while keeping the north packed storage row copied from its neighboring physical row. Other Y-boundary behavior remains on the existing path.

The changes apply the same x-face closure to the option-2 horizontal U stress tendency and to the vertical stress coefficient/density arrays. The closure maps the already-computed physical closing face into U face 0, preserves faces 1 through the closing face, and fills the extra packed tail from face 1.

## Test and evidence review

`run_packed_u_stress_boundary_contract` has independent expected values for horizontal and vertical increments in raw coupled stress-tendency units (Pa·m/s²). These values become accelerations only after division by the appropriate velocity mass. It checks west face 0, the physical closing face, face 1, and the extra packed tail. Its D13 setup verifies that the physical south row remains distinct from row 1 and that the north storage row retains its copy rule. The tolerances use a float32 rounding budget scaled by the flux operands.

The recorded default suite and targeted CLI both pass. The same CLI against the archived old library fails as expected. The test is a manufactured local contract check; it does not claim full-model endpoint attribution. The separate schema-5 Fortran capture provides an actual south-row D13 witness.

The C++ observer is opt-in through the exact environment value `WRF_PARITY_RK_TEND_DUMP=1`, uses detached CPU copies, writes snapshots, and continues with the same tensors and RHS calls. The Fortran observers are similarly gated to the first RK step, one full-domain tile/rank, and the stated case. I did not run these observers or any tests during this review.

## Limits

This was a static review of the new closure calls/guards, the new test, and the diagnostic capture sites. It does not audit the entire surrounding solver diff, validate a rebuilt executable, or prove the full remaining forecast/RHS residual is explained by these local changes.

