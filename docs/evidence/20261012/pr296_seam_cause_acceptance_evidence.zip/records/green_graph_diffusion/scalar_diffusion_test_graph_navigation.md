# Scalar diffusion contract test graph refresh

Target `3c8ef9c26d6caf9b3a54876d0caa19db361e5dc9` (`codex/uv-seam-cause-20261012`), with all 55 source hashes verified between the worktree and isolated graph copy. Only `external/libtorch_wrf/sdirk3/tests/test_scalar_diffusion_contract.cpp` was copied and AST re-extracted (149 nodes, 307 edges); the other 54 source ASTs were reused. Graphify semantics were not rerun.

The refreshed graph SHA-256 is `2fb71cb985c4bb32b84503a4bf7fb749b4d321a0838ee6a8de16543e2fbceff1` (2095 nodes, 4722 edges). Existing navigation for the manual FirstPart2-to-Fortran diffusion edge and the C++ packed-face closure is retained. This task did not build or run the test; graph links are navigation evidence only.
