# Red audit of current PR296 criteria documentation

Local timestamp: 2026-10-12 02:16:36 JST (+0900)

## Result

No blocking criteria-claim issue found in the reviewed documents:

- `/private/tmp/pr296-seam-cause-20261012/docs/(202610120157)_pr296_packed_u_diffusion_cause_and_criteria.md`
- `/private/tmp/pr296-seam-cause-20261012/docs/PROBLEM_DEFINITION.md`

Both documents keep V3 scoped to the named dry, flat 16³, 240-second
`em_b_wave` research case and call the 1% target proposed/root-proposed. They
do not claim user selection, project-wide adoption, project completion, or a
general forecast target. The project definition still marks its broader
forecast window and budgets as unselected.

The documented reference qualification agrees with the frozen V3 evaluation:
the h=0.9375 versus h=1.875 RK3 gate fails all 24 field/checkpoint comparisons;
the h=15 candidate comparisons are provisional because the reference is
unqualified. Neither document calls those comparisons accepted accuracy or a
true-error estimate. The ULP floor is identified as stored-output spacing,
not internal arithmetic uncertainty.

Both documents correctly limit `gamma_n*sum|terms|` to accumulation of
already-computed terms and leave full cross-model RHS roundoff and complete
`F_Δ` parity open. Efficiency remains optional with no speed requirement.
The PR296 note also preserves the remaining full-RHS discrepancy and does
not attribute it to the corrected diffusion terms.

The frozen V3 JSON has one documentary metadata mismatch: `sampling.PH`
describes height in metres, while `budgets.PH` and the evaluator use raw PH
perturbation geopotential in m²/s². The separate metadata erratum resolves
interpretation without changing the frozen contract or numerical rule. I
verified the frozen V3 SHA-256 remains
`77bc4dcc7b8e0bde91d6089e9aaa11a67a49311f824d88c97919bbbb8e64fe3f`, matching
the evaluator's contract hash. The evaluator masks raw PH with `PH[1:,:,:]`,
gets units from `budgets.PH`, and applies epsilon `0.010249750539744869
m²/s²`; the equivalent height budget is `0.00104482676246 m` at g=9.81.
This is a metadata correction only; no evaluation rule changed.

Supporting numerical and implementation checks are in
[`Redfinalcriterion_audit.md`](Redfinalcriterion_audit.md) and
[`Redfinalcriterion_audit.json`](Redfinalcriterion_audit.json). This was a
read-only documentation audit; no repository edits, rebuilds, or model runs
were performed.
