# Red final audit of V3 acceptance criteria

Local timestamp: 2026-10-12 02:00:04 JST (+0900)

## Verdict

V3 implements a coherent **case-scoped proposed research contract**. The 1% target is root-proposed and still awaits user selection; it does not set a general project forecast target. The fixed endpoint epsilons are applied unchanged at 60, 120, 180 and 240 s, with no candidate-derived floor or post-result relaxation. This audit read the frozen contract, evaluator, run receipts and output data; it performed no model run, build or production edit.

## Reference qualification

One h=0.9375 RK3 run was compared with archived h=1.875 RK3 using the same fixed endpoint `epsilon_X/3` at all four nonzero checkpoints. All 24 field/checkpoint comparisons fail. Ratios below are `RMS(h=0.9375 - h=1.875)/(epsilon_X/3)`, so values above 1 fail. This gate reports observed resolution sensitivity, not error versus exact truth, temporal order, or a global bound. The contract authorizes no further refinement ladder.

| Time (s) | U | V | W | PH | T | MU |
|---:|---:|---:|---:|---:|---:|---:|
| 60 | 3.49× fail | 7.20× fail | 26.15× fail | 1.54× fail | 7.48× fail | 1.78× fail |
| 120 | 11.48× fail | 17.92× fail | 35.91× fail | 4.32× fail | 15.11× fail | 10.64× fail |
| 180 | 21.39× fail | 27.73× fail | 68.18× fail | 17.48× fail | 21.50× fail | 29.79× fail |
| 240 | 31.69× fail | 35.37× fail | 74.38× fail | 43.21× fail | 26.88× fail | 60.34× fail |

## Candidate comparison at 240 s

| Field | Fixed epsilon | h=15 ARK RMS vs h=1.875 | Error / epsilon | Conditional result |
|---|---:|---:|---:|---|
| U | 0.000774442 m/s | 0.0135072 | 17.44× | Exceeds |
| V | 0.00010122 m/s | 0.00357184 | 35.29× | Exceeds |
| W | 7.79444e-06 m/s | 0.000297601 | 38.18× | Exceeds |
| PH | 0.0102498 m^2/s^2 geopotential | 0.257211 | 25.09× | Exceeds |
| T | 3.61957e-05 physical potential temperature T+300 K | 0.000164905 | 4.56× | Exceeds |
| MU | 0.0145909 total dry column mass MU+MUB in Pa | 0.504095 | 34.55× | Exceeds |

All six endpoint discrepancies exceed the frozen candidate budget versus h=1.875. Since the reference gate fails, these remain provisional comparisons; they do not establish that ARK h=15 passes or fails against truth. The evaluation output likewise marks candidate accuracy unresolved while reference qualification is open.

## Data and implementation checks

- Recomputed endpoint response scales and raw perturbation-output ULPs from archived RK3 h=1.875 NetCDF exactly reproduce the six V3 budgets (within float64 representation; contract SHA-256 `77bc4dcc7b8e0bde91d6089e9aaa11a67a49311f824d88c97919bbbb8e64fe3f`). The 3q floor is output representation only; it does not cover internal FP32 accumulation or intermediate arithmetic.
- Epsilon values are read from the frozen V3 JSON and reused for every checkpoint. The evaluator does not retune thresholds from candidate errors.
- The 0.9375 RK3 run and h=15 ARK run share exact initial values for all eight raw state/base arrays. PHB and MUB also match the archived reference exactly at all five outputs. The fresh h=3.75 stock control matches its archived control bitwise for all eight variables at all five outputs, with matching archived namelist hash. Contract freeze at 01:34:45 preceded final output mtimes at 01:47:10–01:47:14.
- Source, executable, solver library, contract and input hashes were reverified. The fresh runs recorded 16 ARK h=15 main steps, 64 RK3 h=3.75 steps and 256 RK3 h=0.9375 steps. WRF `debug_level=200`, SDIRK debug level 1; diagnostic capture flags were unset and WRF environment variables removed.
- Finite fields, positive theta/mass/layer depth, and exact periodic U, symmetric V-wall and fixed-bottom-W invariants pass.
- The evaluator compares PH perturbations in m²/s²; exact common PHB means this is physically equivalent to comparing height differences after division by g. The endpoint epsilon `0.01024975054 m²/s²` is `0.00104482676 m` of height. T and MU perturbation differences likewise equal total theta and dry-mass differences under their shared bases.

## Remaining limits

The `gamma_n * sum(abs(terms))` criterion bounds only accumulation of already computed source terms. It is not a bound on primitive term evaluation or complete cross-model RHS arithmetic. Keep the independent per-term oracle and operation-DAG qualification open even if the periodic seam defect is fixed. Efficiency is optional, and this case-scoped proposal makes no claim of project-wide completion or whole-operator equality.

Machine-readable details: [Redfinalcriterion_audit.json](Redfinalcriterion_audit.json).
