#!/usr/bin/env python3
"""Independent old seam counterfactual using final FT diffusion increments.

Evidence-only. It consumes frozen NPZ/raw captures, reuses the fail-closed
full-RHS state parser, performs no operator calls, and makes no code changes.
"""
from __future__ import annotations
import hashlib, importlib.util, json
from pathlib import Path
import numpy as np

BASE = Path(__file__).resolve().parents[1]
RED = BASE/'red_arrays'
PROV = BASE/'runs'
FULL_PY = BASE/'analyze_snapshots.py'
spec=importlib.util.spec_from_file_location('full_snap',FULL_PY)
full=importlib.util.module_from_spec(spec); spec.loader.exec_module(full)

def sha(p:Path)->str:
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1<<20),b''): h.update(c)
 return h.hexdigest()
def rms(a): return float(np.sqrt(np.mean(np.asarray(a,dtype=np.float64)**2)))
def metric(a, ref):
 a=np.asarray(a,dtype=np.float64); ref=np.asarray(ref,dtype=np.float64); d=a-ref
 return {'count':int(d.size),'absolute_rms':rms(d),'max_abs':float(np.max(np.abs(d))) if d.size else 0.0,
         'signal_rms':rms(ref),'relative_rms':rms(d)/rms(ref) if rms(ref) else None}
def projection(d,p):
 d=np.asarray(d,dtype=np.float64);p=np.asarray(p,dtype=np.float64); e=d-p
 d2=float(np.sum(d*d)); p2=float(np.sum(p*p)); e2=float(np.sum(e*e)); dot=float(np.sum(d*p))
 return {'whole_delta':metric(d,np.zeros_like(d)),'predicted_delta':metric(p,np.zeros_like(p)),
         'prediction_error':metric(e,np.zeros_like(e)),
         'squared_residual_explained_pct':100*(1-e2/d2) if d2 else None,
         'signed_projection_share_pct':100*dot/d2 if d2 else None,
         'prediction_energy_share_pct':100*p2/d2 if d2 else None,
         'correlation':float(np.corrcoef(d.ravel(),p.ravel())[0,1]) if d.size and np.std(d) and np.std(p) else None}
def captures(variant,phase):
 f=PROV/variant/f'{phase}_fortran_rk3_h15'; c=PROV/variant/f'{phase}_cpp_ark3_h15'
 return f,c

def run():
 out={'schema':'independent-old-seam-vdiff-counterfactual-v1','accuracy_budget_adopted':False,
      'source_root':'/private/tmp/pr296-seam-cause-20261012','source_head':'3c8ef9c26d6caf9b3a54876d0caa19db361e5dc9',
      'method':{'old_delta':'baseline CPP Full physical U minus baseline Fortran Full physical U',
       'old_counterfactual':'baseline captured HD cross-code delta minus final Fortran VDiff physical increment; on the west seam this equals -(FT_HDiff+FT_VDiff) because baseline CPP HD and VDiff contributions are zero there',
       'why_vdiff_zero_at_old_west_seam':'baseline C++ did not capture an isolated VDiff term; source-level periodic-U helper witness reports cpp_west_seam_i0=-0 and adjacent i1=0.1962 for an analytic nonzero vertical stress fixture. This is direct helper evidence, not a captured full-RHS CPP VDiff field.',
       'normalization':'RMS and max of actual delta / predicted delta / remainder; relative RMS divides by the Fortran RHS signal RMS in the same mask. Seam pair counts x=0 and duplicate closing x=16.',
       'masks':{'west_face':'x=0','closing_duplicate':'x=16','seam_pair':'x=[0,16] duplicate-counted','owner_unique':'x=0..15'}},
      'cases':{},'source_receipts':{}}
 # Pin run-level source snapshots. Only the C++ operator and Fortran capture wrapper hashes differ.
 for variant in ('baseline','fixed_xy'):
  rp=PROV/f'{variant}_runs.json'; r=json.loads(rp.read_text())
  out['source_receipts'][variant]={'run_manifest':str(rp),'manifest_sha256':sha(rp),'head':r['head'],
    'source_sha256_before':r['source_sha256_before'],'source_sha256_after':r['source_sha256_after']}
 for phase in ('initial','stored'):
  bft,bcpp=captures('baseline',phase); fft,fcpp=captures('fixed_xy',phase)
  bftfull=bft/'wrf_full_rhs_snapshot.bin'; bcppfull=bcpp/'port_full_rhs_snapshot.bin'
  fftfull=fft/'wrf_full_rhs_snapshot.bin'; fcppfull=fcpp/'port_full_rhs_snapshot.bin'
  bg=full.analyze(bftfull,bcppfull,Path('/private/tmp/pr296-seam-cause-20261012'))
  fg=full.analyze(ffull if False else fftfull,fcppfull,Path('/private/tmp/pr296-seam-cause-20261012'))
  if not (bg.get('comparison_available') and bg.get('state_exact_match') and bg.get('full_storage_exact_match') and fg.get('comparison_available') and fg.get('state_exact_match') and fg.get('full_storage_exact_match')):
   raise RuntimeError(f'{phase}: baseline/final full six-state gate did not pass')
  # Confirm all six state arrays are unchanged across source variants in both implementations.
  bm,bfs=full.read_fortran(bftfull); fm,ffs=full.read_fortran(ffull if False else fftfull)
  bd=tuple(full.read_cpp(bcppfull)[0]['dims_nx_ny_nz_nxu_nyv_nzw']); fd=tuple(full.read_cpp(fcppfull)[0]['dims_nx_ny_nz_nxu_nyv_nzw'])
  if bd!=fd: raise RuntimeError(f'{phase}: baseline/final C++ dimensions differ')
  bstate=full.logical_fortran_state(bm,bfs,bd); fstate=full.logical_fortran_state(fm,ffs,fd)
  cstate_b=full.read_cpp(bcppfull)[1]; cstate_f=full.read_cpp(fcppfull)[1]
  state_blocks={}
  for name in ('u','v','w','ph','t','mu'):
   state_blocks[name]={'fortran_baseline_equals_final':bool(np.array_equal(bstate[name],fstate[name])),
                       'cpp_baseline_equals_final':bool(np.array_equal(cstate_b[name],cstate_f[name])),
                       'baseline_cpp_equals_fortran':bool(np.array_equal(bstate[name],cstate_b[name])),
                       'final_cpp_equals_fortran':bool(np.array_equal(fstate[name],cstate_f[name]))}
  if not all(vv for x in state_blocks.values() for vv in x.values()):
   raise RuntimeError(f'{phase}: cross-run or paired six-field state equality failed: {state_blocks}')
  old=np.load(BASE/f'baseline_{phase}_term_arrays.npz')
  final=np.load(BASE/f'final_{phase}_term_arrays.npz')
  # Fail closed on shared Fortran U full RHS and component inputs across variants.
  for name in ('ft_full_u_phys','ft_hd_phys','ft_hdiff_delta_coupled','ft_hdiff_ru_tendf_before','ft_hdiff_ru_tendf_after'):
   if not np.array_equal(old[name],final[name]): raise RuntimeError(f'{phase}: baseline/final Fortran {name} mismatch')
  D=old['whole_delta']; old_hd=old['hd_delta']; ft_vd=final['ft_vdiff_u_component_physical']; ft_hd=final['ft_hd_phys']
  prediction=old_hd-ft_vd
  # The explicit FT component-only expression should coincide at x=0 with the
  # actual baseline HD cross-code term plus the missing VDiff term.
  masks={'west_face_x0':(slice(None),slice(None),slice(0,1)),
         'closing_face_x16':(slice(None),slice(None),slice(16,17)),
         'seam_pair_x0_x16':(slice(None),slice(None),np.array([0,16])),
         'owner_unique_x0_to15':(slice(None),slice(None),slice(0,16))}
  regions={}
  for label,sl in masks.items():
   item={'old_full_delta_vs_zero':metric(D[sl],np.zeros_like(D[sl])),
    'old_hd_delta':metric(old_hd[sl],np.zeros_like(old_hd[sl])),
    'ft_hd_component':metric(ft_hd[sl],np.zeros_like(ft_hd[sl])),
    'ft_vdiff_component':metric(ft_vd[sl],np.zeros_like(ft_vd[sl])),
    'observed_cpp_hd_x0_max_abs':float(np.max(np.abs(old['cpp_hd_phys'][:,:,0])))}
   if label in ('west_face_x0','closing_face_x16','seam_pair_x0_x16'):
    item['counterfactual_missing_vdiff_plus_actual_old_hd_delta']=projection(D[sl],prediction[sl])
   else:
    item['counterfactual_status']='not evaluated: old CPP VDiff is not assumed zero away from the periodic U seam'
   item['old_delta_hot']={'local_jki':list(map(int,np.unravel_index(np.argmax(np.abs(D[sl])),D[sl].shape))),
                     'actual_delta_max_abs':float(np.max(np.abs(D[sl]))),
                     'prediction_at_west_hot':float(prediction[15,10,0]),
                     'old_delta_at_west_hot':float(D[15,10,0]),
                     'ft_hd_at_west_hot':float(ft_hd[15,10,0]),
                     'ft_vdiff_at_west_hot':float(ft_vd[15,10,0])}
   regions[label]=item
  # Isolated pure-Fourier period closure diagnostics at west and closing faces.
  regions['west_face_x0']['old_delta_equals_negative_ft_hd_plus_vdiff']={
      'max_abs_error':float(np.max(np.abs(D[:,:,0]+ft_hd[:,:,0]+ft_vd[:,:,0]))),
      'rms_error':rms(D[:,:,0]+ft_hd[:,:,0]+ft_vd[:,:,0])}
  # Correct direct full-RHS delta metrics: prior term script's top-level whole_u_rhs_delta
  # passes candidate arrays into a delta-taking helper and therefore reports CPP signal, not delta.
  ftrhs=final['ft_full_u_phys']; finalcpp=final['cpp_full_u_phys']; finaldelta=final['whole_delta']
  after={}
  for label,sl in masks.items():
   after[label]={'full_rhs_cpp_minus_fortran':metric(finalcpp[sl],ftrhs[sl]),
     'component_residual_after_hdiff_vdiff':metric(final['delta_full_minus_hd_minus_vdiff'][sl],np.zeros_like(final['delta_full_minus_hd_minus_vdiff'][sl])),
     'hdiff_cpp_minus_fortran':metric(final['hd_delta'][sl],np.zeros_like(final['hd_delta'][sl])),
     'vdiff_cpp_minus_fortran':metric(final['delta_vdiff_cpp_minus_fortran'][sl],np.zeros_like(final['delta_vdiff_cpp_minus_fortran'][sl]))}
  # all-field unmasked RHS difference and signal
  after['all_physical_u_faces']={'full_rhs_cpp_minus_fortran':metric(finalcpp,ftrhs),
    'component_residual_after_hdiff_vdiff':metric(final['delta_full_minus_hd_minus_vdiff'],np.zeros_like(final['delta_full_minus_hd_minus_vdiff']))}
  final_json=json.loads((RED/f'fixed_xy_{phase}_hd_vd_audit.json').read_text())
  out['cases'][phase]={'gate':{'baseline_state_exact':bg['state_exact_match'],'baseline_storage_exact':bg['full_storage_exact_match'],
       'fixed_xy_state_exact':fg['state_exact_match'],'fixed_xy_storage_exact':fg['full_storage_exact_match'],
       'cross_run_all_six_blocks_bitwise_equal':True,'blocks':state_blocks,
       'fortran_full_rhs_u_exact_baseline_vs_fixed_xy':bool(np.array_equal(old['ft_full_u_phys'],ftrhs))},
    'baseline_old_delta_counterfactual_using_final_ft_components':{'regions':regions,
       'whole_delta_owner_unique_rms':rms(D[:,:,:16]),'whole_delta_owner_unique_max_abs':float(np.max(np.abs(D[:,:,:16]))),
       'prediction': 'old baseline HD CPP-minus-FT delta - final FT VDiff physical increment; at west seam both CPP isolated terms are zero, so prediction is -(FT_HDiff+FT_VDiff)',
       'component_data_provenance':'final_*_term_arrays.npz are fixed_xy raw snapshots; exact Fortran Full U RHS, HD operand frames, and all six C++/Fortran input state blocks are checked equal to baseline before reuse'},
    'fixed_xy_after_metrics_recomputed_from_arrays':{'whole_full_rhs_delta_not_analyzer_mislabeled_signal':after,
       'reported_state_gate':final_json['full_rhs_state_gate'],
       'vdiff_before_west_u_face_state':final_json['vdiff_extension']['fortran_vdiff_before_ru_tendf']['owner_u_face0_max_abs'],
       'v_component_cpp_minus_ft_over_all_physical_faces':final_json['vdiff_extension']['component_deltas']['vdiff_u_cpp_minus_fortran'],
       'hd_component_cpp_minus_ft_over_all_physical_faces':final_json['vdiff_extension']['component_deltas']['hdiff_cpp_minus_fortran'],
       'combined_component_residual_is_partial_not_full_f_gate':True}}
 # Source change summary: reporter only; digests provide exact source pin.
 br=out['source_receipts']['baseline']['source_sha256_before']; fr=out['source_receipts']['fixed_xy']['source_sha256_before']
 out['source_change_summary']={'same_head':out['source_receipts']['baseline']['head']==out['source_receipts']['fixed_xy']['head'],
   'changed_paths':{k:{'baseline':br.get(k),'fixed_xy':fr.get(k)} for k in sorted(set(br)|set(fr)) if br.get(k)!=fr.get(k)},
   'interpretation':'Run receipts pin the exact revisions. Changed hashes must be interpreted against the source diff and diagnostic-only capture additions; this audit does not infer absence of numerical edits from hashes alone.'}
 out['caveats']=[
  'Baseline whole seam counterfactual is conditional on the independently witnessed old CPP VDiff zero at the west periodic face and the observed baseline CPP HD zero there; it is not an uninstrumented captured CPP VDiff measurement.',
  'The seam-pair mask counts both periodic U copies (x=0 and x=16); owner-unique RHS metrics use x=0..15.',
  'The remaining fixed_xy full-RHS difference and component remainder are finite but nonzero; this report does not claim any project F acceptance gate passed.',
  'No accuracy budget is adopted and no production source, model executable, or build was changed/run by this audit.' ]
 return out

if __name__=='__main__':
 report=run(); outpath=RED/'final_causality_audit.json'; outpath.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 print(outpath)
