#!/usr/bin/env python3
"""Analyze paired Fortran/C++ U horizontal-diffusion term snapshots.

Evidence-only: it reuses the prior exact full-state gate and physical-grid
normalizations, then compares the captured isolated HD increments and their
remainder in the full U RHS difference. It never evaluates a model operator.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import struct
import subprocess
from pathlib import Path
from typing import Any

import numpy as np


EVIDENCE = Path(__file__).resolve().parents[1]
EXTERNAL_EVIDENCE = Path("/Users/yhlee/AD-SDIRK3-review-evidence/full-rhs-contract-20261011")
DEFAULT_SOURCE_ROOT = Path("/private/tmp/pr296-seam-cause-20261012")
DEFAULT_OUT = EVIDENCE / "red_arrays/u_hdiff_capture_analysis.json"
DEFAULT_VDIFF_OUT = EVIDENCE / "red_arrays/u_hdiff_vdiff_capture_analysis.json"
DEFAULT_HDIFF_NPZ = EVIDENCE / "red_arrays/u_hdiff_capture_arrays.npz"
DEFAULT_VDIFF_NPZ = EVIDENCE / "red_arrays/u_hdiff_vdiff_capture_arrays.npz"
ANALYZER_PATH = EVIDENCE / "analyze_snapshots.py"
if not ANALYZER_PATH.is_file():
    ANALYZER_PATH = EXTERNAL_EVIDENCE / "analyze_snapshots.py"
SOURCE_FILES = (
    "dyn_em/module_first_rk_step_part2.F",
    "dyn_em/module_diffusion_em.F",
    "dyn_em/module_big_step_utilities_em.F",
    "dyn_em/module_em.F",
    "dyn_em/module_small_step_em.F",
    "dyn_em/module_implicit_sdirk3.F",
    "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp",
)
HD_SCHEMA = EVIDENCE / "green_mass/u_hdiff_snapshot_schema.json"

spec = importlib.util.spec_from_file_location("full_rhs_analyzer", ANALYZER_PATH)
if spec is None or spec.loader is None:
    raise RuntimeError(f"could not load reusable full-RHS analyzer: {ANALYZER_PATH}")
full = importlib.util.module_from_spec(spec)
spec.loader.exec_module(full)


class CaptureError(RuntimeError):
    pass


def rms(value: np.ndarray) -> float:
    return float(np.sqrt(np.mean(np.asarray(value, dtype=np.float64) ** 2)))


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def source_receipt(root: Path) -> dict[str, Any]:
    try:
        head = subprocess.run(["git", "-C", str(root), "rev-parse", "HEAD"], check=True,
                              capture_output=True, text=True).stdout.strip()
        dirty = bool(subprocess.run(["git", "-C", str(root), "status", "--porcelain"], check=True,
                                    capture_output=True, text=True).stdout.strip())
    except (OSError, subprocess.CalledProcessError):
        head, dirty = None, None
    return {
        "worktree": str(root),
        "head": head,
        "working_tree_dirty": dirty,
        "files": {rel: {"present": (root / rel).is_file(), "sha256": sha256_file(root / rel) if (root / rel).is_file() else None}
                  for rel in SOURCE_FILES},
        "fortran_hdiff_schema_sha256": sha256_file(HD_SCHEMA) if HD_SCHEMA.is_file() else None,
    }


def receipt(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise CaptureError(f"capture missing: {path}")
    return {"path": str(path), "byte_count": path.stat().st_size, "sha256": sha256_file(path)}


def read_hdiff_fortran(path: Path) -> tuple[dict[str, Any], dict[str, np.ndarray]]:
    data = path.read_bytes()
    if len(data) < 60:
        raise CaptureError(f"Fortran HD header is short ({len(data)} bytes)")
    version, = struct.unpack_from("<I", data, 0)
    if version != 1:
        raise CaptureError(f"unsupported Fortran HD version {version}")
    bounds = struct.unpack_from("<12i", data, 4)
    rdx, rdy = struct.unpack_from("<2f", data, 52)
    ids, ide, jds, jde, kds, kde, ims, ime, jms, jme, kms, kme = map(int, bounds)
    ni, nj, nk = ime - ims + 1, jme - jms + 1, kme - kms + 1
    if min(ni, nj, nk) <= 0:
        raise CaptureError(f"invalid Fortran HD memory bounds {bounds}")
    count = ni * nj * nk
    expected = 60 + 10 * count * 4
    if len(data) != expected:
        raise CaptureError(f"Fortran HD byte count mismatch: expected {expected}, got {len(data)}")
    names = ("ru_tendf_before", "ru_tendf_after", "xkmh", "rho", "defor11", "defor12", "div", "rdzw", "zx", "zy")
    arrays: dict[str, np.ndarray] = {}
    offset = 60
    for name in names:
        arr = np.frombuffer(data, dtype="<f4", count=count, offset=offset).reshape((nj, nk, ni), order="C")
        arrays[name] = arr
        offset += count * 4
    meta = {
        "version": version,
        "bounds": dict(zip(("ids", "ide", "jds", "jde", "kds", "kde", "ims", "ime", "jms", "jme", "kms", "kme"), bounds)),
        "memory_shape_jki": [nj, nk, ni],
        "rdx": float(rdx),
        "rdy": float(rdy),
        "dtype": "little-endian float32",
        "order": list(names),
    }
    return meta, arrays


def read_hdiff_cpp(path: Path) -> tuple[dict[str, Any], np.ndarray, np.ndarray]:
    data = path.read_bytes()
    if len(data) < 16:
        raise CaptureError(f"C++ HD header is short ({len(data)} bytes)")
    version, ny, nz, nxu = struct.unpack_from("<4i", data, 0)
    if version != 1 or min(ny, nz, nxu) <= 0:
        raise CaptureError(f"invalid C++ HD header {(version, ny, nz, nxu)}")
    count = ny * nz * nxu
    expected = 16 + 2 * count * 8
    if len(data) != expected:
        raise CaptureError(f"C++ HD byte count mismatch: expected {expected}, got {len(data)}")
    inc = np.frombuffer(data, dtype="<f8", count=count, offset=16).reshape((ny, nz, nxu))
    mass = np.frombuffer(data, dtype="<f8", count=count, offset=16 + count * 8).reshape((ny, nz, nxu))
    return ({"version": version, "shape_jki": [ny, nz, nxu], "dtype": "little-endian float64", "order": ["coupled_increment", "velocity_mass_u"]}, inc, mass)


def read_vdiff_fortran(path: Path) -> tuple[dict[str, Any], dict[str, np.ndarray]]:
    data = path.read_bytes()
    if len(data) < 60:
        raise CaptureError(f"Fortran VDiff header is short ({len(data)} bytes)")
    version, = struct.unpack_from("<I", data, 0)
    if version != 1:
        raise CaptureError(f"unsupported Fortran VDiff version {version}")
    bounds = struct.unpack_from("<12i", data, 4)
    rdx, rdy = struct.unpack_from("<2f", data, 52)
    ids, ide, jds, jde, kds, kde, ims, ime, jms, jme, kms, kme = map(int, bounds)
    ni, nj, nk = ime - ims + 1, jme - jms + 1, kme - kms + 1
    if min(ni, nj, nk) <= 0:
        raise CaptureError(f"invalid Fortran VDiff memory bounds {bounds}")
    count = ni * nj * nk
    expected = 60 + 5 * count * 4
    if len(data) != expected:
        raise CaptureError(f"Fortran VDiff byte count mismatch: expected {expected}, got {len(data)}")
    names = ("ru_tendf_before_v", "xkmv", "rho", "defor13", "rdz")
    arrays: dict[str, np.ndarray] = {}
    offset = 60
    for name in names:
        arrays[name] = np.frombuffer(data, dtype="<f4", count=count, offset=offset).reshape((nj, nk, ni), order="C")
        offset += count * 4
    return ({
        "version": version,
        "bounds": dict(zip(("ids", "ide", "jds", "jde", "kds", "kde", "ims", "ime", "jms", "jme", "kms", "kme"), bounds)),
        "memory_shape_jki": [nj, nk, ni], "rdx": float(rdx), "rdy": float(rdy),
        "dtype": "little-endian float32", "order": list(names),
    }, arrays)


def read_vdiff_cpp(path: Path) -> tuple[dict[str, Any], np.ndarray, np.ndarray]:
    # Same binary header/layout as the paired CPP HD capture: version, Ny/Nz/Nxu,
    # float64 coupled U increment, then float64 U velocity mass.
    return read_hdiff_cpp(path)


def physical_full_arrays(ft_meta: dict[str, Any], ft: dict[str, np.ndarray], dims: tuple[int, ...]) -> dict[str, Any]:
    bounds = ft_meta["bounds"]
    nx, ny, nz, nxu, nyv, nzw = dims
    px, py, pz = full.physical_dimensions(dims, ft_meta)
    i0, j0, k0 = bounds["ids"], bounds["jds"], bounds["kds"]
    # Physical state must first satisfy the reusable six-field exact gate.
    storage_state = full.logical_fortran_state(ft_meta, ft, dims)
    phys_state = full.physical_state(storage_state, dims)
    continuity = full.calc_mu_dot(ft_meta, ft, dims)
    muu = full._slice2(ft["muu"], bounds, i0=i0, i1=i0 + nxu, j0=j0, j1=j0 + ny)[:py, :px + 1].astype(np.float64)
    muv = full._slice2(ft["muv"], bounds, i0=i0, i1=i0 + nx, j0=j0, j1=j0 + nyv)[:py + 1, :px].astype(np.float64)
    msfuy = full._slice2(ft["msfuy"], bounds, i0=i0, i1=i0 + nxu, j0=j0, j1=j0 + ny)[:py, :px + 1].astype(np.float64)
    msfvx = full._slice2(ft["msfvx"], bounds, i0=i0, i1=i0 + nx, j0=j0, j1=j0 + nyv)[:py + 1, :px].astype(np.float64)
    c1h = ft["c1h"][k0 - bounds["kms"]:k0 - bounds["kms"] + pz].astype(np.float64)
    c2h = ft["c2h"][k0 - bounds["kms"]:k0 - bounds["kms"] + pz].astype(np.float64)
    lu = c1h[None, :, None] * muu[:, None, :] + c2h[None, :, None]
    lv = c1h[None, :, None] * muv[:, None, :] + c2h[None, :, None]
    u = storage_state["u"][:py, :, :px + 1].astype(np.float64)
    v = storage_state["v"][:py + 1, :, :px].astype(np.float64)
    ru_tend = full._slice3(ft["ru_tend"], bounds, i0=i0, i1=i0 + nxu, k0=k0, k1=k0 + pz, j0=j0, j1=j0 + ny)[:py, :, :px + 1].astype(np.float64)
    rv_tend = full._slice3(ft["rv_tend"], bounds, i0=i0, i1=i0 + nx, k0=k0, k1=k0 + pz, j0=j0, j1=j0 + nyv)[:py + 1, :, :px].astype(np.float64)
    ft_u_phys = full.fortran_tendency_to_physical(ru_tend, u, c1h, continuity["mu_u_dot"], msfuy, lu)
    ft_v_phys = full.fortran_tendency_to_physical(rv_tend, v, c1h, continuity["mu_v_dot"], msfvx, lv)
    cpp_meta = None
    return {
        "bounds": bounds, "dims": dims, "physical_dims": (px, py, pz), "storage_state": storage_state,
        "physical_state": phys_state, "continuity": continuity, "muu": muu, "muv": muv,
        "msfuy": msfuy, "msfvx": msfvx, "c1h": c1h, "c2h": c2h, "layer_mass_u": lu,
        "ft_u_phys": ft_u_phys, "ft_v_phys": ft_v_phys,
    }


def metrics(delta: np.ndarray, reference: np.ndarray) -> dict[str, Any]:
    # Reuse the established full-RHS normalization by expressing a delta as
    # (reference+delta) minus reference.
    return full.metrics(reference.astype(np.float64) + delta, reference.astype(np.float64), "m/s^2")


def squared_explanation(whole: np.ndarray, term: np.ndarray) -> dict[str, Any]:
    remainder = whole - term
    denom = float(np.sum(whole.astype(np.float64) ** 2))
    term_ss = float(np.sum(term.astype(np.float64) ** 2))
    rem_ss = float(np.sum(remainder.astype(np.float64) ** 2))
    dot = float(np.sum(whole.astype(np.float64) * term.astype(np.float64)))
    return {
        "whole_delta_squared_norm": denom,
        "term_delta_squared_norm": term_ss,
        "remainder_squared_norm": rem_ss,
        "squared_residual_explained_pct": 100.0 * (1.0 - rem_ss / denom) if denom else None,
        "term_energy_share_pct": 100.0 * term_ss / denom if denom else None,
        "signed_projection_share_pct": 100.0 * dot / denom if denom else None,
    }


def region_slices(px: int) -> dict[str, tuple[slice, ...]]:
    return {
        "owner_unique_all_x0_to15": (slice(None), slice(None), slice(0, px)),
        "west_periodic_face_x0": (slice(None), slice(None), slice(0, 1)),
        "closing_physical_face_x16_duplicate": (slice(None), slice(None), slice(px, px + 1)),
        "seam_pair_x0_and_x16_duplicate_counted": (slice(None), slice(None), np.array([0, px])),
        "internal_x1_to15": (slice(None), slice(None), slice(1, px)),
    }


def region_x_indices(name: str, px: int) -> np.ndarray:
    if name == "owner_unique_all_x0_to15":
        return np.arange(px)
    if name == "west_periodic_face_x0":
        return np.array([0])
    if name == "closing_physical_face_x16_duplicate":
        return np.array([px])
    if name == "seam_pair_x0_and_x16_duplicate_counted":
        return np.array([0, px])
    if name == "internal_x1_to15":
        return np.arange(1, px)
    raise CaptureError(f"unknown region {name}")


def manufactured_map_cancellation_check() -> dict[str, Any]:
    delta = np.array([5.0], dtype=np.float64)
    map_y = 2.5
    layer_mass = 10.0
    ru_tendf_component = delta / map_y
    reconstructed = ru_tendf_component * map_y / layer_mass
    direct = delta / layer_mass
    wrong_no_cancellation = delta * map_y / layer_mass
    if not np.array_equal(reconstructed, direct) or np.array_equal(wrong_no_cancellation, direct):
        raise CaptureError("manufactured map-cancellation self-check failed")
    return {"passed": True, "delta_ru_tendf": 5.0, "map_y": map_y, "layer_mass": layer_mass,
            "expected_physical": 0.5, "wrong_delta_times_map_over_layer": 1.25}


def analyze_one(
    ft_hdiff_path: Path, cpp_hdiff_path: Path, ft_full_path: Path, cpp_full_path: Path,
    source_root: Path, ft_vdiff_path: Path | None = None, cpp_vdiff_path: Path | None = None,
) -> dict[str, Any]:
    # This call is the authoritative six-block physical state gate and retains
    # all established normalizations and periodic-face checks.
    full_gate = full.analyze(ft_full_path, cpp_full_path, source_root)
    if (not full_gate.get("comparison_available") or not full_gate.get("state_exact_match")
            or not full_gate.get("full_storage_exact_match")):
        return {"comparison_available": False, "reason": "full-RHS six-field state/periodic gate failed", "full_rhs_gate": full_gate}
    ft_full_receipt = receipt(ft_full_path)
    cpp_full_receipt = receipt(cpp_full_path)
    ft_hdiff_receipt = receipt(ft_hdiff_path)
    cpp_hdiff_receipt = receipt(cpp_hdiff_path)
    ft_full_meta, ft_full = full.read_fortran(ft_full_path)
    cpp_full_meta, cpp_state, cpp_full_rhs = full.read_cpp(cpp_full_path)
    dims = tuple(cpp_full_meta["dims_nx_ny_nz_nxu_nyv_nzw"])
    arrays = physical_full_arrays(ft_full_meta, ft_full, dims)
    ft_hdiff_meta, h = read_hdiff_fortran(ft_hdiff_path)
    cpp_hdiff_meta, cpp_increment_storage, cpp_mass_storage = read_hdiff_cpp(cpp_hdiff_path)
    if ft_hdiff_meta["bounds"] != ft_full_meta["bounds"] or (ft_hdiff_meta["rdx"], ft_hdiff_meta["rdy"]) != (ft_full_meta["scalars"]["rdx"], ft_full_meta["scalars"]["rdy"]):
        raise CaptureError("U-HDiff and full-RHS Fortran snapshot headers differ")
    if cpp_hdiff_meta["shape_jki"] != list(cpp_state["u"].shape):
        raise CaptureError(f"CPP HD storage shape {cpp_hdiff_meta['shape_jki']} != full-U state shape {list(cpp_state['u'].shape)}")
    if cpp_hdiff_meta["shape_jki"] != list(cpp_full_rhs["u"].shape):
        raise CaptureError("CPP HD shape does not match full-RHS U output")

    px, py, pz = arrays["physical_dims"]
    bounds = ft_hdiff_meta["bounds"]
    nx, ny, nz, nxu, nyv, nzw = dims
    i0, j0, k0 = bounds["ids"], bounds["jds"], bounds["kds"]
    before_store = full._slice3(h["ru_tendf_before"], bounds, i0=i0, i1=i0 + nxu, k0=k0, k1=k0 + nz, j0=j0, j1=j0 + ny)
    after_store = full._slice3(h["ru_tendf_after"], bounds, i0=i0, i1=i0 + nxu, k0=k0, k1=k0 + nz, j0=j0, j1=j0 + ny)
    ft_delta_coupled_storage = after_store - before_store
    ft_delta_coupled = ft_delta_coupled_storage[:py, :, :px + 1].astype(np.float64)
    before_phys = before_store[:py, :, :px + 1].astype(np.float64)
    after_phys = after_store[:py, :, :px + 1].astype(np.float64)
    hdiff_operands = {
        name: full._slice3(h[name], bounds, i0=i0, i1=i0 + nxu, k0=k0, k1=k0 + nz, j0=j0, j1=j0 + ny)[:py, :, :px + 1].astype(np.float64)
        for name in ("xkmh", "rho", "defor11", "defor12", "div", "rdzw", "zx", "zy")
    }
    cpp_inc = cpp_increment_storage[:py, :, :px + 1].astype(np.float64)
    cpp_mass = cpp_mass_storage[:py, :, :px + 1].astype(np.float64)
    layer_mass = arrays["layer_mass_u"]
    if layer_mass.shape != ft_delta_coupled.shape or cpp_mass.shape != ft_delta_coupled.shape:
        raise CaptureError(f"physical U layer shapes differ: FT delta {ft_delta_coupled.shape}, L {layer_mass.shape}, CPP mass {cpp_mass.shape}")
    if np.any(layer_mass == 0.0) or np.any(cpp_mass == 0.0):
        raise CaptureError("zero U layer mass prevents HD normalization")
    # Fortran ru_tendf is the accumulated physics component before rk_addtend:
    # coupled contribution is Delta/msfuy, then physical is *msfuy/L = Delta/L.
    # Keep both algebraic forms visible and check map cancellation analytically.
    msfuy = arrays["msfuy"]
    ft_hd_phys_cancelled = ft_delta_coupled / layer_mass
    ft_hd_phys_two_step = (ft_delta_coupled / msfuy[:, None, :]) * msfuy[:, None, :] / layer_mass
    cpp_hd_phys = cpp_inc / cpp_mass
    if not np.allclose(ft_hd_phys_cancelled, ft_hd_phys_two_step, rtol=2e-15, atol=1e-30):
        raise CaptureError("Fortran map-factor cancellation forms disagree")

    ft_full_u_phys = arrays["ft_u_phys"]
    cpp_full_u_phys = cpp_full_rhs["u"][:py, :, :px + 1].astype(np.float64)
    whole_delta = cpp_full_u_phys - ft_full_u_phys
    hd_delta = cpp_hd_phys - ft_hd_phys_cancelled
    remainder = whole_delta - hd_delta
    regions = {}
    for name, sl in region_slices(px).items():
        full_d, hd_d, rem_d = whole_delta[sl], hd_delta[sl], remainder[sl]
        x_indices = region_x_indices(name, px)
        hot_local = tuple(map(int, np.unravel_index(np.argmax(np.abs(full_d)), full_d.shape))) if full_d.size else None
        if hot_local is None:
            hot_global = None
            hot_terms = None
        else:
            jh, kh, xlocal = hot_local
            ih = int(x_indices[xlocal])
            hot_global = [int(j0 + jh), int(k0 + kh), int(i0 + ih)]
            hot_terms = {
                "cpp_full_physical": float(cpp_full_u_phys[jh, kh, ih]),
                "fortran_full_physical": float(ft_full_u_phys[jh, kh, ih]),
                "whole_delta": float(whole_delta[jh, kh, ih]),
                "cpp_hdiff_physical": float(cpp_hd_phys[jh, kh, ih]),
                "fortran_hdiff_physical": float(ft_hd_phys_cancelled[jh, kh, ih]),
                "hd_delta": float(hd_delta[jh, kh, ih]),
                "remainder": float(remainder[jh, kh, ih]),
                "fortran_hdiff_operands": {key: float(value[jh, kh, ih]) for key, value in hdiff_operands.items()},
            }
        regions[name] = {
            "count": int(full_d.size),
            "whole_delta_vs_fortran": metrics(full_d, ft_full_u_phys[sl]),
            "hd_delta_cpp_minus_fortran": metrics(hd_d, ft_hd_phys_cancelled[sl]),
            "remainder_full_delta_minus_hd_delta": metrics(rem_d, ft_full_u_phys[sl]),
            **squared_explanation(full_d, hd_d),
            "whole_delta_hot": {
                "max_abs": float(np.max(np.abs(full_d))) if full_d.size else 0.0,
                "local_index_jki": list(hot_local) if hot_local is not None else None,
                "physical_global_index_jki": hot_global,
                "all_terms_at_hot": hot_terms,
            },
        }
    vdiff_extension = None
    vdiff_arrays: dict[str, np.ndarray] = {}
    if (ft_vdiff_path is None) != (cpp_vdiff_path is None):
        raise CaptureError("Fortran and C++ VDiff captures must be supplied together")
    if ft_vdiff_path is not None and cpp_vdiff_path is not None:
        ft_vdiff_receipt, cpp_vdiff_receipt = receipt(ft_vdiff_path), receipt(cpp_vdiff_path)
        ft_vdiff_meta, v = read_vdiff_fortran(ft_vdiff_path)
        cpp_vdiff_meta, cpp_vd_increment_store, cpp_vd_mass_store = read_vdiff_cpp(cpp_vdiff_path)
        if ft_vdiff_meta["bounds"] != ft_full_meta["bounds"] or (ft_vdiff_meta["rdx"], ft_vdiff_meta["rdy"]) != (ft_full_meta["scalars"]["rdx"], ft_full_meta["scalars"]["rdy"]):
            raise CaptureError("Fortran VDiff and full-RHS snapshot headers differ")
        if (ft_vdiff_meta["bounds"] != ft_hdiff_meta["bounds"]
                or (ft_vdiff_meta["rdx"], ft_vdiff_meta["rdy"]) != (ft_hdiff_meta["rdx"], ft_hdiff_meta["rdy"])):
            raise CaptureError("Fortran VDiff and HDiff capture frames have different headers")
        if cpp_vdiff_meta["shape_jki"] != list(cpp_full_rhs["u"].shape):
            raise CaptureError("CPP VDiff shape does not match the paired Full U state/RHS storage")
        if cpp_vdiff_meta["shape_jki"] != cpp_hdiff_meta["shape_jki"]:
            raise CaptureError("CPP VDiff shape does not match CPP HDiff shape")
        if not np.array_equal(cpp_mass_storage, cpp_vd_mass_store):
            raise CaptureError("CPP HDiff and VDiff captures do not share bitwise-identical velocity_mass_u")
        if not np.array_equal(h["rho"], v["rho"]):
            raise CaptureError("Fortran HDiff and VDiff snapshots have different rho fields; cannot attribute their frame delta to the isolated vertical-U call")
        vbefore_store = full._slice3(v["ru_tendf_before_v"], bounds, i0=i0, i1=i0 + nxu, k0=k0, k1=k0 + nz, j0=j0, j1=j0 + ny)
        ft_vd_coupled_storage = before_store - vbefore_store
        ft_vd_coupled = ft_vd_coupled_storage[:py, :, :px + 1].astype(np.float64)
        ft_vd_phys = ft_vd_coupled / layer_mass
        cpp_vd_inc = cpp_vd_increment_store[:py, :, :px + 1].astype(np.float64)
        cpp_vd_mass = cpp_vd_mass_store[:py, :, :px + 1].astype(np.float64)
        if cpp_vd_mass.shape != ft_vd_phys.shape or np.any(cpp_vd_mass == 0.0):
            raise CaptureError("invalid CPP VDiff velocity_mass_u shape or zero denominator")
        cpp_vd_phys = cpp_vd_inc / cpp_vd_mass
        if not all(np.isfinite(a).all() for a in (vbefore_store, ft_vd_phys, cpp_vd_inc, cpp_vd_mass, cpp_vd_phys)):
            raise CaptureError("non-finite value in VDiff capture or normalized increment")
        vdiff_delta = cpp_vd_phys - ft_vd_phys
        combined_term_delta = hd_delta + vdiff_delta
        remainder_after_both = whole_delta - combined_term_delta
        v_before_phys = vbefore_store[:py, :, :px + 1].astype(np.float64)
        vdiff_rho_owner = full._slice3(v["rho"], bounds, i0=i0, i1=i0 + nxu, k0=k0, k1=k0 + nz, j0=j0, j1=j0 + ny)[:py, :, :px + 1]
        vdiff_extension_regions = {}
        for name, sl in region_slices(px).items():
            whole_d = whole_delta[sl]
            hd_d = hd_delta[sl]
            vd_d = vdiff_delta[sl]
            together = hd_d + vd_d
            rem_d = whole_d - together
            full_hot = regions[name]["whole_delta_hot"]
            hot_global = full_hot["physical_global_index_jki"]
            if hot_global is None:
                hot_terms = None
            else:
                jh, kh, ih = hot_global[0] - j0, hot_global[1] - k0, hot_global[2] - i0
                hot_terms = {
                    "cpp_full_physical": float(cpp_full_u_phys[jh, kh, ih]),
                    "fortran_full_physical": float(ft_full_u_phys[jh, kh, ih]),
                    "whole_delta": float(whole_delta[jh, kh, ih]),
                    "cpp_hdiff_physical": float(cpp_hd_phys[jh, kh, ih]),
                    "fortran_hdiff_physical": float(ft_hd_phys_cancelled[jh, kh, ih]),
                    "hd_delta": float(hd_delta[jh, kh, ih]),
                    "cpp_vdiff_physical": float(cpp_vd_phys[jh, kh, ih]),
                    "fortran_vdiff_physical": float(ft_vd_phys[jh, kh, ih]),
                    "vdiff_delta": float(vdiff_delta[jh, kh, ih]),
                    "remainder_after_hd_and_vdiff": float(remainder_after_both[jh, kh, ih]),
                }
            vdiff_extension_regions[name] = {
                "count": int(whole_d.size),
                "whole_delta_vs_fortran": metrics(whole_d, ft_full_u_phys[sl]),
                "hd_component_delta": metrics(hd_d, ft_hd_phys_cancelled[sl]),
                "vdiff_u_component_delta": metrics(vd_d, ft_vd_phys[sl]),
                "hd_plus_vdiff_delta": metrics(together, ft_full_u_phys[sl]),
                "remainder_after_hd_and_vdiff": metrics(rem_d, ft_full_u_phys[sl]),
                "hd_explanation": squared_explanation(whole_d, hd_d),
                "vdiff_explanation": squared_explanation(whole_d, vd_d),
                "combined_explanation": squared_explanation(whole_d, together),
                "remainder_hot": {
                    "max_abs": float(np.max(np.abs(rem_d))) if rem_d.size else 0.0,
                    "rms": rms(rem_d),
                    "whole_delta_hot_physical_global_jki": hot_global,
                    "all_terms_at_whole_delta_hot": hot_terms,
                },
            }
        vdiff_before_owner0_max = float(np.max(np.abs(v_before_phys[:, :, 0])))
        vdiff_extension = {
            "inputs": {
                "fortran_vdiff": {**ft_vdiff_receipt, **ft_vdiff_meta},
                "cpp_vdiff": {**cpp_vdiff_receipt, **cpp_vdiff_meta},
            },
            "method": {
                "fortran_vdiff_u_physical": "(ru_tendf_before_horizontal - ru_tendf_before_vertical)/(c1h*muu+c2h); the same map cancellation applies",
                "cpp_vdiff_u_physical": "coupled_increment/velocity_mass_u",
                "source_interval": "Fortran vdiff snapshot is immediately before vertical_diffusion_2; the existing HDiff before frame is after vertical_diffusion_2 and before horizontal_diffusion_2. Within vertical_diffusion_2, vertical_diffusion_u_2 is the RU mutator; V/W routines mutate RV/RW.",
                "claim_scope": "isolated vertical U diffusion increment from the paired pre/post RU snapshots; not a broad operator-parity claim",
                "source_locations": {
                    "fortran_vdiff_capture_and_order": "dyn_em/module_first_rk_step_part2.F:1092-1124",
                    "fortran_u_then_v_vertical_diffusion_calls": "dyn_em/module_diffusion_em.F:4131-4146",
                    "cpp_vdiff_term_capture": "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp (capture source pinned at runtime)",
                },
            },
            "fortran_vdiff_before_ru_tendf": {
                "owner_u_face0_max_abs": float(np.max(np.abs(v_before_phys[:, :, 0]))),
                "owner_u_face0_rms": rms(v_before_phys[:, :, 0]),
                "owner_u_face0_check_completed_before_component_claim": True,
                "hdiff_before_ru_tendf_owner_u_face0_max_abs": float(np.max(np.abs(before_phys[:, :, 0]))),
                "isolated_vertical_u_increment_owner_face0_max_abs": float(np.max(np.abs(ft_vd_coupled[:, :, 0]))),
                "isolated_vertical_u_increment_owner_face0_physical_max_abs": float(np.max(np.abs(ft_vd_phys[:, :, 0]))),
                "finite": bool(np.isfinite(v_before_phys).all()),
                "rho_exactly_unchanged_between_vdiff_and_hdiff_captures": True,
            },
            "regions": vdiff_extension_regions,
            "whole_u_rhs_delta": metrics(cpp_full_u_phys - ft_full_u_phys, ft_full_u_phys),
            "component_deltas": {
                "hdiff_cpp_minus_fortran": metrics(hd_delta, ft_hd_phys_cancelled),
                "vdiff_u_cpp_minus_fortran": metrics(vdiff_delta, ft_vd_phys),
                "hdiff_plus_vdiff_cpp_minus_fortran": metrics(combined_term_delta, ft_hd_phys_cancelled + ft_vd_phys),
                "remainder_full_minus_hdiff_minus_vdiff": metrics(remainder_after_both, ft_full_u_phys),
            },
            "claim_pure_vdiff_u_component": bool(np.isfinite(vdiff_before_owner0_max) and np.isfinite(ft_vd_coupled[:, :, 0]).all()),
            "pure_component_basis": "paired RU captures bracket vertical_diffusion_2; source order calls vertical_diffusion_u_2 first (the only subcall in that interval that mutates RU), then V/W diffusion, followed by the HDiff-before frame. CPP HDiff/VDiff velocity_mass_u and FT rho are required to match exactly. The pre-VDiff RU owner-face0 max is reported above as requested.",
        }
        vdiff_arrays = {
            "ft_vdiff_ru_tendf_before_v": v_before_phys,
            "ft_vdiff_u_component_coupled": ft_vd_coupled,
            "ft_vdiff_u_component_physical": ft_vd_phys,
            "cpp_vdiff_u_increment_coupled": cpp_vd_inc,
            "cpp_vdiff_velocity_mass_u": cpp_vd_mass,
            "fortran_vdiff_rho": vdiff_rho_owner,
            "cpp_vdiff_u_component_physical": cpp_vd_phys,
            "delta_vdiff_cpp_minus_fortran": vdiff_delta,
            "delta_full_minus_hd_minus_vdiff": remainder_after_both,
        }
    per_x = []
    for x in range(px + 1):
        d, hdd = whole_delta[:, :, x], hd_delta[:, :, x]
        per_x.append({"x": x, "whole_delta_rms": rms(d), "hd_delta_rms": rms(hdd),
                      "remainder_rms": rms(d - hdd), "whole_max_abs": float(np.max(np.abs(d)))})

    # First Full input equivalence is the reusable old analyzer's exact six-field
    # gate. It prevents attributing a term delta across different states.
    all_finite = all(np.isfinite(x).all() for x in (ft_delta_coupled, cpp_inc, cpp_mass, ft_hd_phys_cancelled, cpp_hd_phys, whole_delta))
    if not all_finite:
        raise CaptureError("non-finite value in full/HD U comparison payload")
    return {
        "schema": "paired-u-horizontal-diffusion-attribution-v1",
        "comparison_available": True,
        "source_root": str(source_root),
        "source_revision": full_gate.get("source_revision"),
        "source_sha256": full_gate.get("source_sha256"),
        "hdiff_source_provenance": source_receipt(source_root),
        "full_rhs_state_gate": {
            "passed": full_gate["state_gate"]["passed"],
            "physical_owned_six_field_exact": full_gate["state_gate"]["physical_owned_six_field_exact"],
            "periodic_u_closing_face_exact": full_gate["state_gate"]["periodic_u_closing_face_exact"],
            "full_storage_exact": full_gate["full_storage_exact_match"],
            "physical_dims": full_gate["geometry"]["physical_operator_nx_ny_nz"],
            "cpp_storage_dims": full_gate["geometry"]["cpp_storage_nx_ny_nz"],
        },
        "input_frame_link": {
            "fortran_full_six_field_input_exact": full_gate["state_gate"]["physical_owned_six_field_exact"],
            "cpp_full_six_field_input_exact": full_gate["state_gate"]["physical_owned_six_field_exact"],
            "full_storage_bytes_exact": full_gate["full_storage_exact_match"],
            "interpretation": "The first C++ Full horizontal-U increment is captured inside that Full RHS evaluation; the Fortran HD before/after bracket is in first_rk_step_part2, and the paired full snapshot records the same pre-advance U2 state. The reusable full-RHS six-field gate is required before term attribution.",
            "fortran_order_refs": "dyn_em/module_first_rk_step_part2.F:1124-1162 then dyn_em/solve_em.F:1364-1404; advance_uv is later at solve_em.F:1714",
            "cpp_order_ref": "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp:23837-23858 inside Full RHS evaluation",
        },
        "inputs": {
            "fortran_hdiff": {**ft_hdiff_receipt, **ft_hdiff_meta},
            "cpp_hdiff": {**cpp_hdiff_receipt, **cpp_hdiff_meta},
            "fortran_full_rhs": ft_full_receipt,
            "cpp_full_rhs": cpp_full_receipt,
        },
        "method": {
            "fortran_hdiff_physical": "(ru_tendf_after-ru_tendf_before)/(c1h*muu+c2h); equivalent to (Delta/msfuy)*msfuy/L, so maps cancel",
            "cpp_hdiff_physical": "coupled_increment/velocity_mass_u",
            "no_mass_product_rule": "horizontal diffusion contributes no MU tendency; no mu_dot subtraction is applied to this isolated term",
            "whole_delta": "CPP Full physical U RHS minus Fortran Full physical U RHS, using the reused full-RHS conversion",
            "remainder": "whole_delta - (CPP_HDiff_physical - Fortran_HDiff_physical)",
            "owner_mask": "physical U y=0..15, k=0..15, unique x=0..15; seam pair reports x=0 and duplicate closing x=16 separately and together",
            "source_locations": {
                "fortran_hd_capture": "dyn_em/module_first_rk_step_part2.F:1124-1162",
                "cpp_hd_capture": "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp:23837-23858",
                "fortran_map_combination": "dyn_em/module_em.F:1063-1069",
                "fortran_face_mass": "dyn_em/module_big_step_utilities_em.F:369-384",
                "cpp_physical_uv_conversion": "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp:25003-25023",
            },
        },
        "manufactured_map_cancellation_check": manufactured_map_cancellation_check(),
        "fortran_hd_physical": metrics(ft_hd_phys_cancelled, np.zeros_like(ft_hd_phys_cancelled)),
        "cpp_hd_physical": metrics(cpp_hd_phys, np.zeros_like(cpp_hd_phys)),
        "whole_u_rhs_delta": metrics(cpp_full_u_phys - ft_full_u_phys, ft_full_u_phys),
        "regions": regions,
        "vdiff_extension": vdiff_extension,
        "per_x": per_x,
        "normalization": {
            "squared_explained_definition": "100*(1-||whole_delta-hd_delta||^2/||whole_delta||^2)",
            "also_reported": ["term_energy_share_pct", "signed_projection_share_pct"],
            "relative_metrics": "RMS divided by Fortran reference RMS; null where reference signal is zero",
            "accuracy_budget_adopted": False,
        },
        "claim_scope": "isolated horizontal-U-diffusion contribution attribution at an exact common state; not full operator or accuracy/cost parity",
    }, {
        "ft_full_u_phys": ft_full_u_phys,
        "cpp_full_u_phys": cpp_full_u_phys,
        "ft_hdiff_ru_tendf_before": before_phys,
        "ft_hdiff_ru_tendf_after": after_phys,
        "ft_hdiff_delta_coupled": ft_delta_coupled,
        "ft_hd_phys": ft_hd_phys_cancelled,
        "cpp_hd_phys": cpp_hd_phys,
        "cpp_hdiff_coupled_increment": cpp_inc,
        "cpp_velocity_mass_u": cpp_mass,
        "whole_delta": whole_delta,
        "hd_delta": hd_delta,
        "remainder": remainder,
        **{f"ft_hdiff_{key}": value for key, value in hdiff_operands.items()},
        **vdiff_arrays,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fortran-hdiff", type=Path)
    parser.add_argument("--cpp-hdiff", type=Path)
    parser.add_argument("--fortran-full", type=Path)
    parser.add_argument("--cpp-full", type=Path)
    parser.add_argument("--fortran-vdiff-before", type=Path)
    parser.add_argument("--cpp-vdiff", type=Path)
    parser.add_argument("--source-root", type=Path, default=DEFAULT_SOURCE_ROOT)
    parser.add_argument("--case", default="unspecified")
    parser.add_argument("--out", type=Path, default=None)
    parser.add_argument("--npz", type=Path, default=None)
    parser.add_argument("--self-check", action="store_true")
    args = parser.parse_args()
    if args.self_check:
        print(json.dumps(manufactured_map_cancellation_check(), indent=2, sort_keys=True))
        return 0
    missing = [name for name in ("fortran_hdiff", "cpp_hdiff", "fortran_full", "cpp_full") if getattr(args, name) is None]
    if missing:
        parser.error("required unless --self-check: " + ", ".join("--" + name.replace("_", "-") for name in missing))
    if (args.fortran_vdiff_before is None) != (args.cpp_vdiff is None):
        parser.error("--fortran-vdiff-before and --cpp-vdiff must be supplied together")
    has_vdiff = args.fortran_vdiff_before is not None
    out_path = args.out or (DEFAULT_VDIFF_OUT if has_vdiff else DEFAULT_OUT)
    npz_path = args.npz or (DEFAULT_VDIFF_NPZ if has_vdiff else DEFAULT_HDIFF_NPZ)
    try:
        report, arrays = analyze_one(
            args.fortran_hdiff, args.cpp_hdiff, args.fortran_full, args.cpp_full, args.source_root,
            args.fortran_vdiff_before, args.cpp_vdiff,
        )
        report["case"] = args.case
        npz_path.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(npz_path, **arrays)
        report["npz"] = {"path": str(npz_path), "sha256": sha256_file(npz_path), "byte_count": npz_path.stat().st_size}
    except (OSError, CaptureError, full.SnapshotError, ValueError) as exc:
        report = {"schema": "paired-u-horizontal-diffusion-attribution-v1", "comparison_available": False,
                  "case": args.case, "reason": str(exc), "accuracy_budget_adopted": False}
        for label, path in (("fortran_hdiff", args.fortran_hdiff), ("cpp_hdiff", args.cpp_hdiff),
                            ("fortran_full", args.fortran_full), ("cpp_full", args.cpp_full)):
            if path.is_file():
                report.setdefault("inputs", {})[label] = receipt(path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(report, indent=2, sort_keys=True,
                                   default=lambda x: x.item() if hasattr(x, "item") else str(x)) + "\n")
    print(out_path)
    return 0 if report.get("comparison_available") else 2


if __name__ == "__main__":
    raise SystemExit(main())
