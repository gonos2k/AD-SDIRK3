# Green native qualification review — V3

Evaluated after the V3 contract freeze (2026-10-12 01:34:45.915796 JST). Only the three authorized fresh 240 s runs were launched. Whole-WRF-path comparisons are reported; they do not isolate integrator-only accuracy or cost.

## Run and pin verification

The input SHA-256 is `e71b730a12e5a16d181f404f6314e7904e0165eefa622ffd0c508bf8c00dd2a9`. The fresh ARK/RK3 cases share executable SHA-256 `f7c4e1dbb69a3ec68e5376294e326cbaff339531f31dac13ed47e0fcbf413b64` and libtorch archive SHA-256 `5f28e24cc3019c59c45ed8942e9ad104fc6a8a2c62f59416fe0d04fec317556f`. Seven authoritative source pins, the V3 contract, executable, library, input, and every run namelist were rehashed after execution and match the recorded values. The C++ implementation source and library match the final XY helper regression receipt. Full hashes and receipt paths are in `runs/runs.json` and `evaluation_v3.json`.

| Case | Scheme / exact namelist step | Main steps | Wall time | Main-step log sum |
|---|---:|---:|---:|---:|
| Final ARK | scheme 6, 15 + 0/1 s | 16 | 9.573 s | 8.667 s |
| Stock RK3 control | scheme 0, 3 + 6/8 s | 64 | 1.604 s | 0.648 s |
| RK3 reference qualification | scheme 0, 0 + 15/16 s | 256 | 2.209 s | 1.321 s |

Each run returned zero, printed `SUCCESS COMPLETE`, and logged the expected route. Runs used one MPI rank and one OpenMP thread, `sdirk3_debug_level=1`, with all `WRF_*` environment flags removed. The main-step log sums are not wall time. Cost is optional and has no acceptance gate.

The new 3.75 s RK3 control has the same input and namelist SHA as the archived control and reproduces all eight raw NetCDF variables exactly at t=0, 60, 120, 180, and 240 s. Each fresh run also matches the archived 1.875 s initial state exactly for all eight raw arrays. At all five timestamps, U's periodic seam, both physical V walls, and the bottom W face satisfy exact zero/alias invariants. All arrays are finite; total theta, total MU, and layer depths remain positive.

## Acceptance result

The fixed six-field endpoint epsilon values were applied unchanged at t=60, 120, 180, and 240 s. The single h=0.9375 reference check does **not** qualify h=1.875: all six fields exceed epsilon/3 at every checkpoint. At 240 s, the h=0.9375-to-h=1.875 RMS divided by the allowed epsilon/3 is U 31.69, V 35.37, W 74.38, PH 43.21, theta 26.88, and MU 60.34. The one permitted refinement is exhausted; no further ladder was run.

The ARK h=15 versus archived h=1.875 comparison is therefore **provisional only**, not a final pass/fail or completion result. At 240 s its observed RMS errors and ratios to frozen epsilon are:

| Field | RMS error | Fixed epsilon | Ratio |
|---|---:|---:|---:|
| U | 0.0135072 m/s | 0.000774442 m/s | 17.44 |
| V | 0.00357184 m/s | 0.000101220 m/s | 35.29 |
| W | 0.000297601 m/s | 0.00000779444 m/s | 38.18 |
| PH | 0.257211 m²/s² | 0.0102498 m²/s² | 25.09 |
| theta | 0.000164905 K | 0.0000361957 K | 4.56 |
| MU | 0.504095 Pa | 0.0145909 Pa | 34.55 |

These are measured differences to an unqualified reference. They do not establish true candidate error, and the h=15 candidate is neither accepted nor rejected by V3. No project-wide accuracy-window decision or completion claim follows.

## Durable receipts

- `runs/runs.json`: exact case inputs, namelists, executable/library/source pins, route, step counts, wall and RSS receipts.
- `analysis_v3.json`: exact-time raw-field analysis using the archived 1.875 s result and the three fresh runs.
- `evaluation_v3.json`: fixed-threshold assessment, exact control comparison, state/BC invariants, and physical admissibility.
- `run_three_qualified_cases.py`: reusable runner snapshot; it was adjusted after execution to improve the RSS parser and enforce expected step counts. RSS was recovered from the original `/usr/bin/time -l` logs; these post-run enrichments did not alter run outputs or acceptance thresholds.
