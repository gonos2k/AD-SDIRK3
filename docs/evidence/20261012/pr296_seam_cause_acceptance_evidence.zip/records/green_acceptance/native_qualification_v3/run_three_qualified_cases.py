#!/usr/bin/env python3
"""Run exactly the three pre-authorized V3 WRF qualification cases."""
from __future__ import annotations
from fractions import Fraction
from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, time

ROOT = Path('/private/tmp/pr296-seam-cause-20261012')
EVIDENCE = Path('/Users/yhlee/AD-SDIRK3-review-evidence/seam-cause-acceptance-20261012')
OUT = EVIDENCE / 'green_acceptance/native_qualification_v3/runs'
BASE = Path('/Users/yhlee/Documents/AD-SDIRK3-worktree-archive/20261005/native_wave_refinement/wrf_runs/signfix_fp64_carry_on15_240')
V3 = EVIDENCE / 'acceptance_candidate_v3.json'
INPUT_SHA = 'e71b730a12e5a16d181f404f6314e7904e0165eefa622ffd0c508bf8c00dd2a9'
SOURCE_PATHS = [
 'dyn_em/module_first_rk_step_part2.F',
 'dyn_em/module_diffusion_em.F',
 'dyn_em/module_em.F',
 'dyn_em/module_advect_em.F',
 'dyn_em/module_implicit_sdirk3.F',
 'dyn_em/module_initialize_ideal.F',
 'external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp',
]
CASES = [
 ('ark3_h15_final', Fraction(15,1), 15, 0, 1, 'ARK3', 6),
 # Keep the archived control's literal 3 + 6/8 namelist representation.
 ('rk3_h3p75_stock_control', Fraction(15,4), 3, 6, 8, 'RK3', 0),
 # Do not round the subsecond reference through an eighth-second denominator.
 ('rk3_h0p9375_reference_qualification', Fraction(15,16), 0, 15, 16, 'RK3', 0),
]

def sha(p: Path) -> str:
 h=hashlib.sha256();
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()

def replace(text,key,value):
 text,n=re.subn(r'(\b'+re.escape(key)+r'\s*=\s*)[-+0-9]+',lambda m:m.group(1)+str(value),text,count=1,flags=re.I)
 if n!=1: raise RuntimeError(f'namelist key missing or duplicated: {key}')
 return text

def run_command(cmd, **kw): return subprocess.run(cmd,check=True,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,**kw).stdout.strip()

def main():
 if OUT.exists() and any(OUT.iterdir()): raise RuntimeError(f'refusing to overwrite evidence: {OUT}')
 OUT.mkdir(parents=True,exist_ok=True)
 exe=ROOT/'main/wrf.exe'; lib=ROOT/'external/libtorch_wrf/sdirk3/libwrf_sdirk3_libtorch.a'
 if not exe.is_file() or not lib.is_file(): raise RuntimeError('final WRF executable or solver library missing')
 if sha(BASE/'wrfinput_d01')!=INPUT_SHA: raise RuntimeError('archived input hash mismatch')
 v3=json.loads(V3.read_text())
 if v3['contract_id']!='dry-em-b-wave-16cubed-240s-fixed-physical-budgets-v3': raise RuntimeError('unexpected frozen contract')
 srcpins={p:{'sha256':sha(ROOT/p),'git_blob':run_command(['git','hash-object',str(ROOT/p)],cwd=ROOT)} for p in SOURCE_PATHS}
 build_time=exe.stat().st_mtime
 if any((ROOT/p).stat().st_mtime>build_time for p in SOURCE_PATHS): raise RuntimeError('a pinned source changed after executable build')
 if lib.stat().st_mtime>build_time: raise RuntimeError('library newer than executable')
 mpiver=run_command(['/opt/homebrew/bin/mpirun','--version'])
 compiler=run_command(['/opt/homebrew/bin/gfortran','--version']) if Path('/opt/homebrew/bin/gfortran').exists() else 'gfortran version unavailable at that path'
 plan={
  'schema':'green-native-qualification-v3-runs-v1','contract_id':v3['contract_id'],
  'contract_path':str(V3),'contract_sha256':sha(V3),'contract_frozen_at_local':v3['frozen_at_local'],
  'worktree':str(ROOT),'git_revision':run_command(['git','rev-parse','HEAD'],cwd=ROOT),
  'source_pin_scope':'seven authoritative files; exact working-tree SHA256 plus Git blob ids', 'source_pins':srcpins,
  'executable':{'path':str(exe),'sha256':sha(exe),'mtime_local':time.strftime('%Y-%m-%dT%H:%M:%S%z',time.localtime(exe.stat().st_mtime))},
  'solver_library':{'path':str(lib),'sha256':sha(lib),'mtime_local':time.strftime('%Y-%m-%dT%H:%M:%S%z',time.localtime(lib.stat().st_mtime))},
  'input':{'path':str(BASE/'wrfinput_d01'),'sha256':sha(BASE/'wrfinput_d01')},
  'source_namelist_sha256':sha(BASE/'namelist.input'),
  'stack':{'mpirun_version':mpiver,'compiler_version':compiler,'mpi_ranks':1,'omp_threads':1},
  'run_policy':{'debug_level':200,'sdirk3_debug_level':1,'all_WRF_environment_variables_removed':True,'diagnostic_capture_flags_unset':True,'comparison_scope':'whole WRF path; not integrator-only proof'},
  'status':'prepared','runs':[]}
 planpath=OUT/'runs.json'; planpath.write_text(json.dumps(plan,indent=2)+'\n')
 for label,h,integer,n,d,method,scheme in CASES:
  folder=OUT/label; folder.mkdir()
  shutil.copy2(BASE/'wrfinput_d01',folder/'wrfinput_d01')
  shutil.copy2(BASE/'diagnostics.txt',folder/'diagnostics.txt')
  for table in ('LANDUSE.TBL','VEGPARM.TBL','SOILPARM.TBL','GENPARM.TBL'):
   target=ROOT/'run'/table
   if target.exists(): (folder/table).symlink_to(target)
  # V3 requests explicit exact fractions; preserve archived 3.75 representation for stock control.
  text=(BASE/'namelist.input').read_text()
  for key,value in [('time_step',integer),('time_step_fract_num',n),('time_step_fract_den',d),('rk_ord',3),('time_integration_scheme',scheme)]: text=replace(text,key,value)
  if not math_isclose(float(Fraction(integer,1)+Fraction(n,d)),float(h)): raise RuntimeError('fractional timestep mismatch')
  (folder/'namelist.input').write_text(text)
  nml_sha=sha(folder/'namelist.input')
  # Verify requested debug settings and route/timestep after write.
  if not re.search(r'(?im)^\s*sdirk3_debug_level\s*=\s*1\s*,?',text): raise RuntimeError('expected sdirk3_debug_level=1')
  if not re.search(r'(?im)^\s*debug_level\s*=\s*200\s*,?',text): raise RuntimeError('base WRF debug_level changed unexpectedly')
  env={k:v for k,v in os.environ.items() if not k.startswith('WRF_')}
  env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
  # Check no diagnostic capture controls survived env filtering.
  if any(k.startswith('WRF_') for k in env): raise RuntimeError('WRF diagnostic environment leaked')
  cmd=['/usr/bin/time','-l','-o',str(folder/'time.log'),'/opt/homebrew/bin/mpirun','-np','1','--bind-to','none',str(exe)]
  row={'label':label,'path':str(folder),'h_seconds':float(h),'exact_h_numerator':h.numerator,'exact_h_denominator':h.denominator,'method':method,'time_integration_scheme':scheme,'rk_ord':3,'run_seconds':240,'expected_main_steps':int(Fraction(240,1)/h),'input_sha256':sha(folder/'wrfinput_d01'),'namelist_sha256':nml_sha,'executable_sha256':sha(exe),'solver_library_sha256':sha(lib),'command':cmd,'omp_threads':1,'mpi_ranks':1,'debug_level':200,'sdirk3_debug_level':1,'WRF_environment_variables_removed':True,'diagnostic_capture_flags_unset':True,'status':'running'}
  plan['runs'].append(row); plan['status']='running'; planpath.write_text(json.dumps(plan,indent=2)+'\n')
  start=time.monotonic()
  with (folder/'run.log').open('wb') as log: result=subprocess.run(cmd,cwd=folder,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
  row['wall_seconds']=time.monotonic()-start; row['return_code']=result.returncode
  timetxt=(folder/'time.log').read_text(errors='replace'); m=re.search(r'(\d+)\s+maximum resident(?: set)? size',timetxt)
  row['peak_rss_bytes']=int(m.group(1)) if m else None
  row['outputs']={n:sha(folder/n) for n in ('rsl.out.0000','rsl.error.0000','namelist.output') if (folder/n).is_file()}
  err=(folder/'rsl.error.0000').read_text(errors='replace') if (folder/'rsl.error.0000').is_file() else ''
  out=(folder/'rsl.out.0000').read_text(errors='replace') if (folder/'rsl.out.0000').is_file() else ''
  row['success_complete']='SUCCESS COMPLETE' in err
  row['actual_cpp_sdirk_route']=('SDIRK3 Zero-Copy: Calling actual solver' in err or 'SDIRK3 implicit time integration' in err or 'SDIRK3 Zero-Copy: Calling actual solver' in out)
  row['main_timing_count']=len(re.findall(r'Timing for main:.*?:\s*([0-9.]+) elapsed seconds',out))
  row['namelist_time_step_fields']={'time_step':integer,'time_step_fract_num':n,'time_step_fract_den':d,'derived_seconds':str(h)}
  route_ok=row['actual_cpp_sdirk_route']==(method=='ARK3')
  if row['main_timing_count'] != row['expected_main_steps']:
   raise RuntimeError(f"unexpected main-step count for {label}: {row['main_timing_count']} != {row['expected_main_steps']}")
  row['status']='completed' if result.returncode==0 and row['success_complete'] and route_ok else 'failed'
  planpath.write_text(json.dumps(plan,indent=2)+'\n')
  print(label,row['status'],'wall',row['wall_seconds'],'steps_logged',row['main_timing_count'],flush=True)
  if row['status']!='completed': raise RuntimeError(f'run failed or unexpected route: {label}')
 plan['status']='completed'; plan['completed_at_local']=time.strftime('%Y-%m-%dT%H:%M:%S%z'); planpath.write_text(json.dumps(plan,indent=2)+'\n')

def math_isclose(a,b): return abs(a-b)<1e-12
if __name__=='__main__': main()
