#!/usr/bin/env python3
"""Evaluate the frozen V3 candidate and one-step reference qualification."""
import json, hashlib
from pathlib import Path
import numpy as np
from netCDF4 import Dataset

E=Path('/Users/yhlee/AD-SDIRK3-review-evidence/seam-cause-acceptance-20261012')
G=E/'green_acceptance/native_qualification_v3'
RUNS=G/'runs/runs.json'
ARCH=Path('/Users/yhlee/AD-SDIRK3-review-evidence/WRF-accuracy-cost-20261011/after_fix')
ANA=Path('/Users/yhlee/AD-SDIRK3-review-evidence/WRF-accuracy-cost-20261011/analysis_after.json')
V3=E/'acceptance_candidate_v3.json'
FIELDS=('U','V','W','PH','T','MU')
RAW=('U','V','W','PH','PHB','T','MU','MUB')
TIMES=[f'0001-01-01_00:{m//60:02d}:{m%60:02d}' for m in (0,60,120,180,240)]
CHECK=TIMES[1:]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def time_text(row):return b''.join(np.asarray(row).tolist()).decode('ascii').rstrip('\0 ')
def read_frames(run_dir):
 out={}
 for p in sorted(Path(run_dir).glob('wrfout_d01*')):
  with Dataset(p) as d:
   for i,tt in enumerate(d.variables['Times'][:]):
    t=time_text(tt)
    if t in out:raise ValueError(f'duplicate time {t} in {run_dir}')
    out[t]={k:np.asarray(d.variables[k][i]) for k in RAW}
 return out
def owned(f):return {'U':f['U'][:,:,:-1],'V':f['V'],'W':f['W'][1:,:,:],'PH':f['PH'][1:,:,:],'T':f['T'],'MU':f['MU']}
def rms(x):return float(np.sqrt(np.mean(np.asarray(x,dtype=np.float64)**2)))
def maxabs(x):return float(np.max(np.abs(x)))
def main():
 contract=json.loads(V3.read_text()); plan=json.loads(RUNS.read_text()); old=json.loads(ANA.read_text())
 rows={r['label']:r for r in plan['runs']}
 integrity={rel:sha(Path(plan['worktree'])/rel)==pin['sha256'] for rel,pin in plan['source_pins'].items()}
 integrity.update({'executable':sha(plan['executable']['path'])==plan['executable']['sha256'],
                   'solver_library':sha(plan['solver_library']['path'])==plan['solver_library']['sha256'],
                   'frozen_contract':sha(V3)==plan['contract_sha256'],
                   'base_input':sha(plan['input']['path'])==plan['input']['sha256']})
 archived=next(r for r in old['runs'] if r['label']=='fortran_rk3_h1p875')
 h1={
  'label':'archived_rk3_h1p875','path':archived['path'],'h_seconds':archived['h_seconds'],'method':archived['method'],
  'wall_seconds':archived['wall_seconds'],'wall_receipt_source':'existing archived analysis_after.json end-to-end receipt',
  'peak_rss_bytes':archived['peak_rss_bytes'],'input_sha256':archived['input_sha256']['sha256'],'input_sha256_path':archived['input_sha256']['path'],
  'namelist_sha256':archived['namelist_sha256']['sha256'],'namelist_sha256_path':archived['namelist_sha256']['path'],
  'executable_sha256':archived['executable_sha256']['sha256'],'executable_path':archived['executable_sha256']['path'],
  'rsl_out':str(Path(archived['path'])/'rsl.out.0000'),'rsl_error':str(Path(archived['path'])/'rsl.error.0000')}
 analysis_plan={'schema':'green-v3-analysis-only-reused-archive-v1','purpose':'Use three authorized fresh runs plus one existing archived h1.875 reference; no additional native run.','contract_id':contract['contract_id'],'fresh_run_plan':str(RUNS),'runs':[h1]+list(plan['runs'])}
 ap=G/'analysis_runs.json';ap.write_text(json.dumps(analysis_plan,indent=2)+'\n')
 fresh={label:read_frames(row['path']) for label,row in rows.items()}
 ref=read_frames(archived['path'])
 # Exact initial-state equality across all complete state arrays.
 init=[]
 for label,frames in fresh.items():
  init.append({'label':label,'all_raw_8_fields_exact_at_t0':all(np.array_equal(frames[TIMES[0]][k],ref[TIMES[0]][k]) for k in RAW)})
 # Verify stock h=3.75 reproduces the prior archived outputs byte-for-byte by variable values.
 old375=next(r for r in old['runs'] if r['label']=='fortran_rk3_h3p75')
 stock_frames=read_frames(rows['rk3_h3p75_stock_control']['path']); archive375=read_frames(old375['path'])
 control=[]
 for t in TIMES:
  per={k:bool(np.array_equal(stock_frames[t][k],archive375[t][k])) for k in RAW}
  control.append({'time':t,'exact_raw_field_equality':per,'all_8_exact':all(per.values())})
 # Exact boundary and alias invariants on both qualification candidates and reference.
 boundary=[]
 for label,frames in {**fresh,'archived_rk3_h1p875':ref}.items():
  for t in TIMES:
   f=frames[t]
   boundary.append({'label':label,'time':t,'u_periodic_seam_max_abs':maxabs(f['U'][:,:,0]-f['U'][:,:,-1]),'v_south_wall_max_abs':maxabs(f['V'][:,0,:]),'v_north_wall_max_abs':maxabs(f['V'][:,-1,:]),'w_bottom_max_abs':maxabs(f['W'][0,:,:])})
 # Physical admissibility over all records used in the comparison.
 physical=[]
 for label,frames in {**fresh,'archived_rk3_h1p875':ref}.items():
  mt=1e300; mm=1e300; md=1e300; finite=True
  for t,f in frames.items():
   theta=f['T']+300.0; totalmu=f['MU']+f['MUB']; depth=np.diff(f['PH']+f['PHB'],axis=0)/9.81
   finite=bool(finite and all(np.isfinite(a).all() for a in f.values()) and np.isfinite(theta).all() and np.isfinite(totalmu).all() and np.isfinite(depth).all())
   mt=min(mt,float(theta.min()));mm=min(mm,float(totalmu.min()));md=min(md,float(depth.min()))
  physical.append({'label':label,'all_finite':bool(finite),'min_total_theta_K':mt,'min_total_mu_Pa':mm,'min_layer_depth_m':md,'positive_theta_mu_depth':bool(finite and mt>0 and mm>0 and md>0)})
 # Build fixed-epsilon table at all times: each endpoint epsilon_240 is held constant.
 eps={k:contract['budgets'][k]['epsilon'] for k in FIELDS}
 qualification=[]; candidate=[]; h15=[]
 for t in CHECK:
  fine=owned(fresh['rk3_h0p9375_reference_qualification'][t]); primary=owned(ref[t])
  for k in FIELDS:
   err=rms(fine[k]-primary[k]); threshold=eps[k]/3
   qualification.append({'time':t,'field':k,'units':contract['budgets'][k]['units'],'rms_h09375_minus_h1875':err,'fixed_epsilon_over_3':threshold,'ratio':err/threshold,'pass':err<=threshold})
   ar=owned(fresh['ark3_h15_final'][t]); cr=rms(ar[k]-primary[k])
   candidate.append({'time':t,'field':k,'units':contract['budgets'][k]['units'],'rms_ark_h15_minus_h1875':cr,'fixed_epsilon_240':eps[k],'ratio':cr/eps[k],'pass':cr<=eps[k]})
   c375=owned(fresh['rk3_h3p75_stock_control'][t]); hrms=rms(c375[k]-primary[k])
   h15.append({'time':t,'field':k,'rms_h375_minus_h1875':hrms})
 report={
  'schema':'green-v3-native-qualification-evaluation-v1','contract_id':contract['contract_id'],'contract_sha256':sha(V3),'frozen_at_local':contract['frozen_at_local'],
  'evaluated_at_local':__import__('datetime').datetime.now().astimezone().isoformat(timespec='seconds'),
  'native_runs_plan':str(RUNS),'analysis_only_plan':str(ap),'fresh_run_labels':list(rows),'archived_reference_label':'fortran_rk3_h1p875',
  'scope':'Three authorized fresh runs only: final ARK h15, stock RK3 h3.75 archive control, one RK3 h0.9375 reference qualifier. Comparisons are whole-WRF-path; no integrator-only claim.',
  'exact_input_sha256':plan['input']['sha256'],'source_pins':plan['source_pins'],'executable':plan['executable'],'solver_library':plan['solver_library'],
  'post_run_source_binary_contract_hash_reverification':integrity,'all_post_run_hashes_match':all(integrity.values()),
  'all_fresh_runs_completed':plan['status']=='completed' and all(r['status']=='completed' for r in plan['runs']),
  'native_run_count':len(plan['runs']),'only_authorized_three_fresh_runs':len(plan['runs'])==3,
  'fresh_run_source_route_checks':[{k:r[k] for k in ('label','h_seconds','namelist_time_step_fields','time_integration_scheme','actual_cpp_sdirk_route','expected_main_steps','main_timing_count','return_code','success_complete','wall_seconds','peak_rss_bytes')} for r in plan['runs']],
  'existing_xy_helper_build_receipt':str(E/'green_probe/periodic_regression_final_xy_receipt.json'),
  'existing_xy_helper_receipt_sha256':sha(E/'green_probe/periodic_regression_final_xy_receipt.json'),
  'library_matches_final_xy_helper_receipt':json.loads((E/'green_probe/periodic_regression_final_xy_receipt.json').read_text())['library']['sha256']==plan['solver_library']['sha256'],
  'implementation_source_matches_final_xy_helper_receipt':json.loads((E/'green_probe/periodic_regression_final_xy_receipt.json').read_text())['library']['implementation_source_sha256']==plan['source_pins']['external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp']['sha256'],
  'exact_initial_state_checks_raw_8_fields':init,'h375_archived_control_exactness':control,
  'h375_control_namelist_sha256_matches_archive':rows['rk3_h3p75_stock_control']['namelist_sha256']==next(r for r in old['runs'] if r['label']=='fortran_rk3_h3p75')['namelist_sha256']['sha256'],
  'physical_admissibility':physical,'boundary_and_alias_checks_raw_values':boundary,
  'fixed_numeric_endpoint_epsilon_applied_to_all_times':eps,'reference_qualification_rows':qualification,'reference_qualification_pass':all(r['pass'] for r in qualification),
  'ark15_candidate_rows':candidate,'ark15_accuracy_pass_if_reference_qualified':all(r['pass'] for r in candidate),
  'reference_qualification_disposition':'unqualified_after_the_one_authorized_h0p9375_refinement; no further refinement was performed or authorized' if not all(r['pass'] for r in qualification) else 'qualified_under_observed_resolution_sensitivity_rule_only',
  'ark15_candidate_disposition':'provisional_comparison_only_reference_unqualified; do not call candidate accepted or rejected, and do not claim project completion. Conditionally versus h1.875, all six 240s RMS values exceed the frozen epsilon.',
  'rk3_h375_to_h1875_context':h15,
  'interpretation':{'h09375_gate':'A pass is only observed refinement sensitivity under the frozen candidate criterion; not a bound to truth, global accuracy, or measured order. A failure withholds candidate acceptance.','ark15':'Do not classify candidate error as pass/fail unless h1.875 qualifies. If reference qualifies, apply exact six independent fixed budgets at all four checkpoints.','cost':'Recorded wall/RSS are whole-path optional context; no cost gate.'}}
 out=G/'evaluation_v3.json';out.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'out':str(out),'reference_qualification_pass':report['reference_qualification_pass'],'candidate_error_fields_passing':sum(x['pass'] for x in candidate),'candidate_error_fields_total':len(candidate),'stock_h375_exact_all_fields_all_times':all(x['all_8_exact'] for x in control),'initial_exact_all':all(x['all_raw_8_fields_exact_at_t0'] for x in init),'physical_all_positive':all(x['positive_theta_mu_depth'] for x in physical),'max_boundary':max(max(x['u_periodic_seam_max_abs'],x['v_south_wall_max_abs'],x['v_north_wall_max_abs'],x['w_bottom_max_abs']) for x in boundary)},indent=2))
if __name__=='__main__': main()
