# Green source symbol probe

Local timestamp: 2026-10-28 22:12:42 Asia/Tokyo  
Authoritative source: `/private/tmp/standard-forward-comparison-20261024`  
Git revision: `8dc34517336c901a5ec70bc990c5d0d87995e842`

Relevant source SHA-256 pins:

- `external/libtorch_wrf/sdirk3/wrf_sdirk3_phi_horizontal.h`: `b8a658b161bf792eb1b6e64026050b093b6ff9caf7ea6aa4f58a7258421bd433`
- `external/libtorch_wrf/sdirk3/wrf_sdirk3_acoustic_substep.cpp`: `2e6f687a7b4a5671384b49b3d76b21a22ce031f0bd8ddf8ae860b2070bcceffb`
- `external/libtorch_wrf/sdirk3/wrf_sdirk3_acoustic_substep.h`: `d4af5c7ec882f5b270351cf41e7b89efda6c17d65986d063c466817df1ac7410`
- `dyn_em/module_big_step_utilities_em.F`: `aabb885c142ae3f7b183dc7cd4983f98dda5362caf7ee95928e97e57594c49f1`
- `Registry/Registry.EM_COMMON`: `289879a55bc46bb6b281751ab35878135856b9df362c0b47e62dfc4817aee77b`
- `test/em_b_wave/namelist.input`: `37cc6e7ac183c3846f5d8759e2187efdae76e03e068ef9ec5b19350857333a39`

## Finding

The source supports a conditional near-Nyquist response contrast between the fast acoustic pressure/divergence block and PH advection. It does **not** establish that this contrast caused the plotted W/V/T pattern or indicates instability.

- **Scope is conditional on the actual run.** `canonical_horizontal` is enabled only when effective WRF mass-flux mode is on and the boundary contract is periodic X plus symmetric Y (`wrf_sdirk3_tile_unified_impl.cpp:15339-43`). Effective WRF mass-flux mode follows `mass_coordinate_mode` (`wrf_sdirk3_config.h:652-664,724-731`); mode 1 (`WRFParity`) resolves it on. The actual RSL must confirm this mode and the canonical branch for the analyzed run. The generic test namelist and Registry defaults alone do not prove runtime selection.
- **Conditional PH parity:** On `canonical_horizontal`, the C++ PH Y operator calls `native_w_phi_horizontal`; `advection_order=5` maps to centered PH order 6 (`wrf_sdirk3_tile_unified_impl.cpp:19402-16,19444-53`). The stage setter passes `sdirk3_advection_order` from Fortran (`module_implicit_sdirk3.F:1943-44`); the registry default is 5 (`Registry/Registry.EM_COMMON:3754`), but runtime override still must be checked. The helper uses the centered stencil `(45*d1 - 9*d2 + d3)/60` and the sum of the north/south V-face factors (`wrf_sdirk3_phi_horizontal.h:27-36,88-98,110-119`), matching the authoritative `rhs_ph` order-6 branch when `h_sca_adv_order=5` (`module_big_step_utilities_em.F:1442,1781-1808`). The stagger contract is PH `[ny,nz_w,nx]` at mass Y rows and V `[ny+1,nz,nx]` on Y faces (`phi_horizontal.h:71-80`); Y scalar ghosts reflect evenly as `q(-j)=q(j-1)` (`:17-25`).
- For a uniform-interior perturbation, native PH advection has symbol
  \[
  -i\,C_v\,\frac{1}{dy}\left(1.5\sin\theta-0.3\sin 2\theta+\frac{1}{30}\sin 3\theta\right),
  \]
  where `C_v` is the locally constant velocity, mass, and map-factor multiplier from the adjacent V faces and `msfty`. It is odd and vanishes at `theta=pi`.
- The fast acoustic V pressure gradient uses adjacent mass-row differences at V faces. The WRF formula combines differences of `ph` on both bounding W levels with adjacent pressure terms (`module_big_step_utilities_em.F:2327-34`); C++ `horizontal_pgf_primary` applies the same `0.5*rdy` weighted sum (`wrf_sdirk3_acoustic_substep.h:267-277`, `.cpp:570-579`). For vertically constant pure-PH perturbations, its G2 symbol has magnitude `2*abs(sin(theta/2))/dy`, nonzero at Nyquist.
- The split acoustic mass-continuity operator takes the V-face flux difference `rdy*(vflux[j+1]-vflux[j])` (`wrf_sdirk3_acoustic_substep.cpp:641-646`). Under locally constant coefficients, composing this D2 with the PGF G2 yields magnitude `4*sin^2(theta/2)/dy^2`, maximal at Nyquist. The fast acoustic block therefore retains a strong short-wave response where centered order-6 PH advection has a zero. This is a difference between operators with different physical roles, not a source-parity defect.
- Do not conflate that acoustic divergence with the Newton RHS column-mass `mu` **legacy/diagnostic fallback**: that branch vertically integrates `rv`, averages the V-staggered column flux to mass rows, then differences the mass rows (`wrf_sdirk3_tile_unified_impl.cpp:18828-65,18917-23`). Under the root-confirmed mode-1 WRFParity branch it is skipped (details below). The plotted block’s actual pathway must be tied to the producing RHS mode before interpreting its spectrum.

## Source-only check to resolve the evidence gap

Using the actual RSL-resolved stage mode, assemble finite Y matrices for the active PGF, acoustic flux divergence, and PH order-6 advection. Only include the Newton `mu` average-then-difference operator for a run whose outer mass-tendency branch selects that legacy/diagnostic fallback; under confirmed mode 1, use the direct mass-face flux operator instead. Apply the implemented symmetric-Y reflections, actual V-face rows, metrics, and coefficient arrays; compare high-index reflection-compatible modes or matrix eigenvalues. A uniform-coefficient local symbol is a useful control only. This probe did not run tests or models, inspect plotted data, or add a filter.

## Mode-1 mass-tendency path trace

Run configuration premise: root confirmed the actual RSL has `mass_coordinate_mode=1` and effective `wrf_omega_ww_cp=true`. Under that resolved WRFParity configuration:

- `effective_wrf_omega_ww_cp()` and `effective_mu_horizontal_div_only()` both resolve true for mode 1 (`wrf_sdirk3_config.h:724-739`), so `use_wrf_mass_flux` is true when not exporting coupled slow. The stage RHS's outer mass-tendency branch is therefore selected (`wrf_sdirk3_tile_unified_impl.cpp:15339-43,18632-40`).
- Canonical input `v` is a V-face field `[ny+1,nz,nx]`; `diagnose_wrf_mass_flux` requires that shape, and its production caller passes `v[0:m+1]` (`wrf_sdirk3_ww_cp.h:181-195,226-235`; tile source `:15852-62`). It forms `cv=(c1h*muv+c2h)*v/msfvx` at those V faces, then `divy=rdy*(cv[j+1]-cv[j])`, weights by `msftx*dnw`, and vertically sums to `mass_tendency_over_map_y` (`ww_cp.h:285-303`). The mode-1 RHS adds `msfty * mass_tendency_over_map_y` directly unless `hevi_pure_implicit` is true (`tile source:18634-39`).
- Native WRF `advance_mu_t` also evaluates horizontal divergence as direct north-minus-south V-face flux, then vertically sums `dnw* dvdxi` and updates `MU` by `DMDT+MU_TEND` (`module_small_step_em.F:1283-1296`). The direct incidence row has `-rdy*cv_south + rdy*cv_north`; one interior face contributes with opposite signs to its adjacent mass rows. This path has no V-face-to-mass column-flux average.
- The previously flagged average-then-difference expression (`V_col_stagger` → `V_col`, `tile source:18828-65,18917-23`) is confined to the outer `else` and is not executed for the root-confirmed mode-1 `use_wrf_mass_flux && effective_mu_horizontal_div_only` configuration. The later `mu_tend -= hevi_mu_div` at `:19202` is inside that same legacy/diagnostic `else`, so it is bypassed too. Under HEVI pure-implicit evaluation the direct branch intentionally adds no horizontal mass divergence (`:17353-56,18634-40`); horizontal continuity is routed to the explicit pass.
- `mu_tend_fortran_parity` defaults true (`wrf_sdirk3_config.h:2249-52`), which skips the later C++ mean-subtraction/clamp. An actual runtime override of that separate option should still be checked if claiming exact tendency parity. Also, this source trace establishes the face-difference topology and sign; it does not independently prove identity of every `v` versus native `v/v_1` operand in the physical flux formula.
- Conclusion for this hypothesis: the extra averaging phase shift is **not active** in the confirmed mode-1 mass-tendency branch. Do not attribute the plotted noise or prescribe a stencil change on that basis. The branch-local row check is simply the direct face-incidence sign above; no numerical matrix or model calculation was performed.
