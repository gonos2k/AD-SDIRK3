# Saved-field W pressure/mass-force diagnostic

Prepared: 2026-10-28 22:37:39 JST  
Source worktree: `/private/tmp/standard-forward-comparison-20261024`, HEAD `8dc34517336c901a5ec70bc990c5d0d87995e842`.  
Status: preparation only. The script was not executed and no figures/results were generated. Wait for the benchmark owner to release the plotting/analysis hold.

## Question

Do the saved ARK h=600 s outputs carry a growing grid-scale Y component in the instantaneous W pressure-gradient versus column-mass balance, relative to RK3? This can locate which saved-field contribution carries the mode. It cannot establish when or why the mode originated.

## Authoritative equation and source mapping

For dry `em_b_wave`, `cqw=0`, so WRF `pg_buoy_w` has `cq1=1` and `cq2=0`. The authoritative Fortran equations are in `dyn_em/module_big_step_utilities_em.F:2493-2510`:

- Interior W faces, Fortran `k=2..kde-1`: `rw_tend += (g/MSFTY) * [RDN(k)*(P(k)-P(k-1)) - C1F(k)*MUpert]`.
- Top W face, Fortran `k=kde`: `rw_tend += (g/MSFTY) * [2*RDNW(kde-1)*(-P(kde-1)) - C1F(k)*MUpert]`.

The output variables store P, MU, MUB, RDN, RDNW, C1F, C2F, and `MAPFAC_MY` as FP32. `Registry.EM_COMMON:1410` names WRF's `msfty` state as NetCDF `MAPFAC_MY`; `module_implicit_sdirk3.F:1459` passes `grid%msfty` to C++, where it forms `alpha_w` (`wrf_sdirk3_tile_unified_impl.cpp:21241-21243`). The script promotes stored values to FP64 for arithmetic, preserving the saved values. The owned W faces are NetCDF C indices 1..64: omit the fixed bottom face 0; indices 1..63 map to the interior Fortran loop, and index 64 maps to the top formula. The domain has 64 mass levels, 65 W faces, 80 Y mass points, and 40 X mass points.

For canonical WRF mass-flux mode, the current C++ source builds `w_pgf_buoy = g/MSFTY * F`, multiplies the coupled term by `velocity_mass_w / alpha_w`, where `alpha_w = Mface/MSFTY`, and converts back by dividing by `velocity_mass_w` (`wrf_sdirk3_tile_unified_impl.cpp:21235-21243, 22218-22248, 26052-26068`). The product cancels to physical acceleration `g*F/Mface`; therefore the saved-field diagnostic uses:

```text
Mface[k,j,i] = C1F[k] * (MU[j,i] + MUB[j,i]) + C2F[k]
Pg[k,j,i]    = g * RDN[k] * (P[k,j,i] - P[k-1,j,i]) / Mface[k,j,i]
Bmu[k,j,i]   = g * C1F[k] * MU[j,i] / Mface[k,j,i]
Net[k,j,i]   = Pg[k,j,i] - Bmu[k,j,i]
```

At the top, `Pg = g * 2 * RDNW[-1] * (-P[-1]) / Mface[-1]`; `Bmu` uses the top C1F and Mface. The sign of RDN is retained exactly as stored. `Mface` and `MAPFAC_MY` must be finite and positive or the script fails closed. The script numerically checks the source conversion identity on the actual saved `MAPFAC_MY` values before applying the canceled physical formula. `MAP_PROJ=0` is independently checked; no spatial map factor is invented or omitted.

The production W tendency also includes other terms and stage-coupled conversion. In particular, the reported `Net` is only this saved pressure/mass-force pair. It is not the complete W tendency and it is not a native stage RHS.

## Inputs and pins

Frames and SHA-256 pins are read from `../green_maps/raw_frame_hashes.json`, whose own SHA-256 is `dc8ebd21562863795bc1b704304bbfc905e3bab64cd015e755880d4f062c9a0a`. The diagnostic uses ARK source key `ao` and RK3 key `r`, at 24, 30, and 36 h. Both runs must have byte-identical 0 h input frames. Every selected wrfout file hash, timestamp, flat projection, 100 km spacing, shape, finiteness, and positive Mface are checked before calculation.

Source pins at preparation time:

- `dyn_em/module_big_step_utilities_em.F`: `aabb885c142ae3f7b183dc7cd4983f98dda5362caf7ee95928e97e57594c49f1`
- `dyn_em/module_implicit_sdirk3.F`: `dc60f0c90513d2d11d878c5ac45710b930d103a4de0801e87129bc28be08c775`
- `Registry/Registry.EM_COMMON`: `289879a55bc46bb6b281751ab35878135856b9df362c0b47e62dfc4817aee77b`
- `external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp`: `9afe11f0967facefee9082a9f946e128d89395d02982b7be6cf6f86489ccb0b4`
- `external/libtorch_wrf/sdirk3/wrf_sdirk3_config.h`: `ad1d1113cfe65fcf353ea0cb5194ef491e022afebbffecd3ea98e5308664f7f8`

## Metrics

For each method/lead, report RMS(Pg), RMS(Bmu), RMS(Net), and cancellation ratio `RMS(Net)/(RMS(Pg)+RMS(Bmu))`, first over all owned W faces and then after retaining DCT-II Y modes `k>=40` and inverse transforming. This is a physical-space reconstructed high-Y component; do not report retained-coefficient RMS as if it were a physical-grid RMS. Also report the corresponding ARK−RK3 saved-force differences.

When explicitly requested after the plotting hold is released, the script can write:

- a separate x-mean actual-W figure for 24/30/36 h, with ARK, RK3, and ARK−RK3;
- separate ARK and RK3 x-mean high-Y saved-force figures for Pg, Bmu, and Net.

The figures do not overlay inferred force with actual W and do not assert causation. Output is under `red_force/results/`.

## Scope limits and interpretation

This is a saved-output diagnostic using FP32 fields promoted to FP64. It is not an exact native stage RHS capture, not a replay of the solver's internal FP64 state, not proof of the RHS values at the stage evaluation times, and not a causal oracle for the ARK W mode. A small saved-state pressure/mass residual does not rule out temporal amplification or other fast/slow terms; a large residual locates imbalance in this pair but does not by itself explain the mechanism.

## Run gate

The script was prepared only. Do not invoke it, do not request its PNGs, and do not run any additional diagnostics until the benchmark owner explicitly releases the hold after the EW timing comparison. Suggested eventual command:

```bash
python3 /Users/yhlee/AD-SDIRK3-review-evidence/noise-location-20261028/red_force/analyze_saved_w_pg_buoyancy.py --write-plots
```


## Execution update 2026-10-28T23:17:28.182563+09:00

The benchmark hold was released after all four native ARK cases ended. Root ran the saved-field diagnostic. First execution produced metrics but force plotting failed due to Y/Z array orientation; the original script is retained as `analyze_saved_w_pg_buoyancy_before_plot_fix.py`. The correction transposes only the plotted x-mean force array to z,y; the arithmetic is unchanged. The signed-RDNW comment and conversion-description typo were corrected. A rerun produced the metrics JSON and three PNGs. Root also wrote `results/shared_scale_force_36h.png` with one common scale across ARK/RK3 and all three force terms; use this comparative figure rather than the exploratory independently auto-scaled panels. These are saved-FP32 endpoint diagnostics, not native stage RHS/cause proof.

Current script SHA-256: `f6d4d98456be792fd92d5a09d2b43882996e8a6e9ff8022bf37a68b77cbf9a5f`.
