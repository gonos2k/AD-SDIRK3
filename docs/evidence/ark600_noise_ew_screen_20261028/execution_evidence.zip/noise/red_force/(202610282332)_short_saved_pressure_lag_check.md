# Short-run saved pressure same-time versus one-step-prior check

Local time: 2026-10-28 23:32:19 JST  
Source worktree: `/private/tmp/standard-forward-comparison-20261024`, HEAD `8dc34517336c901a5ec70bc990c5d0d87995e842`.  
Scope: offline arrays only; no model/build/source changes.

## Finding

The short saved-pressure comparison disfavors a full 600 s one-step diagnostic-pressure lag. Across A0, B0, and the RK3 control, same-time saved `P` stays close to the active C++ dry pressure EOS evaluated on the same saved `T`, `PH`, and `MU` state. Same-time residual RMS remains about 0.0054 Pa, close to the common 0 h calibration of 0.00538 Pa. Comparing `P_saved(t)` with EOS state from the previous 600 s frame instead produces 0.78–3.12 Pa RMS over the 10–60 min endpoints. High-Y k≥40 same-time residual RMS stays near 0.0025 Pa; prior-frame residual is 0.016–0.061 Pa.

This supports “not a previous-output-step P field” for these frames. It does not prove that saved P corresponds exactly to the final combined prognostic endpoint or to the W RHS evaluation that caused the observed W growth.

## Base state and active EOS

The exact C++ constants are `Rd=287`, `Cp=1004.5`, `Cv=717.5`, `P0=100000 Pa`, matching WRF `module_model_constants.F`. C++ receives WRF `grid%t_init` as its base-temperature input; the setter stores `t_init_pert_ = T_INIT` and `th_base_ = T_INIT + 300` (`wrf_sdirk3_tile_unified_impl.cpp:31133`). Recomputing base inverse density from `T_INIT+300` and `PB` matches input `ALB` to relative RMS `5.495e-8` and max `1.251e-7`. `QVAPOR` is present and identically zero in every sampled frame.

The comparison uses the active C++ `calc_p_rho_wrf` formula: recompute base `alb` from `T_INIT+300, PB`; calculate `al_pert` from perturbation `PH`, `MU`, `RDNW`, `C1H/C2H`, and `MUB+MU`; set `alt=alb+al_pert`; then `p_pert=P0*(Rd*(T+300)/(P0*alt))^(Cp/Cv)-PB`. The saved field `P` is perturbation pressure and is compared directly with `p_pert`. The saved signed `RDNW` values are negative; the C++ function uses `-abs(RDNW)` in the same term.

## Key measurements

| Run | Lead | Same-state residual RMS | Prior-state residual RMS | Same-state high-Y RMS | Prior-state high-Y RMS |
|---|---:|---:|---:|---:|---:|
| A0 | 10 min | 0.00552 Pa | 0.776 Pa | 0.00254 Pa | 0.0457 Pa |
| A0 | 60 min | 0.00543 Pa | 2.991 Pa | 0.00252 Pa | 0.0275 Pa |
| B0 | 10 min | 0.00552 Pa | 0.776 Pa | 0.00253 Pa | 0.0457 Pa |
| B0 | 60 min | 0.00543 Pa | 2.991 Pa | 0.00252 Pa | 0.0275 Pa |
| RK3 | 10 min | 0.00540 Pa | 0.931 Pa | 0.00249 Pa | 0.0416 Pa |
| RK3 | 60 min | 0.00545 Pa | 2.942 Pa | 0.00253 Pa | 0.0245 Pa |

At 0 min the same and prior frames are identical. The same-state residual RMS is 0.00538 Pa, max 0.0322 Pa, and high-Y RMS 0.00252 Pa. This is an empirical t0 residual floor, not a certified quantization-only bound. Relative to the initial residual field, same-state residual changes stay around 0.0047–0.0050 Pa RMS, while prior-state residual changes grow from about 0.78 Pa to 3.12 Pa.

The A0 and RK3 receipts report `failed_or_incomplete` overall status despite containing all seven expected ten-minute output frames; B0 reports `completed`. This is saved-frame evidence only, not a run-quality qualification.

## Pressure synchronization trace and limitation

- Fortran passes `grid%p` into the zero-copy solver (`module_implicit_sdirk3.F:1443-1447`).
- The active C++ pressure path computes `p_pert_` from the current RHS input state (`wrf_sdirk3_tile_unified_impl.cpp:20332-20344`, `wrf_hydrostatic_pressure.h:83-112`).
- The zero-copy wrapper copies the most recent `p_pert_` back through the `p` view (`wrf_sdirk3_tile_unified_impl.cpp:36198-36238`). Source therefore refreshes P during the current timestep; it is not simply left at its previous-step value.
- The accepted prognostic vector is unpacked as U/V/W/PH/T/MU (`tile_unified_impl.cpp:13073-13077`). Mode 3 constructs the final weighted state after stage evaluations (`wrf_sdirk3_ark324_composition.h:34-43`). The common weights match the implicit last row but differ from the explicit last row, so saved P can represent the last stage pressure diagnostic rather than a recomputation on the exact final weighted endpoint.

Therefore the same-time/prior-time comparison rules against a gross 600 s lag, but not against a within-step stage-to-endpoint diagnostic difference. It is not a native stage RHS capture or causal oracle for the W mode.

## Reproduction and pins

Script: `analyze_short_pressure_lag.py`, SHA-256 `fbdd239b88bc1228ef7c4e9bc4b784ca9e676737ab210ac8866bfc6c2945eb7d`.  
Metrics: `results/short_same_vs_prior_pressure_eos.json`, SHA-256 `b467b6b6693ad90f45516c39ca3d39ced9d798a80afc2c827e25b3aea1df9824`.  
The script checks the saved A0/B0/RK3 frame files, common input SHA, dry QVAPOR, grid geometry, base-ALB EOS consistency, and pinned sources before calculation.
