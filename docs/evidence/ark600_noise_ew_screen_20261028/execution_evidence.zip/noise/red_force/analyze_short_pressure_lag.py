#!/usr/bin/env python3
"""Compare short-run saved P to same-time and one-step-prior dry EOS states.

Offline wrfout diagnostic only. The comparison tests gross inter-step P lag;
it does not prove exact native-stage or accepted-endpoint pressure identity.
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import numpy as np
from netCDF4 import Dataset
from scipy.fft import dct, idct


HERE = Path(__file__).resolve().parent
EVIDENCE = Path("/Users/yhlee/AD-SDIRK3-review-evidence/ew-forcing-abba-20261028")
SOURCE_ROOT = Path("/private/tmp/standard-forward-comparison-20261024")
SOURCE_REVISION = "8dc34517336c901a5ec70bc990c5d0d87995e842"
RD, CP, CV, P0, G, T0 = 287.0, 1004.5, 717.5, 100_000.0, 9.81, 300.0
NX, NY, NZ = 40, 80, 64
DY_M = DX_M = 100_000.0
HOURS = tuple(range(0, 61, 10))
SECONDS = tuple(600 * i for i in range(7))
ORIGIN = datetime(1, 1, 1, 0, 0, 0)
RUNS = {
    "A0": EVIDENCE / "runs/A0",
    "B0": EVIDENCE / "runs/B0",
    "RK3": EVIDENCE / "rk3_reference/runs/rk3_short",
}
SOURCE_PINS = {
    "dyn_em/module_small_step_em.F":
        "037f706dd3b32f61cc2489f46a58cfd63e78795483662d18f66452f9f229d50c",
    "share/module_model_constants.F":
        "5b80377fecdc18a5f0ad38d3b6c15cfc86ad5d76701adbbbb08a08698d0f7062",
    "Registry/Registry.EM_COMMON":
        "289879a55bc46bb6b281751ab35878135856b9df362c0b47e62dfc4817aee77b",
    "dyn_em/module_implicit_sdirk3.F":
        "dc60f0c90513d2d11d878c5ac45710b930d103a4de0801e87129bc28be08c775",
    "dyn_em/solve_em.F":
        "95e7ccf6a8b09bb491a70f07c0ad56605c1a175f0e62c9ad194c1b33abcab4e6",
    "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp":
        "9afe11f0967facefee9082a9f946e128d89395d02982b7be6cf6f86489ccb0b4",
    "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified.h":
        "a3e0df6ffb493142e328b6312ec991bfdee854c6aaf33ab45d1dc2358891884e",
    "external/libtorch_wrf/sdirk3/wrf_hydrostatic_pressure.h":
        "f926092be30df9a21b2e9967f7f4bf7d18b1fe2790cc8d2145d316aa9f73591b",
    "external/libtorch_wrf/sdirk3/wrf_sdirk3_imex_ark324_coeffs.h":
        "fb85dd9343c325f66504b31d85f7c9e6c9a44dd27d263c43a6cc2c65bce0ba35",
    "external/libtorch_wrf/sdirk3/wrf_sdirk3_ark324_composition.h":
        "8ebf4d680c79a0103522b68c278f5145e2c2dd1c5007fd17e684014411a2a907",
    "dyn_em/solve_em.F":
        "95e7ccf6a8b09bb491a70f07c0ad56605c1a175f0e62c9ad194c1b33abcab4e6",
}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def rms(a: np.ndarray) -> float:
    a64 = np.asarray(a, dtype=np.float64)
    return float(np.sqrt(np.mean(np.square(a64), dtype=np.float64)))


def high_y(a: np.ndarray) -> np.ndarray:
    coeff = dct(a, type=2, axis=1, norm="ortho")
    coeff[:, :40, :] = 0.0
    return idct(coeff, type=2, axis=1, norm="ortho")


def metrics(a: np.ndarray, reference_pressure: np.ndarray) -> dict[str, float]:
    return {
        "error_rms_pa": rms(a),
        "error_max_abs_pa": float(np.max(np.abs(a))),
        "reference_pressure_rms_pa": rms(reference_pressure),
        "relative_error_rms": rms(a) / max(rms(reference_pressure), np.finfo(np.float64).tiny),
    }


def expected_time(seconds: int) -> str:
    return (ORIGIN + timedelta(seconds=seconds)).strftime("%Y-%m-%d_%H:%M:%S")


def get_frame_paths(run_dir: Path) -> dict[int, Path]:
    found: dict[int, Path] = {}
    for path in run_dir.glob("wrfout_d01_*"):
        with Dataset(path, "r") as ds:
            text = b"".join(ds["Times"][0]).decode("ascii").rstrip("\x00 ")
        stamp = datetime.strptime(text, "%Y-%m-%d_%H:%M:%S")
        second = int((stamp - ORIGIN).total_seconds())
        found[second] = path
    missing = [s for s in SECONDS if s not in found]
    if missing:
        raise ValueError(f"{run_dir}: missing saved timestamps {missing}")
    return {s: found[s] for s in SECONDS}


def read_frame(path: Path, expected_seconds: int) -> dict[str, Any]:
    with Dataset(path, "r") as ds:
        if b"".join(ds["Times"][0]).decode("ascii").rstrip("\x00 ") != expected_time(expected_seconds):
            raise ValueError(f"{path}: time does not match expected endpoint")
        dims = {name: len(dim) for name, dim in ds.dimensions.items()}
        for name, expected in {"west_east": NX, "south_north": NY,
                               "bottom_top": NZ, "bottom_top_stag": NZ + 1}.items():
            if dims.get(name) != expected:
                raise ValueError(f"{path}: {name}={dims.get(name)}, expected {expected}")
        if int(ds.getncattr("MAP_PROJ")) != 0 or not np.isclose(float(ds.getncattr("DX")), DX_M) \
                or not np.isclose(float(ds.getncattr("DY")), DY_M):
            raise ValueError(f"{path}: unexpected grid geometry")
        names = ("T", "P", "PB", "PH", "PHB", "MU", "MUB", "RDNW", "C1H", "C2H")
        miss = [n for n in names if n not in ds.variables]
        if miss:
            raise ValueError(f"{path}: missing variables {miss}")
        f = {n: np.asarray(ds[n][0], dtype=np.float64) for n in names}
        qv = np.asarray(ds["QVAPOR"][0], dtype=np.float64) if "QVAPOR" in ds.variables else None
    shapes = {"T": (NZ, NY, NX), "P": (NZ, NY, NX), "PB": (NZ, NY, NX),
              "PH": (NZ + 1, NY, NX), "PHB": (NZ + 1, NY, NX),
              "MU": (NY, NX), "MUB": (NY, NX), "RDNW": (NZ,),
              "C1H": (NZ,), "C2H": (NZ,)}
    for n, shape in shapes.items():
        if f[n].shape != shape or not np.isfinite(f[n]).all():
            raise ValueError(f"{path}: invalid {n} shape or nonfinite values")
    if qv is not None and (not np.isfinite(qv).all() or np.any(qv != 0.0)):
        raise ValueError(f"{path}: QVAPOR not identically zero")
    f["qv_max_abs"] = float(np.max(np.abs(qv))) if qv is not None else None
    f["path"] = str(path)
    f["sha256"] = sha256_file(path)
    f["time"] = expected_time(expected_seconds)
    return f


def read_base(path: Path) -> dict[str, Any]:
    with Dataset(path, "r") as ds:
        needed = ("T_INIT", "ALB", "PB", "MUB")
        missing = [name for name in needed if name not in ds.variables]
        if missing:
            raise ValueError(f"{path}: missing base-state variables {missing}")
        base = {name: np.asarray(ds[name][0], dtype=np.float64) for name in needed}
    expected = {"T_INIT": (NZ, NY, NX), "ALB": (NZ, NY, NX),
                "PB": (NZ, NY, NX), "MUB": (NY, NX)}
    for name, shape in expected.items():
        if base[name].shape != shape or not np.isfinite(base[name]).all():
            raise ValueError(f"{path}: invalid base {name} shape or nonfinite values")
    return base


def base_alb_check(base: dict[str, np.ndarray]) -> dict[str, float]:
    """Check WRF ALB against the same EOS used to initialize C++ th_base_."""
    theta_base = base["T_INIT"] + T0
    alb_cpp = (RD / P0) * theta_base * np.power(base["PB"] / P0, -CV / CP)
    err = alb_cpp - base["ALB"]
    rel = err / base["ALB"]
    return {"alb_from_t_init_pb_rms_m3_kg": rms(alb_cpp),
            "alb_input_rms_m3_kg": rms(base["ALB"]),
            "alb_error_rms_m3_kg": rms(err),
            "alb_error_max_abs_m3_kg": float(np.max(np.abs(err))),
            "alb_relative_error_rms": rms(rel),
            "alb_relative_error_max_abs": float(np.max(np.abs(rel)))}


def pressure_eos_wrf(f: dict[str, Any], base: dict[str, np.ndarray]) -> np.ndarray:
    """Replay the active C++ calc_p_rho_wrf formula from saved endpoint fields.

    This is the pressure calculation used by C++ from its current RHS state, not
    a reconstruction from total PH. Base alpha is recomputed from T_INIT+T0 and
    PB exactly as the C++ base-state setter does, then compared with input ALB.
    """
    theta_base = base["T_INIT"] + T0
    alb = (RD / P0) * theta_base * np.power(base["PB"] / P0, -CV / CP)
    theta = f["T"] + T0
    mu = f["MU"]
    mub = base["MUB"]
    muts = mub + mu
    c1 = f["C1H"][:, None, None]
    c2 = f["C2H"][:, None, None]
    rdnw_abs = np.abs(f["RDNW"])
    dph_pert = f["PH"][1:, :, :] - f["PH"][:-1, :, :]
    denom = c1 * muts[None, :, :] + c2
    if not np.isfinite(denom).all() or np.any(denom <= 0.0):
        raise ValueError("C1H*muts+C2H must be finite and positive")
    # calc_p_rho_wrf: rdnw_wrf = -abs(rdnw); no base PH is added here.
    al_pert = -(alb * c1 * mu[None, :, :] - rdnw_abs[:, None, None] * dph_pert) / denom
    alt = alb + al_pert
    if not np.isfinite(alt).all() or np.any(alt <= 0.0):
        raise ValueError("active EOS alt=alb+al_pert must be finite and positive")
    p_full_eos = P0 * np.power(RD * theta / (P0 * alt), CP / CV)
    p_pert_eos = p_full_eos - base["PB"]
    if not np.isfinite(p_pert_eos).all():
        raise ValueError("active EOS pressure produced NaN/Inf")
    return p_pert_eos
    total_mass = f["MU"] + f["MUB"]
    denominator = f["C1H"][:, None, None] * total_mass[None, :, :] + f["C2H"][:, None, None]
    if not np.isfinite(denominator).all() or np.any(denominator <= 0.0):
        raise ValueError("C1H*(MU+MUB)+C2H nonpositive/nonfinite")
    alpha = -f["RDNW"][:, None, None] * np.diff(phi, axis=0) / denominator
    if not np.isfinite(alpha).all() or np.any(alpha <= 0.0):
        raise ValueError("geometric alpha nonpositive/nonfinite")
    if not np.isfinite(theta).all() or np.any(theta <= 0.0):
        raise ValueError("theta=T+300 nonpositive/nonfinite")
    p_saved = f["P"] + f["PB"]
    if not np.isfinite(p_saved).all() or np.any(p_saved <= 0.0):
        raise ValueError("saved P+PB nonpositive/nonfinite")
    p_eos = P0 * np.power(RD * theta / (P0 * alpha), CP / CV)
    if not np.isfinite(p_eos).all() or np.any(p_eos <= 0.0):
        raise ValueError("EOS pressure nonpositive/nonfinite")
    return p_saved, p_eos


def main() -> None:
    receipt_info: dict[str, Any] = {}
    loaded: dict[str, dict[int, dict[str, Any]]] = {}
    for run, run_dir in RUNS.items():
        receipt = json.loads((run_dir / "forecast_receipt.json").read_text())
        base_path = run_dir / "wrfinput_d01"
        if not base_path.is_file():
            raise FileNotFoundError(base_path)
        receipt_input = str(receipt.get("input_sha256"))
        input_sha = sha256_file(base_path)
        # In this harness input_sha256 is the shared wrfinput content pin.
        if input_sha != receipt_input:
            raise ValueError(f"{run}: wrfinput SHA does not match forecast receipt")
        base = read_base(base_path)
        receipt_info[run] = {"status": receipt.get("status"),
                             "input_sha256": receipt.get("input_sha256"),
                             "wrfinput_path": str(base_path),
                             "t_init_plus_300_alb_check": base_alb_check(base),
                             "executable_sha256": receipt.get("executable_sha256"),
                             "timestamps": receipt.get("output_check", {}).get("timestamps")}
        loaded[run] = {sec: read_frame(path, sec)
                       for sec, path in get_frame_paths(run_dir).items()}
        # Retain the exact base fields used by C++ calc_p_rho_wrf for each run.
        receipt_info[run]["_base_fields"] = base
    input_hashes = {v["input_sha256"] for v in receipt_info.values()}
    if len(input_hashes) != 1:
        raise ValueError(f"runs do not share the same input hash: {input_hashes}")

    result: dict[str, Any] = {
        "scope": "saved_output_same_time_vs_prior_time_EOS_diagnostic",
        "interpretation_limit": "same-time vs previous-frame comparison detects gross 600s lag only; saved P is a stage diagnostic, not guaranteed exact final-combined-state P",
        "constants": {"Rd": RD, "Cp": CP, "Cv": CV, "P0_Pa": P0, "T0_K": T0,
                      "exponent": CP / CV, "g": G},
        "grid": {"nx": NX, "ny": NY, "nz": NZ, "dx_m": DX_M, "dy_m": DY_M,
                 "high_y": "DCT-II mass-y modes k>=40"},
        "runs": receipt_info,
        "frames": {},
    }
    for run, series in loaded.items():
        p_saved: dict[int, np.ndarray] = {}
        p_eos: dict[int, np.ndarray] = {}
        base = receipt_info[run].pop("_base_fields")
        for sec, f in series.items():
            p_saved[sec] = f["P"]
            p_eos[sec] = pressure_eos_wrf(f, base)
        baseline = p_saved[0] - p_eos[0]
        baseline_hi = high_y(baseline)
        run_result: dict[str, Any] = {
            "pressure_formula": "active C++ calc_p_rho_wrf: alb(T_INIT+300,PB), alpert=-(alb*C1H*MU - abs(RDNW)*dPHpert)/(C1H*(MUB+MU)+C2H), alt=alb+alpert, ppert=p0*(Rd*(T+300)/(p0*alt))^(cp/cv)-PB",
            "t0_calibration": {
                "same_state_residual_all_y": metrics(baseline, p_saved[0]),
                "same_state_residual_high_y_k40_plus": metrics(baseline_hi, high_y(p_saved[0])),
                "note": "empirical t0 residual floor includes stored-FP32 quantization and EOS/update discretization; not a certified round-to-nearest bound",
            },
            "steps": {},
        }
        for sec in SECONDS:
            row: dict[str, Any] = {"time_minutes": sec // 60,
                                   "path": series[sec]["path"],
                                   "sha256": series[sec]["sha256"],
                                   "qv_max_abs": series[sec]["qv_max_abs"]}
            same = p_saved[sec] - p_eos[sec]
            same_hi = high_y(same)
            row["same_time_error_all_y"] = metrics(same, p_saved[sec])
            row["same_time_error_high_y_k40_plus"] = metrics(same_hi, high_y(p_saved[sec]))
            row["same_vs_t0_residual_delta_rms_pa"] = rms(same - baseline)
            row["same_vs_t0_residual_delta_high_y_rms_pa"] = rms(high_y(same - baseline))
            if sec > 0:
                lag = p_saved[sec] - p_eos[sec - 600]
                lag_hi = high_y(lag)
                row["prior_600s_state_error_all_y"] = metrics(lag, p_saved[sec])
                row["prior_600s_state_error_high_y_k40_plus"] = metrics(lag_hi, high_y(p_saved[sec]))
                row["prior_vs_t0_residual_delta_rms_pa"] = rms(lag - baseline)
                row["prior_vs_t0_residual_delta_high_y_rms_pa"] = rms(high_y(lag - baseline))
                row["eos_state_increment_rms_pa"] = rms(p_eos[sec] - p_eos[sec - 600])
                row["eos_state_increment_high_y_rms_pa"] = rms(high_y(p_eos[sec] - p_eos[sec - 600]))
            run_result["steps"][str(sec // 60)] = row
        result["frames"][run] = run_result

    # Pointers/source pins keep this analysis tied to the active code/equation.
    result["source_revision"] = SOURCE_REVISION
    result["source_pins"] = {p: sha256_file(SOURCE_ROOT / p) for p in SOURCE_PINS}
    result["source_sync_trace"] = {
        "fortran_passes_grid_p_pointer": "module_implicit_sdirk3.F:1443-1447",
        "cpp_recomputes_pressure_from_rhs_state": "wrf_sdirk3_tile_unified_impl.cpp:20332-20344; calc_p_rho_wrf in wrf_hydrostatic_pressure.h",
        "cpp_base_state_alb": "wrf_sdirk3_tile_unified_impl.cpp:20333-20337; set_base_state_checked copies T_INIT and C++ sets th_base_=T_INIT+300 at tile_unified_impl.cpp:31133, then compute_inverse_density(th_base_,PB,rd,cv,cp,p1000mb)",
        "cpp_writes_last_rhs_p_back": "wrf_sdirk3_tile_unified_impl.cpp:36198-36238",
        "accepted_prognostic_state_unpack": "wrf_sdirk3_tile_unified_impl.cpp:13073-13077 (u,v,w,ph,t,mu only)",
        "mode3_final_state": "solve_em.F skips the traditional RK/acoustic loop after the ARK solve; ARK final_state is a weighted sum after stage evaluations. b equals the implicit last row but not the explicit last row, so the last p diagnostic is a current stage value and need not be from the exact final weighted endpoint",
    }
    out = HERE / "results" / "short_same_vs_prior_pressure_eos.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"status": "complete", "output": str(out)}, indent=2))


if __name__ == "__main__":
    main()
