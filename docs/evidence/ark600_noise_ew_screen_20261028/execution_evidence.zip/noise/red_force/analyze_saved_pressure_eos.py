#!/usr/bin/env python3
"""Check saved P+PB against dry ideal-gas pressure from saved T and PH thickness.

This is an offline saved-output thermodynamic consistency check. It is not a
native ARK-stage pressure capture and cannot establish when or why a field
became stale. NetCDF values are FP32 and are promoted to FP64 for arithmetic.
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import numpy as np
from netCDF4 import Dataset
from scipy.fft import dct, idct


HERE = Path(__file__).resolve().parent
GREEN = HERE.parent / "green_maps"
RECEIPT_PATH = GREEN / "raw_frame_hashes.json"
RECEIPT_SHA256 = "dc8ebd21562863795bc1b704304bbfc905e3bab64cd015e755880d4f062c9a0a"
SOURCE_ROOT = Path("/private/tmp/standard-forward-comparison-20261024")
SOURCE_REVISION = "8dc34517336c901a5ec70bc990c5d0d87995e842"
SOURCE_PINS = {
    "dyn_em/module_small_step_em.F":
        "037f706dd3b32f61cc2489f46a58cfd63e78795483662d18f66452f9f229d50c",
    "share/module_model_constants.F":
        "5b80377fecdc18a5f0ad38d3b6c15cfc86ad5d76701adbbbb08a08698d0f7062",
    "Registry/Registry.EM_COMMON":
        "289879a55bc46bb6b281751ab35878135856b9df362c0b47e62dfc4817aee77b",
}
NY, NX, NZ = 80, 40, 64
DX_M = DY_M = 100_000.0
G = 9.81
RD = 287.0
CP = 7.0 * RD / 2.0
P0 = 100_000.0
T0 = 300.0
HIGH_Y_FIRST_MODE = 40
HOURS = (0, 24, 36)
ORIGIN = datetime(1, 1, 1, 0, 0, 0)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def rms(a: np.ndarray) -> float:
    a64 = np.asarray(a, dtype=np.float64)
    return float(np.sqrt(np.mean(np.square(a64), dtype=np.float64)))


def high_y(a: np.ndarray) -> np.ndarray:
    """DCT-II even-reflection high-Y component for [k,j,i] arrays."""
    if a.ndim != 3 or a.shape[1] != NY:
        raise ValueError(f"expected [k,{NY},i] field, got {a.shape}")
    coeff = dct(a, type=2, axis=1, norm="ortho")
    coeff[:, :HIGH_Y_FIRST_MODE, :] = 0.0
    return idct(coeff, type=2, axis=1, norm="ortho")


def expected_time(hour: int) -> str:
    return (ORIGIN + timedelta(hours=hour)).strftime("%Y-%m-%d_%H:%M:%S")


def frame(receipt: dict[str, Any], method: str, hour: int) -> tuple[Path, str]:
    run_key = "ao" if method == "ARK" else "r"
    try:
        item = receipt["frames"][run_key][str(hour)]
    except KeyError as exc:
        raise ValueError(f"missing receipt frame {method} {hour}h") from exc
    return Path(item["path"]), str(item["sha256"])


def read_frame(path: Path, expected_hour: int) -> dict[str, Any]:
    with Dataset(path, "r") as ds:
        dims = {k: len(v) for k, v in ds.dimensions.items()}
        for name, expected in {"west_east": NX, "south_north": NY,
                               "bottom_top": NZ, "bottom_top_stag": NZ + 1}.items():
            if dims.get(name) != expected:
                raise ValueError(f"{path}: {name}={dims.get(name)}, expected {expected}")
        time_text = b"".join(ds["Times"][0]).decode("ascii").rstrip("\x00 ")
        if time_text != expected_time(expected_hour):
            raise ValueError(f"{path}: time {time_text!r}, expected {expected_time(expected_hour)!r}")
        if int(ds.getncattr("MAP_PROJ")) != 0:
            raise ValueError(f"{path}: expected flat MAP_PROJ=0")
        if not np.isclose(float(ds.getncattr("DX")), DX_M) or not np.isclose(
            float(ds.getncattr("DY")), DY_M
        ):
            raise ValueError(f"{path}: unexpected DX/DY")
        required = ("T", "P", "PB", "PH", "PHB", "MU", "MUB", "RDNW", "C1H", "C2H")
        missing = [v for v in required if v not in ds.variables]
        if missing:
            raise ValueError(f"{path}: missing {missing}")
        values = {v: np.asarray(ds[v][0], dtype=np.float64) for v in required}
        qv = np.asarray(ds["QVAPOR"][0], dtype=np.float64) if "QVAPOR" in ds.variables else None
    expected_shapes = {
        "T": (NZ, NY, NX), "P": (NZ, NY, NX), "PB": (NZ, NY, NX),
        "PH": (NZ + 1, NY, NX), "PHB": (NZ + 1, NY, NX),
        "MU": (NY, NX), "MUB": (NY, NX), "RDNW": (NZ,),
        "C1H": (NZ,), "C2H": (NZ,),
    }
    for name, shape in expected_shapes.items():
        if values[name].shape != shape:
            raise ValueError(f"{path}: {name}.shape={values[name].shape}; expected {shape}")
        if not np.isfinite(values[name]).all():
            raise ValueError(f"{path}: {name} has NaN/Inf")
    if qv is not None and (not np.isfinite(qv).all() or np.any(qv != 0.0)):
        raise ValueError(f"{path}: QVAPOR is not identically zero; dry theta EOS is invalid")
    values.update({"path": str(path), "time_text": time_text,
                   "qv_present": qv is not None,
                   "qv_max_abs": float(np.max(np.abs(qv))) if qv is not None else None})
    return values


def eos_compare(f: dict[str, Any]) -> dict[str, Any]:
    """Compare saved P+PB with EOS pressure from saved theta and layer alpha."""
    theta = f["T"] + T0
    phi = f["PH"] + f["PHB"]
    total_mass = f["MU"] + f["MUB"]
    layer_mass = f["C1H"][:, None, None] * total_mass[None, :, :] + f["C2H"][:, None, None]
    if not np.isfinite(layer_mass).all() or np.any(layer_mass <= 0.0):
        raise ValueError("C1H*(MU+MUB)+C2H must be finite and positive")
    # WRF RDNW is signed negative on this grid. The leading minus makes alpha positive.
    alpha = -f["RDNW"][:, None, None] * np.diff(phi, axis=0) / layer_mass
    if not np.isfinite(alpha).all() or np.any(alpha <= 0.0):
        raise ValueError(f"geometric alpha must be finite and positive; min={float(np.nanmin(alpha))}")
    if not np.isfinite(theta).all() or np.any(theta <= 0.0):
        raise ValueError("T+300 K must be finite and positive")
    p_saved = f["P"] + f["PB"]
    if not np.isfinite(p_saved).all() or np.any(p_saved <= 0.0):
        raise ValueError("saved P+PB must be finite and positive")
    exponent = CP / (CP - RD)
    p_eos = P0 * np.power(RD * theta / (P0 * alpha), exponent)
    if not np.isfinite(p_eos).all() or np.any(p_eos <= 0.0):
        raise ValueError("EOS pressure must be finite and positive")
    err = p_saved - p_eos
    rel = err / p_saved
    err_hi, ps_hi, pe_hi = high_y(err), high_y(p_saved), high_y(p_eos)
    return {
        "scope": "saved_output_eos_consistency_diagnostic",
        "constants": {"Rd_J_kgK": RD, "Cp_J_kgK": CP, "P0_Pa": P0,
                      "T0_K": T0, "g_m_s2": G, "exponent": exponent},
        "alpha_definition": "-RDNW[k]*(PH+PHB[k+1]-PH-PHB[k])/(C1H[k]*(MU+MUB)+C2H[k]); RDNW is signed and negative in saved frames",
        "theta_definition": "T + 300 K; dry QVAPOR must be exactly zero when present",
        "metrics": {
            "all_y": {
                "p_saved_rms_Pa": rms(p_saved), "p_eos_rms_Pa": rms(p_eos),
                "error_rms_Pa": rms(err), "error_max_abs_Pa": float(np.max(np.abs(err))),
                "relative_error_rms": rms(rel), "relative_error_max_abs": float(np.max(np.abs(rel))),
            },
            "high_y_k40_plus": {
                "p_saved_rms_Pa": rms(ps_hi), "p_eos_rms_Pa": rms(pe_hi),
                "error_rms_Pa": rms(err_hi), "error_max_abs_Pa": float(np.max(np.abs(err_hi))),
                "relative_error_rms_to_highpass_saved": rms(err_hi) / max(rms(ps_hi), np.finfo(np.float64).tiny),
                "relative_error_max_abs_to_highpass_saved": float(np.max(np.abs(err_hi))) /
                    max(float(np.max(np.abs(ps_hi))), np.finfo(np.float64).tiny),
            },
            "alpha_range_m3_kg": [float(alpha.min()), float(alpha.max())],
            "theta_range_K": [float(theta.min()), float(theta.max())],
            "saved_pressure_range_Pa": [float(p_saved.min()), float(p_saved.max())],
            "eos_pressure_range_Pa": [float(p_eos.min()), float(p_eos.max())],
        },
        "not_claimed": ["not an exact native stage RHS/EOS capture",
                        "not proof that saved P was or was not consumed by the accepted ARK stage",
                        "not a causal oracle for the high-Y W mode"],
    }


def main() -> None:
    out = HERE / "results" / "saved_pressure_eos_metrics.json"
    if sha256_file(RECEIPT_PATH) != RECEIPT_SHA256:
        raise ValueError("green raw-frame receipt hash changed")
    receipt = json.loads(RECEIPT_PATH.read_text())
    if receipt.get("source_revision") != SOURCE_REVISION:
        raise ValueError("frame receipt source revision changed")
    for relative, expected in SOURCE_PINS.items():
        actual = sha256_file(SOURCE_ROOT / relative)
        if actual != expected:
            raise ValueError(f"source pin changed: {relative} {actual} != {expected}")

    result: dict[str, Any] = {
        "source_revision": SOURCE_REVISION,
        "frame_receipt_sha256": RECEIPT_SHA256,
        "source_pins": SOURCE_PINS,
        "scope": "offline saved-output thermodynamic consistency; no model/source edits",
        "grid": {"nx": NX, "ny": NY, "nz": NZ, "dx_m": DX_M, "dy_m": DY_M,
                 "high_y": "DCT-II mass-y scalar modes k>=40"},
        "frames": {},
    }
    for method in ("ARK", "RK3"):
        result["frames"][method] = {}
        for hour in HOURS:
            path, expected_hash = frame(receipt, method, hour)
            if not path.is_file():
                raise FileNotFoundError(path)
            actual_hash = sha256_file(path)
            if actual_hash != expected_hash:
                raise ValueError(f"frame hash changed: {method} {hour}h")
            f = read_frame(path, hour)
            row = eos_compare(f)
            row.update({"path": str(path), "sha256": actual_hash,
                        "time": f["time_text"], "qv_present": f["qv_present"],
                        "qv_max_abs": f["qv_max_abs"]})
            result["frames"][method][str(hour)] = row
    # Shared frame verifies a common start; receipt pins exact content elsewhere.
    ark0, ark0sha = frame(receipt, "ARK", 0)
    rk0, rk0sha = frame(receipt, "RK3", 0)
    if ark0sha != rk0sha or sha256_file(ark0) != sha256_file(rk0):
        raise ValueError("ARK and RK3 initial frames differ")
    result["shared_initial_sha256"] = ark0sha
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"status": "complete", "output": str(out)}, indent=2))


if __name__ == "__main__":
    main()
