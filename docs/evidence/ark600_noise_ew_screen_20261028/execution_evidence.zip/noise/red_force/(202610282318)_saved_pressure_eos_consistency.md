# Saved pressure versus dry EOS consistency

Local time: 2026-10-28 23:18:21 JST  
Source worktree: `/private/tmp/standard-forward-comparison-20261024`, HEAD `8dc34517336c901a5ec70bc990c5d0d87995e842`.  
Status: offline saved-output diagnostic completed; no model/build/source changes.

## Result

Saved `P+PB` is consistent with the dry ideal-gas pressure reconstructed from saved `T`, `PH+PHB`, `MU+MUB`, and vertical coefficients. The all-grid RMS pressure error is about 0.0358 Pa (relative RMS 1.36e-6), with a maximum absolute error below 0.093 Pa for all six method/time frames. `QVAPOR` is present and exactly zero in each selected frame, so the saved `T+300 K` is dry potential temperature under `use_theta_m`'s Registry default of 1.

The high-Y error RMS remains nearly constant at 0.00249–0.00252 Pa. Relative to the saved high-Y pressure signal, this is 0.67% at ARK 24 h, 0.18% at ARK 36 h, 1.66% at RK3 24 h, and 1.73% at RK3 36 h. The 0 h high-Y relative error is ill-conditioned because the high-Y pressure amplitude is near zero; the absolute error is about 0.0025 Pa. This argues against grossly stale/inconsistent saved P as the explanation for ARK's growing W band, but it does not establish which pressure the native ARK stage used.

Selected values:

| Method | Lead | All-grid pressure error RMS | Max abs error | High-Y pressure error RMS | High-Y relative RMS |
|---|---:|---:|---:|---:|---:|
| ARK | 0 h | 0.03576 Pa | 0.09075 Pa | 0.002516 Pa | 35.6%* |
| ARK | 24 h | 0.03581 Pa | 0.09148 Pa | 0.002500 Pa | 0.675% |
| ARK | 36 h | 0.03582 Pa | 0.09134 Pa | 0.002491 Pa | 0.179% |
| RK3 | 0 h | 0.03576 Pa | 0.09075 Pa | 0.002516 Pa | 35.6%* |
| RK3 | 24 h | 0.03582 Pa | 0.09274 Pa | 0.002509 Pa | 1.665% |
| RK3 | 36 h | 0.03582 Pa | 0.09162 Pa | 0.002503 Pa | 1.731% |

*The 0 h denominator is very small; use the absolute error there.

## Equation and validation

The exact dry equation of state used for this diagnostic is

```text
pEOS = p0 * (Rd * theta / (p0 * alpha)) ** (cp / (cp - Rd))
theta = T + 300 K
alpha = -RDNW[k] * ((PH+PHB)[k+1] - (PH+PHB)[k])
         / (C1H[k] * (MU+MUB) + C2H[k])
```

The signed saved RDNW is negative; the leading minus gives positive specific volume. Constants match `share/module_model_constants.F`: `Rd=287`, `cp=7*Rd/2=1004.5`, `p0=100000 Pa`, and `T0=300 K`. The case namelist sets `mp_physics=0`; `QVAPOR` is identically zero in selected files. `C1H`, `C2H`, `RDNW`, and PH face dimensions were checked. Derived alpha is positive and ranges about 0.752–6.189 m³/kg.

This is an exact dry EOS consistency comparison, not WRF's nonhydrostatic `calc_p_rho` temporally linearized perturbation-pressure update (`dyn_em/module_small_step_em.F:492-529`). That difference is why the small residual is supportive evidence rather than proof of native-stage state identity. Pressure, temperature, geopotential, and mass are saved FP32 values promoted to FP64 before arithmetic. High-Y uses DCT-II scalar modes `k>=40` over the 80 mass-Y cells.

## Inputs and pins

The ARK/RK3 frames at 0, 24, and 36 h are selected from `../green_maps/raw_frame_hashes.json` SHA-256 `dc8ebd21562863795bc1b704304bbfc905e3bab64cd015e755880d4f062c9a0a`. The six frame SHA-256s and the computed metrics are preserved in `results/saved_pressure_eos_metrics.json` (SHA-256 `456883e9ec9d7643398e34ee2396637f374534c7df4c8633c19e0fa62105572a`).

Source pins: `module_small_step_em.F` `037f706dd3b32f61cc2489f46a58cfd63e78795483662d18f66452f9f229d50c`; `module_model_constants.F` `5b80377fecdc18a5f0ad38d3b6c15cfc86ad5d76701adbbbb08a08698d0f7062`; `Registry.EM_COMMON` `289879a55bc46bb6b281751ab35878135856b9df362c0b47e62dfc4817aee77b`.

The reusable script is `analyze_saved_pressure_eos.py` (SHA-256 `79fa459a71682c49b8b776aff46ed03c4a04cdf8f19c103529224bd67fc29dde`). It verifies these pins and the selected frame hashes before calculation.

## Scope limits

This checks endpoint saved-field thermodynamic consistency only. It does not prove that saved `P` was current at the accepted ARK evaluation point, reproduce internal FP64 pressure, capture a native stage RHS, or establish causality for the grid-scale W mode. It should be combined with a native-stage pressure/temperature/mass capture before assigning the W growth to pressure/mass imbalance.
