#!/usr/bin/env python3
"""Saved-output diagnostic of dry W pressure/mass-force terms on high Y modes.

This reconstructs the source-equation's instantaneous physical W force from
saved FP32 wrfout P/MU/MUB and vertical coefficients. It is not a native stage
RHS capture, an internal-FP64 replay, or a causal oracle. Do not run until the
benchmark owner has released the plotting/analysis hold.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import numpy as np
from netCDF4 import Dataset
from scipy.fft import dct, idct


HERE = Path(__file__).resolve().parent
EVIDENCE = HERE.parent
GREEN = EVIDENCE / "green_maps"
FRAME_RECEIPT = GREEN / "raw_frame_hashes.json"
FRAME_RECEIPT_SHA256 = "dc8ebd21562863795bc1b704304bbfc905e3bab64cd015e755880d4f062c9a0a"
SOURCE_REVISION = "8dc34517336c901a5ec70bc990c5d0d87995e842"
EXPECTED_SOURCE_SHA256 = {
    "dyn_em/module_big_step_utilities_em.F":
        "aabb885c142ae3f7b183dc7cd4983f98dda5362caf7ee95928e97e57594c49f1",
    "dyn_em/module_implicit_sdirk3.F":
        "dc60f0c90513d2d11d878c5ac45710b930d103a4de0801e87129bc28be08c775",
    "Registry/Registry.EM_COMMON":
        "289879a55bc46bb6b281751ab35878135856b9df362c0b47e62dfc4817aee77b",
    "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp":
        "9afe11f0967facefee9082a9f946e128d89395d02982b7be6cf6f86489ccb0b4",
    "external/libtorch_wrf/sdirk3/wrf_sdirk3_config.h":
        "ad1d1113cfe65fcf353ea0cb5194ef491e022afebbffecd3ea98e5308664f7f8",
}
G = 9.81
NY, NX, NZ = 80, 40, 64
DY_M = 100_000.0
DX_M = 100_000.0
HOURS = (24, 30, 36)
HIGH_Y_FIRST_MODE = 40
ORIGIN = datetime(1, 1, 1, 0, 0, 0)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def rms(a: np.ndarray) -> float:
    a64 = np.asarray(a, dtype=np.float64)
    return float(np.sqrt(np.mean(np.square(a64), dtype=np.float64)))


def high_y_part(a: np.ndarray) -> np.ndarray:
    """DCT-II even-reflection high-Y component, over axis 0 (mass-y)."""
    if a.shape[0] != NY:
        raise ValueError(f"high-Y input has {a.shape[0]} y cells; expected {NY}")
    coeff = dct(a, type=2, axis=0, norm="ortho")
    coeff[:HIGH_Y_FIRST_MODE, ...] = 0.0
    return idct(coeff, type=2, axis=0, norm="ortho")


def frame_path_and_pin(receipt: dict[str, Any], run_key: str, hour: int) -> tuple[Path, str]:
    try:
        row = receipt["frames"][run_key][str(hour)]
        return Path(row["path"]), str(row["sha256"])
    except KeyError as exc:
        raise ValueError(f"Frame receipt lacks {run_key=} at {hour=} h") from exc


def expected_time(hour: int) -> str:
    return (ORIGIN + timedelta(hours=hour)).strftime("%Y-%m-%d_%H:%M:%S")


def load_saved_fields(path: Path, expected_hour: int) -> dict[str, Any]:
    """Read and validate source fields; preserve stored FP32 values, promote to FP64."""
    with Dataset(path, "r") as ds:
        if len(ds.dimensions["Time"]) != 1:
            raise ValueError(f"expected one frame in {path}")
        dims = {k: len(v) for k, v in ds.dimensions.items()}
        expected_dims = {
            "west_east": NX, "south_north": NY, "bottom_top": NZ,
            "bottom_top_stag": NZ + 1,
        }
        for name, size in expected_dims.items():
            if name not in dims or dims[name] != size:
                raise ValueError(f"{path}: dimension {name}={dims.get(name)}; expected {size}")

        time_text = b"".join(ds["Times"][0]).decode("ascii").rstrip("\x00 ")
        if time_text != expected_time(expected_hour):
            raise ValueError(f"{path}: Times={time_text!r}; expected {expected_time(expected_hour)!r}")
        if int(ds.getncattr("MAP_PROJ")) != 0:
            raise ValueError(f"{path}: MAP_PROJ is not flat (MAP_PROJ must be 0)")
        if not np.isclose(float(ds.getncattr("DX")), DX_M) or not np.isclose(
            float(ds.getncattr("DY")), DY_M
        ):
            raise ValueError(f"{path}: DX/DY do not match the pinned 100 km grid")

        required = ("P", "MU", "MUB", "RDN", "RDNW", "C1F", "C2F",
                    "PH", "PHB", "W", "MAPFAC_MY")
        missing = [name for name in required if name not in ds.variables]
        if missing:
            raise ValueError(f"{path}: missing required variables {missing}")

        # Reads one selected output record only. Conversion occurs after loading,
        # so arithmetic is FP64 while each source value remains the stored FP32.
        f = {name: np.asarray(ds[name][0], dtype=np.float64) for name in required}
    wanted_shapes = {
        "P": (NZ, NY, NX), "MU": (NY, NX), "MUB": (NY, NX),
        "RDN": (NZ,), "RDNW": (NZ,), "C1F": (NZ + 1,), "C2F": (NZ + 1,),
        "PH": (NZ + 1, NY, NX), "PHB": (NZ + 1, NY, NX),
        "W": (NZ + 1, NY, NX), "MAPFAC_MY": (NY, NX),
    }
    for name, shape in wanted_shapes.items():
        if f[name].shape != shape:
            raise ValueError(f"{path}: {name}.shape={f[name].shape}; expected {shape}")
        if not np.isfinite(f[name]).all():
            raise ValueError(f"{path}: {name} contains NaN/Inf")
    f["time_text"] = time_text
    f["path"] = str(path)
    return f


def reconstruct_force(f: dict[str, Any]) -> dict[str, np.ndarray | float]:
    """Return physical W pressure, column-mass, and net terms on W faces 1..64.

    For dry cqw=0, cq1=1,cq2=0. Interior Fortran k=2..kde-1 maps to
    NetCDF C indices 1..63. The top W face (Fortran k=kde) maps to face 64
    and uses 2*RDNW[-1]*(-P[-1]).
    """
    p, mu, mub = f["P"], f["MU"], f["MUB"]
    rdn, rdnw, c1f, c2f = f["RDN"], f["RDNW"], f["C1F"], f["C2F"]
    total_mu = mu + mub
    mface = c1f[None, :, None] * total_mu[:, None, :] + c2f[None, :, None]
    if mface.shape != (NY, NZ + 1, NX):
        raise ValueError(f"Mface shape {mface.shape} is not [ny,nz_w,nx]")
    used_mface = mface[:, 1:, :]
    if not np.isfinite(used_mface).all() or np.any(used_mface <= 0.0):
        min_value = float(np.nanmin(used_mface))
        raise ValueError(f"Mface must be finite and positive; minimum={min_value}")
    msfty = f["MAPFAC_MY"]
    if not np.isfinite(msfty).all() or np.any(msfty <= 0.0):
        raise ValueError("MAPFAC_MY (Fortran grid%msfty) must be finite and positive")
    if not np.isfinite(total_mu).all() or np.any(total_mu <= 0.0):
        raise ValueError("MU+MUB must be finite and positive")

    # Audit the source conversion on the actual saved map factor. C++ forms
    # rw = (g/msfty)*F * (velocity_mass/alpha_w), alpha_w=Mface/msfty,
    # then converts rw by dividing by the same velocity_mass. This identity
    # must reduce to g*F/Mface to numerical precision.
    alpha_w = mface / msfty[:, None, :]
    source_prefactor = G / msfty[:, None, :]
    source_velocity_mass = total_mu[:, None, :]
    source_physical_prefactor = source_prefactor * (source_velocity_mass / alpha_w) / source_velocity_mass
    target_physical_prefactor = G / mface
    conversion_error = float(np.max(np.abs(source_physical_prefactor[:, 1:, :] -
                                           target_physical_prefactor[:, 1:, :])))
    conversion_scale = float(np.max(np.abs(target_physical_prefactor[:, 1:, :])))
    conversion_rel_error = conversion_error / max(conversion_scale, np.finfo(np.float64).tiny)
    if not np.isfinite(conversion_rel_error) or conversion_rel_error > 5.0e-15:
        raise ValueError(f"MSFTY physical-force conversion identity failed: relative error={conversion_rel_error}")

    # First 63 owned W faces correspond to Fortran k=2..kde-1.
    # RDN retains WRF's signed value; do not abs() it.
    pg_inside = (
        G * rdn[None, 1:NZ, None]
        * (p[1:, :, :] - p[:-1, :, :]).transpose(1, 0, 2)
    )
    # p is [k,j,i], convert pressure difference to [j,k,i].
    # The transpose above is [j,k,i] because axis order is (1,0,2).
    b_inside = G * c1f[None, 1:NZ, None] * mu[:, None, :] / mface[:, 1:NZ, :]
    pg_inside = pg_inside / mface[:, 1:NZ, :]

    # Fortran k=kde top: preserve the signed RDNW in 2*RDNW(kde-1)*(-p(kde-1)).
    pg_top = G * (2.0 * rdnw[-1] * (-p[-1, :, :])) / mface[:, -1, :]
    b_top = G * c1f[-1] * mu / mface[:, -1, :]
    pg = np.concatenate((pg_inside, pg_top[:, None, :]), axis=1)
    buoy = np.concatenate((b_inside, b_top[:, None, :]), axis=1)
    net = pg - buoy
    return {"pg": pg, "buoy_mu": buoy, "net": net,
            "mface_min": float(used_mface.min()),
            "mapfac_my_min": float(msfty.min()),
            "mapfac_my_max": float(msfty.max()),
            "conversion_relative_error": conversion_rel_error}


def field_metrics(fields: dict[str, np.ndarray]) -> dict[str, Any]:
    high = {name: high_y_part(value) for name, value in fields.items()}
    metrics: dict[str, Any] = {"scope": "saved_output_instantaneous_force_diagnostic"}
    for band_name, arrays in (("all_y", fields), ("high_y_k40_plus", high)):
        part = {name: rms(arr) for name, arr in arrays.items()}
        denom = part["pg"] + part["buoy_mu"]
        metrics[band_name] = {
            "rms_m_s2": part,
            "cancellation_ratio": part["net"] / denom if denom > 0.0 else None,
            "cancellation_ratio_definition": "RMS(Pg-Bmu)/(RMS(Pg)+RMS(Bmu)); 0 means exact cancellation, 1 means no cancellation",
        }
    return metrics


def load_all(receipt: dict[str, Any]) -> tuple[dict[tuple[str, int], dict[str, Any]], dict[str, Any]]:
    loaded: dict[tuple[str, int], dict[str, Any]] = {}
    pins: dict[str, Any] = {}
    for method, run_key in (("ARK", "ao"), ("RK3", "r")):
        for hour in HOURS:
            path, expected_sha = frame_path_and_pin(receipt, run_key, hour)
            if not path.is_file():
                raise FileNotFoundError(path)
            observed_sha = sha256_file(path)
            if observed_sha != expected_sha:
                raise ValueError(f"{method} {hour}h SHA mismatch: {observed_sha} != {expected_sha}")
            frame = load_saved_fields(path, hour)
            loaded[(method, hour)] = frame
            pins[f"{method}_{hour}h"] = {"path": str(path), "sha256": observed_sha,
                                         "time": frame["time_text"]}
    # Same initial condition is a prerequisite for the ARK/RK3 difference map.
    ark0, _ = frame_path_and_pin(receipt, "ao", 0)
    rk0, _ = frame_path_and_pin(receipt, "r", 0)
    if sha256_file(ark0) != sha256_file(rk0):
        raise ValueError("ARK and RK3 0 h files do not have identical hashes")
    pins["initial_state"] = {"path_ark": str(ark0), "path_rk3": str(rk0),
                             "shared_sha256": sha256_file(ark0)}
    return loaded, pins


def compute_results(loaded: dict[tuple[str, int], dict[str, Any]]) -> dict[str, Any]:
    results: dict[str, Any] = {
        "scope": "saved_output_instantaneous_force_diagnostic",
        "not_claimed": [
            "not an exact native stage RHS capture",
            "not an internal-FP64 replay (source fields are FP32, promoted to FP64 for arithmetic)",
            "not a causal oracle for which term generated the later W mode",
        ],
        "formula": {
            "interior": "Pg=g*RDN[k]*(P[k]-P[k-1])/Mface; Bmu=g*C1F[k]*MU/Mface",
            "top": "Pg=g*2*RDNW[-1]*(-P[-1])/Mface[-1]; Bmu=g*C1F[-1]*MU/Mface[-1]",
            "Mface": "C1F[k]*(MU+MUB)+C2F[k]",
            "dry": "source configuration mp_physics=0; set cq1=1,cq2=0",
            "physical_conversion": "source coupled tendency g/MSFTY*F multiplied by velocity_mass/alpha_w, then divided by velocity_mass; alpha_w=Mface/MSFTY, so MSFTY cancels, leaving g*F/Mface",
        },
        "grid": {"nx": NX, "ny": NY, "nz_mass": NZ, "w_owned_faces": "NetCDF C indices 1..64; lower fixed face 0 excluded",
                 "dx_m": DX_M, "dy_m": DY_M, "gravity": G,
                 "high_y_transform": "DCT-II even scalar reflection on 80 mass-y points; retain k>=40"},
        "frames": {},
    }
    for hour in HOURS:
        per_hour: dict[str, Any] = {}
        force_arrays: dict[str, dict[str, np.ndarray]] = {}
        for method in ("ARK", "RK3"):
            frame = loaded[(method, hour)]
            force = reconstruct_force(frame)
            terms = {name: force[name] for name in ("pg", "buoy_mu", "net")}
            force_arrays[method] = terms
            per_hour[method] = {
                **field_metrics(terms),
                "mface_min": force["mface_min"],
                "mapfac_my_min": force["mapfac_my_min"],
                "mapfac_my_max": force["mapfac_my_max"],
                "conversion_relative_error": force["conversion_relative_error"],
                "actual_W_rms_m_s": rms(frame["W"][1:, :, :]),
            }
        delta = {name: force_arrays["ARK"][name] - force_arrays["RK3"][name]
                 for name in ("pg", "buoy_mu", "net")}
        per_hour["ARK_minus_RK3_saved_force_difference"] = field_metrics(delta)
        per_hour["ARK_minus_RK3_actual_W_rms_m_s"] = rms(
            loaded[("ARK", hour)]["W"][1:, :, :] - loaded[("RK3", hour)]["W"][1:, :, :]
        )
        results["frames"][str(hour)] = per_hour
    return results


def save_plots(loaded: dict[tuple[str, int], dict[str, Any]], outdir: Path) -> None:
    """Optional saved-field maps. Not called unless --write-plots is explicit."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import TwoSlopeNorm

    y = (np.arange(NY, dtype=np.float64) + 0.5) * DY_M / 1000.0
    actual_by_hour: dict[int, dict[str, np.ndarray]] = {}
    force_by_method: dict[str, dict[int, dict[str, np.ndarray]]] = {"ARK": {}, "RK3": {}}
    z_by_key: dict[tuple[str, int], np.ndarray] = {}
    for hour in HOURS:
        actual_by_hour[hour] = {}
        for method in ("ARK", "RK3"):
            f = loaded[(method, hour)]
            z = ((f["PH"] + f["PHB"]) / G)[1:, :, :].mean(axis=2)
            z_by_key[(method, hour)] = z
            actual_by_hour[hour][method] = f["W"][1:, :, :].mean(axis=2)
            force = reconstruct_force(f)
            force_by_method[method][hour] = {
                name: high_y_part(force[name]).mean(axis=2).T
                for name in ("pg", "buoy_mu", "net")
            }

    # Actual W maps are kept separate from the inferred saved-field force maps.
    actual_values = [a for hour in HOURS for a in actual_by_hour[hour].values()]
    actual_limit = float(np.percentile(np.abs(np.concatenate([a.ravel() for a in actual_values])), 99.5))
    fig, axes = plt.subplots(len(HOURS), 3, figsize=(15, 11), constrained_layout=True)
    fig.suptitle("Saved raw W x-means (W faces 1..64); separate from inferred force diagnostic")
    for row, hour in enumerate(HOURS):
        arrs = {
            "ARK": actual_by_hour[hour]["ARK"],
            "RK3": actual_by_hour[hour]["RK3"],
            "ARK-RK3": actual_by_hour[hour]["ARK"] - actual_by_hour[hour]["RK3"],
        }
        for col, (label, arr) in enumerate(arrs.items()):
            ax = axes[row, col]
            z = z_by_key[("ARK", hour)]
            X = np.broadcast_to(y[None, :], z.shape)
            m = ax.pcolormesh(X, z / 1000.0, arr, shading="auto", cmap="RdBu_r",
                              norm=TwoSlopeNorm(vmin=-actual_limit, vcenter=0.0, vmax=actual_limit))
            ax.set_title(f"{hour} h | {label}")
            ax.set_xlabel("Y mass centers (km)")
            if col == 0:
                ax.set_ylabel("Height from PH+PHB (km)")
            fig.colorbar(m, ax=ax, label="W (m s$^{-1}$)")
    fig.savefig(outdir / "actual_w_xmean_24_30_36h.png", dpi=160)
    plt.close(fig)

    # Force maps use only the high-Y component and are in physical acceleration units.
    for method in ("ARK", "RK3"):
        fig, axes = plt.subplots(len(HOURS), 3, figsize=(15, 11), constrained_layout=True)
        fig.suptitle(f"{method}: saved-output high-Y W pressure/mass-force terms (diagnostic only)")
        for row, hour in enumerate(HOURS):
            for col, name in enumerate(("pg", "buoy_mu", "net")):
                arr = force_by_method[method][hour][name]
                lim = max(float(np.percentile(np.abs(arr), 99.5)), 1e-30)
                ax = axes[row, col]
                z = z_by_key[(method, hour)]
                X = np.broadcast_to(y[None, :], z.shape)
                m = ax.pcolormesh(X, z / 1000.0, arr, shading="auto", cmap="RdBu_r",
                                  norm=TwoSlopeNorm(vmin=-lim, vcenter=0.0, vmax=lim))
                ax.set_title(f"{hour} h | {name}")
                ax.set_xlabel("Y mass centers (km)")
                if col == 0:
                    ax.set_ylabel("Height from PH+PHB (km)")
                fig.colorbar(m, ax=ax, label="acceleration (m s$^{-2}$)")
        fig.savefig(outdir / f"{method.lower()}_saved_w_force_xmean_k40plus.png", dpi=160)
        plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outdir", type=Path, default=HERE / "results",
                        help="output directory; default is red_force/results")
    parser.add_argument("--write-plots", action="store_true",
                        help="write actual-W and saved-force maps; held until benchmark release")
    args = parser.parse_args()

    if not FRAME_RECEIPT.is_file():
        raise FileNotFoundError(FRAME_RECEIPT)
    receipt_sha = sha256_file(FRAME_RECEIPT)
    if receipt_sha != FRAME_RECEIPT_SHA256:
        raise ValueError(f"frame receipt SHA mismatch: {receipt_sha} != {FRAME_RECEIPT_SHA256}")
    receipt = json.loads(FRAME_RECEIPT.read_text())
    if receipt.get("source_revision") != SOURCE_REVISION:
        raise ValueError(f"frame receipt source revision {receipt.get('source_revision')} != {SOURCE_REVISION}")
    source_root = Path("/private/tmp/standard-forward-comparison-20261024")
    for relative, expected in EXPECTED_SOURCE_SHA256.items():
        source = source_root / relative
        observed = sha256_file(source)
        if observed != expected:
            raise ValueError(f"source pin mismatch for {relative}: {observed} != {expected}")

    loaded, pins = load_all(receipt)
    results = compute_results(loaded)
    results["source_revision"] = SOURCE_REVISION
    results["source_pins"] = EXPECTED_SOURCE_SHA256
    results["frame_pins"] = pins
    results["frame_receipt_sha256"] = receipt_sha
    results["status"] = "saved_field_diagnostic_only"
    args.outdir.mkdir(parents=True, exist_ok=True)
    (args.outdir / "saved_w_pg_buoyancy_metrics.json").write_text(
        json.dumps(results, indent=2, allow_nan=False) + "\n"
    )
    if args.write_plots:
        save_plots(loaded, args.outdir)
    print(json.dumps({"status": results["status"], "outdir": str(args.outdir),
                      "plots_written": bool(args.write_plots)}, indent=2))


if __name__ == "__main__":
    main()
