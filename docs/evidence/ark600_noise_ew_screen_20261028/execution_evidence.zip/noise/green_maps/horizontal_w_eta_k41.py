"""Raw 36 h native W-face XY slice; analysis-only."""
import hashlib,json
from pathlib import Path
import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from netCDF4 import Dataset
O=Path(__file__).resolve().parent
RUNS={'ARK':'/Users/yhlee/AD-SDIRK3-review-evidence/ark600-five-day-20261025/runs/ark_h600','RK3':'/Users/yhlee/AD-SDIRK3-review-evidence/standard-forward-comparison-20261024/runs/rk3_h600'}
DX=DY=100000.; G=9.81; HOUR=36; K_OWNED=40; K_RAW=K_OWNED+1

def path_at(root,h):
 for p in Path(root).glob('wrfout_d01*'):
  with Dataset(p) as d:
   t=b''.join(d['Times'][0]).decode().rstrip()
  hh=int(t[11:13])+24*(int(t[8:10])-1)
  if hh==h:return p
 raise FileNotFoundError((root,h))
def sha(p):
 q=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):q.update(b)
 return q.hexdigest()
data={}; zrange={}; files={}
for name,root in RUNS.items():
 p=path_at(root,HOUR); files[name]={'path':str(p),'sha256':sha(p)}
 with Dataset(p) as d:
  # Python index 41 is native W vertical face k=41 (1-based); owned index is 40 after bottom-face exclusion.
  data[name]=np.asarray(d['W'][0,K_RAW,:,:],dtype=np.float64)
  z=(np.asarray(d['PH'][0,K_RAW,:,:])+np.asarray(d['PHB'][0,K_RAW,:,:]))/G
  zrange[name]=[float(z.min()/1000),float(z.max()/1000)]
diff=data['ARK']-data['RK3']
actual_lim=max(float(np.nanpercentile(np.abs(data[n]),99.5)) for n in ('ARK','RK3'))
delta_lim=max(float(np.nanpercentile(np.abs(diff),99.5)),1e-15)
xx=(np.arange(data['ARK'].shape[1])+.5)*DX/1000
yy=(np.arange(data['ARK'].shape[0])+.5)*DY/1000
fig,ax=plt.subplots(1,3,figsize=(16,5.3),constrained_layout=True)
fig.suptitle(f'36 h actual W on native W array k=41 / owned k=40 (W eta face, not constant height)\n'
             f'Not a constant-height plane; physical Z ranges: ARK {zrange["ARK"][0]:.2f}–{zrange["ARK"][1]:.2f} km, RK3 {zrange["RK3"][0]:.2f}–{zrange["RK3"][1]:.2f} km',fontsize=13)
for a,title,field,lim in zip(ax,('ARK h=600 s','RK3 h=600 s','ARK − RK3'),(data['ARK'],data['RK3'],diff),(actual_lim,actual_lim,delta_lim)):
 m=a.pcolormesh(xx,yy,field,shading='auto',cmap='RdBu_r',norm=TwoSlopeNorm(vmin=-lim,vcenter=0,vmax=lim),rasterized=True)
 a.set_title(title);a.set_xlabel('X mass centers (km)');a.set_xlim(0,4000);a.set_ylim(0,8000)
 a.set_ylabel('Y mass centers (km)');fig.colorbar(m,ax=a,label='W (m s$^{-1}$)',shrink=.86)
fig.savefig(O/'horizontal_w_eta_k41_36h.png',dpi=180);plt.close(fig)
receipt={'field':'W','lead_hours':36,'native_vertical_face_python_index_0based':41,'native_vertical_face_fortran_index_1based':42,'owned_vertical_index_0based':40,'coordinate_warning':'native eta W face, not constant physical height','physical_z_km_by_run':zrange,'x_centers_km':xx.tolist(),'y_centers_km':yy.tolist(),'grid_spacing_m':{'DX':DX,'DY':DY},'actual_ark_rk3_shared_color_limit_m_s':actual_lim,'difference_color_limit_m_s':delta_lim,'input_frames':files}
(O/'horizontal_w_eta_k41_36h.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'z_km':zrange,'actual_limit':actual_lim,'delta_limit':delta_lim,'sha':{k:v['sha256'] for k,v in files.items()}},indent=2))
