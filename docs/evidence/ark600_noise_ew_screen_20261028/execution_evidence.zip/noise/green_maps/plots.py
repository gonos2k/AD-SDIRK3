import hashlib,json
from pathlib import Path
import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from netCDF4 import Dataset
from scipy.fft import dct,idct,dst,idst
O=Path(__file__).resolve().parent; G=9.81; DY=100000.; NY=80; NZ=64
R={'ao':Path('/Users/yhlee/AD-SDIRK3-review-evidence/ark600-five-day-20261025/runs/ark_h600'),'an':Path('/Users/yhlee/AD-SDIRK3-review-evidence/ark600-3hour-continuous-20261027/runs/ark_h600'),'r':Path('/Users/yhlee/AD-SDIRK3-review-evidence/standard-forward-comparison-20261024/runs/rk3_h600')}
VARS=['W','V','theta']; UN={'W':'m/s','V':'m/s','theta':'K'}
def index(root):
 out={}
 for p in root.glob('wrfout_d01*'):
  with Dataset(p) as d:
   for t in d['Times'][:]:
    s=b''.join(t).decode().rstrip(); h=int(s[11:13])+24*(int(s[8:10])-1); out[h]=p
 return out
I={k:index(v) for k,v in R.items()}; C={}
def get(run,h):
 if (run,h) not in C:
  p=I[run][h]
  with Dataset(p) as d:
   w=np.asarray(d['W'][0,1:]).mean(axis=2); v=np.asarray(d['V'][0]).mean(axis=2); t=np.asarray(d['T'][0]).mean(axis=2)+300
   zf=(np.asarray(d['PH'][0])+np.asarray(d['PHB'][0])).mean(axis=2)/G; zm=(zf[:-1]+zf[1:])/2
   zv=np.empty((NZ,NY+1)); zv[:,1:-1]=(zm[:,:-1]+zm[:,1:])/2; zv[:,0]=zm[:,0]; zv[:,-1]=zm[:,-1]
   C[run,h]=({'W':w,'V':v,'theta':t},{'W':zf[1:],'V':zv,'theta':zm},{'W':(np.arange(NY)+.5)*DY/1000,'V':np.arange(NY+1)*DY/1000,'theta':(np.arange(NY)+.5)*DY/1000},p)
 return C[run,h]

def norm(data):
 m=max(np.nanpercentile(np.abs(data),99.5),1e-12); return TwoSlopeNorm(vmin=-m,vcenter=0,vmax=m)
# Endpoint maps: raw fields then changes from initial; columns ARK / RK3 / ARK-RK3.
for h in (18,24,30,36):
 a,za,ya,_=get('ao',h); r,zr,yr,_=get('r',h); a0=get('ao',0)[0]; r0=get('r',0)[0]
 fig,ax=plt.subplots(6,3,figsize=(17,19),constrained_layout=True)
 fig.suptitle(f'{h} h raw WRF x-mean y-z fields: ARK h=600 s vs RK3 h=600 s\nNative Y/Z stagger; column 3 is ARK−RK3',fontsize=15)
 for i,var in enumerate(VARS*2):
  actual=i<3; row=i%3
  vals=[a[var],r[var],a[var]-r[var]] if actual else [a[var]-a0[var],r[var]-r0[var],(a[var]-a0[var])-(r[var]-r0[var])]
  n=norm(np.concatenate([x.ravel() for x in vals[:2]])) if actual else norm(vals[2])
  if actual and var=='theta':
   from matplotlib.colors import Normalize
   ntheta=Normalize(vmin=min(np.nanpercentile(vals[0],.5),np.nanpercentile(vals[1],.5)),vmax=max(np.nanpercentile(vals[0],99.5),np.nanpercentile(vals[1],99.5)))
  for j in range(3):
   axx=ax[i,j]; y=ya[var] if j!=1 else yr[var]; z=za[var] if j!=1 else zr[var]
   use_n=ntheta if actual and var=='theta' and j<2 else (norm(vals[2]) if actual and var=='theta' and j==2 else n)
   use_cmap='viridis' if actual and var=='theta' and j<2 else 'RdBu_r'
   m=axx.pcolormesh(y,z/1000,vals[j],shading='auto',cmap=use_cmap,norm=use_n,rasterized=True)
   if j==0: axx.set_ylabel(f'{var} '+('actual' if actual else 'change from 0 h')+f'\nheight (km)')
   if i==0: axx.set_title(['ARK','RK3','ARK − RK3'][j])
   axx.set_ylim(0,22)
   if i==5: axx.set_xlabel('Y (km)')
   fig.colorbar(m,ax=axx,pad=.01,shrink=.72,label=UN[var])
 fig.savefig(O/f'cross_sections_{h:02d}h.png',dpi=150); plt.close(fig)
# spectral mode analysis: DCT-II W/T (even reflection), DST-I V (zero wall endpoints).
def coeff(x,v): return dst(x[:,1:-1],type=1,axis=1,norm='ortho') if v=='V' else dct(x,type=2,axis=1,norm='ortho')
common=sorted(set(I['an'])&set(I['r'])); hrs={k:sorted(I[k]) for k in I}
fig=plt.figure(figsize=(16,16),constrained_layout=True); gs=fig.add_gridspec(4,3,height_ratios=[1,1,1,.72]); fig.suptitle('Y-mode RMS of changes from each run’s own initial state; high band k≥20 (λ≤800 km)\nARK every 3 h; RK3 and ARK−RK3 only at shared 6 h outputs',fontsize=15)
metrics={}; curve_data={}
for i,v in enumerate(VARS):
 rowdata=[]
 for j,run in enumerate(['an','r','delta']):
  hs=hrs['an'] if run=='an' else common; ss=[]
  for h in hs:
   aa=get('an',h)[0][v]-get('an',0)[0][v]
   if run=='an': x=aa
   else:
    rr=get('r',h)[0][v]-get('r',0)[0][v]; x=aa-rr if run=='delta' else rr
   cc=coeff(x,v); ss.append(np.sqrt(np.mean(cc**2,axis=0)))
  S=np.array(ss).T; rowdata.append((run,hs,S))
 finite_logs=np.concatenate([np.log10(S[S>1e-10]) for _,_,S in rowdata if np.any(S>1e-10)])
 vmin=float(np.percentile(finite_logs,5)); vmax=float(np.percentile(finite_logs,99.5))
 for j,(run,hs,S) in enumerate(rowdata):
  modes=np.arange(len(S)) if v!='V' else np.arange(1,len(S)+1)
  ax=fig.add_subplot(gs[i,j]); im=ax.pcolormesh(hs,modes,np.log10(np.maximum(S,1e-14)),shading='nearest',cmap='magma',vmin=vmin,vmax=vmax)
  band=S[20 if v!='V' else 19:,:]; hrms=np.sqrt(np.mean(band**2,axis=0)); curve_data[(v,run)]=(hs,hrms)
  metrics[f'{v}_{run}']={'hours':hs,'high_band_rms':hrms.tolist(),'band_modes':'k>=20','coefficient_rms':S.tolist()}
  ax.axhline(19.5,color='cyan',ls='--',lw=.8); ax.set_ylim((-.5 if v!='V' else .5),min(40.5,float(modes[-1])+.5))
  if i==0: ax.set_title(['ARK actual change','RK3 actual change','ARK−RK3 change'][j])
  if j==0: ax.set_ylabel(f'{v} Y mode k')
  if i==2: ax.set_xlabel('lead time (h)')
  fig.colorbar(im,ax=ax,label='log10 mode RMS ('+UN[v]+')')
# One high-band time-series panel per variable. ARK lines use every archived 3 h;
# RK3 circles and the difference use only common 6 h outputs (no interpolation).
for i,v in enumerate(VARS):
 ax=fig.add_subplot(gs[3,i])
 for run,label,color,marker in [('an','ARK (3 h)','#1f77b4','-'),('r','RK3 (6 h)','#ff7f0e','o'),('delta','ARK−RK3 (6 h)','#2ca02c','s')]:
  hh,yy=curve_data[(v,run)]; ax.plot(hh,yy,marker if run!='an' else marker,color=color,label=label,ms=4,lw=1.4)
 ax.set_title(f'{v} modal coefficient RMS (k≥20)'); ax.set_xlabel('lead time (h)'); ax.set_ylabel(UN[v]); ax.grid(alpha=.25); ax.legend(fontsize=7)
fig.savefig(O/'early_y_mode_growth.png',dpi=160); plt.close(fig)
(O/'high_y_band_metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
# Direct high-band reconstructions of actual changes at the common 36 h endpoint.
def hp(x,v):
 if v=='V':
  c=dst(x[:,1:-1],type=1,axis=1,norm='ortho'); c[:,:19]=0; return np.pad(idst(c,type=1,axis=1,norm='ortho'),((0,0),(1,1)))
 c=dct(x,type=2,axis=1,norm='ortho'); c[:,:20]=0; return idct(c,type=2,axis=1,norm='ortho')
a,za,ya,_=get('ao',36); r,zr,yr,_=get('r',36); a0=get('ao',0)[0]; r0=get('r',0)[0]
fig,ax=plt.subplots(3,3,figsize=(17,12),constrained_layout=True); fig.suptitle('36 h high-Y part of actual x-mean changes (modes ≥20; λ≤800 km)\nMatched color scale within each variable: ARK, RK3, and ARK−RK3',fontsize=15); peaks={}
for i,v in enumerate(VARS):
 aa=hp(a[v]-a0[v],v); rr=hp(r[v]-r0[v],v); dd=aa-rr; arrays=[aa,rr,dd]; peaks[v]={}
 lim=max(float(np.nanpercentile(np.abs(q),99.5)) for q in arrays); n=TwoSlopeNorm(vmin=-lim,vcenter=0,vmax=lim)
 for j,q in enumerate(arrays):
  zz=za[v] if j!=1 else zr[v]; yy=ya[v] if j!=1 else yr[v]
  iz,iy=np.unravel_index(np.argmax(np.abs(q)),q.shape); ypk=float(yy[iy]); zpk=float(zz[iz,iy]/1000)
  peaks[v][['ark','rk3','ark_minus_rk3'][j]]={'native_y_index':int(iy),'native_z_index':int(iz),'y_km':ypk,'z_km':zpk,'highpass_abs':float(abs(q[iz,iy]))}
  m=ax[i,j].pcolormesh(yy,zz/1000,q,shading='auto',cmap='RdBu_r',norm=n,rasterized=True)
  if j==0: ax[i,j].set_ylabel(f'{v} high-pass\nheight (km)')
  pk=peaks[v][['ark','rk3','ark_minus_rk3'][j]]
  method=['ARK actual change','RK3 actual change','ARK−RK3 change'][j]
  ax[i,j].set_title(f"{method}\npeak (j,k)=({pk['native_y_index']},{pk['native_z_index']}), Y={pk['y_km']:.0f} km, Z={pk['z_km']:.2f} km",fontsize=8.5)
  if i==2: ax[i,j].set_xlabel('Y (km)')
  ax[i,j].set_ylim(0,22); fig.colorbar(m,ax=ax[i,j],label=UN[v],shrink=.8)
fig.savefig(O/'ark36h_high_y_zoom.png',dpi=170); plt.close(fig)
(O/'zoom_peak_locations.json').write_text(json.dumps(peaks,indent=2)+'\n')
# Raw frame hashes and coordinate/protocol receipts.
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()
used={}
for key,hs in [('ao',[0,6,12,18,24,30,36]),('an',hrs['an']),('r',sorted(set(hrs['r'])&set([0,6,12,18,24,30,36])) )]: used[key]={str(h):{'path':str(I[key][h]),'sha256':sha(I[key][h])} for h in hs}
(O/'raw_frame_hashes.json').write_text(json.dumps({'source_revision':'8dc34517336c901a5ec70bc990c5d0d87995e842','grid':{'nx':40,'ny':80,'nz':64,'DX_m':100000,'DY_m':100000,'g_m_s2':G},'protocol':'x mean actual fields; W bottom-face excluded; V physical y walls retained; height PH+PHB/g; theta=T+300; initial changes from each run t0; DCT-II W/theta; DST-I V; high band mode >=20','frames':used},indent=2)+'\n')
print(json.dumps(peaks,indent=2)); print('plots',*[p.name for p in sorted(O.glob('*.png'))])
