"""Focused W maps and grid-scale Y-band RMS; separate k>=40 protocol."""
import hashlib, json
from pathlib import Path
import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from netCDF4 import Dataset
from scipy.fft import dct, idct, dst, idst
O=Path(__file__).resolve().parent
ROOTS={'ark':'/Users/yhlee/AD-SDIRK3-review-evidence/ark600-five-day-20261025/runs/ark_h600',
       'rk3':'/Users/yhlee/AD-SDIRK3-review-evidence/standard-forward-comparison-20261024/runs/rk3_h600',
       'ark3h':'/Users/yhlee/AD-SDIRK3-review-evidence/ark600-3hour-continuous-20261027/runs/ark_h600'}
DY=100000.; G=9.81; NY=80

def index(root):
 out={}
 for p in Path(root).glob('wrfout_d01*'):
  with Dataset(p) as d:
   for r in d['Times'][:]:
    s=b''.join(r).decode().rstrip(); out[int(s[11:13])+24*(int(s[8:10])-1)]=p
 return out
IDX={k:index(v) for k,v in ROOTS.items()}
def read(run,h):
 p=IDX[run][h]
 with Dataset(p) as d:
  # Native W: bottom fixed z face excluded, all owned y/x points retained.
  w=np.asarray(d['W'][0,1:,:,:],dtype=np.float64)
  z=((np.asarray(d['PH'][0])+np.asarray(d['PHB'][0])).mean(axis=2)/G)[1:]
  return w,z,p

def hp_k40(a,var):
 if var=='V':
  c=dst(a[:,1:-1,:],type=1,axis=1,norm='ortho'); c[:,:39,:]=0
  interior=idst(c,type=1,axis=1,norm='ortho')
  return np.pad(interior,((0,0),(1,1),(0,0))) # restore both zero-valued physical walls
 c=dct(a,type=2,axis=1,norm='ortho'); c[:,:40,:]=0
 return idct(c,type=2,axis=1,norm='ortho')

def read_var(run,h,var):
 p=IDX[run][h]
 with Dataset(p) as d:
  if var=='W': return np.asarray(d['W'][0,1:,:,:],dtype=np.float64)
  if var=='V': return np.asarray(d['V'][0,:,:,:],dtype=np.float64)
  return np.asarray(d['T'][0,:,:,:],dtype=np.float64)+300.0

def read_ark_var(h,var): return read_var('ark3h' if h in IDX['ark3h'] else 'ark',h,var)

def rms(a): return float(np.sqrt(np.mean(np.square(a),dtype=np.float64)))

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()
# Grid-scale (Y wavelength <= 4*DY) RMS after reconstructing k>=40 to native
# physical points. This includes all owned points; V's two zero wall values
# are restored before the RMS denominator is formed.
hours_ark=sorted(set(IDX['ark3h']) | set(IDX['ark']))
common=sorted(set(hours_ark)&set(IDX['rk3'])&set(range(0,37,6)))
series={}
for var in ('W','V','theta'):
 series[var]={}
 for kind in ('raw','change'):
  runs={}
  for name,hs in [('ark',hours_ark),('rk3',[h for h in sorted(IDX['rk3']) if h<=36])]:
   reader=(lambda h:read_ark_var(h,var)) if name=='ark' else (lambda h:read_var('rk3',h,var))
   init=reader(0); vals={}
   for h in hs:
    field=reader(h); source=field if kind=='raw' else field-init
    vals[h]=rms(hp_k40(source,var))
   runs[name]=vals
  vals={}
  for h in common:
   wa=read_ark_var(h,var); wr=read_var('rk3',h,var)
   delta=wa-wr if kind=='raw' else (wa-read_ark_var(0,var))-(wr-read_var('rk3',0,var))
   vals[h]=rms(hp_k40(delta,var))
  runs['ark_minus_rk3']=vals
  series[var][kind]=runs
# 6 panels: actual x-mean W at 24/36 h, matched color normalization, full physical Z.
fig,axs=plt.subplots(2,3,figsize=(17,10),constrained_layout=True)
fig.suptitle('Raw x-mean W at 24 h and 36 h | ARK h=600 s, RK3 h=600 s\nY=4000–8000 km; full PH+PHB/g height including model top; matched color scale',fontsize=15)
arrays={}; zs={}; ymax=0.
for h in (24,36):
 for run in ('ark','rk3'):
  w,z,_=read(run,h); arrays[(h,run)]=w.mean(axis=2); zs[(h,run)]=z; ymax=max(ymax,float(np.nanmax(z)))
 arrays[(h,'delta')]=arrays[(h,'ark')]-arrays[(h,'rk3')]
# One scale for all panels so time/method magnitude is directly comparable.
lim=float(np.nanpercentile(np.abs(np.concatenate([a.ravel() for a in arrays.values()])),99.5)); norm=TwoSlopeNorm(vmin=-lim,vcenter=0,vmax=lim)
y=(np.arange(NY)+.5)*DY/1000
for i,h in enumerate((24,36)):
 for j,run in enumerate(('ark','rk3','delta')):
  ax=axs[i,j]; keyrun={'delta':'delta'}.get(run,run); data=arrays[(h,keyrun)]; z=zs.get((h,run),zs[(h,'ark')])
  m=ax.pcolormesh(y,z/1000,data,shading='auto',cmap='RdBu_r',norm=norm,rasterized=True)
  ax.set_xlim(4000,8000); ax.set_ylim(0,ymax/1000+.25)
  ax.set_ylabel(f'{h} h | height (km)') if j==0 else None
  ax.set_xlabel('Y (km)')
  ax.set_title({'ark':'ARK actual W','rk3':'RK3 actual W','delta':'ARK − RK3 actual W'}[run])
  fig.colorbar(m,ax=ax,label='m s$^{-1}$',shrink=.86)
fig.savefig(O/'focus_w_24_36h.png',dpi=180); plt.close(fig)
# Physical RMS curves for W/V/theta: rows actual raw and initial change, columns variables.
fig,axs=plt.subplots(2,3,figsize=(16,8),constrained_layout=True)
fig.suptitle('Y-grid-scale RMS after native-space reconstruction (k≥40; λ≤4Δy)\nRMS over owned physical points; V includes both zero-valued wall points',fontsize=14)
units={'W':'m/s','V':'m/s','theta':'K'}
for i,(kind,title) in enumerate([('raw','Actual raw fields'),('change','Change from each run’s own 0 h field')]):
 for j,var in enumerate(('W','V','theta')):
  ax=axs[i,j]
  for key,label,color,marker in [('ark','ARK 3 h cadence','#1f77b4','o'),('rk3','RK3 6 h cadence','#ff7f0e','s'),('ark_minus_rk3','ARK−RK3 common 6 h','#2ca02c','^')]:
   xs=sorted(series[var][kind][key]); ys=[series[var][kind][key][h] for h in xs]
   ax.plot(xs,ys,color=color,marker=marker,label=label,ms=3.5,lw=1.4)
  ax.set_title(f'{title}: {var}'); ax.set_xlabel('lead time (h)'); ax.set_ylabel(f'RMS ({units[var]})'); ax.grid(alpha=.25)
  if i==0 and j==0: ax.legend(fontsize=7)
fig.savefig(O/'physical_rms_k40.png',dpi=170); plt.close(fig)
frames={}
for run,hs in [('ark',[0,24,30,36]),('rk3',[0,6,12,18,24,30,36]),('ark3h',sorted(IDX['ark3h']))]:
 frames[run]={str(h):{'path':str(IDX[run][h]),'sha256':sha(IDX[run][h])} for h in hs}
receipt={'protocol_version':'k40-native-reconstruction-v2-all-fields','source_revision':'8dc34517336c901a5ec70bc990c5d0d87995e842','transform':{'W':'DCT-II over 80 scalar mass-y points; zero modes k=0..39','V':'DST-I over 79 interior y points; zero modes k=1..39; inverse transform and pad both zero physical wall values','theta':'DCT-II over 80 mass-y points; zero modes k=0..39'},'band':'k>=40, lambda=2*L_y/k <= 4*DY = 400 km','metric':'for each field, reconstruct k>=40 then sqrt(mean(field_hp**2)) over all owned physical z/y/x points; V denominator includes 64x81x40 and both zero wall faces; no retained-coefficient RMS','ark_timeseries':'3-hour continuous outputs through 27 h plus archived 6-hour frames at 30 and 36 h; common old/new ARK frames match SHA-256 at 0,6,12,18,24 h','comparison_horizon_hours':36,'W_policy':'exclude fixed lower W face, keep all owned y/x points','map_geometry':'x-mean W, Y mass centers (j+0.5)DY, Z=(PH+PHB)/g at W vertical faces; y window 4000..8000km; top is max PH+PHB/g plus 0.25km plot margin','spacing_m':{'DX':100000,'DY':100000},'grid':{'nx':40,'ny':80,'nz_owned_w':64,'nz_mass':64,'g':G},'frames':frames,'series':series,'old_k20_metric_note':'high_y_band_metrics.json high_band_rms is RMS of retained modal coefficient RMS values, not reconstructed physical-space RMS; preserve as exploratory modal metric.'}
(O/'w_k40_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'rms':series['W'],'height_max_m':ymax,'map_lim':lim},indent=2))
