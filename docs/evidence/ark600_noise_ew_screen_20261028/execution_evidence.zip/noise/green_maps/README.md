# Raw WRF high-Y structure maps

Generated: 2026-10-28 22:07 JST (visuals regenerated after scale and mode-index review)  
Source worktree revision: `8dc34517336c901a5ec70bc990c5d0d87995e842` (`/private/tmp/standard-forward-comparison-20261024`; branch `codex/ew-forcing-performance-20261028`, clean at inspection).

## What is plotted

- `cross_sections_{18,24,30,36}h.png`: raw x-mean y-z fields at common lead times. Each image has the actual W, V, and dry potential temperature (T+300 K), their changes from each run's own initial frame, and ARK−RK3. The RK3 and archived ARK h=600 s cases supply all four leads.
- `early_y_mode_growth.png`: mode-by-time amplitudes of each run's own changes plus matched high-band RMS curves. The continuous ARK archive supplies 3-hour snapshots through 27 h. RK3 and ARK−RK3 are plotted only at the shared 6-hour outputs through 24 h; no RK3 3-hour value is inferred.
- `ark36h_high_y_zoom.png`: matched-scale reconstruction of modes k≥20 in the actual 36-hour changes for ARK, RK3, and ARK−RK3, with maximum native indices and physical coordinates in each panel title.
- `high_y_band_metrics.json`, `zoom_peak_locations.json`, and `raw_frame_hashes.json` retain the numeric diagnostics, peak locations, exact input frame SHA-256 values, source revision, and plotting protocol. `plots.py` regenerates the PNGs from those WRF outputs.

## Coordinate and field policy

The archived cases are the 40×80×64 `wrfout` grids with DX=DY=100 km. Arrays follow the frozen `tools/benchmark_wrf_accuracy_cost.py` ownership convention: exclude W's fixed bottom face, retain both physical V y walls, and use all T mass points. W is plotted at native vertical faces; V keeps native y faces at y=j·DY; W and theta use y mass centers at (j+0.5)·DY. Physical height is `(PH+PHB)/9.81` m. For T/theta, adjacent face heights are averaged vertically. For V, mass-y heights are interpolated to interior y faces and nearest mass columns set the two wall heights. The x-mean fields and heights are plotted on their corresponding native y/z positions. Theta is T+300 K; theta changes are exactly T(t)−T(0).

The high-Y diagnostic uses DCT-II for W and theta's even-reflection scalar boundaries, and DST-I on V's interior with the physical zero wall endpoints. It does not use a periodic Y FFT. The displayed/aggregated high band is k≥20, corresponding to wavelengths ≤800 km on the 8000 km Y span. Modal amplitudes are RMS over vertical levels for each mode; the high-band curve is RMS over those mode amplitudes. This is a locator diagnostic, not by itself proof that every high mode is nonphysical noise.

The old and continuous ARK output files at 0, 6, 12, 18, and 24 h have identical SHA-256 hashes. The h=600 s RK3 outputs are every 6 h. There was no model or production-code change and no model rerun for this analysis.

## Findings from the plotted fields

- W is the clearest ARK-specific high-Y feature. At 36 h, ARK has strong vertically alternating bands concentrated around Y≈4,800–7,800 km and Z≈7–16 km. RK3's corresponding high-pass W is much weaker there. The strongest ARK high-pass point is native owned-array `(j_y,k_z)=(75,40)` (W k starts after the excluded fixed bottom face), Y=7,550 km, Z=9.37 km, amplitude 0.00968 m/s; the RK3 maximum is 0.00178 m/s at `(57,57)`, Y=5,750 km, Z=13.86 km.
- At common lead times, the W high-band change-RMS separation grows after 12 h: ARK−RK3 is 0.000114 m/s at 12 h, 0.000380 at 18 h, and 0.000477 at 24 h. ARK's 3 h value is already 0.000653 m/s, but RK3 has no 3 h output, and its first 6 h value (0.000594) is similar to the ARK 3 h value. Thus these files locate later ARK-specific growth but do not prove an ARK-only onset at 3 h.
- V's high-Y band is large in both methods and declines at similar rates through 24 h (0.05735 m/s ARK and 0.05704 m/s RK3 at 18 h). Theta's high-band RMS also tracks closely through 18 h (0.07070 K ARK and 0.07061 K RK3); its ARK−RK3 component rises by 24 h. At 36 h, the largest high-pass V values are similar in both methods (0.2869 vs 0.2817 m/s), as are theta (0.9916 vs 0.9841 K). These shared components should not be attributed to ARK alone.
- The plotted evidence supports investigating Y-edge/stagger-aware high-mode damping or its numerical source for the W growth. It is not enough to select a filter or prescribe a code change; the timing and variable coupling still need a targeted numerical diagnosis.

## Validation scope

Inspected the generated 36 h raw cross-section, high-Y mode/time figure, and matched-scale 36 h high-pass map in the image viewer. No numerical tests or model runs were requested or performed. All referenced input snapshots are pinned in `raw_frame_hashes.json`.


## Grid-scale physical-space addendum (protocol v2)

- `focus_w_24_36h.png` is the focused six-panel raw W view at 24/36 h, Y=4000–8000 km and full physical height (PH+PHB)/g through the model top, on one matched color scale.
- `physical_rms_k40.png` and `w_k40_receipt.json` add the corrected k≥40 grid-scale RMS. Each field is transformed along Y, modes below 40 are zeroed, the high-band is inverse transformed, then RMS is computed over all owned physical points. W uses DCT-II on its 80 mass-y locations and excludes its fixed lower face; V uses DST-I on its 79 interior points and restores both zero wall points before RMS over the full 81-point y extent; theta uses DCT-II and T+300 K. At DX=DY=100 km, k≥40 means wavelength ≤400 km (4Δy). RK3 and ARK−RK3 are shown only at common 6-hour leads; ARK uses the continuous 3-hour archive through 27 h and the byte-identical archived 6-hour outputs at 30/36 h. Both raw-field and own-initial-change curves include 0 h. W's raw and change curves coincide because W(0)=0.
- W k≥40 physical RMS grows from 0.000548 m/s at 24 h to 0.001391 at 30 h and 0.002480 at 36 h. RK3 is 0.000360, 0.000332, and 0.000319 m/s at those leads; the reconstructed ARK−RK3 RMS is 0.000417, 0.001362, and 0.002459 m/s. This verifies that the late northern W bands occupy the grid-scale band. V's RMS includes its zero walls; no retained-modal RMS is used in this addendum.
- The earlier k≥20 files remain exploratory. In particular, `high_y_band_metrics.json` field `high_band_rms` is a modal-coefficient RMS aggregate, not a reconstructed physical-space RMS; `early_y_mode_growth.png` now labels those curves “modal coefficient RMS”.

- `horizontal_w_eta_k41_36h.png` adds the actual 36 h XY plane at native W eta face k=41 (owned k=40), with ARK, RK3 and ARK−RK3. It uses native X/Y mass centers and full domain; the title gives PH+PHB/g range 9.34–10.63 km. This plane is not constant physical height.
