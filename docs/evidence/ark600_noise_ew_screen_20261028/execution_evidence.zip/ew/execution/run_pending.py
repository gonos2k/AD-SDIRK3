#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[1]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(v): (R/'pending_receipt.json').write_text(json.dumps(v,indent=2)+'\n')
a=json.loads((R/'manifest.json').read_text());b=json.loads((R/'manifest_remaining.json').read_text());a.pop('controller_sha256');expected=b.pop('controller_sha256');assert a==b
q=json.loads((R/'A0_caller_qualification.json').read_text());assert sha(R/'runs/A0/forecast_receipt.json')==q['original_receipt_sha256'] and q['converged_stages']==18 and q['max_final_nonlinear_residual']<=1e-9
controller=R/'execution/run_case_remaining.py';assert sha(controller)==expected
assert not(R/'pending_receipt.json').exists()
v={'started_local':datetime.now().astimezone().isoformat(),'status':'running','remaining_order':['B0','B1','A1'],'A0_not_rerun':True,'A0_original_receipt_sha256':q['original_receipt_sha256'],'remaining_manifest_sha256':sha(R/'manifest_remaining.json'),'controller_sha256':expected,'cases':[]};save(v)
for name in v['remaining_order']:
 assert not(R/'runs'/name/'forecast_intent.json').exists()
 cmd=[sys.executable,'-B',str(controller),'--manifest',str(R/'manifest_remaining.json'),'--manifest-sha256',v['remaining_manifest_sha256'],'--case',name,'--go']
 rc=subprocess.run(cmd,cwd=R).returncode
 f=R/'runs'/name/'forecast_receipt.json';d=json.loads(f.read_text()) if f.exists() else {}
 v['cases'].append({'case':name,'controller_return_code':rc,'model_return_code':d.get('return_code'),'status':d.get('status'),'stop_reason':d.get('stop_reason'),'receipt_sha256':sha(f) if f.exists() else None});save(v)
 if rc!=0 or d.get('status')!='completed':v.update(status='failed',stopped_after=name);save(v);sys.exit(2)
v.update(status='all_pending_completed',finished_local=datetime.now().astimezone().isoformat());save(v)
