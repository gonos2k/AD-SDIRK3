#!/usr/bin/env python3
"""Analyze a completed EW-forcing ABBA block; never launches or alters WRF."""
from datetime import datetime
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import statistics
import sys

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
ORDER = ("A0", "B0", "B1", "A1")
EPS32 = float(np.finfo(np.float32).eps)
TIME_RE = re.compile(r"Timing for main:\s*time\s+(\S+)\s+on\s+domain\s+\d+:\s*([0-9.eE+-]+)\s+elapsed\s+seconds")
FGMRES_RE = re.compile(r"\[FGMRES\]\s+(CONVERGED|NOT CONVERGED):\s*(.*)")


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def fields(text):
    values = {}
    for item in text.split(","):
        key, sep, value = item.partition("=")
        if sep:
            values[key.strip()] = value.strip()
    return values


def assign_outer_steps(rows):
    step, previous = 0, None
    for row in rows:
        stage = int(row["stage"])
        if stage == 2 and previous == 4:
            step += 1
        elif step == 0:
            step = 1
        row["outer_step"] = step
        previous = stage
    return rows


def parse_logs(case_dir):
    out = (case_dir / "rsl.out.0000").read_text(errors="replace")
    err = (case_dir / "rsl.error.0000").read_text(errors="replace")
    times = [{"timestamp": m.group(1), "seconds": float(m.group(2))}
             for m in TIME_RE.finditer(out)]
    solver, stages, fgmres, effective, budget = [], [], [], [], []
    for line in err.splitlines():
        if "[SOLVER TELEMETRY]" in line:
            solver.append(fields(line.split("[SOLVER TELEMETRY]", 1)[1]))
        elif "[STAGE METRIC TELEMETRY]" in line:
            stages.append(fields(line.split("[STAGE METRIC TELEMETRY]", 1)[1]))
        else:
            match = FGMRES_RE.search(line)
            if match:
                fgmres.append({"status": match.group(1), **fields(match.group(2))})
            if "[CONFIG EFFECTIVE] solver:" in line:
                effective.append(fields(line.split("solver:", 1)[1]))
            if "[CONFIG EFFECTIVE] r49:" in line:
                budget.append(fields(line.split("r49:", 1)[1]))
    assign_outer_steps(solver)
    assign_outer_steps(stages)
    linked = []
    if len(solver) == len(fgmres):
        for row, gm in zip(solver, fgmres):
            linked.append({"outer_step": row["outer_step"], "stage": int(row["stage"]),
                           "newton": int(row["newton"]),
                           "jvp_calls": int(row["jvp_calls"]),
                           "jvp_ms": float(row["jvp_ms"]),
                           "gmres_relative_error": float(row["gmres_rel"]),
                           "fgmres_status": gm["status"],
                           "fgmres_raw_true_residual": float(gm["residual_norm_raw"]),
                           "fgmres_relative_error": float(gm["rel_error"]),
                           "fgmres_restart_cycles": int(gm["restarts"]),
                           "fgmres_arnoldi_iterations": int(gm["arnoldi"]),
                           "ew_eta_enabled": row["ew_eta_enabled"], "ew_eta": float(row["ew_eta"]),
                           "budget_coupled": row["budget_coupled"],
                           "budget_scale": float(row["budget_scale"])})
    return {"main_times": times, "solver": solver, "stages": stages,
            "fgmres": fgmres, "linked_newton": linked,
            "effective_config": effective, "budget_config": budget,
            "abort_markers": len(re.findall(r"final_update_aborted=[1-9]|outcome=HARD_STAGE_ABORT", err)),
            "jvp_diag_count": (out + err).count("[JVP DIAG]"),
            "stage_csv_count": len(list(case_dir.glob("*.csv")))}


def qualify_a0(root):
    case_dir = root / "runs" / "A0"
    receipt_path = case_dir / "forecast_receipt.json"
    qualification_path = root / "A0_caller_qualification.json"
    block_path = root / "block_receipt.json"
    if not all(p.is_file() for p in (receipt_path, qualification_path, block_path)):
        raise FileNotFoundError("A0 caller qualification, raw receipt, or original block receipt is missing")
    receipt = json.loads(receipt_path.read_text())
    qualification = json.loads(qualification_path.read_text())
    block = json.loads(block_path.read_text())
    digest = sha256(receipt_path)
    counts = receipt.get("quiet_diagnostic_counts", {})
    allowed = {"[SOLVER TELEMETRY]", "[Newton] JVP calls:", "[GMRES] CONVERGED", "[FGMRES] CONVERGED"}
    disallowed = {k: v for k, v in counts.items() if k not in allowed and v}
    attempts = block.get("cases", [])
    okay = (
        digest == qualification.get("original_receipt_sha256") and
        qualification.get("original_status") == receipt.get("status") == "failed_or_incomplete" and
        receipt.get("manifest_sha256") == sha256(root / "manifest.json") and
        receipt.get("return_code") == 0 and receipt.get("stop_reason") is None and
        receipt.get("actual_outer_step_count") == 6 and
        receipt.get("terminal_wrapper_calls_ok") is True and
        receipt.get("terminal_fortran_wrapper_calls") == [[18, 0]] and
        receipt.get("success_marker") is True and
        receipt.get("initial_gate", {}).get("status") == "passed" and
        receipt.get("output_check") is not None and
        receipt.get("newton_converged_stage_log_records") == 18 and
        qualification.get("model_return_code") == 0 and
        qualification.get("converged_stages") == 18 and
        math.isfinite(float(qualification.get("max_final_nonlinear_residual", math.nan))) and
        float(qualification.get("max_final_nonlinear_residual", math.inf)) <= 1e-9 and
        qualification.get("output_checked") is True and
        qualification.get("matched_diagnostic_eligible") is True and
        qualification.get("cost_eligible_general") is False and
        disallowed == {"[Newton] CONVERGED": 18} and
        block.get("status") == "failed" and block.get("stopped_after") == "A0" and
        len(attempts) == 1 and attempts[0].get("case") == "A0" and
        attempts[0].get("receipt_sha256") == digest and attempts[0].get("return_code") == 2
    )
    return {"qualified_for_field_and_jvp_analysis": okay,
            "raw_controller_status": receipt.get("status"),
            "raw_receipt_sha256": digest,
            "sole_false_reject_count": disallowed,
            "timing_status": "provisional_due_to_controller_quiet_policy_mismatch",
            "qualification_path": str(qualification_path)}


def check_case(helper, manifest, name, expected_manifest_sha, allow_a0_qualification=False):
    case = manifest["cases"][name]
    case_dir = Path(case["directory"])
    receipt_path = case_dir / "forecast_receipt.json"
    if not receipt_path.is_file():
        raise FileNotFoundError(f"{name}: missing forecast receipt")
    receipt = json.loads(receipt_path.read_text())
    logs = parse_logs(case_dir)
    issues = []
    if receipt.get("manifest_sha256") != expected_manifest_sha:
        issues.append("receipt manifest SHA-256 differs from its assigned controller manifest")
    if (receipt.get("return_code") != 0 or
            receipt.get("actual_outer_step_count") != 6 or
            receipt.get("terminal_wrapper_calls_ok") is not True):
        issues.append("case receipt is not an RC=0 six-step run with 18 wrapper calls")
    if receipt.get("status") != "completed" and not allow_a0_qualification:
        issues.append("raw controller status is not completed")
    if logs["abort_markers"]:
        issues.append(f"{logs['abort_markers']} aborted-update/hard-stage markers")
    if logs["jvp_diag_count"] or logs["stage_csv_count"]:
        issues.append("detailed JVP diagnostics or stage CSV output was emitted")
    if len(logs["main_times"]) != 6 or any(not math.isfinite(x["seconds"]) or x["seconds"] <= 0
                                               for x in logs["main_times"]):
        issues.append("RSL does not contain six finite positive main-step timings")
    if len(logs["stages"]) != 18:
        issues.append(f"expected 18 stage metrics, found {len(logs['stages'])}")
    stage_counts = {s: sum(int(r.get("stage", -1)) == s for r in logs["stages"]) for s in (2, 3, 4)}
    for row in logs["stages"]:
        try:
            rho = float(row["rho_newton_scaled_exit"])
            if int(row["converged"]) != 1 or not math.isfinite(rho) or rho < 0.0 or rho > 1e-9:
                issues.append(f"stage {row.get('stage')} outer {row.get('outer_step')} failed Newton gate")
        except (KeyError, ValueError):
            issues.append("stage metric missing converged/rho_newton_scaled_exit")
    if stage_counts != {2: 6, 3: 6, 4: 6}:
        issues.append(f"unexpected implicit stage counts: {stage_counts}")
    if len(logs["solver"]) != len(logs["fgmres"]) or not logs["linked_newton"]:
        issues.append("FGMRES and per-Newton telemetry records do not pair one-to-one")
    for row in logs["linked_newton"]:
        expected_ew = "yes" if name.startswith("B") else "no"
        if row["ew_eta_enabled"] != expected_ew:
            issues.append(f"outer {row['outer_step']} stage {row['stage']} EW-enable differs from arm")
        if row["budget_coupled"] != "no" or not math.isclose(row["budget_scale"], 1.0):
            issues.append(f"outer {row['outer_step']} stage {row['stage']} changed Krylov budget")
        if name.startswith("B") and not (1e-7 <= row["ew_eta"] <= 0.1):
            issues.append(f"candidate EW eta outside pinned bounds: {row['ew_eta']}")
    if not logs["effective_config"] or any(
            int(r.get("gmres_restart", -1)) != 30 or int(r.get("max_krylov", -1)) != 50
            for r in logs["effective_config"]):
        issues.append("effective GMRES restart/max-cycle budget is not 30/50 in RSL")
    if not logs["budget_config"] or any(
            r.get("stage2_budget") != "0/0/0" or r.get("stage3_budget") != "0/0/0"
            for r in logs["budget_config"]):
        issues.append("effective stage-2/3 budget knobs are not all zero")

    run = {"label": name, "path": str(case_dir), "method": case["method"],
           "h_seconds": case["h_seconds"], "input_sha256": manifest["common_input"]["sha256"],
           "executable_path": manifest["executable"]["path"],
           "executable_sha256": manifest["executable"]["sha256"],
           "namelist_sha256": case["namelist_sha256"]}
    loaded = helper._load_run(run, ROOT, manifest["analysis_contract"])
    summary = {"controller_status": receipt.get("status"), "return_code": receipt.get("return_code"),
               "manifest_sha256": receipt.get("manifest_sha256"),
               "outer_steps": receipt.get("actual_outer_step_count"),
               "initial_gate": receipt.get("initial_gate", {}).get("status"),
               "stage_counts": stage_counts, "rsl_step_seconds": [x["seconds"] for x in logs["main_times"]],
               "total_jvp_calls": sum(x["jvp_calls"] for x in logs["linked_newton"]),
               "total_jvp_ms": sum(x["jvp_ms"] for x in logs["linked_newton"]),
               "solver_telemetry": logs["linked_newton"], "stage_metrics": logs["stages"],
               "fgmres_record_count": len(logs["fgmres"]),
               "fgmres_not_converged_count": sum(x["status"] != "CONVERGED" for x in logs["fgmres"]),
               "abort_markers": logs["abort_markers"], "jvp_diag_count": logs["jvp_diag_count"],
               "stage_csv_count": logs["stage_csv_count"]}
    return loaded, summary, issues


def screen_pair(helper, manifest, left_name, right_name, loaded):
    pair = {name: loaded[name] for name in (left_name, right_name)}
    gate = helper._validate_shared_initial_state(pair, manifest["analysis_contract"])
    left, right = pair[left_name], pair[right_name]
    if left["timestamps"] != right["timestamps"] or len(left["timestamps"]) != 7:
        raise ValueError(f"{left_name}/{right_name}: expected identical seven-frame timestamps")
    fields = list(helper.VARIABLE_UNITS)
    if manifest["analysis_contract"].get("include_total_pressure", False):
        fields.extend(helper.PRESSURE_UNITS)
    reports = []
    for timestamp in left["timestamps"]:
        for field in fields:
            a = np.asarray(left["frames"][timestamp][field])
            b = np.asarray(right["frames"][timestamp][field])
            if a.shape != b.shape:
                raise ValueError(f"{timestamp}/{field}: owned shapes differ: {a.shape} != {b.shape}")
            limit = 8.0 * EPS32 * np.maximum(np.maximum(np.abs(a), np.abs(b)), 1.0)
            delta = np.abs(b - a)
            ratios = delta / limit
            reports.append({"timestamp": timestamp, "field": field, "units": helper.VARIABLE_UNITS.get(field, helper.PRESSURE_UNITS.get(field)),
                            "owned_points": int(a.size), "violations": int(np.count_nonzero(delta > limit)),
                            "max_abs_delta": float(delta.max()), "max_allowed_delta": float(limit.max()),
                            "max_delta_to_allowance": float(ratios.max())})
    return {"left": left_name, "right": right_name, "initial_state_gate": gate,
            "screen": "abs(B-A) <= 8*float32_eps*max(abs(A),abs(B),1) per owned value",
            "checks": reports,
            "passed": gate.get("status") == "passed" and all(x["violations"] == 0 for x in reports)}


def load_rk3_field_reference(helper, manifest, loaded_ark):
    """Optionally include the separate short RK3 run as a field-only comparator."""
    ref_root = ROOT / "rk3_reference"
    ref_manifest_path = ref_root / "manifest.json"
    if not ref_manifest_path.is_file():
        return {"status": "not_available", "reason": "rk3_reference/manifest.json is absent"}
    ref_manifest = json.loads(ref_manifest_path.read_text())
    case = ref_manifest.get("cases", {}).get("rk3_short")
    if not case or case.get("method") != "RK3":
        return {"status": "not_available", "reason": "pinned rk3_short RK3 case is absent"}
    case_dir = Path(case["directory"])
    receipt_path = case_dir / "forecast_receipt.json"
    if not receipt_path.is_file():
        return {"status": "not_available", "reason": "RK3 field-reference receipt is absent"}
    receipt = json.loads(receipt_path.read_text())
    if (receipt.get("manifest_sha256") != sha256(ref_manifest_path) or
            receipt.get("return_code") != 0 or receipt.get("actual_outer_step_count") != 6 or
            receipt.get("initial_gate", {}).get("status") != "passed" or
            receipt.get("output_check") is None):
        return {"status": "not_available", "reason": "RK3 receipt lacks RC=0, six steps, initial gate, or output check"}
    if ref_manifest.get("common_input", {}).get("sha256") != manifest["common_input"]["sha256"]:
        return {"status": "input_mismatch", "reason": "RK3 reference has a different common input"}
    helper_pin = ref_manifest.get("analysis_helper", {})
    helper_path = Path(helper_pin.get("path", ""))
    if not helper_path.is_file() or sha256(helper_path) != helper_pin.get("sha256"):
        return {"status": "helper_mismatch", "reason": "RK3 analysis helper pin does not match"}
    row = {"label": "rk3_short", "path": str(case_dir), "method": "RK3",
           "h_seconds": case["h_seconds"], "input_sha256": ref_manifest["common_input"]["sha256"],
           "executable_path": ref_manifest["executable"]["path"],
           "executable_sha256": ref_manifest["executable"]["sha256"],
           "namelist_sha256": case["namelist_sha256"]}
    rk3 = helper._load_run(row, ROOT, manifest["analysis_contract"])
    joint = {"rk3_short": rk3, **loaded_ark}
    gate = helper._validate_shared_initial_state(joint, manifest["analysis_contract"])
    if gate.get("status") != "passed":
        return {"status": "initial_state_mismatch", "shared_initial_state_gate": gate}
    fields_to_compare = list(helper.VARIABLE_UNITS)
    if manifest["analysis_contract"].get("include_total_pressure", False):
        fields_to_compare.extend(helper.PRESSURE_UNITS)
    times = rk3["timestamps"]
    comparisons = {}
    initial = rk3["frames"][times[0]]
    for name in ORDER:
        comparisons[name] = {
            ts: {field: helper._metrics(loaded_ark[name]["frames"][ts][field],
                                        rk3["frames"][ts][field],
                                        rk3["frames"][ts][field] - initial[field], ())
                 for field in fields_to_compare}
            for ts in times
        }
    return {"status": "available_field_only", "interpretation": "RK3 field comparator, not exact truth",
            "performance_comparison_eligible": False,
            "controller_status": receipt.get("status"),
            "controller_return_code": receipt.get("return_code"),
            "qualification": "Used only because RC=0, six output steps, initial-state gate, and helper output check passed; controller may remain failed_or_incomplete due aggregate quiet-policy checks.",
            "reference_manifest_sha256": sha256(ref_manifest_path),
            "shared_initial_state_gate": gate, "endpoint_timestamp": times[-1],
            "history_files": rk3["wrfout_files"], "comparisons": comparisons}


def main():
    manifest_path = ROOT / "manifest.json"
    protocol_path = ROOT / "protocol.json"
    manifest = json.loads(manifest_path.read_text())
    protocol = json.loads(protocol_path.read_text())
    manifest_sha = sha256(manifest_path)
    if manifest_sha != protocol.get("manifest_sha256"):
        raise ValueError("protocol manifest SHA-256 is stale")
    helper_path = Path(manifest["analysis_helper"]["path"])
    if sha256(helper_path) != manifest["analysis_helper"]["sha256"]:
        raise ValueError("frozen analysis-helper SHA-256 mismatch")
    remaining_path = ROOT / "manifest_remaining.json"
    remaining_controller = ROOT / "execution" / "run_case_remaining.py"
    if not remaining_path.is_file() or not remaining_controller.is_file():
        raise FileNotFoundError("remaining-case manifest/controller is missing")
    remaining_manifest = json.loads(remaining_path.read_text())
    if ({k: v for k, v in remaining_manifest.items() if k != "controller_sha256"} !=
            {k: v for k, v in manifest.items() if k != "controller_sha256"}):
        raise ValueError("remaining manifest differs from the original outside controller SHA")
    remaining_sha = sha256(remaining_path)
    if sha256(remaining_controller) != remaining_manifest.get("controller_sha256"):
        raise ValueError("remaining controller SHA-256 does not match remaining manifest")
    a0_qualification = qualify_a0(ROOT)
    if not a0_qualification["qualified_for_field_and_jvp_analysis"]:
        raise ValueError("A0 caller qualification does not match the immutable raw receipt/gates")
    block_path = ROOT / "block_receipt.json"
    block = json.loads(block_path.read_text())
    if (block.get("manifest_sha256") != manifest_sha or block.get("status") != "failed" or
            block.get("stopped_after") != "A0" or [x.get("case") for x in block.get("cases", [])] != ["A0"]):
        raise ValueError("original block receipt is not the qualified one-attempt A0 stop")
    spec = importlib.util.spec_from_file_location("pinned_accuracy_helper", helper_path)
    helper = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = helper
    spec.loader.exec_module(helper)

    loaded, cases, issues = {}, {}, {}
    for name in ORDER:
        source_manifest = manifest if name == "A0" else remaining_manifest
        loaded[name], cases[name], issues[name] = check_case(
            helper, source_manifest, name,
            manifest_sha if name == "A0" else remaining_sha,
            allow_a0_qualification=(name == "A0"))
    cases["A0"]["caller_qualification"] = a0_qualification
    pairs = [screen_pair(helper, manifest, a, b, loaded) for a, b in (("A0", "B0"), ("A1", "B1"))]
    rk3_reference = load_rk3_field_reference(helper, manifest, loaded)
    baseline_jvp = statistics.median(cases[n]["total_jvp_calls"] for n in ("A0", "A1"))
    candidate_jvp = statistics.median(cases[n]["total_jvp_calls"] for n in ("B0", "B1"))
    baseline_steps = [t for n in ("A0", "A1") for t in cases[n]["rsl_step_seconds"]]
    candidate_steps = [t for n in ("B0", "B1") for t in cases[n]["rsl_step_seconds"]]
    baseline_rsl = statistics.median(baseline_steps) if baseline_steps else math.inf
    candidate_rsl = statistics.median(candidate_steps) if candidate_steps else math.inf
    pair_medians = {f"{a}/{b}": {"baseline_median_s": statistics.median(cases[a]["rsl_step_seconds"]),
                                   "candidate_median_s": statistics.median(cases[b]["rsl_step_seconds"]),
                                   "not_slower": statistics.median(cases[b]["rsl_step_seconds"]) <=
                                                 statistics.median(cases[a]["rsl_step_seconds"])}
                    for a, b in (("A0", "B0"), ("A1", "B1"))}
    performance = {"baseline_total_jvp_median": baseline_jvp,
                   "candidate_total_jvp_median": candidate_jvp,
                   "candidate_jvp_lower": candidate_jvp < baseline_jvp,
                   "baseline_rsl_step_median_s": baseline_rsl,
                   "candidate_rsl_step_median_s": candidate_rsl,
                   "rsl_median_reduction_fraction": 1.0 - candidate_rsl / baseline_rsl if baseline_rsl > 0 else None,
                   "rsl_at_least_10pct_lower": baseline_rsl > 0 and candidate_rsl <= 0.9 * baseline_rsl,
                   "paired_block_medians": pair_medians,
                   "each_outer_time_pair_not_slower": all(x["not_slower"] for x in pair_medians.values())}
    issues = {name: rows for name, rows in issues.items() if rows}
    all_raw_controllers_completed = all(cases[n]["controller_status"] == "completed" for n in ORDER)
    performance["jvp_count_status"] = "measured_from_aggregate_per_newton_telemetry"
    performance["rsl_timing_status"] = (
        "provisional_due_to_A0_controller_quiet_policy_mismatch"
        if not all_raw_controllers_completed else "controller_receipts_completed")
    performance["rsl_timing_eligible"] = all_raw_controllers_completed
    passed = (not issues and all_raw_controllers_completed and all(pair["passed"] for pair in pairs)
              and performance["candidate_jvp_lower"] and performance["rsl_at_least_10pct_lower"]
              and performance["each_outer_time_pair_not_slower"])
    result = {"schema": "ew_forcing_abba_analysis_v1", "at_local": datetime.now().astimezone().isoformat(),
              "manifest_sha256": manifest_sha, "remaining_manifest_sha256": remaining_sha,
              "block_status": block["status"], "raw_block_receipt_preserved": True,
              "orchestration_gap": a0_qualification, "case_results": cases,
              "matched_output_pairs": pairs, "rk3_field_reference": rk3_reference,
              "performance": performance,
              "acceptance": {"passed": passed, "issues": issues,
                             "scope": "six-step matched ABBA screening only; not five-day or RK3 accuracy acceptance"}}
    out = ROOT / "analysis" / "block_analysis.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result["acceptance"], indent=2))
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
