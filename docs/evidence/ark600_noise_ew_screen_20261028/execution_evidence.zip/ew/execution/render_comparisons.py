from pathlib import Path
import json, importlib.util
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from netCDF4 import Dataset
from scipy.fft import dct,idct
R=Path(__file__).resolve().parents[1]; O=R/'analysis'; O.mkdir(exist_ok=True)
paths={'RK3':R/'rk3_reference/runs/rk3_short','ARK fixed':R/'runs/A0','ARK EW':R/'runs/B0'}
fields={}; curves={}; x=(np.arange(40)+.5)*100; y=(np.arange(80)+.5)*100
for name,root in paths.items():
 frames=sorted(root.glob('wrfout_d01*')); curve=[]
 for p in frames:
  with Dataset(p) as d:
   w=np.asarray(d['W'][0],dtype=np.float64)[1:]; c=dct(w,type=2,axis=1,norm='ortho'); c[:,:40,:]=0; hp=idct(c,type=2,axis=1,norm='ortho'); curve.append(float(np.sqrt(np.mean(hp*hp))))
   if p==frames[-1]: fields[name]=w[40]
 curves[name]=curve
limit=max(np.max(np.abs(v)) for v in fields.values()); fig,axes=plt.subplots(2,3,figsize=(17,10),constrained_layout=True)
fig.suptitle('Actual six-step h600 forecasts: genuine WRF split-explicit RK3 and ARK fixed / EW\nNative W face: Python k=41 (owned k=40); raw fields above, differences below; not a long-range accuracy certificate')
for ax,(name,value) in zip(axes[0],fields.items()):
 im=ax.pcolormesh(x,y,value,shading='nearest',cmap='RdBu_r',norm=TwoSlopeNorm(vmin=-limit,vcenter=0,vmax=limit));ax.set_title(name+' W at 1 h');fig.colorbar(im,ax=ax,label='m/s')
deltas=[fields['ARK fixed']-fields['RK3'],fields['ARK EW']-fields['RK3'],fields['ARK EW']-fields['ARK fixed']]
dlimit=max(np.max(np.abs(v)) for v in deltas[:2])
for j,(ax,v,title) in enumerate(zip(axes[1],deltas,['fixed ARK − RK3','EW ARK − RK3','EW − fixed ARK'])):
 lim=dlimit if j<2 else max(float(np.max(np.abs(v))),1e-30);im=ax.pcolormesh(x,y,v,shading='nearest',cmap='RdBu_r',norm=TwoSlopeNorm(vmin=-lim,vcenter=0,vmax=lim));ax.set_title(title+(' (separate tiny scale)' if j==2 else ''));fig.colorbar(im,ax=ax,label='m/s')
for ax in axes.flat:ax.set_xlabel('X mass centres (km)');ax.set_ylabel('Y mass centres (km)')
fig.savefig(O/'actual_RK3_ARK_EW_1h.png',dpi=160);plt.close(fig)
fig,ax=plt.subplots(figsize=(9,5),constrained_layout=True)
for name,v in curves.items():ax.plot(np.arange(7)*10,v,'o-',label=name)
ax.set(xlabel='lead time (minutes)',ylabel='W k_y≥40 RMS over owned points (m/s)',title='Same six-step trajectory: actual W grid-scale component, native Y basis')
ax.legend();ax.grid(alpha=.25);fig.savefig(O/'actual_RK3_ARK_EW_Wband_1h.png',dpi=160);plt.close(fig)
(O/'short_plot_metrics.json').write_text(json.dumps({'method_frames':{n:str(p) for n,p in paths.items()},'Wband_rms':curves,'qualification':'RK3 field-only reference; original quiet-screen failure preserved. A0 caller false-reject qualified separately; no timing/accuracy acceptance inferred.'},indent=2)+'\n')
# A new common-scale force figure; source equations/data remain in the prepared diagnostic.
N=R.parent/'noise-location-20261028';script=N/'red_force/analyze_saved_w_pg_buoyancy.py';spec=importlib.util.spec_from_file_location('saved_force_shared_plot',script);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);receipt=json.loads(m.FRAME_RECEIPT.read_text());loaded,pins=m.load_all(receipt);panels=[]
for name in ['ARK','RK3']:
 f=loaded[(name,36)];force=m.reconstruct_force(f);z=((f['PH']+f['PHB'])/9.81)[1:].mean(axis=2)/1000;panels.append((name,z,[m.high_y_part(force[k]).mean(axis=2).T for k in ['pg','buoy_mu','net']]))
lim=max(float(np.max(np.abs(a))) for _,_,parts in panels for a in parts)
fig,axes=plt.subplots(2,3,figsize=(17,9),constrained_layout=True);fig.suptitle('36 h: common-scale saved-endpoint pressure / mass contributions to W acceleration (k_y≥40)\nSame dry source formula for ARK and RK3; FP32 output promoted to FP64; partial diagnostic, not native stage RHS / cause proof')
for row,(name,z,parts) in enumerate(panels):
 for col,(v,title) in enumerate(zip(parts,['Pg','B_mu (subtracted)','Pg − B_mu'])):
  ax=axes[row,col];assert v.shape==z.shape;im=ax.pcolormesh(np.broadcast_to(y,z.shape),z,v,shading='nearest',cmap='RdBu_r',norm=TwoSlopeNorm(vmin=-lim,vcenter=0,vmax=lim));ax.set(title=name+' '+title,xlabel='Y mass centres (km)',ylabel='height (km)',ylim=(0,float(z.max())+.25));fig.colorbar(im,ax=ax,label='m/s²')
fig.savefig(N/'red_force/results/shared_scale_force_36h.png',dpi=160);plt.close(fig)
print('renderedRK3/fixed/EW1h+common-scale force figures')
