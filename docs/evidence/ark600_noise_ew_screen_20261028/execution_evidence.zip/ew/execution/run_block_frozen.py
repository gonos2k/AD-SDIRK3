#!/usr/bin/env python3
"""Run the manifest-pinned six-step cases once, serially, in A0/B0/B1/A1 order."""
import argparse
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parents[1]
ORDER = ("A0", "B0", "B1", "A1")
PROTECTED = ("forecast_intent.json", "forecast_receipt.json", "initial_gate.json",
             "launcher_pid.json", "launcher.stdout.log", "launcher.stderr.log",
             "monitor_samples.jsonl", "rsl.out.0000", "rsl.error.0000",
             "namelist.output")


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2) + "\n")
    tmp.replace(path)


def nml_value(text, name):
    match = re.search(rf"(?im)^\s*{re.escape(name)}\s*=\s*([^,\n]+)", text)
    if not match:
        raise ValueError(f"namelist is missing {name}")
    return match.group(1).strip().lower()


def normalized_namelist(text):
    variable = {"sdirk3_nk_adaptive_tol", "sdirk3_stage2_ew_eta_min",
                "sdirk3_stage2_ew_eta_max", "sdirk3_stage3_ew_eta_min",
                "sdirk3_stage3_ew_eta_max"}
    result = []
    for line in text.splitlines():
        match = re.match(r"^(\s*)([A-Za-z][A-Za-z0-9_]*)\s*=", line)
        if match and match.group(2).lower() in variable:
            line = f"{match.group(1)}{match.group(2).lower()} = <EW_VARIABLE>"
        result.append(line.rstrip())
    return "\n".join(result) + "\n"


def validate_block(manifest, protocol, manifest_path):
    if sha256(manifest_path) != protocol.get("manifest_sha256"):
        raise ValueError("protocol manifest SHA-256 is stale")
    if tuple(protocol.get("order", ())) != ORDER:
        raise ValueError(f"protocol order must be {ORDER}")
    if set(manifest.get("cases", {})) != set(ORDER):
        raise ValueError("manifest cases must be exactly A0, B0, B1, A1")
    if manifest.get("resource_authorized") is not True or manifest.get("no_retries_or_cold_restart") is not True:
        raise ValueError("manifest must authorize one no-retry block")
    limits = manifest["limits"]
    if (limits["case_wall_seconds"] != protocol["case_cap_seconds"] or
            limits["total_wall_seconds"] != protocol["block_cap_seconds"] or
            protocol["steps_each"] != 6):
        raise ValueError("protocol caps or six-step target differ from manifest")
    if (manifest["analysis_contract"]["duration_seconds"] != 3600 or
            manifest["analysis_contract"]["output_interval_seconds"] != 600 or
            manifest["analysis_contract"]["expected_history_states"] != 7):
        raise ValueError("manifest analysis contract is not the pinned 6-step/7-frame case")
    if manifest.get("numerical_source_changes_since_accepted_model"):
        raise ValueError("manifest reports numerical source changes")
    fixed = protocol.get("fixed", {})
    if (float(fixed.get("Newton_abs", -1)) != 1e-9 or
            float(fixed.get("Newton_rel", -1)) != 0.0 or fixed.get("h") != 600 or
            fixed.get("gmres_restart") != 30 or fixed.get("effective_max_restarts") != 50 or
            fixed.get("stage_Krylov_overrides") != 0):
        raise ValueError("protocol does not preserve the baseline Newton and Krylov budget")
    if manifest.get("runtime_policy", {}).get("ranks") != 1:
        raise ValueError("the pinned block requires one MPI rank")
    env_initial = manifest.get("common_environment", {}).get("WRF_SDIRK3_EW_ETA_INITIAL")
    if env_initial is None or not math.isclose(float(env_initial), 0.1, rel_tol=0.0, abs_tol=1e-12):
        raise ValueError("manifest must pin WRF_SDIRK3_EW_ETA_INITIAL=0.1")

    cases = manifest["cases"]
    a_hashes = {cases[name]["namelist_sha256"] for name in ("A0", "A1")}
    b_hashes = {cases[name]["namelist_sha256"] for name in ("B0", "B1")}
    if len(a_hashes) != 1 or len(b_hashes) != 1 or a_hashes == b_hashes:
        raise ValueError("ABBA cases need identical within-arm, distinct between-arm namelist pins")
    texts = {name: (Path(cases[name]["directory"]) / "namelist.input").read_text()
             for name in ORDER}
    if normalized_namelist(texts["A0"]) != normalized_namelist(texts["B0"]):
        raise ValueError("A/B namelists differ outside adaptive-EW controls")
    for name in ORDER:
        case = cases[name]
        if (case["method"] != "ARK324" or case["h_seconds"] != 600 or
                case["expected_steps"] != 6 or case["expected_duration_seconds"] != 3600 or
                case["expected_output_frames"] != 7 or case["expected_fortran_wrapper_calls"] != 18):
            raise ValueError(f"{name}: case contract is not the pinned six-step ARK600 block")
        run_dir = Path(case["directory"])
        if not run_dir.is_dir():
            raise FileNotFoundError(run_dir)
        collisions = [n for n in PROTECTED if (run_dir / n).exists()]
        collisions += sorted({p.name for pattern in ("wrfout_d01*", "wrfoutReady_d01*", "wrfrst_d01*")
                              for p in run_dir.glob(pattern) if p.exists() or p.is_symlink()})
        if collisions or (run_dir / "controller_initial_views").exists():
            raise FileExistsError(f"{name}: refusing to reuse case outputs: {collisions}")
        text = texts[name]
        if nml_value(text, "restart") != ".false." or nml_value(text, "time_step") != "600":
            raise ValueError(f"{name}: restart must be off and time_step must remain 600")
        if (not math.isclose(float(nml_value(text, "sdirk3_newton_tol")), 1e-9, rel_tol=0, abs_tol=1e-18) or
                float(nml_value(text, "sdirk3_newton_rtol")) != 0.0 or
                int(nml_value(text, "sdirk3_gmres_restart")) != 30 or
                int(nml_value(text, "sdirk3_debug_level")) != 0 or
                int(nml_value(text, "sdirk3_jvp_method")) != 1 or
                nml_value(text, "sdirk3_solver_telemetry") != ".true."):
            raise ValueError(f"{name}: Newton, restart, telemetry, or debug settings differ from protocol")
        for stage in (2, 3):
            for knob in ("gmres_restart", "max_krylov_restarts", "krylov_tol"):
                if float(nml_value(text, f"sdirk3_stage{stage}_{knob}")) != 0.0:
                    raise ValueError(f"{name}: stage{stage}_{knob} must remain zero")
        if int(nml_value(text, "sdirk3_gmres_restart")) != 30:
            raise ValueError(f"{name}: global GMRES restart must remain 30")
        expected_adaptive = ".true." if name.startswith("B") else ".false."
        if nml_value(text, "sdirk3_nk_adaptive_tol") != expected_adaptive:
            raise ValueError(f"{name}: adaptive linear forcing does not match its AB arm")
        for stage in (2, 3):
            expected_min, expected_max = (("1e-07", "0.1") if name.startswith("B") else ("0", "0"))
            actual_min = float(nml_value(text, f"sdirk3_stage{stage}_ew_eta_min"))
            actual_max = float(nml_value(text, f"sdirk3_stage{stage}_ew_eta_max"))
            if not (math.isclose(actual_min, float(expected_min), rel_tol=0, abs_tol=1e-15) and
                    math.isclose(actual_max, float(expected_max), rel_tol=0, abs_tol=1e-12)):
                raise ValueError(f"{name}: stage {stage} EW bounds differ from the protocol")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--go", action="store_true", help="required to launch the one-shot block")
    args = parser.parse_args(argv)
    if not args.go:
        parser.error("--go is required; no case was launched")

    manifest_path = ROOT / "manifest.json"
    protocol = json.loads((ROOT / "protocol.json").read_text())
    manifest = json.loads(manifest_path.read_text())
    validate_block(manifest, protocol, manifest_path)
    if shutil.disk_usage(ROOT).free < int(manifest["limits"]["reserve_disk_bytes"]):
        raise OSError("whole-volume free-space reserve is below the manifest floor")
    controller = ROOT / "execution" / "run_case.py"
    if sha256(controller) != manifest["controller_sha256"]:
        raise ValueError("case controller SHA-256 does not match manifest")
    helper = Path(manifest["analysis_helper"]["path"])
    if sha256(helper) != manifest["analysis_helper"]["sha256"]:
        raise ValueError("analysis helper SHA-256 does not match manifest")
    receipt_path = ROOT / "block_receipt.json"
    if receipt_path.exists():
        raise FileExistsError("refusing to repeat an existing ABBA block")

    receipt = {"schema": "ew_forcing_abba_block_receipt_v1",
               "started_local": datetime.now().astimezone().isoformat(),
               "manifest_sha256": sha256(manifest_path),
               "controller_sha256": sha256(controller), "case_order": list(ORDER),
               "one_attempt_only": True, "cases": [], "status": "running"}
    save(receipt_path, receipt)
    for name in ORDER:
        case = manifest["cases"][name]
        command = [sys.executable, "-B", str(controller), "--manifest", str(manifest_path),
                   "--manifest-sha256", receipt["manifest_sha256"], "--case", name, "--go"]
        started = time.monotonic()
        try:
            result = subprocess.run(command, cwd=ROOT, check=False)
        except Exception as exc:
            row = {"case": name, "failure": repr(exc), "return_code": None}
            receipt["cases"].append(row)
            receipt.update(status="failed", stopped_after=name, stop_reason=row["failure"],
                           finished_local=datetime.now().astimezone().isoformat())
            save(receipt_path, receipt)
            return 2
        case_receipt = Path(case["directory"]) / "forecast_receipt.json"
        row = {"case": name, "return_code": result.returncode,
               "wall_seconds": time.monotonic() - started,
               "receipt_path": str(case_receipt),
               "receipt_sha256": sha256(case_receipt) if case_receipt.is_file() else None}
        receipt["cases"].append(row)
        if case_receipt.is_file():
            detail = json.loads(case_receipt.read_text())
            row.update(status=detail.get("status"), stop_reason=detail.get("stop_reason"),
                       actual_outer_step_count=detail.get("actual_outer_step_count"),
                       terminal_wrapper_calls_ok=detail.get("terminal_wrapper_calls_ok"))
        if (result.returncode != 0 or row.get("status") != "completed" or
                row.get("actual_outer_step_count") != 6 or
                row.get("terminal_wrapper_calls_ok") is not True):
            row["failure"] = row.get("stop_reason") or "case did not complete its pinned six steps"
            receipt.update(status="failed", stopped_after=name, stop_reason=row["failure"],
                           finished_local=datetime.now().astimezone().isoformat())
            save(receipt_path, receipt)
            return 2
        save(receipt_path, receipt)
    receipt.update(status="all_cases_completed", finished_local=datetime.now().astimezone().isoformat())
    save(receipt_path, receipt)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
