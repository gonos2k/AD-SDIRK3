#!/usr/bin/env python3
"""One pinned six-model-hour forecast; serial, no retry, no state-only restart."""
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

from initialize_once import sha, processes, family

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / 'forecast_manifest_6h.json'
MANIFEST_SHA = '1a7d1bb2b78c7717efdb2f58b460196cb47e391b309926cf8502088ec657b480'
HELPER = Path('/private/tmp/standard-forward-comparison-20261024/tools/benchmark_wrf_accuracy_cost.py')
HELPER_SHA = '9fc8475c33194f146f59ad8dc5e6ff394564599da0ca68fcc85404b0702aa2d4'
GRID = {'nx':40, 'ny':80, 'nz':64}
CASE_WALL = 6*3600
TOTAL_WALL = 18*3600
RSS_CAP = 32*1024**3
RESERVE = 20*1024**3


def save(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n')


def get_helper():
    assert sha(HELPER) == HELPER_SHA
    spec = importlib.util.spec_from_file_location('benchmark_frozen', HELPER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def closed_t0(cwd):
    file = cwd/'wrfout_d01_0001-01-01_00:00:00'
    ready = cwd/'wrfoutReady_d01_0001-01-01_00:00:00'
    if not file.exists() or not ready.exists():
        return None
    before=file.stat(); time.sleep(.1); after=file.stat()
    if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):
        return None
    opened=subprocess.run(['/usr/sbin/lsof','-F','pa','--',str(file)],
                          capture_output=True,text=True,timeout=3)
    if opened.returncode not in (0,1):
        raise RuntimeError('cannot verify t0 writer closure')
    if any(line in ('aw','au') for line in opened.stdout.splitlines()):
        return None
    return file


def initial_gate(key, cwd, helper):
    file = closed_t0(cwd)
    if file is None:
        return None
    view = ROOT/'initial_views_6h'/key
    view.mkdir(parents=True, exist_ok=False)
    (view/'wrfinput_d01').symlink_to(cwd/'wrfinput_d01')
    (view/file.name).symlink_to(file)
    state = helper.load_initial_state(view, GRID, dry_case_no_qv=True,
                                      use_theta_m=1, source='wrfout')
    if key == 'rk3_h600':
        result = {'status':'canonical_post_init_history', 'source_kind':state['source_kind']}
    else:
        reference = helper.load_initial_state(ROOT/'initial_views/rk3_h600', GRID,
                      dry_case_no_qv=True, use_theta_m=1, source='wrfout')
        result = helper.compare_initial_states({'rk3_h600':reference,key:state})
    result.update(history=str(file), history_sha256=sha(file), input_sha256=state['input_sha256'])
    save(cwd/'initial_gate.json', result)
    return result


def cleanup(proc, tracked, exe):
    """Reap our launcher; kill only mapped, birth-matched known rank children."""
    report = {'signals':[], 'errors':[]}
    def owned_now():
        rows=processes(); found=family(rows,proc.pid)
        for p,r in rows.items():
            try:
                if os.getsid(p)==proc.pid:
                    found[p]=r
            except ProcessLookupError:
                pass
            except PermissionError:
                if p in tracked:
                    raise
        tracked.update(found)
        return {p:r for p,r in rows.items() if p in tracked and
                r['birth']==tracked[p]['birth'] and not r['state'].startswith('Z')}
    oldmask = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGINT, signal.SIGTERM})
    try:
        try:
            owned_now()  # Covers a child missed by the first normal RSS sample.
        except Exception as exc:
            report['errors'].append('initial cleanup snapshot:'+repr(exc))
        if proc.poll() is None:
            proc.terminate(); report['signals'].append('launcher_TERM')
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill(); report['signals'].append('launcher_KILL'); proc.wait(timeout=5)
        proc.wait(timeout=5)
        remaining={}
        for _ in range(2):
            try:
                remaining=owned_now()
            except Exception as exc:
                report['errors'].append('cleanup rescan:'+repr(exc)); break
            if not remaining:
                break
            for p in remaining:
                try:
                    mapped=subprocess.run(['/usr/sbin/lsof','-a','-p',str(p),'-d','txt','-Fn'],
                                          capture_output=True,text=True,timeout=3)
                    fresh=processes().get(p)
                    if fresh is None or fresh['state'].startswith('Z'):
                        continue
                    same=fresh['birth']==remaining[p]['birth'] and os.getsid(p)==proc.pid
                    if same and 'n'+str(Path(exe).resolve()) in mapped.stdout.splitlines():
                        os.kill(p,signal.SIGKILL); report['signals'].append(f'verified_rank_KILL:{p}')
                    else:
                        report['errors'].append(f'unverified owned session member:{p}')
                except ProcessLookupError:
                    pass
                except Exception as exc:
                    report['errors'].append(f'rank cleanup:{p}:'+repr(exc))
            time.sleep(.2)
        try:
            report['remaining_owned']=owned_now()
        except Exception as exc:
            report['remaining_owned']=remaining
            report['errors'].append('final cleanup snapshot:'+repr(exc))
        return report
    except Exception as exc:
        report['errors'].append('owned reap:'+repr(exc))
        report['remaining_owned']=tracked
        return report
    finally:
        signal.pthread_sigmask(signal.SIG_SETMASK, oldmask)


def main():
    assert len(sys.argv)==3 and sys.argv[2]=='--go'
    key=sys.argv[1]; assert sha(MANIFEST)==MANIFEST_SHA
    manifest=json.loads(MANIFEST.read_text()); case=manifest['cases'][key]
    cwd=Path(case['directory']); exe=Path(manifest['executable']['path'])
    assert sha(exe)==manifest['executable']['sha256']
    assert sha(cwd/'wrfinput_d01')==manifest['common_input']['sha256']
    assert sha(cwd/'namelist.input')==case['namelist_sha256']
    assert not any((cwd/x).exists() for x in ('forecast_intent.json','forecast_receipt.json','rsl.error.0000','launcher.stdout.log'))
    others=list((ROOT/'runs').glob('*/forecast_receipt.json'))+list((ROOT/'lean_runs').glob('*/forecast_receipt.json'))+list((ROOT/'six_hour_runs').glob('*/forecast_receipt.json'))
    assert sum(json.loads(x.read_text()).get('wall_seconds',0) for x in others)<TOTAL_WALL
    if key!='rk3_h600':
        assert (ROOT/'initial_views/rk3_h600').is_dir()
    bad=[k for k in os.environ if k.startswith(('PMIX_','OMPI_COMM_WORLD_','OMPI_MCA_','PRTE_MCA_','OPAL_MCA_'))]
    assert not bad, f'foreign runtime environment {bad}'
    env={k:v for k,v in os.environ.items() if not k.startswith(('WRF_SDIRK3_','WRF_PARITY_'))}
    overrides={**manifest['common_environment'], **case.get('environment_overrides',{})}
    env.update(overrides)
    helper=get_helper(); command=['/opt/homebrew/bin/mpirun','-np','1','--bind-to','none',str(exe)]
    record={'case':key,'command':command,'manifest_sha256':sha(MANIFEST),'helper_sha256':HELPER_SHA,
            'input_sha256':manifest['common_input']['sha256'],'executable_sha256':sha(exe),
            'runner_source_sha256':sha(__file__),
            'namelist_sha256':case['namelist_sha256'],'environment_overrides':overrides,
            'expected_steps':case['expected_steps'],'expected_duration_seconds':21600,
            'clock_scope':'Whole-path OS-waited launcher; not pure integrator time'}
    save(cwd/'forecast_intent.json',record)
    proc=None; tracked={}; peak=0; reason=None; gate=None; threads=None
    start=time.monotonic(); wall0=time.time_ns(); prior_wall=sum(json.loads(x.read_text()).get('wall_seconds',0) for x in others)
    with (cwd/'launcher.stdout.log').open('xb') as out, (cwd/'launcher.stderr.log').open('xb') as err:
        try:
            proc=subprocess.Popen(command,cwd=cwd,env=env,stdout=out,stderr=err,start_new_session=True)
            save(cwd/'launcher_pid.json', {'pid':proc.pid,'wall_start_ns':wall0})
            while proc.poll() is None:
                rows=processes()
                if proc.poll() is not None:
                    break
                own=family(rows,proc.pid); tracked.update(own)
                peak=max(peak,sum(r['rss'] for r in own.values()))
                elapsed=(time.time_ns()-wall0)/1e9
                if elapsed>CASE_WALL or prior_wall+elapsed>TOTAL_WALL:
                    reason='wall_resource_cap'; break
                if peak>RSS_CAP or shutil.disk_usage(ROOT).free<RESERVE:
                    reason='memory_or_disk_resource_cap'; break
                if gate is None:
                    try:
                        gate=initial_gate(key,cwd,helper)
                    except Exception as exc:
                        reason='initialization_mismatch_or_gate_error:'+repr(exc); break
                if threads is None and gate is not None:
                    natives=[p for p in own if p!=proc.pid]
                    if natives:
                        q=subprocess.run(['/bin/ps','-M','-p',str(natives[-1])],
                                         capture_output=True,text=True,timeout=3)
                        threads={'pid':natives[-1],'ps_M_return_code':q.returncode,'raw':q.stdout}
                time.sleep(1)
        except BaseException as exc:
            reason=repr(exc)
        finally:
            cleanup_result=cleanup(proc,tracked,exe) if proc is not None else {}
    elapsed=time.monotonic()-start; wall=time.time_ns()-wall0; rc=proc.returncode if proc else None
    if wall/1e9>CASE_WALL or prior_wall+wall/1e9>TOTAL_WALL:
        reason=reason or 'late_wall_resource_cap'
    if cleanup_result.get('remaining_owned') or cleanup_result.get('errors'):
        reason=reason or 'cleanup_incomplete'
    if gate is None and reason is None:
        try:
            gate=initial_gate(key,cwd,helper)
        except Exception as exc:
            reason='initialization_gate_error:'+repr(exc)
    stdout=(cwd/'rsl.out.0000').read_text(errors='replace') if (cwd/'rsl.out.0000').exists() else ''
    stderr=(cwd/'rsl.error.0000').read_text(errors='replace') if (cwd/'rsl.error.0000').exists() else ''
    steps=len(re.findall(r'Timing for main:', stdout)); converged=stderr.count('[Newton] CONVERGED')
    aborted=len(re.findall(r'final_update_aborted=[1-9]|outcome=HARD_STAGE_ABORT',stderr))
    success_marker='SUCCESS COMPLETE WRF' in stdout or 'SUCCESS COMPLETE WRF' in stderr
    output_check=None
    if rc==0 and reason is None:
        try:
            row={'label':key,'path':str(cwd),'method':case['method'],'h_seconds':case['h_seconds'],
                 'input_sha256':record['input_sha256'],'executable_sha256':record['executable_sha256'],
                 'executable_path':str(exe),'namelist_sha256':case['namelist_sha256']}
            checked=helper._load_run(row,ROOT,manifest['analysis_contract'])
            output_check={k:checked[k] for k in ('grid','physical_minima_over_all_frames','physical_minimum_total_pressure_Pa','timestamps','step_logs')}
        except Exception as exc:
            reason='output_validation_error:'+repr(exc)
    normal=rc==0 and reason is None and gate is not None and success_marker and steps==case['expected_steps'] and aborted==0
    if case['method']=='ARK324':
        normal=normal and converged==3*case['expected_steps']
    record.update(return_code=rc,stop_reason=reason,elapsed_seconds=elapsed,wall_seconds=wall/1e9,
                  suspend_or_clock_discrepancy_seconds=wall/1e9-elapsed,peak_sampled_tree_rss_bytes=peak,
                  initial_gate=gate,actual_outer_step_count=steps,newton_converged_stages=converged,
                  aborted_markers=aborted,threads_snapshot=threads,cleanup=cleanup_result,output_check=output_check,
                  success_marker=success_marker,
                  status='completed' if normal else 'failed_or_incomplete',
                  cost_eligible=normal and abs(wall/1e9-elapsed)<5,
                  accuracy_pass_claim=False,same_accuracy_speedup_claim=False)
    save(cwd/'forecast_receipt.json',record)
    print(json.dumps({k:record[k] for k in ('case','status','return_code','stop_reason','elapsed_seconds','actual_outer_step_count','cost_eligible')},indent=2))
    return 0 if normal else 2


if __name__=='__main__':
    raise SystemExit(main())
