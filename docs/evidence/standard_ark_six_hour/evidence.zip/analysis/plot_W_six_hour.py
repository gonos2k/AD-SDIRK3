"""Native W endpoint comparison; select the layer of maximum ARK-RK3 difference."""
from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from netCDF4 import Dataset
import numpy as np

def main(ark_path, rk3_path):
    with Dataset(rk3_path) as dataset:
        rk3 = np.asarray(dataset["W"][0], dtype=np.float64)[1:]
    with Dataset(ark_path) as dataset:
        ark = np.asarray(dataset["W"][0], dtype=np.float64)[1:]
    difference = ark - rk3
    layer = np.unravel_index(np.argmax(np.abs(difference)), difference.shape)[0]
    limit = max(np.abs(rk3[layer]).max(), np.abs(ark[layer]).max())
    delta_limit = np.abs(difference[layer]).max()
    figure, axes = plt.subplots(2, 2, figsize=(12, 8), constrained_layout=True)
    for axis, values, title in zip(
        axes.flat[:3], [rk3[layer], ark[layer], difference[layer]],
        ["Split-explicit RK3", "Native ARK324", "ARK - RK3 (separate color scale)"],
        strict=True,
    ):
        scale = delta_limit if axis is axes.flat[2] else limit
        artist = axis.imshow(values, origin="lower", cmap="RdBu_r", vmin=-scale,
                             vmax=scale, aspect="auto")
        axis.set(title=title, xlabel="Native x index (0-based)",
                 ylabel="Native y index (0-based)")
        figure.colorbar(artist, ax=axis, label="W [m/s]")
    profile = np.sqrt(np.mean(difference**2, axis=(1, 2)))
    axes[1, 1].plot(profile, np.arange(1, len(profile) + 1))
    axes[1, 1].axhline(layer + 1, color="gray", linestyle="--", linewidth=1)
    axes[1, 1].set(xlabel="ARK - RK3 RMS [m/s]", ylabel="Native W vertical index",
                   title="All owned levels; fixed k=0 excluded, top retained")
    axes[1, 1].ticklabel_format(axis="x", style="sci", scilimits=(0, 0))
    axes[1, 1].locator_params(axis="x", nbins=5)
    axes[1, 1].grid(alpha=0.25)
    figure.suptitle(f"Official-scale em_b_wave: six hours, h=600 s; slice k={layer + 1}\n"
                   "Shared initial state; full-path difference, no phase alignment or exact-truth claim")
    figure.savefig(Path(__file__).with_name("W_six_hour_comparison.png"), dpi=170)
    plt.close(figure)


if __name__ == "__main__":
    main(Path(sys.argv[1]), Path(sys.argv[2]))
