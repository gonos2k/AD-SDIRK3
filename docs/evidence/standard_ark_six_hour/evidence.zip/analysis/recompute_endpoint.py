"""Direct endpoint subtraction; accepts ARK and RK3 NetCDF paths, never runs WRF."""
import json
from pathlib import Path
import sys

from netCDF4 import Dataset
import numpy as np


def main(ark_path, rk3_path):
    result = {}
    with Dataset(ark_path) as ark, Dataset(rk3_path) as rk3:
        for field in ("U", "V", "W", "PH", "T", "MU", "P_total"):
            names = ("P", "PB") if field == "P_total" else (field,)
            left = sum(np.asarray(ark[key][0], dtype=np.float64) for key in names)
            right = sum(np.asarray(rk3[key][0], dtype=np.float64) for key in names)
            if field == "U":
                left, right = left[..., :-1], right[..., :-1]
            elif field in ("W", "PH"):
                left, right = left[1:], right[1:]
            difference = left - right
            result[field] = {"rms": float(np.sqrt(np.mean(difference**2))),
                             "max_abs": float(np.abs(difference).max()),
                             "mean_bias_ark_minus_rk3": float(difference.mean())}
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main(Path(sys.argv[1]), Path(sys.argv[2]))
