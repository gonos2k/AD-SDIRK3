"""Read-only off-path check against the committed PR325 EW B0 trajectory."""
from pathlib import Path
import hashlib,json
import numpy as np
from netCDF4 import Dataset
root=Path(__file__).resolve().parents[1]
prior=Path('/private/tmp/ark600-noise-ew-pr-20261029/docs/evidence/ark600_noise_ew_screen_20261028')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=prior/'ew_analysis.json'
entry=next(e for e in json.loads((prior/'artifact_manifest.json').read_text()) if e['file']==source.name)
assert sha(source)==entry['sha256'] and source.stat().st_size==entry['bytes']
old_root=Path('/Users/yhlee/AD-SDIRK3-review-evidence/ew-forcing-abba-20261028/runs/B0')
old_receipt=old_root/'forecast_receipt.json'
archive=json.loads((prior/'execution_evidence_manifest.json').read_text())
items=archive['payload']
pin=next(e for e in items if e['file']=='ew/runs/B0/forecast_receipt.json')
assert sha(old_receipt)==pin['sha256']
old={p.name:{'path':str(p),'sha256':sha(p)} for p in sorted(old_root.glob('wrfout_d01*'))}
assert len(old)==7
receipt=json.loads((root/'runs/A0/forecast_receipt.json').read_text())
assert receipt['status']=='completed'
rows=[]
for name,record in sorted(old.items()):
    a=Path(record['path']);b=root/'runs/A0'/name
    assert sha(a)==record['sha256']
    failures=[];count=0
    with Dataset(a) as da,Dataset(b) as db:
        assert set(da.variables)==set(db.variables)
        for field in da.variables:
            va=np.asarray(da[field][:]);vb=np.asarray(db[field][:])
            if not np.issubdtype(va.dtype,np.number):continue
            count+=1
            if va.dtype!=vb.dtype or va.shape!=vb.shape or va.tobytes()!=vb.tobytes():
                failures.append({'field':field,'old_shape':list(va.shape),'new_shape':list(vb.shape),
                                 'max_abs':float(np.max(np.abs(vb.astype(float)-va.astype(float)))) if va.shape==vb.shape else None})
    rows.append({'name':name,'prior_sha256':sha(a),'new_sha256':sha(b),'numeric_arrays':count,'failures':failures})
result={'source_analysis_sha256':sha(source),'new_case':'A0 probe OFF, EW enabled','reference':'Retained PR325 B0 EW output; receipt matches committed archive pin', 'old_receipt_sha256':sha(old_receipt),
        'frames':rows,'all_numeric_array_bytes_match':all(not row['failures'] for row in rows),
        'all_file_bytes_match':all(row['prior_sha256']==row['new_sha256'] for row in rows),
        'scope':'Regression parity only; not physical accuracy or timing comparison.'}
out=root/'analysis';out.mkdir(exist_ok=True)
(out/'off_parity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='frames'}))
raise SystemExit(0 if result['all_numeric_array_bytes_match'] else 1)
