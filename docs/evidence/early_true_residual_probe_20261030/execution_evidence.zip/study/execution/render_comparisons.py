"""Actual native W fields at the previously selected face, with genuine RK3."""
from pathlib import Path
import hashlib,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from netCDF4 import Dataset
from scipy.fft import dct,idct
root=Path(__file__).resolve().parents[1]
out=root/'analysis'; out.mkdir(exist_ok=True)
paths={'RK3':root/'rk3_reference/runs/rk3_short',
       'ARK EW, probe OFF':root/'runs/A0',
       'ARK EW, probe ON':root/'runs/B0'}
fields={};curves={};pins={}
for name,folder in paths.items():
    frames=sorted(folder.glob('wrfout_d01*'))
    if len(frames)!=7: raise ValueError(f'{name}: expected seven frames')
    series=[]
    for index,path in enumerate(frames):
        pins[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
        with Dataset(path) as ds:
            w=np.asarray(ds['W'][0],dtype=np.float64)[1:]
            if w.shape!=(64,80,40) or not np.isfinite(w).all():
                raise ValueError(f'{name}: bad W shape or finite values')
            coeff=dct(w,type=2,axis=1,norm='ortho');coeff[:,:40,:]=0
            high=idct(coeff,type=2,axis=1,norm='ortho')
            series.append(float(np.sqrt(np.mean(high*high))))
            if index==6: fields[name]=w[40].copy()
    curves[name]=series
x=(np.arange(40)+.5)*100;y=(np.arange(80)+.5)*100
fig,axes=plt.subplots(2,3,figsize=(16,9),constrained_layout=True)
fig.suptitle('Six consecutive h600 steps: actual WRF RK3 and ARK with identical EW forcing\nW native face Python k=41 (owned k=40), 1 h; short numerical screen, not long-range accuracy acceptance')
limit=max(float(np.max(np.abs(v))) for v in fields.values())
for ax,(name,value) in zip(axes[0],fields.items()):
    im=ax.pcolormesh(x,y,value,shading='nearest',cmap='RdBu_r',norm=TwoSlopeNorm(vmin=-limit,vcenter=0,vmax=limit))
    ax.set_title(name);fig.colorbar(im,ax=ax,label='m/s')
values=list(fields.values());deltas=[values[1]-values[0],values[2]-values[0],values[2]-values[1]]
dlimit=max(float(np.max(np.abs(v))) for v in deltas[:2])
for j,(ax,value,title) in enumerate(zip(axes[1],deltas,['probe OFF - RK3','probe ON - RK3','probe ON - OFF (separate scale)'])):
    lim=dlimit if j<2 else max(float(np.max(np.abs(value))),1e-30)
    im=ax.pcolormesh(x,y,value,shading='nearest',cmap='RdBu_r',norm=TwoSlopeNorm(vmin=-lim,vcenter=0,vmax=lim))
    ax.set_title(title);fig.colorbar(im,ax=ax,label='m/s')
for ax in axes.flat: ax.set(xlabel='X mass centres (km)',ylabel='Y mass centres (km)')
fig.savefig(out/'actual_rk3_ark_probe_1h.png',dpi=160);plt.close(fig)
fig,ax=plt.subplots(figsize=(9,5),constrained_layout=True)
for name,values in curves.items(): ax.plot(np.arange(7)*10,values,'o-',label=name)
ax.set(xlabel='Lead time (minutes)',ylabel='Y modes k >= 40 W RMS (m/s)',title='Native physical-space W grid band: 2-4 grid lengths, all owned points')
ax.legend();ax.grid(alpha=.25);fig.savefig(out/'actual_w_band_1h.png',dpi=160);plt.close(fig)
np.savez_compressed(out/'selected_w_planes.npz',**{f'W_{i}':v for i,v in enumerate(fields.values())})
(out/'plot_metrics.json').write_text(json.dumps({'source_sha256':pins,'fields':list(fields),'native_W_python_face_index':41,'W_band_rms':curves,'scope':'Non-mass-weighted physical-space RMS after DCT-II Y-band reconstruction. Genuine archived RK3 is a field-only comparator. No 24-36h noise cure or physical accuracy claim.'},indent=2)+'\n')
print('Rendered actual native RK3 / ARK probe OFF / ON fields and W-band curves')
