"""Available one-hour fields only; the interrupted ON forecast is not plotted."""
from pathlib import Path
import hashlib,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from netCDF4 import Dataset
from scipy.fft import dct,idct
root=Path(__file__).resolve().parents[1];out=root/'analysis'
paths={'Genuine split-explicit RK3':root/'rk3_reference/runs/rk3_short','ARK EW, probe OFF':root/'runs/A0'}
fields={};curves={};pins={}
for label,folder in paths.items():
    frames=sorted(folder.glob('wrfout_d01*'));assert len(frames)==7
    values=[]
    for i,p in enumerate(frames):
        pins[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
        with Dataset(p) as ds:
            w=np.asarray(ds['W'][0],dtype=np.float64)[1:]
            assert w.shape==(64,80,40) and np.isfinite(w).all()
            c=dct(w,type=2,axis=1,norm='ortho');c[:,:40,:]=0
            hp=idct(c,type=2,axis=1,norm='ortho');values.append(float(np.sqrt(np.mean(hp*hp))))
            if i==6:fields[label]=w[40].copy()
    curves[label]=values
x=(np.arange(40)+.5)*100;y=(np.arange(80)+.5)*100
raw=list(fields.values());delta=raw[1]-raw[0];limit=max(float(np.max(np.abs(v))) for v in raw)
fig,axes=plt.subplots(1,3,figsize=(16,5),constrained_layout=True)
fig.suptitle('Available native W fields at 1 h: six consecutive h600 steps\nProbe ON was interrupted before its first completed step; no ON field or speedup is shown')
for i,(ax,v,label) in enumerate(zip(axes,raw+[delta],list(fields)+['ARK probe OFF - RK3'])):
    lim=limit if i<2 else max(float(np.max(np.abs(v))),1e-30)
    im=ax.pcolormesh(x,y,v,shading='nearest',cmap='RdBu_r',norm=TwoSlopeNorm(vmin=-lim,vcenter=0,vmax=lim))
    ax.set(title=label,xlabel='X mass centres (km)',ylabel='Y mass centres (km)');fig.colorbar(im,ax=ax,label='m/s')
fig.savefig(out/'actual_available_rk3_ark_1h.png',dpi=160);plt.close(fig)
fig,ax=plt.subplots(figsize=(9,5),constrained_layout=True)
for label,v in curves.items():ax.plot(np.arange(7)*10,v,'o-',label=label)
ax.set(xlabel='Lead time (minutes)',ylabel='Y modes k >= 40 W RMS (m/s)',title='Available native physical-space W grid band (2-4 grid lengths)')
ax.legend();ax.grid(alpha=.25);fig.savefig(out/'available_w_band_1h.png',dpi=160);plt.close(fig)
np.savez_compressed(out/'available_w_planes.npz',RK3=raw[0],ARK_EW_probe_OFF=raw[1])
(out/'available_plot_metrics.json').write_text(json.dumps({'source_sha256':pins,'native_W_python_face_index':41,'W_band_rms':curves,'scope':'RK3 field-only comparator; actual raw W at one native eta face. DCT-II Y high band reconstructed on all owned points before non-mass-weighted RMS. No ON, long-time noise cure, or accuracy/speedup acceptance.'},indent=2)+'\n')
print('Rendered available RK3 and ARK OFF fields; ON intentionally absent')
