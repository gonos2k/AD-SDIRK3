#!/usr/bin/env python3
"""Pin a verified rebuilt executable before the one-shot block."""
import argparse, hashlib, json
from pathlib import Path
root = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser()
p.add_argument('executable', type=Path)
p.add_argument('--source-revision', required=True)
p.add_argument('--build-receipt', type=Path, required=True, help='Existing build provenance receipt')
a = p.parse_args()
if (root / 'block_receipt.json').exists():
    raise SystemExit('Cannot rebind after the block starts')
exe = a.executable.resolve(strict=True)
receipt = a.build_receipt.resolve(strict=True)
if not exe.is_file() or not receipt.is_file():
    raise SystemExit('Executable and build receipt must be regular files')
def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()
mfile = root/'manifest.json'; pfile = root/'protocol.json'
m = json.loads(mfile.read_text()); proto = json.loads(pfile.read_text())
if m['executable']['path'] is not None: raise SystemExit('Executable is already bound')
m['executable'] = {'path': str(exe), 'sha256': sha(exe)}
m['runtime_policy']['argv'][-1] = str(exe)
m['model_source_revision'] = a.source_revision
m['build_receipt'] = {'path': str(receipt), 'sha256': sha(receipt)}
mfile.write_text(json.dumps(m,indent=2)+'\n')
proto['manifest_sha256'] = sha(mfile); proto['executable_binding'] = 'bound; provenance must be independently verified'
pfile.write_text(json.dumps(proto,indent=2)+'\n')
print(json.dumps(m['executable'],indent=2))
