#!/usr/bin/env python3
"""Extract the incomplete ABBA evidence from existing receipts and logs only."""
import hashlib
import importlib.util
import json
from datetime import datetime
from pathlib import Path

root = Path(__file__).resolve().parents[1]
analysis = root / 'execution' / 'analyze_block.py'
spec = importlib.util.spec_from_file_location('previous_analysis', analysis)
parser = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parser)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def receipt(case):
    return json.loads((root / 'runs' / case / 'forecast_receipt.json').read_text())

a0, b0 = receipt('A0'), receipt('B0')
ar, br = parser.parse_logs(root / 'runs' / 'A0'), parser.parse_logs(root / 'runs' / 'B0')
block = json.loads((root / 'block_receipt.json').read_text())
samples = [json.loads(line) for line in (root / 'runs' / 'B0' / 'monitor_samples.jsonl').read_text().splitlines()]
samples = [s for s in samples if s.get('status') == 'sampled' and 'disk_free_bytes' in s]
values = [float(row['rho_newton_scaled_exit']) for row in ar['stages']]
out = root / 'analysis' / 'partial_summary.json'
size = sum(path.stat().st_size for path in root.rglob('*')
           if path.is_file() and not path.is_symlink() and path != out)
result = {
    'schema': 'early_residual_probe_partial_summary_v1',
    'created_local': datetime.now().astimezone().isoformat(),
    'block_status': block['status'], 'stop_reason': block['stop_reason'],
    'no_retry': True, 'cases_not_launched': ['B1', 'A1'],
    'manifest_sha256': sha(root / 'manifest.json'),
    'block_receipt_sha256': sha(root / 'block_receipt.json'),
    'a0': {
        'status': a0['status'], 'model_return_code': a0['return_code'],
        'completed_steps': a0['actual_outer_step_count'],
        'rsl_main_step_sum_seconds': sum(row['seconds'] for row in ar['main_times']),
        'rsl_step_seconds': [row['seconds'] for row in ar['main_times']],
        'effective_estimate_probe': sorted({row.get('estimate_probe') for row in ar['effective_config']}),
        'selected_jvp_total': sum(int(row['jvp_calls']) for row in ar['solver']),
        'selected_jvp_ad_total': sum(int(row['jvp_ad_calls']) for row in ar['solver']),
        'selected_jvp_fd_total': sum(int(row['jvp_fd_calls']) for row in ar['solver']),
        'newton_corrections': len(ar['solver']),
        'newton_iteration_log_sum_including_convergence_checks': a0['output_check']['step_logs']['newton_iterations_sum'],
        'stage_counts': {str(n): sum(int(row['stage']) == n for row in ar['stages']) for n in (2, 3, 4)},
        'stage_count': len(values),
        'converged_stage_count': sum(row['converged'] == '1' for row in ar['stages']),
        'final_scaled_newton_residual_range': [min(values), max(values)],
        'initial_gate': a0['initial_gate']['status'],
        'receipt_sha256': sha(root / 'runs' / 'A0' / 'forecast_receipt.json'),
    },
    'b0': {
        'status': b0['status'], 'model_return_code': b0['return_code'],
        'stop_reason': b0['stop_reason'], 'elapsed_seconds': b0['elapsed_seconds'],
        'completed_steps': b0['actual_outer_step_count'],
        'effective_estimate_probe': sorted({row.get('estimate_probe') for row in br['effective_config']}),
        'initial_gate': b0['initial_gate']['status'],
        'completed_stage_telemetry': [
            {'stage': int(row['stage']), 'converged': row['converged'] == '1',
             'final_scaled_newton_residual': float(row['rho_newton_scaled_exit'])}
            for row in br['stages']
        ],
        'receipt_sha256': sha(root / 'runs' / 'B0' / 'forecast_receipt.json'),
        'free_disk_sampling': {
            'first_sample': {'elapsed_seconds': samples[0]['monotonic_elapsed_seconds'],
                             'free_bytes': samples[0]['disk_free_bytes']},
            'last_sample': {'elapsed_seconds': samples[-1]['monotonic_elapsed_seconds'],
                            'free_bytes': samples[-1]['disk_free_bytes']},
            'minimum_sampled_free_bytes': min(row['disk_free_bytes'] for row in samples),
            'reserved_free_bytes': 5368709120,
            'note': 'Stop followed the last recorded sample when free volume space fell below reserve. Source of the free-space drop is unexplained.',
        },
    },
    'study_regular_file_bytes_at_measurement': size,
    'study_size_note': 'Logical bytes, regular files under study, excludes symlinks and this summary; measured when extracted.',
    'native_on_performance_claim': False, 'on_off_field_acceptance_claim': False,
    'cost_eligible': False,
    'interpretation': 'Incomplete B0 and unlaunched B1/A1 do not support ON performance or field acceptance; no failure of numerical accuracy is inferred.',
}
out.parent.mkdir(exist_ok=True)
out.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
print(json.dumps(result, indent=2))
