from pathlib import Path
import json,hashlib,zipfile
root=Path('/private/tmp/pr294-same-state-rhs-20261011')
ev=Path('/Users/yhlee/AD-SDIRK3-review-evidence/same-state-rhs-20261011')
members={}
# Preserve original receipts; byte hashes in these records describe local builds.
for p in sorted(ev.rglob('*')):
    if not p.is_file() or p.is_symlink() or 'build' in p.relative_to(ev).parts: continue
    if p.name in ('pack_receipt.json',) or p.suffix=='.o': continue
    if p.read_bytes()[:4] in (b'\xcf\xfa\xed\xfe',b'\xca\xfe\xba\xbe',b'\x7fELF'): continue
    members['records/'+str(p.relative_to(ev))]=p.read_bytes()
plan=json.loads((ev/'wrf_validation/runs.json').read_text())
for row in plan['runs']:
    row['path']='records/wrf_validation/'+row['label']
    row['recorded_executable_sha256']=row.pop('executable_sha256')
    row.pop('executable_path',None)
plan['executable_bytes_in_archive']=False
members['runs.json']=json.dumps(plan,indent=2).encode()
for name in list(json.loads((ev/'production_source_pin.json').read_text())['sources'])+['external/libtorch_wrf/sdirk3/tests/test_scalar_diffusion_contract.cpp','external/libtorch_wrf/sdirk3/tests/test_base_state_checked_abi.cpp','tools/benchmark_wrf_accuracy_cost.py']:
    members['sources/'+name]=(root/name).read_bytes()
members['README.txt']=b'Option-2 WRF wind mixing-base correction. Same-state shear operand comparison is not full U/V/MU RHS equality. Raw snapshot inputs and extracted Fortran branches are preserved. Original host receipts retain execution-time hashes. Binary bytes remain locally archived and are excluded from this ZIP. RK3 is provisional; no accuracy-per-cost superiority or general WRF closure. Earlier failed diagnostics remain records, final selected test logs supersede them.\n'
manifest={'files':[{'path':n,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in sorted(members.items())]}
members['manifest.json']=json.dumps(manifest,indent=2).encode()
dst=root/'docs/evidence/20261011/wrf_option2_wind_mixing_base.zip'
with zipfile.ZipFile(dst,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in sorted(members.items()):z.writestr(n,b)
with zipfile.ZipFile(dst) as z:
 assert z.testzip() is None
 for rec in manifest['files']: assert hashlib.sha256(z.read(rec['path'])).hexdigest()==rec['sha256']
receipt={'archive':str(dst),'bytes':dst.stat().st_size,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'verified_payloads':len(manifest['files']),'crc_pass':True,'executable_bytes_in_archive':False}
(ev/'pack_receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
