from pathlib import Path
import hashlib,json
import numpy as np
from netCDF4 import Dataset
out=Path(__file__).parent
root=Path('/private/tmp/pr294-same-state-rhs-20261011')
p=Path('/Users/yhlee/AD-SDIRK3-review-evidence/WRF-accuracy-cost-20261011/after_fix/sdirk_h15/wrfinput_d01')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with Dataset(p) as d:raw={n:np.asarray(d[n][0],dtype=np.float32) for n in ['U','V','W','PH','PHB','U_BASE','V_BASE','RDNW']}
assert raw['U'].shape==(16,16,17) and raw['V'].shape==(16,17,16) and np.all(raw['W']==0)
z=(raw['PH']+raw['PHB'])/np.float32(9.81)
r=np.zeros((17,16,16),np.float32);r[0]=np.float32(2)/(z[1]-z[0]);r[1:16]=np.float32(2)/(z[2:17]-z[:15])
a={n.lower():raw[n].transpose(1,0,2).copy() for n in ['U','V','W']};a.update(rdz=r.transpose(1,0,2).copy(),rdnw=np.abs(raw['RDNW']),u_base=raw['U_BASE'],v_base=raw['V_BASE'])
for n,v in a.items():np.asarray(v,dtype='<f4').tofile(out/(n+'.bin'))
s=(root/'dyn_em/module_diffusion_em.F').read_text()
def extract(var):
 needle='    IF ( config_flags%mix_full_fields ) THEN\n\n      DO j = j_start, j_end\n      DO k = kts+1, ktf\n      DO i = i_start, i_end\n        tmp1(i,k,j) = ( '+var+'(i,k,j)'
 start=s.index(needle);end=s.index('\n    END IF',start)+len('\n    END IF');return s[start:end]
bu,bv=extract('u'),extract('v')
pre='''program snapshot_shear
implicit none
integer,parameter:: nx=16,ny=16,nz=16
integer:: i,j,k,unit,m,kts,ktf,i_start,i_end,j_start,j_end
real:: u(nx+1,nz,ny),v(nx,nz,ny+1),rdz(nx,nz+1,ny)
real:: u_base(nz),v_base(nz),tmp1(nx+1,nz+1,ny+1)
real:: ou(nx+1,nz+1,ny),ov(nx,nz+1,ny+1)
type flags
 logical::mix_full_fields
end type
type(flags)::config_flags
'''
for name in ['u','v','rdz','u_base','v_base']:pre+=f"open(newunit=unit,file='{name}.bin',access='stream',form='unformatted');read(unit){name};close(unit)\n"
pre+='kts=1;ktf=nz\nDO m=1,2\nconfig_flags%mix_full_fields=(m==2)\ntmp1=0.;i_start=2;i_end=nx;j_start=1;j_end=ny\n'
mid='\nou=tmp1(1:nx+1,1:nz+1,1:ny)\ntmp1=0.;i_start=1;i_end=nx;j_start=2;j_end=ny\n'
post='\nov=tmp1(1:nx,1:nz+1,1:ny+1)\nif(m==1)then\n'
for kind in ['profile','full']:
 if kind=='full':post+='else\n'
 for var in ['u','v']:post+=f"open(newunit=unit,file='fortran_{kind}_{var}.bin',access='stream',form='unformatted',status='replace');write(unit)o{var};close(unit)\n"
post+='endif\nEND DO\nend program\n';(out/'snapshot_shear.f90').write_text(pre+bu+mid+bv+post)
rec={'scope':'archived initial state option-2 D13/D23 shear operand, not full RHS or endpoint cause','input_sha256':sha(p),'source_revision':'35037bd2093e17beb23d27857a6d9c81ce08aed0','fortran_source_sha256':sha(root/'dyn_em/module_diffusion_em.F'),'u_branch_sha256':hashlib.sha256(bu.encode()).hexdigest(),'v_branch_sha256':hashlib.sha256(bv.encode()).hexdigest(),'inputs':{n:{'shape':list(v.shape),'sha256':sha(out/(n+'.bin'))} for n,v in a.items()},'dtype':'little-endian float32 C [j,k,i], which equals Fortran memory [i,k,j]','W_exactly_zero':True,'owned_comparison':'U i2..16 j1..16 k2..16; V i1..16 j2..16 k2..16; fixed indices no correlation alignment','metric_scope':'shared FP32 physical rdz from PH+PHB source equation; metric implementation equality not independently established'}
(out/'snapshot_receipt.json').write_text(json.dumps(rec,indent=2));print('snapshot/extracted branches ready')
