#!/usr/bin/env python3
"""Analyze saved-state fields for the PR294 option-2 wind-base WRF runs.

This is an offline comparison only. It checks six owned WRF state fields at
all shared saved timestamps; it does not compare tendencies or the full RHS.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np


def _run_by_label(plan_path: Path, label: str, module):
    plan = json.loads(plan_path.read_text())
    matches = [row for row in plan["runs"] if row.get("label") == label]
    if len(matches) != 1:
        raise ValueError(f"{plan_path}: expected one run labeled {label}, found {len(matches)}")
    row = matches[0]
    data = module._load_run(row, plan_path.parent)
    files = []
    for output in data["wrfout_files"]:
        files.append({"path": output["path"], "sha256": output["sha256"],
                      "timestamps": output["timestamps"]})
    return plan, row, data, files


def _stats(a: np.ndarray, b: np.ndarray) -> dict:
    left = np.asarray(a, dtype=np.float64)
    right = np.asarray(b, dtype=np.float64)
    if left.shape != right.shape:
        raise ValueError(f"field shape mismatch: {left.shape} != {right.shape}")
    if not np.isfinite(left).all() or not np.isfinite(right).all():
        raise ValueError("non-finite field in offline comparison")
    delta = left - right
    return {"unit": None, "owned_point_count": int(delta.size),
            "absolute_error_rms": float(np.sqrt(np.mean(delta * delta))),
            "absolute_error_max": float(np.max(np.abs(delta))),
            "exact_array_equal": bool(np.array_equal(left, right))}


def _compare_runs(a: dict, b: dict, units: dict, labels: tuple[str, str]) -> dict:
    if a["grid"] != b["grid"]:
        raise ValueError(f"{labels}: grid or spacing differs")
    if set(a["timestamps"]) != set(b["timestamps"]):
        raise ValueError(f"{labels}: saved timestamp sets differ")
    common = a["timestamps"]
    if not common or common[0] != b["timestamps"][0] or common[-1] != b["timestamps"][-1]:
        raise ValueError(f"{labels}: no full exact timestamp overlap")
    result = {"left": labels[0], "right": labels[1], "times": {}}
    all_equal = True
    for timestamp in common:
        row = {}
        for field in units:
            item = _stats(a["frames"][timestamp][field], b["frames"][timestamp][field])
            item["unit"] = units[field]
            row[field] = item
            all_equal = all_equal and item["exact_array_equal"]
        result["times"][timestamp] = row
    result["all_fields_all_times_exact_equal"] = all_equal
    return result


def _endpoint_errors(actual: dict, reference: dict, units: dict, label: str) -> dict:
    if actual["grid"] != reference["grid"]:
        raise ValueError(f"{label}: grid or spacing differs from reference")
    end = actual["timestamps"][-1]
    if end not in reference["frames"]:
        raise ValueError(f"{label}: endpoint {end} absent from reference")
    out = {"time": end, "candidate": label, "fields": {}}
    for field in units:
        item = _stats(actual["frames"][end][field], reference["frames"][end][field])
        item["unit"] = units[field]
        out["fields"][field] = item
    return out


def _after_setter_shear_helper(evidence_dir: Path) -> dict:
    """Compare archived Fortran profile shear with C++ production-setter output."""
    shapes = {"u": (16, 17, 17), "v": (17, 17, 16)}
    result = {}
    for name in ("u", "v"):
        fortran = np.fromfile(evidence_dir / f"fortran_profile_{name}.bin",
                              dtype="<f4").reshape(shapes[name]).astype(np.float64)
        cpp = np.fromfile(evidence_dir / "after_setter" / f"cpp_profile_{name}.bin",
                          dtype="<f4").reshape(shapes[name]).astype(np.float64)
        mask = ((slice(1, 15), slice(1, 16), slice(1, 16)) if name == "u"
                else (slice(None), slice(None), slice(None)))
        left, right = fortran[mask], cpp[mask]
        error = right - left
        if not np.isfinite(left).all() or not np.isfinite(right).all():
            raise ValueError(f"non-finite {name.upper()} same-state shear helper")
        result[name.upper()] = {
            "unit": "s^-1", "owned_point_count": int(error.size),
            "fortran_vs_cpp_profile_error_rms": float(np.sqrt(np.mean(error * error))),
            "fortran_vs_cpp_profile_error_max_abs": float(np.max(np.abs(error))),
            "fortran_max_abs": float(np.max(np.abs(left))),
            "cpp_max_abs": float(np.max(np.abs(right))),
            "exact_array_equal": bool(np.array_equal(left, right)),
            "owned_mask": ("C-order [j=1:15,k=1:16,i=1:16] / matching Fortran "
                           "[j=2:15,k=2:16,i=2:16]" if name == "u"
                           else "all Y/Z/X faces; nondiscriminating because V profile is zero")}
    return {"scope": "D13/D23 shear helper outputs only, not full RHS",
            "profile_fixture": "same archived initial state and option-2 U_BASE/V_BASE profiles",
            "probe_receipt": str(evidence_dir / "shear_after_build_receipt.json"),
            "comparison": result}


def _run_receipt(plan: dict, row: dict, data: dict, files: list[dict]) -> dict:
    pin = plan.get("source_pin", {})
    return {"label": row["label"], "method": row["method"],
            "timestep_seconds": row["h_seconds"],
            "wall_seconds_single_run": row.get("wall_seconds"),
            "return_code": row.get("return_code"), "status": row.get("status"),
            "actual_cpp_sdirk_route": row.get("actual_cpp_sdirk_route"),
            "mpi_ranks": row.get("mpi_ranks"), "omp_threads": row.get("omp_threads"),
            "input_sha256": row.get("input_sha256"),
            "namelist_sha256": row.get("namelist_sha256"),
            "executable_sha256": row.get("executable_sha256"),
            "source_revision": plan.get("revision"),
            "source_pin_sha256": pin.get("production_diff_sha256"),
            "source_pin_files": pin.get("authoritative_production_sources", pin.get("sources", {})),
            "grid": data["grid"], "timestamps": data["timestamps"],
            "physical_minima_over_all_frames": data["physical_minima_over_all_frames"],
            "step_logs": data["step_logs"], "wrfout_files": files}


def _snapshot_run(manifest_path: Path, key: str, module):
    manifest = json.loads(manifest_path.read_text())
    spec = manifest["snapshots"][key]
    # Snapshot directories travel beside their manifest; original host paths
    # remain receipt metadata only.
    run_path = (manifest_path.parent / key).resolve()
    import hashlib
    for item in spec["wrfout_files"]:
        local_path = run_path / item["name"]
        actual = hashlib.sha256(local_path.read_bytes()).hexdigest()
        if actual != item["sha256"]:
            raise ValueError(f"snapshot hash mismatch for {local_path}")
    original = spec["original_run_receipt"]
    loader_row = {"label": original["label"], "path": str(run_path),
                  "h_seconds": original["h_seconds"], "method": original["method"]}
    data = module._load_run(loader_row, manifest_path.parent)
    originals = {item["name"]: item["original_path"] for item in spec["wrfout_files"]}
    files = [{**item, "original_path": originals[Path(item["path"]).name]}
             for item in data["wrfout_files"]]
    plan = {"revision": manifest["source_plan_revision"],
            "source_pin": manifest["source_pin"]}
    row = dict(original)
    row["path"] = str(run_path)
    row["snapshot_original_path"] = spec["original_run_path"]
    row["snapshot_manifest_path"] = str(manifest_path)
    return plan, row, data, files


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True,
                        help="worktree containing tools/benchmark_wrf_accuracy_cost.py")
    parser.add_argument("--new-plan", type=Path, required=True,
                        help="new post-wind-base WRF validation runs.json")
    parser.add_argument("--reference-snapshots", type=Path, required=True,
                        help="manifest for archived reference NetCDF snapshots bundled with this evidence")
    parser.add_argument("--evidence-dir", type=Path, required=True,
                        help="same-state-rhs evidence directory containing the shear helper binaries")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    sys.path.insert(0, str(repo / "tools"))
    import benchmark_wrf_accuracy_cost as benchmark

    new_plan, new_row, new, new_files = _run_by_label(
        args.new_plan.resolve(), "sdirk_h15", benchmark)
    new_rk_plan, new_rk_row, new_rk, new_rk_files = _run_by_label(
        args.new_plan.resolve(), "fortran_rk3_h3p75", benchmark)
    theta_plan, theta_row, theta, theta_files = _snapshot_run(
        args.reference_snapshots.resolve(), "after_theta_sdirk_h15", benchmark)
    theta_rk_plan, theta_rk_row, theta_rk, theta_rk_files = _snapshot_run(
        args.reference_snapshots.resolve(), "pr292_rk3_h3p75", benchmark)
    provisional_plan, provisional_row, provisional, provisional_files = _snapshot_run(
        args.reference_snapshots.resolve(), "pr292_rk3_h1p875", benchmark)

    all_input_hashes = {row["input_sha256"] for row in
                        (new_row, new_rk_row, theta_row, theta_rk_row, provisional_row)}
    if len(all_input_hashes) != 1:
        raise ValueError(f"run plans do not share one wrfinput_d01 SHA: {sorted(all_input_hashes)}")

    units = benchmark.VARIABLE_UNITS
    new_vs_archived_rk = _compare_runs(
        new_rk, theta_rk, units, (new_rk_row["label"], theta_rk_row["label"]))
    new_vs_after_theta_sdirk = _compare_runs(
        new, theta, units, (new_row["label"], theta_row["label"]))
    same_rk_reference_endpoint = _endpoint_errors(
        new, new_rk, units, new_row["label"])
    provisional_endpoint = _endpoint_errors(
        new, provisional, units, new_row["label"])
    after_theta_vs_same_rk = _endpoint_errors(
        theta, new_rk, units, theta_row["label"])
    after_theta_vs_provisional = _endpoint_errors(
        theta, provisional, units, theta_row["label"])

    output = {
        "schema": "pr294-option2-wind-base-wrf-saved-state-comparison-v1",
        "status": "offline_saved_output_analysis_complete",
        "scope": ("Owned-point U,V,W,PH,T,MU output-state comparisons only. "
                  "No tendency/full-RHS/forecast-cause certification."),
        "grid": new["grid"], "endpoint_seconds": 240,
        "units": units,
        "run_receipts": {
            "new_rk3_h3p75": _run_receipt(new_plan, new_rk_row, new_rk, new_rk_files),
            "new_option2_wind_base_sdirk_h15": _run_receipt(new_plan, new_row, new, new_files),
            "archived_after_theta_rk3_h3p75": _run_receipt(theta_rk_plan, theta_rk_row, theta_rk, theta_rk_files),
            "archived_after_theta_sdirk_h15": _run_receipt(theta_plan, theta_row, theta, theta_files),
            "provisional_pr292_rk3_h1p875": _run_receipt(
                provisional_plan, provisional_row, provisional, provisional_files)},
        "comparisons_all_saved_times": {
            "new_rk3_h3p75_vs_archived_pr292_rk3_h3p75": new_vs_archived_rk,
            "new_wind_base_sdirk_h15_vs_archived_after_theta_sdirk_h15":
                new_vs_after_theta_sdirk},
        "endpoint_error_rms_vs_references": {
            "new_wind_base_sdirk_h15_vs_same_state_rk3_h3p75": same_rk_reference_endpoint,
            "new_wind_base_sdirk_h15_vs_provisional_pr292_rk3_h1p875": provisional_endpoint,
            "archived_after_theta_sdirk_h15_vs_same_state_rk3_h3p75": after_theta_vs_same_rk,
            "archived_after_theta_sdirk_h15_vs_provisional_pr292_rk3_h1p875":
                after_theta_vs_provisional},
        "same_state_fortran_vs_cpp_profile_helper": _after_setter_shear_helper(
            args.evidence_dir.resolve()),
        "interpretation_limits": [
            "The h=1.875 RK3 run is provisional historical context, not exact truth or an order claim.",
            "The RK3 h=3.75 comparison checks output parity and is not proof of full-RHS parity.",
            "The SDIRK h=15 before/after comparison isolates neither the complete RHS nor an endpoint cause.",
            "Whole-path runtime is one observation per case, not an integrator-only benchmark or cost advantage claim.",
            "Four selected CTests, including the same-branch mixed-state AD/FD check, passed; full-RHS and endpoint attribution remain open."],
    }
    out_path = args.out.resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"status": output["status"], "out": str(out_path),
                      "shared_times": sorted(new_vs_archived_rk["times"]),
                      "rk3_exact_all_fields_all_times": new_vs_archived_rk["all_fields_all_times_exact_equal"],
                      "sdirk_shared_times": sorted(new_vs_after_theta_sdirk["times"])}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
