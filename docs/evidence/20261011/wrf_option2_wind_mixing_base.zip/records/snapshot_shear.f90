program snapshot_shear
implicit none
integer,parameter:: nx=16,ny=16,nz=16
integer:: i,j,k,unit,m,kts,ktf,i_start,i_end,j_start,j_end
real:: u(nx+1,nz,ny),v(nx,nz,ny+1),rdz(nx,nz+1,ny)
real:: u_base(nz),v_base(nz),tmp1(nx+1,nz+1,ny+1)
real:: ou(nx+1,nz+1,ny),ov(nx,nz+1,ny+1)
type flags
 logical::mix_full_fields
end type
type(flags)::config_flags
open(newunit=unit,file='u.bin',access='stream',form='unformatted');read(unit)u;close(unit)
open(newunit=unit,file='v.bin',access='stream',form='unformatted');read(unit)v;close(unit)
open(newunit=unit,file='rdz.bin',access='stream',form='unformatted');read(unit)rdz;close(unit)
open(newunit=unit,file='u_base.bin',access='stream',form='unformatted');read(unit)u_base;close(unit)
open(newunit=unit,file='v_base.bin',access='stream',form='unformatted');read(unit)v_base;close(unit)
kts=1;ktf=nz
DO m=1,2
config_flags%mix_full_fields=(m==2)
tmp1=0.;i_start=2;i_end=nx;j_start=1;j_end=ny
    IF ( config_flags%mix_full_fields ) THEN

      DO j = j_start, j_end
      DO k = kts+1, ktf
      DO i = i_start, i_end
        tmp1(i,k,j) = ( u(i,k,j) - u(i,k-1,j) ) *  &
                      0.5 * ( rdz(i,k,j) + rdz(i-1,k,j) )
      END DO
      END DO
      END DO

    ELSE

      DO j = j_start, j_end
      DO k = kts+1, ktf
      DO i = i_start, i_end
        tmp1(i,k,j) = ( u(i,k,j) - u_base(k) - u(i,k-1,j) + u_base(k-1) ) *  &
                      0.5 * ( rdz(i,k,j) + rdz(i-1,k,j) )
      END DO
      END DO
      END DO

    END IF
ou=tmp1(1:nx+1,1:nz+1,1:ny)
tmp1=0.;i_start=1;i_end=nx;j_start=2;j_end=ny
    IF ( config_flags%mix_full_fields ) THEN

      DO j = j_start, j_end
      DO k = kts+1, ktf
      DO i = i_start, i_end
        tmp1(i,k,j) = ( v(i,k,j) - v(i,k-1,j) ) *  &
                      0.5 * ( rdz(i,k,j) + rdz(i,k,j-1) )
      END DO
      END DO
      END DO

    ELSE

      DO j = j_start, j_end
      DO k = kts+1, ktf
      DO i = i_start, i_end
        tmp1(i,k,j) = ( v(i,k,j) - v_base(k) - v(i,k-1,j) + v_base(k-1) ) *  &
                      0.5 * ( rdz(i,k,j) + rdz(i,k,j-1) )
      END DO
      END DO
      END DO

    END IF
ov=tmp1(1:nx,1:nz+1,1:ny+1)
if(m==1)then
open(newunit=unit,file='fortran_profile_u.bin',access='stream',form='unformatted',status='replace');write(unit)ou;close(unit)
open(newunit=unit,file='fortran_profile_v.bin',access='stream',form='unformatted',status='replace');write(unit)ov;close(unit)
else
open(newunit=unit,file='fortran_full_u.bin',access='stream',form='unformatted',status='replace');write(unit)ou;close(unit)
open(newunit=unit,file='fortran_full_v.bin',access='stream',form='unformatted',status='replace');write(unit)ov;close(unit)
endif
END DO
end program
