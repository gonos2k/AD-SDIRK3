#include "wrf_sdirk3_tile_unified.h"

#include <torch/torch.h>

#include <array>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace {
using ::TileSDIRK3UnifiedSolver;
constexpr int nx = 16;
constexpr int ny = 16;
constexpr int nz = 16;
constexpr int nx_u = nx + 1;
constexpr int ny_v = ny + 1;
constexpr int nz_w = nz + 1;
using Options = torch::TensorOptions;

struct Defor13Tag {
    using type = torch::Tensor (TileSDIRK3UnifiedSolver::*)(
        const torch::Tensor&, const torch::Tensor&, const torch::Tensor&,
        const torch::Tensor&, const torch::Tensor&, const torch::Tensor&,
        const torch::Tensor&, const torch::Tensor&);
    friend type access(Defor13Tag);
};
struct Defor23Tag {
    using type = torch::Tensor (TileSDIRK3UnifiedSolver::*)(
        const torch::Tensor&, const torch::Tensor&, const torch::Tensor&,
        const torch::Tensor&, const torch::Tensor&, const torch::Tensor&,
        const torch::Tensor&, const torch::Tensor&);
    friend type access(Defor23Tag);
};
struct UBaseTag {
    using type = torch::Tensor TileSDIRK3UnifiedSolver::*;
    friend type access(UBaseTag);
};
struct VBaseTag {
    using type = torch::Tensor TileSDIRK3UnifiedSolver::*;
    friend type access(VBaseTag);
};
struct MixFullFieldsTag {
    using type = bool TileSDIRK3UnifiedSolver::*;
    friend type access(MixFullFieldsTag);
};

template<class Tag, typename Tag::type Member>
struct MemberAccessor {
    friend typename Tag::type access(Tag) { return Member; }
};
template struct MemberAccessor<Defor13Tag, &TileSDIRK3UnifiedSolver::compute_defor13>;
template struct MemberAccessor<Defor23Tag, &TileSDIRK3UnifiedSolver::compute_defor23>;
template struct MemberAccessor<UBaseTag, &TileSDIRK3UnifiedSolver::u_base_>;
template struct MemberAccessor<VBaseTag, &TileSDIRK3UnifiedSolver::v_base_>;
template struct MemberAccessor<MixFullFieldsTag, &TileSDIRK3UnifiedSolver::mix_full_fields_>;

std::vector<float> read_f32(const std::string& path, size_t count) {
    std::ifstream in(path, std::ios::binary);
    if (!in) throw std::runtime_error("cannot open " + path);
    std::vector<float> values(count);
    in.read(reinterpret_cast<char*>(values.data()),
            static_cast<std::streamsize>(count * sizeof(float)));
    if (in.gcount() != static_cast<std::streamsize>(count * sizeof(float)))
        throw std::runtime_error(path + ": unexpected byte count");
    char extra;
    if (in.read(&extra, 1)) throw std::runtime_error(path + ": trailing bytes");
    for (const float value : values)
        if (!std::isfinite(value)) throw std::runtime_error(path + ": non-finite value");
    return values;
}

float read_scalar(const std::string& path) {
    const auto values = read_f32(path, 1);
    return values.front();
}

torch::Tensor tensor3(const std::string& path, int64_t a, int64_t b, int64_t c,
                      const Options& options) {
    auto values = read_f32(path, static_cast<size_t>(a * b * c));
    return torch::from_blob(values.data(), {a, b, c}, options).clone();
}

torch::Tensor tensor1(const std::string& path, int64_t a, const Options& options) {
    auto values = read_f32(path, static_cast<size_t>(a));
    return torch::from_blob(values.data(), {a}, options).clone();
}

void write_f32(const std::string& path, const torch::Tensor& value) {
    const auto contiguous = value.detach().to(torch::kCPU, torch::kFloat32).contiguous();
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (!out) throw std::runtime_error("cannot create " + path);
    out.write(reinterpret_cast<const char*>(contiguous.data_ptr<float>()),
              static_cast<std::streamsize>(contiguous.numel() * sizeof(float)));
    if (!out) throw std::runtime_error("failed writing " + path);
}

void report(const char* label, const torch::Tensor& value) {
    torch::NoGradGuard no_grad;
    std::cout << label << " shape=" << value.sizes()
              << " max_abs=" << value.abs().max().item<double>()
              << " l2=" << value.norm().item<double>() << '\n';
}
}  // namespace

int main(int argc, char** argv) {
    try {
        if (argc != 2) {
            std::cerr << "usage: shear_probe INPUT_DIR\n";
            return 2;
        }
        const std::string dir = argv[1];
        const auto path = [&](const char* name) { return dir + "/" + name; };
        const auto options = Options().dtype(torch::kFloat32).device(torch::kCPU);

        const float dx = read_scalar(path("dx.bin"));
        const float dy = read_scalar(path("dy.bin"));
        const float rdx_value = read_scalar(path("rdx.bin"));
        const float rdy_value = read_scalar(path("rdy.bin"));
        if (!(dx > 0.0f && dy > 0.0f && rdx_value > 0.0f && rdy_value > 0.0f))
            throw std::runtime_error("grid spacing and reciprocal spacing must be positive");

        const auto u = tensor3(path("u.bin"), ny, nz, nx_u, options);
        const auto v = tensor3(path("v.bin"), ny_v, nz, nx, options);
        const auto w = tensor3(path("w.bin"), ny, nz_w, nx, options);
        const auto rdz = tensor3(path("rdz.bin"), ny, nz_w, nx, options);
        const auto rdnw = tensor1(path("rdnw.bin"), nz, options);
        const auto u_base = tensor1(path("u_base.bin"), nz, options);
        const auto v_base = tensor1(path("v_base.bin"), nz, options);
        const auto rdx = torch::full({1}, rdx_value, options);
        const auto rdy = torch::full({1}, rdy_value, options);
        const auto zero_w = torch::zeros({ny, nz_w, nx}, options);
        const auto zero_u = torch::zeros({ny, nz_w, nx_u}, options);
        const auto zero_v = torch::zeros({ny_v, nz_w, nx}, options);
        const auto no_metric = torch::Tensor();

        wrf::sdirk3::g_sdirk3_config = wrf::sdirk3::SDIRK3Config{};
        TileSDIRK3UnifiedSolver solver(nx, ny, nz, dx, dy,
                                       {rdx_value}, {rdy_value},
                                       std::vector<float>(rdnw.data_ptr<float>(),
                                                          rdnw.data_ptr<float>() + nz),
                                       0);
        // Full mass extents are 16x16; the staggered fields retain their 17th face.
        // Unit-map, periodic-X, symmetric-Y em_b_wave boundaries match this fixture.
        solver.setWRFIndices(1, nx, 1, ny, 1, nz,
                             1, nx + 1, 1, ny + 1, 1, nz + 1,
                             1, nx + 1, 1, ny + 1, 1, nz + 1);
        solver.setStaggeredDimensions(nx_u, ny_v, nz_w);
        solver.setBoundaryConditions(true, false, false, false, true, true,
                                     false, false, false, false);

        const auto run = [&](const char* suffix) {
            const auto defor13 = (solver.*access(Defor13Tag{}))(
                u, w, rdx, rdnw, zero_w, zero_w, no_metric, rdz);
            const auto defor23 = (solver.*access(Defor23Tag{}))(
                v, w, rdy, rdnw, zero_w, zero_w, no_metric, rdz);
            write_f32(path((std::string("cpp_") + suffix + "_u.bin").c_str()), defor13);
            write_f32(path((std::string("cpp_") + suffix + "_v.bin").c_str()), defor23);
            report((std::string(suffix) + "_D13").c_str(), defor13);
            report((std::string(suffix) + "_D23").c_str(), defor23);
            return std::pair<torch::Tensor, torch::Tensor>{defor13, defor23};
        };

        (solver.*access(UBaseTag{})) = torch::Tensor();
        (solver.*access(VBaseTag{})) = torch::Tensor();
        (solver.*access(MixFullFieldsTag{})) = true;
        std::cout << "case=current baseline_u_base_defined=0 baseline_v_base_defined=0"
                     " mix_full_fields=1\n";
        auto current = run("current");

        (solver.*access(UBaseTag{})) = u_base.clone();
        (solver.*access(VBaseTag{})) = v_base.clone();
        (solver.*access(MixFullFieldsTag{})) = false;
        std::cout << "case=profile diagnostic_u_base_defined=1 diagnostic_v_base_defined=1"
                     " mix_full_fields=0\n";
        auto profile = run("profile");
        report("delta_D13_profile_minus_current", profile.first - current.first);
        report("delta_D23_profile_minus_current", profile.second - current.second);
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "shear_probe: " << error.what() << '\n';
        return 1;
    }
}
