"""Run the declared 16^3 WRF whole-path benchmark with a frozen input."""
from pathlib import Path
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import time

ROOT = Path('/private/tmp/pr292-wrf-accuracy-cost-20261011')
OUT = Path('/Users/yhlee/AD-SDIRK3-review-evidence/WRF-accuracy-cost-20261011')
BASE = Path('/Users/yhlee/Documents/AD-SDIRK3-worktree-archive/20261005/native_wave_refinement/wrf_runs/signfix_fp64_carry_on15_240')
INPUT_SHA = 'e71b730a12e5a16d181f404f6314e7904e0165eefa622ffd0c508bf8c00dd2a9'
CASES = [('fortran_rk3_h15',15.0,'RK3'), ('fortran_rk3_h7p5',7.5,'RK3'), ('fortran_rk3_h3p75',3.75,'RK3'), ('sdirk_h30_checked',30.0,'SDIRK3')]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def replace_integer(text, key, value):
    text, count = re.subn(r'(\b'+re.escape(key)+r'\s*=\s*)[-+0-9]+',
                         lambda m: m[1]+str(value), text, count=1, flags=re.I)
    if count != 1:
        raise ValueError('missing namelist key '+key)
    return text


def main():
    exe = ROOT/'main/wrf.exe'
    if not exe.is_file() or sha(BASE/'wrfinput_d01') != INPUT_SHA:
        raise ValueError('executable absent or archived initial input changed')
    env = {k:v for k,v in os.environ.items() if not k.startswith('WRF_SDIRK3_')}
    env.update(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
               VECLIB_MAXIMUM_THREADS='1')
    plan = {'schema':'small-wrf-whole-path-accuracy-cost-runs-v1',
            'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
            'grid':[16,16,16], 'final_time_seconds':240,
            'comparison_scope':'whole-path; equality of complete semidiscrete operators is not established',
            'source_namelist_sha256':sha(BASE/'namelist.input'),
            'input_sha256':INPUT_SHA, 'executable_sha256':sha(exe), 'runs':[]}
    output = OUT/'runs.json'
    if output.exists():
        plan=json.loads(output.read_text())
        if plan.get('status')!='continuing':raise ValueError('unexpected existing plan')
    output.write_text(json.dumps(plan,indent=2))
    for label, h, method in CASES:
        folder = OUT/label
        folder.mkdir()
        shutil.copy2(BASE/'wrfinput_d01',folder/'wrfinput_d01')
        shutil.copy2(BASE/'diagnostics.txt',folder/'diagnostics.txt')
        for table in ('LANDUSE.TBL','VEGPARM.TBL','SOILPARM.TBL','GENPARM.TBL'):
            target=ROOT/'run'/table
            if target.exists(): (folder/table).symlink_to(target)
        integer=math.floor(h)
        numerator=round((h-integer)*4)
        denominator=4 if numerator else 1
        text=(BASE/'namelist.input').read_text()
        for key,value in [('time_step',integer),('time_step_fract_num',numerator),
                          ('time_step_fract_den',denominator),('rk_ord',3),('time_integration_scheme',0 if method=='RK3' else 6)]:
            text=replace_integer(text,key,value)
        (folder/'namelist.input').write_text(text)
        local_env=dict(env)
        command=['/usr/bin/time','-l','-o',str(folder/'time.log'),
                 '/opt/homebrew/bin/mpirun','-np','1','--bind-to','none',str(exe)]
        row={'label':label,'path':str(folder),'h_seconds':h,'method':method,
             'input_sha256':INPUT_SHA,'namelist_sha256':sha(folder/'namelist.input'),
             'executable_path':str(exe),'executable_sha256':sha(exe),
             'command':command,'omp_threads':1,'mpi_ranks':1,'status':'running'}
        plan['runs'].append(row);output.write_text(json.dumps(plan,indent=2))
        start=time.monotonic()
        with (folder/'run.log').open('wb') as log:
            process=subprocess.run(command,cwd=folder,env=local_env,stdout=log,
                                   stderr=subprocess.STDOUT,timeout=1800)
        row.update(wall_seconds=time.monotonic()-start,return_code=process.returncode)
        timing=(folder/'time.log').read_text();match=re.search(r'(\d+)\s+maximum resident set size',timing)
        row['peak_rss_bytes']=int(match[1]) if match else None
        for name in ('rsl.out.0000','rsl.error.0000','namelist.output'):
            row[name.replace('.','_')+'_sha256']=sha(folder/name) if (folder/name).exists() else None
        error=(folder/'rsl.error.0000').read_text() if (folder/'rsl.error.0000').exists() else ''
        is_cpp='SDIRK3 Zero-Copy: Calling actual solver' in error or 'SDIRK3 implicit time integration' in error
        step_text=(folder/'rsl.out.0000').read_text() if (folder/'rsl.out.0000').exists() else ''
        is_cpp=is_cpp or 'SDIRK3 Zero-Copy: Calling actual solver' in step_text
        row['actual_cpp_sdirk_route']=is_cpp
        row['status']='completed' if process.returncode==0 and 'SUCCESS COMPLETE' in error and is_cpp==(method=='SDIRK3') else 'failed'
        output.write_text(json.dumps(plan,indent=2))
        print(label,row['status'],row['wall_seconds'],flush=True)
        if row['status']!='completed':raise RuntimeError('native run failed: '+label)
    plan['status']='completed';output.write_text(json.dumps(plan,indent=2))


if __name__=='__main__':
    main()
