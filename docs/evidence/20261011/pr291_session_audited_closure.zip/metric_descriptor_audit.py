"""Recompute corrected selection against the exact archived Linux descriptor."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import zipfile
import numpy as np

ROOT = Path('/private/tmp/pr290-energy-20261011')
PRE = Path('/private/tmp/pr289-rotating-wave-preflight-38106019396')
OUT = Path('/Users/yhlee/AD-SDIRK3-review-evidence/PR290-20261011')
sys.path.insert(0, str(ROOT/'tools'))
import test_fine_wave_inverse as inverse
import test_rotating_wave_inverse as ri
import wave_rotating_reference as fixed
import wave_quadratic_reference as reference

csv = PRE/'extracted/measurement/descriptor_16x12x8.csv'
meta, arrays, _, text = inverse.read_payload(csv)
column = reference.build_case(16, 8, native_csv=csv)
profile = ri.require_rotating_profile(meta, text)
desc = {'column': column, 'rotating_profile': profile, 'base': arrays['base'], 'arrays': arrays}
case = ri.make_case(desc, OUT/'recomputed_case')
spec = importlib.util.spec_from_file_location('old_rotating', '/private/tmp/pr287-y-wave-20261010/tools/wave_rotating_reference.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
ri.rotating = old
try:
 old_case = ri.make_case(desc, OUT/'old_case_same_host')
finally:
 ri.rotating = fixed
same_host_input_bytes = {name: (OUT/'old_case_same_host/inputs'/name).read_bytes() == (OUT/'recomputed_case/inputs'/name).read_bytes() for name in ('initial_state.txt', 'observations.txt', 'canonical_basis.npy', 'source_H_BG.npy')}
old_mode = old.select_seeded_inertia_gravity_mode(case['matrix'], column, case['seed']['state'], f_fp32=case['f'], ny=12)
q = case['quadratures'][0]
rows, v = fixed._unpack(column, q, 12)
hx = column['H_source_physical']
t = column['T']
physical = sum(np.vdot(t@r, hx@(t@r)).real for r in rows)/12
physical += np.sum(np.abs(v)**2*np.real(np.diag(hx)[:8])/12)
new_energy = np.vdot(q, fixed.uniform_energy_metric(column)@q).real
old_energy = np.vdot(q, old.uniform_energy_metric(column)@q).real
input_parity = {}
inputs = PRE/'extracted/measurement/inputs'
for name in ('initial_state.txt', 'observations.txt', 'canonical_basis.npy', 'source_H_BG.npy'):
 a=(inputs/name).read_bytes(); b=(OUT/'recomputed_case/inputs'/name).read_bytes()
 if name.endswith('.npy'):
  left=np.load(inputs/name);right=np.load(OUT/'recomputed_case/inputs'/name)
 else:
  header = 1 if name == 'observations.txt' else 0
  left=np.fromstring(' '.join(a.decode().splitlines()[header:]),sep=' ');right=np.fromstring(' '.join(b.decode().splitlines()[header:]),sep=' ')
 input_parity[name] = {'archived_sha256':hashlib.sha256(a).hexdigest(), 'corrected_sha256':hashlib.sha256(b).hexdigest(), 'byte_identical':a==b, 'max_abs_difference':float(np.max(np.abs(left-right))), 'relative_l2':float(np.linalg.norm(left-right)/max(np.linalg.norm(left),np.finfo(float).tiny))}
with zipfile.ZipFile(PRE/'fixed-fine-accuracy.zip') as z:
 crc = z.testzip()
report = {'schema':'rotating-source-coordinate-metric-audit-v1', 'repo':str(ROOT), 'base_revision':'5baf7b4acebb7e02688372a4cd0432a75b5dc785', 'old_source_sha256':hashlib.sha256(Path('/private/tmp/pr287-y-wave-20261010/tools/wave_rotating_reference.py').read_bytes()).hexdigest(), 'corrected_source_sha256':hashlib.sha256((ROOT/'tools/wave_rotating_reference.py').read_bytes()).hexdigest(), 'descriptor_sha256':hashlib.sha256(csv.read_bytes()).hexdigest(), 'preflight_zip_sha256':hashlib.sha256((PRE/'fixed-fine-accuracy.zip').read_bytes()).hexdigest(), 'zip_crc_passed':crc is None, 'old_frequency':old_mode['angular_frequency'], 'corrected_frequency':case['mode']['angular_frequency'], 'old_overlap':old_mode['overlap_with_f0_seed'], 'corrected_overlap':case['mode']['overlap_with_f0_seed'], 'same_host_old_corrected_input_bytes':same_host_input_bytes, 'mode_array_identical':np.array_equal(old_mode['eigenvector'],case['mode']['eigenvector']), 'old_energy':old_energy, 'corrected_source_energy':new_energy, 'transformed_physical_energy':physical, 'energy_relative_difference':abs(new_energy/physical-1), 'old_to_correct_energy_ratio':old_energy/new_energy, 'input_parity':input_parity, 'uniform_coriolis_identity':case['energy_identity'], 'numpy_version':np.__version__, 'native_executions':0}
assert all(same_host_input_bytes.values())
assert report['mode_array_identical']
assert report['energy_relative_difference'] < 1e-12
assert case['energy_identity']['passed']
assert abs(report['corrected_frequency']/.0025701755450031065-1)<1e-11
assert all(p['relative_l2']<1e-10 for p in input_parity.values())
(OUT/'metric_descriptor_audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
