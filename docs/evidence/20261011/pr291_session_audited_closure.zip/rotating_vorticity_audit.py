#!/usr/bin/env python3
"""Audit native and frozen-source vorticity and divergence from rotating-wave artifacts.

Recipe (no native execution):
  python /Users/yhlee/AD-SDIRK3-review-evidence/PR290-20261011/rotating_vorticity_audit.py \
    --repo /private/tmp/pr290-energy-20261011 \
    --accepted-zip /path/to/rotating-inverse.zip --accepted-sha256 <sha256> \
    --forecast-zip /path/to/rotating-forecast.zip --forecast-sha256 <sha256> \
    --out /path/to/vorticity-audit.json

The accepted inverse ZIP alone audits 0/150/300 s. Supplying the forecast ZIP
adds 600/900 s after verifying the forecast's accepted-parent hash and exact
cold-restart state handoffs. This script reads archived CSV arrays and uses the
accepted 484-state source truth and basis; it never selects a replacement mode.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import zipfile
from pathlib import Path

import numpy as np


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_sha(path: Path) -> str:
    return sha(path.read_bytes())


def archive_report(archive: zipfile.ZipFile, schema: str) -> tuple[dict, str, str]:
    matches = []
    for name in archive.namelist():
        if not name.endswith("report.json"):
            continue
        payload = archive.read(name)
        try:
            report = json.loads(payload)
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
        if report.get("schema") == schema:
            matches.append((report, name.rsplit("/", 1)[0] + "/" if "/" in name else "", sha(payload)))
    if len(matches) != 1:
        raise ValueError(f"expected exactly one {schema} report, found {len(matches)}")
    return matches[0]


def read_artifact_inputs(forecast, report: dict, archive: zipfile.ZipFile, prefix: str) -> dict:
    payloads = {}
    for name, expected in report.get("input_sha256", {}).items():
        rel = f"{prefix}inputs/{name}"
        if rel not in archive.namelist():
            suffix = "/inputs/" + name
            candidates = [member for member in archive.namelist() if member.endswith(suffix)]
            if len(candidates) != 1:
                raise ValueError(f"missing/ambiguous input {name}")
            rel = candidates[0]
        data = archive.read(rel)
        if sha(data) != expected:
            raise ValueError(f"accepted inverse input hash mismatch: {name}")
        payloads[name] = data
    required = {"initial_state.txt", "observations.txt", "canonical_basis.npy", "source_H_BG.npy"}
    if required - payloads.keys():
        raise ValueError(f"missing inputs: {sorted(required-payloads.keys())}")
    return payloads


def verify_source_pins(repo: Path, source: dict) -> dict:
    pins = source.get("sha256", {})
    if not pins:
        raise ValueError("inverse report lacks source hashes")
    checked = {}
    for relative, expected in pins.items():
        path = repo / relative
        actual = file_sha(path) if path.is_file() else None
        if actual != expected:
            raise ValueError(f"source pin mismatch for {relative}: {actual} != {expected}")
        checked[relative] = actual
    return checked


def verify_path_pins(repo: Path, pins: dict, label: str) -> dict:
    checked = {}
    for relative, expected in pins.items():
        path = repo / relative
        actual = file_sha(path) if path.is_file() else None
        if actual != expected:
            raise ValueError(f"{label} source pin mismatch for {relative}: {actual} != {expected}")
        checked[relative] = actual
    return checked


def packed_vorticity(state: np.ndarray, *, nx: int, ny: int, nz: int,
                     rdx: float, rdy: float) -> tuple[np.ndarray, dict]:
    """Compute zeta=Dx(V)-Dy(U) on interior Y faces and unique X faces."""
    value = np.asarray(state, dtype=np.float64)
    sizes = (ny*nz*(nx+1), (ny+1)*nz*nx, ny*(nz+1)*nx,
             ny*(nz+1)*nx, ny*nz*nx, ny*nx)
    if value.shape != (sum(sizes),) or not np.isfinite(value).all():
        raise ValueError("expected finite native packed 8480-state")
    split = np.cumsum((0, *sizes))
    u = value[split[0]:split[1]].reshape(ny, nz, nx+1)
    v = value[split[1]:split[2]].reshape(ny+1, nz, nx)
    # Interior Y faces j=1..ny-1; X-face indices 0..nx-1 are unique.
    dx_v = (v[1:ny] - np.roll(v[1:ny], 1, axis=2)) * rdx
    dy_u = (u[1:ny, :, :nx] - u[:ny-1, :, :nx]) * rdy
    zeta = dx_v - dy_u
    if zeta.shape != (ny-1, nz, nx):
        raise AssertionError("vorticity owned stagger shape mismatch")
    return zeta, {"unique_x_faces": nx, "interior_y_faces": ny-1,
                  "levels": nz, "owned_point_count": int(zeta.size),
                  "rdx_fp32": rdx, "rdy_fp32": rdy,
                  "dx_v_term": stats(dx_v), "dy_u_term": stats(dy_u),
                  "interior_v_rms_m_s": float(np.sqrt(np.mean(v[1:ny]**2)))}


def packed_divergence(state: np.ndarray, *, nx: int, ny: int, nz: int,
                      rdx: float, rdy: float) -> tuple[np.ndarray, dict]:
    """Compute D=Dx(U)+Dy(V) at all owned mass cells, in s^-1."""
    value = np.asarray(state, dtype=np.float64)
    sizes = (ny*nz*(nx+1), (ny+1)*nz*nx, ny*(nz+1)*nx,
             ny*(nz+1)*nx, ny*nz*nx, ny*nx)
    if value.shape != (sum(sizes),) or not np.isfinite(value).all():
        raise ValueError("expected finite native packed 8480-state")
    split = np.cumsum((0, *sizes))
    u = value[split[0]:split[1]].reshape(ny, nz, nx+1)
    v = value[split[1]:split[2]].reshape(ny+1, nz, nx)
    # Mass cells j=0..ny-1 and unique periodic x cells i=0..nx-1.
    dx_u = (u[:, :, 1:nx+1] - u[:, :, :nx]) * rdx
    dy_v = (v[1:ny+1] - v[:ny]) * rdy
    divergence = dx_u + dy_v
    if divergence.shape != (ny, nz, nx):
        raise AssertionError("divergence owned mass-cell shape mismatch")
    if not np.isfinite(divergence).all():
        raise ValueError("non-finite horizontal divergence")
    return divergence, {"mass_cells_x": nx, "mass_cells_y": ny,
                        "levels": nz, "owned_point_count": int(divergence.size),
                        "rdx_fp32": rdx, "rdy_fp32": rdy,
                        "dx_u_term": stats(dx_u), "dy_v_term": stats(dy_v)}


def validate_divergence_math_fixture() -> dict:
    """Check the staggered operator with a simple periodic field and exact answer."""
    nx, ny, nz = 4, 2, 2
    dx, dy = 2.0, 4.0
    rdx, rdy = 1.0/dx, 1.0/dy
    sizes = (ny*nz*(nx+1), (ny+1)*nz*nx, ny*(nz+1)*nx,
             ny*(nz+1)*nx, ny*nz*nx, ny*nx)
    fields = np.zeros(sum(sizes), dtype=np.float64)
    split = np.cumsum((0, *sizes))
    u = fields[split[0]:split[1]].reshape(ny, nz, nx+1)
    v = fields[split[1]:split[2]].reshape(ny+1, nz, nx)
    u[:] = np.array([0.0, 2.0, 0.0, -2.0, 0.0])[None, None, :]
    v[:] = -1.0 * (np.arange(ny+1, dtype=np.float64) * dy)[:, None, None]
    divergence, geometry = packed_divergence(fields, nx=nx, ny=ny, nz=nz,
                                              rdx=rdx, rdy=rdy)
    expected = np.broadcast_to(np.array([0.0, -2.0, -2.0, 0.0]),
                               (ny, nz, nx)).copy()
    if not np.isfinite(fields).all() or not np.isfinite(divergence).all():
        raise ValueError("divergence fixture produced non-finite values")
    if not np.array_equal(divergence, expected):
        raise ValueError("affine staggered divergence fixture failed")
    return {"status": "passed", "shape": list(divergence.shape),
            "expected_D_by_x_s-1": expected[0, 0].tolist(),
            "actual_D_by_x_s-1": divergence[0, 0].tolist(),
            "finite_input_and_output": True,
            "owned_point_count": geometry["owned_point_count"]}


def stats(field: np.ndarray) -> dict:
    value = np.asarray(field, dtype=np.float64)
    return {"rms_s-1": float(np.sqrt(np.mean(value*value))),
            "max_abs_s-1": float(np.max(np.abs(value)))}


def load_call(forecast, archive: zipfile.ZipFile, prefix: str, row: dict,
              expected_f: float) -> tuple[dict, np.ndarray]:
    csv_name, state_name = row.get("bundle_csv"), row.get("bundle_initial_state")
    if not csv_name or not state_name:
        raise ValueError(f"call {row.get('label')} lacks archived CSV/state bundle")
    csv_bytes = forecast._member(archive, prefix, csv_name)
    if row.get("output_sha256") != sha(csv_bytes):
        raise ValueError(f"CSV digest mismatch for {row['label']}")
    state_bytes = forecast._member(archive, prefix, state_name)
    temp = Path(__import__("tempfile").mkdtemp(prefix="pr290-zeta-call-")) / "call.csv"
    temp.write_bytes(csv_bytes)
    meta, arrays, scalars, text = forecast.inverse.read_payload(temp)
    literal = forecast._literal_vector_from_bytes(state_bytes)
    if not np.array_equal(arrays.get("initial_state"), literal):
        raise ValueError(f"literal initial state differs from CSV for {row['label']}")
    if forecast.inverse.digest(literal) != row.get("state_sha256"):
        raise ValueError(f"forecast literal input digest mismatch for {row['label']}")
    forecast.driver.validate_trial(meta, arrays, scalars, text,
                                   expected_initial=literal, center_arrays=None, gradient=False)
    import test_rotating_wave_inverse as rotating_inverse
    rotating_inverse.require_rotating_profile(meta, text, expected_f=expected_f)
    return arrays, literal



def offline_inverse_anchors(parent: dict, source: dict, archive, prefix: str) -> dict:
    """Use archived native states; bound only cross-host chart reconstruction."""
    from rotating_inverse_optimizer_gate import load_call as optimizer_call

    rows = {row["label"]: row for row in parent["calls"]}
    observations = {f"observed_{t}": source["source_truth_observations"][j]
                    for j, t in enumerate((150, 300))}
    labels = {"start": "gradient_u0",
              "terminal": parent["terminal_gradient"]["call_label"]}
    result = {}
    for branch, label in labels.items():
        expected = np.asarray(parent["starting_controls"] if branch == "start"
                              else parent["terminal_gradient"]["delta"])
        row = rows[label]
        if row["kind"] != "gradient" or not np.array_equal(row["delta"], expected):
            raise ValueError(f"{branch} anchor is not its declared native gradient")
        call = optimizer_call(archive, prefix, row, source, source["basis"],
                              None, source["rotating_profile"], observations)
        arrays = call["arrays"]
        result[branch] = {"controls": call["delta"], "call": row,
                          "context_arrays": arrays,
                          "chart_reconstruction": call["chart_reconstruction"],
                          "states": {0: arrays["initial_state"],
                                     150: arrays["checkpoint_150"],
                                     300: arrays["checkpoint_300"]}}
    return result


def audit(args) -> dict:
    repo = args.repo.resolve()
    sys.path.insert(0, str(repo / "tools"))
    import test_y_wave_forecast as forecast

    accepted = args.accepted_zip.resolve()
    if file_sha(accepted) != args.accepted_sha256:
        raise ValueError("accepted inverse ZIP SHA256 mismatch")
    outdir = Path(__import__("tempfile").mkdtemp(prefix="pr290-zeta-source-"))
    with zipfile.ZipFile(accepted) as archive:
        if archive.testzip() is not None:
            raise ValueError("accepted inverse ZIP failed CRC check")
        parent, prefix, report_sha = archive_report(
            archive, "source-generated-rotating-wave-inverse-v1")
        if parent.get("status") != "completed_gradient_threshold":
            raise ValueError(f"inverse did not reach declared gradient threshold: {parent.get('status')}")
        if parent.get("grid") != [16, 12, 8] or parent.get("sigma") != 3.0e-4:
            raise ValueError("inverse grid or observation sigma does not match the frozen case")
        if parent.get("terminal_gradient", {}).get("reached") is not True:
            raise ValueError("terminal gradient threshold is not marked reached")
        if float(parent["terminal_gradient"]["gradient_l2"]) >= float(parent["terminal_gradient"]["threshold"]):
            raise ValueError("terminal gradient norm is not below its threshold")
        source_pins = verify_source_pins(repo, parent.get("source", {}))
        inputs = read_artifact_inputs(forecast, parent, archive, prefix)
        source = forecast._source_arrays(parent, {"input_bytes": inputs}, prefix, archive, outdir)
        if not source["is_rotating"] or source["source_truth_state"].shape != (484,):
            raise ValueError("accepted artifact did not produce the frozen 484-state source")
        anchors = offline_inverse_anchors(parent, source, archive, prefix)
        profile = source["rotating_profile"]
        rdx = forecast.rotating.validate_descriptor_symbols(
            source["column"], source["descriptor_text"], ny=12)["rdx_fp32"]
        rdy = profile["rdy_fp32"]
        inverse_exe = parent.get("native_executable_sha256")
        if inverse_exe != parent.get("source", {}).get("executable_sha256"):
            raise ValueError("inverse executable/source receipt mismatch")
        if not np.array_equal(np.asarray(parent["final_delta"]),
                              np.asarray(parent["terminal_gradient"]["delta"])):
            raise ValueError("terminal gradient and final control coordinates differ")

        states = {branch: dict(anchors[branch]["states"]) for branch in ("start", "terminal")}
        start_gradient = source["basis"].T @ anchors["start"]["context_arrays"]["initial_pullback"]
        terminal_gradient = source["basis"].T @ anchors["terminal"]["context_arrays"]["initial_pullback"]
        reported_terminal_gradient = np.asarray(parent["terminal_gradient"]["gradient"], dtype=np.float64)
        terminal_gradient_projection_error = float(
            np.linalg.norm(terminal_gradient-reported_terminal_gradient))
        if not np.allclose(terminal_gradient, reported_terminal_gradient,
                           rtol=1e-12, atol=1e-14):
            raise ValueError("terminal CSV pullback does not reproduce the reported two-control gradient")
        gradient_receipts = {
            "start": {"call_label": anchors["start"]["call"]["label"],
                      "gradient_vector": start_gradient.tolist(),
                      "gradient_l2": float(np.linalg.norm(start_gradient))},
            "terminal": {"call_label": parent["terminal_gradient"]["call_label"],
                         "gradient_l2": float(np.linalg.norm(terminal_gradient)),
                         "gradient_vector": terminal_gradient.tolist(),
                         "recomputed_vs_reported_l2": terminal_gradient_projection_error,
                         "threshold": parent["terminal_gradient"]["threshold"]}}
        forecast_receipt = None
        if args.forecast_zip:
            if not args.forecast_sha256:
                raise ValueError("--forecast-sha256 is required with --forecast-zip")
            forecast_zip = args.forecast_zip.resolve()
            if file_sha(forecast_zip) != args.forecast_sha256:
                raise ValueError("forecast ZIP SHA256 mismatch")
            with zipfile.ZipFile(forecast_zip) as fzip:
                if fzip.testzip() is not None:
                    raise ValueError("forecast ZIP failed CRC check")
                freport, fprefix, freport_sha = archive_report(fzip, "y-wave-state-only-forecast-v1")
                if freport.get("status") != "completed_state_only_forecast":
                    raise ValueError("forecast artifact is not a completed state-only forecast")
                if freport.get("accepted_zip_sha256") != args.accepted_sha256:
                    raise ValueError("forecast artifact does not name this accepted inverse ZIP")
                if (freport.get("inverse_report_sha256") != report_sha or
                        freport.get("inverse_native_executable_sha256") != inverse_exe or
                        freport.get("forecast_executable_sha256") != inverse_exe or
                        freport.get("final_executable_sha256") != inverse_exe):
                    raise ValueError("forecast source/report/executable chain mismatch")
                for key in ("forecast_source_sha256", "final_source_sha256"):
                    if set(freport.get(key, {})) != set(forecast.SOURCE_PATHS):
                        raise ValueError(f"{key} does not contain the complete expected source pins")
                forecast_source_pins = verify_path_pins(
                    repo, freport["forecast_source_sha256"], "forecast")
                verify_path_pins(repo, freport["final_source_sha256"], "final forecast")
                expected_calls = {"start_300_to_600", "start_600_to_900",
                                  "terminal_300_to_600", "terminal_600_to_900"}
                f_calls = {c.get("label"): c for c in freport.get("calls", [])}
                if (set(f_calls) != expected_calls or len(freport.get("calls", [])) != 4
                        or freport.get("total_native_calls") != 4):
                    raise ValueError("forecast does not contain exactly the four declared segments")
                for branch in ("start", "terminal"):
                    first_label = f"{branch}_300_to_600"
                    second_label = f"{branch}_600_to_900"
                    if first_label not in f_calls or second_label not in f_calls:
                        raise ValueError(f"forecast missing expected segment calls for {branch}")
                    for row in (f_calls[first_label], f_calls[second_label]):
                        if ("--rotating-wave" not in row.get("command", []) or
                                row.get("guards", {}).get("physical_observation_domain") != "passed" or
                                row.get("guards", {}).get("vertical_height_monotonic") != "passed" or
                                row.get("guards", {}).get("admissibility_checked_every_step") != 1):
                            raise ValueError(f"forecast profile/guard receipt failed for {row.get('label')}")
                    a600, literal600 = load_call(forecast, fzip, fprefix, f_calls[first_label], profile["f_fp32"])
                    a900, literal900 = load_call(forecast, fzip, fprefix, f_calls[second_label], profile["f_fp32"])
                    start300 = states[branch][300]
                    if not np.array_equal(literal600, start300):
                        raise ValueError(f"{branch} 300->600 restart initial state mismatch")
                    checkpoint600 = np.asarray(a600["checkpoint_300"], dtype=np.float64)
                    if not np.array_equal(literal900, checkpoint600):
                        raise ValueError(f"{branch} 600->900 restart did not use exact 600 checkpoint")
                    states[branch][600] = checkpoint600
                    states[branch][900] = np.asarray(a900["checkpoint_300"], dtype=np.float64)
                forecast_receipt = {"zip_sha256": args.forecast_sha256,
                                    "report_sha256": freport_sha,
                                    "report_source_revision": freport.get("forecast_source_revision"),
                                    "source_sha256": forecast_source_pins,
                                    "four_calls": ["start_300_to_600", "start_600_to_900",
                                                   "terminal_300_to_600", "terminal_600_to_900"]}

        source_fields = {str(t): forecast._source_state_at(source, t)
                         for t in (0, 150, 300, 600, 900)}
        output = {"schema": "pr290-owned-horizontal-vorticity-divergence-audit-v1",
                  "accepted_inverse_zip_sha256": args.accepted_sha256,
                  "accepted_inverse_report_sha256": report_sha,
                  "accepted_inverse_schema": parent["schema"],
                  "native_executable_sha256": inverse_exe,
                  "source_sha256": source_pins,
                  "descriptor_csv_sha256": parent["descriptor_csv_sha256"],
                  "rotating_profile": profile,
                  "controls": {"start": anchors["start"]["controls"].tolist(),
                               "terminal": anchors["terminal"]["controls"].tolist(),
                               "gradient_receipts": gradient_receipts,
                               "two_control_basis_shape": list(source["basis"].shape),
                               "source_H_BG_rank": int(np.linalg.matrix_rank(
                                   source["source_H_BG"] / 3.0e-4))},
                  "forecast_receipt": forecast_receipt,
                  "offline_anchor_chart_reconstruction": {branch: anchors[branch]["chart_reconstruction"] for branch in ("start", "terminal")},
                  "grid": [16, 12, 8], "owned_vorticity_layout":
                      "zeta_h on j=1..ny-1 Y faces, k=0..nz-1, unique periodic X faces i=0..nx-1",
                  "vorticity_operator": "DxV-DyU; DxV=(V[j,k,i]-V[j,k,i-1 mod nx])*rdx_fp32; DyU=(U[j,k,i]-U[j-1,k,i])*rdy_fp32",
                  "divergence_math_fixture": validate_divergence_math_fixture(),
                  "owned_divergence_layout":
                      "D on mass cells j=0..ny-1, k=0..nz-1, unique periodic X cells i=0..nx-1",
                  "divergence_operator": "D=DxU+DyV; DxU=(U[j,k,i+1]-U[j,k,i])*rdx_fp32; DyV=(V[j+1,k,i]-V[j,k,i])*rdy_fp32; units s^-1",
                  "native_vs_frozen_source": {},
                  "source_truth_scope": "The frozen 484-state linear constant-f source exp(A t), packed with the accepted canonical basis and descriptor equilibrium; not a nonlinear native trajectory or a formal Eg bound.",
                  "audit_native_calls": 0,
                  "artifact_contains_native_calls": True}
        times = (0, 150, 300, 600, 900) if args.forecast_zip else (0, 150, 300)
        source_signal = {str(t): forecast.owned_state_metrics(
            source["equilibrium_base"], source_fields[str(t)]) for t in times}
        for branch in ("start", "terminal"):
            output["native_vs_frozen_source"][branch] = {}
            for time_s in times:
                native_zeta, geometry = packed_vorticity(states[branch][time_s],
                    nx=16, ny=12, nz=8, rdx=rdx, rdy=rdy)
                source_zeta, _ = packed_vorticity(source_fields[str(time_s)],
                    nx=16, ny=12, nz=8, rdx=rdx, rdy=rdy)
                error = native_zeta-source_zeta
                native_divergence, native_divergence_geometry = packed_divergence(
                    states[branch][time_s], nx=16, ny=12, nz=8, rdx=rdx, rdy=rdy)
                source_divergence, source_divergence_geometry = packed_divergence(
                    source_fields[str(time_s)], nx=16, ny=12, nz=8, rdx=rdx, rdy=rdy)
                divergence_error = native_divergence-source_divergence
                owned_state_error = forecast.owned_state_metrics(
                    states[branch][time_s], source_fields[str(time_s)])
                for name, metrics in owned_state_error.items():
                    signal_rms = source_signal[str(time_s)][name]["absolute_error_rms"]
                    metrics["source_perturbation_signal_rms"] = signal_rms
                    metrics["relative_error_to_source_perturbation_signal"] = (
                        metrics["absolute_error_rms"] / signal_rms if signal_rms > 0.0 else None)
                output["native_vs_frozen_source"][branch][str(time_s)] = {
                    "owned_state_error_vs_source_truth": owned_state_error,
                    "native_zeta": stats(native_zeta), "source_zeta": stats(source_zeta),
                    "native_minus_source": stats(error),
                    "native_divergence": stats(native_divergence),
                    "source_divergence": stats(source_divergence),
                    "native_minus_source_divergence": stats(divergence_error),
                    "native_divergence_dx_u_term": native_divergence_geometry["dx_u_term"],
                    "native_divergence_dy_v_term": native_divergence_geometry["dy_v_term"],
                    "source_divergence_dx_u_term": source_divergence_geometry["dx_u_term"],
                    "source_divergence_dy_v_term": source_divergence_geometry["dy_v_term"],
                    "divergence_owned_points": native_divergence_geometry["owned_point_count"],
                    "native_dx_v_term": geometry["dx_v_term"],
                    "native_dy_u_term": geometry["dy_u_term"],
                    "source_dx_v_term": _["dx_v_term"],
                    "source_dy_u_term": _["dy_u_term"],
                    "native_interior_v_rms_m_s": geometry["interior_v_rms_m_s"],
                    "source_interior_v_rms_m_s": _["interior_v_rms_m_s"],
                    "owned_points": geometry["owned_point_count"]}
                if not stats(source_zeta)["rms_s-1"] > 0.0:
                    raise ValueError(f"frozen source has zero horizontal vorticity at {time_s}s")
                if not np.isfinite(divergence_error).all():
                    raise ValueError(f"non-finite native/source divergence error at {time_s}s")
        divergence_ratios = {}
        divergence_ratio_status = {}
        state_error_ratios = {}
        state_error_ratio_status = {}
        for time_s in times:
            values = {}
            statuses = {}
            for label in ("native_divergence", "source_divergence"):
                start_rms = output["native_vs_frozen_source"]["start"][str(time_s)][label]["rms_s-1"]
                terminal_rms = output["native_vs_frozen_source"]["terminal"][str(time_s)][label]["rms_s-1"]
                if not np.isfinite(start_rms) or not np.isfinite(terminal_rms):
                    raise ValueError(f"non-finite terminal/start {label} ratio input at {time_s}s")
                key = label.replace("_divergence", "")
                values[key] = None if start_rms == 0.0 else float(terminal_rms/start_rms)
                statuses[key] = "undefined_zero_start_rms" if start_rms == 0.0 else "defined"
            divergence_ratios[str(time_s)] = values
            divergence_ratio_status[str(time_s)] = statuses

            error_values = {}
            error_statuses = {}
            start_metrics = output["native_vs_frozen_source"]["start"][str(time_s)]
            terminal_metrics = output["native_vs_frozen_source"]["terminal"][str(time_s)]
            for name in ("u", "v", "w", "ph", "theta", "mu"):
                start_rms = start_metrics["owned_state_error_vs_source_truth"][name]["absolute_error_rms"]
                terminal_rms = terminal_metrics["owned_state_error_vs_source_truth"][name]["absolute_error_rms"]
                error_values[name] = None if start_rms == 0.0 else float(terminal_rms/start_rms)
                error_statuses[name] = "undefined_zero_start_error_rms" if start_rms == 0.0 else "defined"
            for name, metric, key in (
                    ("zeta", "native_minus_source", "rms_s-1"),
                    ("divergence", "native_minus_source_divergence", "rms_s-1")):
                start_rms = start_metrics[metric][key]
                terminal_rms = terminal_metrics[metric][key]
                error_values[name] = None if start_rms == 0.0 else float(terminal_rms/start_rms)
                error_statuses[name] = "undefined_zero_start_error_rms" if start_rms == 0.0 else "defined"
            if not all(value is None or np.isfinite(value) for value in error_values.values()):
                raise ValueError(f"non-finite terminal/start error ratio at {time_s}s")
            state_error_ratios[str(time_s)] = error_values
            state_error_ratio_status[str(time_s)] = error_statuses
        output["terminal_to_start_divergence_rms_ratio_by_time"] = divergence_ratios
        output["terminal_to_start_divergence_rms_ratio_status_by_time"] = divergence_ratio_status
        output["terminal_to_start_divergence_rms_ratio_units"] = "dimensionless"
        output["terminal_to_start_error_rms_ratio_by_time"] = state_error_ratios
        output["terminal_to_start_error_rms_ratio_status_by_time"] = state_error_ratio_status
        output["terminal_to_start_error_rms_ratio_units"] = "dimensionless"
        # State differences between controls establish actual two-control rotational response;
        # V presence alone is not used as the diagnostic.
        zeta_control_response = {}
        for time_s in times:
            start_zeta, _ = packed_vorticity(states["start"][time_s],
                nx=16, ny=12, nz=8, rdx=rdx, rdy=rdy)
            terminal_zeta, _ = packed_vorticity(states["terminal"][time_s],
                nx=16, ny=12, nz=8, rdx=rdx, rdy=rdy)
            zeta_control_response[str(time_s)] = stats(terminal_zeta-start_zeta)
        if not any(v["max_abs_s-1"] > 0.0 for v in zeta_control_response.values()):
            raise ValueError("two distinct controls produced no horizontal-vorticity response")
        output["terminal_minus_start_response"] = zeta_control_response
        output["physical_two_control_response"] = {
            "basis_shape": list(source["basis"].shape),
            "source_H_BG_rank": int(np.linalg.matrix_rank(source["source_H_BG"] / 3.0e-4)),
            "control_difference_l2": float(np.linalg.norm(
                anchors["terminal"]["controls"]-anchors["start"]["controls"])),
            "nonzero_vorticity_response": True}
        output["control_response_scope"] = (
            "V velocity is reported separately. Horizontal vorticity is computed from DxV-DyU; terminal-minus-start vorticity is the actual two-control state response, not inferred from V presence alone."
        )
        return output


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--accepted-zip", type=Path, required=True)
    parser.add_argument("--accepted-sha256", required=True)
    parser.add_argument("--forecast-zip", type=Path)
    parser.add_argument("--forecast-sha256")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if bool(args.forecast_zip) != bool(args.forecast_sha256):
        parser.error("--forecast-zip and --forecast-sha256 must be supplied together")
    result = audit(args)
    output = args.out.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": "passed", "out": str(output),
                      "forecast_included": bool(args.forecast_zip),
                      "branches": sorted(result["native_vs_frozen_source"]),
                      "times": sorted(next(iter(result["native_vs_frozen_source"].values())), key=int)},
                     sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
