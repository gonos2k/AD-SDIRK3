# Source-coordinate energy P2 closure and rotating-run continuation

Local timestamp: 2026-10-11 13:19:18 JST (+0900)

## Context and changes

Draft PR #290 https://github.com/gonos2k/AD-SDIRK3/pull/290 is based on merged main `5baf7b4acebb7e02688372a4cd0432a75b5dc785`. Fix revision is `59b301aedc3de7352ca208eb4de01a7344666ff7`. `uniform_energy_metric()` now applies `column["H"] = T^* Hx T` to source rows [u,w,PH,theta,MU]. The production C++/Fortran, operator, ABI and solver settings are unchanged. A focused complex-state regression includes nonzero PH/theta/MU and runs in minimal CI.

## Validation

- Local regression passes; the in-memory old-metric mutation fails. Green and Red independently approve the P2 correction.
- Actual archived Linux descriptor SHA `2fac664bfaa508023d96ea5e3876b6f9fd3a6591173aec48f5a709d33d4f7c83` reproduces the same eigenvector and omega `0.0025701755450031286` before/after the correction on this host. All four same-host inputs are byte-identical. The energy overlap changes from `0.998404519520722` to `0.9981666482617931`; transformed physical and source energies agree exactly. The old metric ratio is `516.4555951103581`.
- Cross-host regenerated arrays have different hashes and tiny numerical differences (basis relative L2 `2.659743113629561e-11`); archived source and input hashes remain authoritative.
- Verified pre-edit graph: 44 sources, zero mismatches. Refreshed graph: 45 sources, zero mismatches, 1522 nodes / 3533 edges, bound to fix revision. Module-qualified Python calls, headers and Fortran extraction have gaps; source code is authoritative.
- CI `38110744931` passed: fast contracts, source-coordinate energy identity, five CTest numerical/adjoint contracts, same-executable 16-step replay and metadata consumer. Artifact `11691539541` ZIP SHA `ab59788c1727e825cda873994bf29ae7531ead14779c22bf39c76b432e1a503a`; CRC passed.

No new production WRF `test/em_b_wave` run or same-setup RK3 forecast-field/runtime comparison was performed. Existing archived evidence is retained. The CI core tests are not a new WRF forecast comparison.

## Pending rotating inverse and prediction

Existing inverse run `38106368123` at producer `746ad78d029c6cf92c498288daee445fe4b3c22d` was still in progress at the latest query. No completed inverse or 600/900 s prediction is claimed. The preserved producer source will be used for continuation rather than weakening accepted-artifact source pins after the metric correction.

Evidence-folder scripts prepare offline checks of all accepted actual-cost Armijo steps, matching trial/fresh-gradient checkpoints, B^T pullback and the unchanged 1e-5 threshold. The continuation monitor must pass these and the source/ZIP/CRC gates before dispatching the four existing cold-restart forecast segments using a unique tag pinned to the original commit. Its singleton lock is atomic; ambiguous dispatch receipts stop without repeating a dispatch. It ends with `archives_audited_pending_team_review`, never an automatic research closure.

The archived-state audit computes owned-grid vorticity, mass-cell divergence and all six per-variable errors using existing authoritative slicing. Terminal/start error ratios have explicit undefined values at zero denominator. Only math fixtures were executed so far; no actual long-run arrays were available yet. Full-state stationarity, formal Eg bounds, variable mass/metrics, stronger rotation, moist/MPI generalization and broad meteorological validation remain separate open scopes.

## Next actions

Review the accepted inverse and forecast artifacts once available, including source/executable/input lineage, actual cost history and raw terminal gradient, all-six unused-time errors, vorticity and divergence. Have Green and Red independently review the newly available numerical evidence before declaring the rotating two-control case complete. Keep draft PR #290 separate from that completion claim.

Monitor launch: 2026-10-11 13:19:29 JST; PID 3188. Verified initial status `waiting_inverse`. State and log: `/Users/yhlee/AD-SDIRK3-review-evidence/PR290-20261011/continuation_state.json`, `/Users/yhlee/AD-SDIRK3-review-evidence/PR290-20261011/continuation.log`. Forecast has not yet been dispatched.
