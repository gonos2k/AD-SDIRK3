"""Continue the existing rotating experiment only after archived optimizer gates."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

EVIDENCE = Path(__file__).resolve().parent
REPO = 'gonos2k/AD-SDIRK3'
PRODUCER = Path('/private/tmp/pr287-y-wave-20261010')
HEAD = '746ad78d029c6cf92c498288daee445fe4b3c22d'
BRANCH = 'codex/pr289-coriolis-wave'
INVERSE_RUN = 38106368123
STATE_PATH = EVIDENCE/'continuation_state.json'
state = {'inverse_run': INVERSE_RUN, 'producer_revision': HEAD, 'status': 'waiting_inverse'}
DEADLINE = time.monotonic() + 5*3600

def save(**values):
    state.update(values, updated_at=datetime.now(timezone.utc).isoformat())
    temporary = STATE_PATH.with_suffix('.tmp')
    temporary.write_text(json.dumps(state, indent=2)+'\n')
    temporary.replace(STATE_PATH)
    print(json.dumps(state), flush=True)


def gh_json(endpoint):
    return json.loads(subprocess.check_output(['gh','api',f'repos/{REPO}/{endpoint}'], timeout=30))


def completed_run(run_id):
    while time.monotonic() < DEADLINE:
        try:
            run = gh_json(f'actions/runs/{run_id}')
        except (subprocess.SubprocessError, json.JSONDecodeError) as error:
            save(last_network_error=str(error))
            time.sleep(60)
            continue
        if run['head_sha'] != HEAD:
            raise ValueError('run source revision differs from frozen producer')
        if run['status'] == 'completed':
            save(last_run=run_id,last_conclusion=run['conclusion'])
            if run['conclusion'] != 'success':
                raise ValueError(f'run {run_id} ended {run["conclusion"]}; no new experiment dispatched')
            return run
        time.sleep(60)
    raise TimeoutError('monitor deadline exceeded without completed evidence')


def artifact(run_id, name):
    rows = gh_json(f'actions/runs/{run_id}/artifacts')['artifacts']
    match = [r for r in rows if r['name'] == f'fixed-fine-accuracy-{run_id}' and not r['expired']]
    if len(match) != 1:
        raise ValueError('completed measurement artifact missing or ambiguous')
    folder = EVIDENCE/f'run-{run_id}'
    folder.mkdir(exist_ok=True)
    path = folder/f'{name}.zip'
    if not path.exists():
        temporary = path.with_suffix('.partial')
        with temporary.open('wb') as output:
            subprocess.run(['gh','api',f'repos/{REPO}/actions/artifacts/{match[0]["id"]}/zip'], stdout=output,check=True,timeout=120)
        temporary.replace(path)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:
            raise ValueError('measurement ZIP CRC failure')
    save(**{name+'_artifact': {'run_id':run_id,'artifact_id':match[0]['id'],'sha256':digest,'path':str(path),'crc':'passed'}})
    return path,digest,match[0]['id']


def run_audit(script, arguments):
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    subprocess.run([sys.executable,'-B',str(EVIDENCE/script),*arguments],check=True,env=env,timeout=180)


def main():
    save()
    completed_run(INVERSE_RUN)
    inverse, inverse_sha, inverse_id = artifact(INVERSE_RUN,'inverse')
    run_audit('rotating_inverse_optimizer_gate.py',['--zip',str(inverse),'--sha256',inverse_sha,'--out',str(EVIDENCE/'actual_optimizer_audit.json')])
    common=['--repo',str(PRODUCER),'--accepted-zip',str(inverse),'--accepted-sha256',inverse_sha]
    run_audit('rotating_vorticity_audit.py',[*common,'--out',str(EVIDENCE/'actual_inverse_horizontal_audit.json')])
    save(status='inverse_archives_verified')
    if gh_json(f'git/ref/heads/{BRANCH}')['object']['sha'] != HEAD:
        raise ValueError('producer branch moved; forecast refused')
    # Pin the dispatch to a new tag created from the exact producer commit.
    forecast_ref = f'research/pr289-forecast-{INVERSE_RUN}-{int(time.time())}-{os.getpid()}'
    subprocess.run(['gh','api','--method','POST',f'repos/{REPO}/git/refs','-f',f'ref=refs/tags/{forecast_ref}','-f',f'sha={HEAD}'],check=True,timeout=30)
    if gh_json(f'git/ref/tags/{forecast_ref}')['object']['sha'] != HEAD:
        raise ValueError('forecast tag does not point at frozen producer')
    save(forecast_ref=forecast_ref, forecast_source_revision=HEAD)
    endpoint=f'actions/workflows/sdirk3-ci.yml/runs?branch={forecast_ref}&event=workflow_dispatch&per_page=20'
    before={r['id'] for r in gh_json(endpoint)['workflow_runs']}
    save(status='dispatching_forecast',forecast_inputs={'fine_accuracy_schedule':'rotating-wave-forecast','continuation_artifact_id':str(inverse_id),'continuation_zip_sha256':inverse_sha})
    subprocess.run(['gh','workflow','run','sdirk3-ci.yml','-R',REPO,'--ref',forecast_ref,'-f','fine_accuracy_diagnostic=true','-f','fine_accuracy_schedule=rotating-wave-forecast','-f',f'continuation_artifact_id={inverse_id}','-f',f'continuation_zip_sha256={inverse_sha}'],check=True,timeout=30)
    forecast_id=None
    for _ in range(30):
        runs=[r for r in gh_json(endpoint)['workflow_runs'] if r['id'] not in before]
        if len(runs)>1:
            raise ValueError('forecast dispatch ambiguous; do not dispatch again')
        if runs:
            if runs[0]['head_sha'] != HEAD or runs[0]['head_branch'] != forecast_ref:
                raise ValueError('new forecast run does not match pinned dispatch tag')
            forecast_id=runs[0]['id'];break
        time.sleep(10)
    if forecast_id is None:
        raise ValueError('forecast dispatch receipt unavailable; do not dispatch again')
    save(status='forecast_in_progress',forecast_run=forecast_id)
    completed_run(forecast_id)
    forecast,forecast_sha,_=artifact(forecast_id,'forecast')
    run_audit('rotating_vorticity_audit.py',[*common,'--forecast-zip',str(forecast),'--forecast-sha256',forecast_sha,'--out',str(EVIDENCE/'actual_forecast_horizontal_audit.json')])
    save(status='archives_audited_pending_team_review',formal_Eg_bound=False,new_WRF_RK3_comparison=False)

if __name__=='__main__':
    try:
        lock = os.open(EVIDENCE/'continuation.lock', os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        raise SystemExit('continuation monitor lock already exists; review before restarting')
    with os.fdopen(lock, 'w') as stream:
        stream.write(str(os.getpid())+'\n')
    if STATE_PATH.exists():
        raise SystemExit('existing continuation state; review before starting another monitor')
    try:
        main()
    except Exception as error:
        save(status='stopped_requires_review',failure_type=type(error).__name__,failure=str(error))
        raise
