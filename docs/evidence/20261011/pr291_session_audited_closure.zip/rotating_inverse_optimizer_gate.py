#!/usr/bin/env python3
"""Offline archive gate for the PR289 rotating-wave optimizer receipt.

This reads a completed CI artifact ZIP and its bundled CSV/state files. It
does not invoke the native executable or alter the producer checkout.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

import numpy as np

PRODUCER_ROOT = Path("/private/tmp/pr287-y-wave-20261010")
PRODUCER_REVISION = "746ad78d029c6cf92c498288daee445fe4b3c22d"
EXPECTED_SOURCE_FILES = {
    "tools/test_rotating_wave_inverse.py",
    "tools/test_y_wave_inverse.py",
    "tools/probe_small_step_inverse.py",
    "tools/test_fine_wave_inverse.py",
    "tools/wave_quadratic_reference.py",
    "tools/wave_y_reference.py",
    "tools/wave_rotating_reference.py",
    "tools/wave_energy_spatial_reference.py",
    "tools/wave_quadratic_transport.py",
    "external/libtorch_wrf/sdirk3/tests/test_native_wave_refinement.cpp",
    "external/libtorch_wrf/sdirk3/wrf_sdirk3_coriolis.h",
    "external/libtorch_wrf/sdirk3/wrf_sdirk3_newton_solver.h",
    "external/libtorch_wrf/sdirk3/wrf_sdirk3_newton_solver.cpp",
    "external/libtorch_wrf/sdirk3/wrf_sdirk3_config.h",
    "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified.h",
    "external/libtorch_wrf/sdirk3/wrf_sdirk3_tile_unified_impl.cpp",
    "dyn_em/module_big_step_utilities_em.F",
    "dyn_em/module_implicit_sdirk3.F",
}
EXPECTED_INPUTS = {
    "initial_state.txt", "observations.txt", "canonical_basis.npy",
    "source_H_BG.npy",
}
EXPECTED_LABELS = ("predicted_150", "checkpoint_150", "bracket_index_150",
                   "predicted_300", "checkpoint_300", "bracket_index_300")

sys.path.insert(0, str(PRODUCER_ROOT / "tools"))
import probe_small_step_inverse as driver  # noqa: E402
import test_fine_wave_inverse as inverse  # noqa: E402
import test_rotating_wave_inverse as rotating_inverse  # noqa: E402
import test_y_wave_forecast as forecast  # noqa: E402
import test_y_wave_inverse as y_inverse  # noqa: E402


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def verify_source(report: dict, source_root: Path) -> dict:
    source = report.get("source", {})
    require(source.get("revision") == PRODUCER_REVISION,
            "producer revision differs from pinned 746ad78 source")
    actual_head = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=source_root, text=True).strip()
    require(actual_head == PRODUCER_REVISION,
            f"source checkout HEAD is {actual_head}, expected {PRODUCER_REVISION}")
    recorded = source.get("sha256", {})
    require(set(recorded) == EXPECTED_SOURCE_FILES,
            "inverse report source-pin set is incomplete or unexpected")
    mismatches = {}
    for relative, expected in recorded.items():
        path = source_root / relative
        actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
        if actual != expected:
            mismatches[relative] = {"expected": expected, "actual": actual}
    require(not mismatches, f"producer source-pin mismatch: {mismatches}")
    executable_sha = source.get("executable_sha256")
    require(bool(executable_sha) and
            report.get("native_executable_sha256") == executable_sha,
            "report and source receipt executable SHA differ")
    return {"revision": actual_head, "source_file_count": len(recorded),
            "source_sha256": recorded,
            "executable_sha256_reported_consistently": executable_sha,
            "executable_binary_rehashed": False}


def verify_chart_reconstruction(base: np.ndarray, basis: np.ndarray,
                                delta: np.ndarray, literal: np.ndarray) -> dict:
    """Bound host-level FP64 rounding when rebuilding the chart state.

    The literal state remains authoritative for native/CSV comparisons. This
    checks only that it is within the forward-error bound of base + B @ delta.
    Four rounded operations cover the two products, their sum, and base add.
    """
    base = np.asarray(base, dtype=np.float64)
    basis = np.asarray(basis, dtype=np.float64)
    delta = np.asarray(delta, dtype=np.float64)
    literal = np.asarray(literal, dtype=np.float64)
    require(base.ndim == literal.ndim == 1 and base.shape == literal.shape and
            basis.shape == (base.size, 2) and delta.shape == (2,),
            "chart reconstruction operands have invalid shapes")
    require(np.isfinite(base).all() and np.isfinite(basis).all() and
            np.isfinite(delta).all() and np.isfinite(literal).all(),
            "chart reconstruction operands must be finite")
    terms = basis * delta[None, :]
    reconstructed = base + basis @ delta
    eps = np.finfo(np.float64).eps
    gamma4 = 4.0 * eps / (1.0 - 4.0 * eps)
    bound = gamma4 * (np.abs(base) + np.abs(terms[:, 0]) + np.abs(terms[:, 1]))
    difference = np.abs(literal - reconstructed)
    ratio = np.divide(difference, bound, out=np.zeros_like(difference), where=bound > 0.0)
    violations = difference > bound
    require(not np.any(violations),
            "literal initial state exceeds componentwise FP64 chart reconstruction bound")
    return {"formula": "base + basis @ delta",
            "bound_formula": "gamma4*(abs(base)+abs(basis[:,0]*delta[0])+abs(basis[:,1]*delta[1]))",
            "gamma4": float(gamma4),
            "max_abs_difference": float(np.max(difference)),
            "mismatched_components": int(np.count_nonzero(difference)),
            "max_componentwise_bound": float(np.max(bound)),
            "max_difference_to_bound_ratio": float(np.max(ratio)),
            "bound_violations": int(np.count_nonzero(violations))}


def load_call(archive: zipfile.ZipFile, prefix: str, row: dict,
              source: dict, basis: np.ndarray, center_arrays: dict | None,
              profile: dict, observations: dict) -> dict:
    require(row.get("kind") in {"gradient", "forward_trial"},
            f"unexpected optimizer call kind: {row.get('label')}")
    require(row.get("return_code") == 0 and row.get("output_sha256") and
            row.get("state_sha256"),
            f"optimizer call lacks successful return/hash receipts: {row.get('label')}")
    meta, arrays, scalars, text, literal = forecast._call_bundle(archive, prefix, row)
    delta = np.asarray(row.get("delta"), dtype=np.float64)
    require(delta.shape == (2,) and np.isfinite(delta).all(),
            f"invalid control vector in {row.get('label')}")
    chart_receipt = verify_chart_reconstruction(
        source["equilibrium_base"], basis, delta, literal)
    require(np.array_equal(arrays.get("initial_state"), literal),
            f"native initial state differs from literal call input: {row.get('label')}")
    is_gradient = row["kind"] == "gradient"
    driver.validate_trial(meta, arrays, scalars, text,
                          expected_initial=literal,
                          center_arrays=center_arrays, gradient=is_gradient)
    rotating_inverse.require_rotating_profile(
        meta, text, expected_f=profile["f_fp32"])
    for key in driver.CONTEXT:
        require(np.array_equal(arrays.get(key), source["descriptor_arrays"].get(key)),
                f"descriptor context mismatch for {key} at {row.get('label')}")
    for key in ("observed_150", "observed_300"):
        require(np.array_equal(arrays.get(key), observations[key]),
                f"observation array mismatch for {key} at {row.get('label')}")
    for time_s in (150, 300):
        predicted = arrays[f"predicted_{time_s}"]
        observed = arrays[f"observed_{time_s}"]
        residual = predicted - observed
        require(np.isfinite(residual).all(),
                f"nonfinite observation residual at {row.get('label')}")
    recomputed_objective = 0.5 * sum(
        float(np.sum((arrays[f"predicted_{time_s}"] - arrays[f"observed_{time_s}"])**2))
        for time_s in (150, 300)) / forecast.OBSERVATION_SIGMA**2
    objective = float(scalars["objective_physical_w"])
    require(np.isclose(objective, recomputed_objective, rtol=2e-12, atol=1e-9),
            f"raw predicted-W objective mismatch at {row.get('label')}: native={objective}, recomputed={recomputed_objective}")
    require(np.isclose(objective, row.get("objective"), rtol=2e-12, atol=1e-9),
            f"call/report objective mismatch at {row.get('label')}")
    gradient = None
    if is_gradient:
        gradient = basis.T @ arrays["initial_pullback"]
        require(gradient.shape == (2,) and np.isfinite(gradient).all(),
                f"invalid projected gradient at {row.get('label')}")
    return {"row": row, "delta": delta, "arrays": arrays,
            "objective": objective, "gradient": gradient,
            "chart_reconstruction": chart_receipt}


def verify_archive(zip_path: Path, expected_sha: str, source_root: Path) -> dict:
    actual_sha = hashlib.sha256(zip_path.read_bytes()).hexdigest()
    require(actual_sha == expected_sha,
            f"artifact ZIP SHA mismatch: expected {expected_sha}, got {actual_sha}")
    with zipfile.ZipFile(zip_path) as archive:
        bad_member = archive.testzip()
        require(bad_member is None, f"ZIP CRC failure at {bad_member}")
        report, prefix, report_sha = forecast._read_report(archive)
        require(report.get("schema") == "source-generated-rotating-wave-inverse-v1",
                "artifact does not contain exactly one rotating inverse report")
        require(report.get("status") == "completed_gradient_threshold",
                f"inverse did not terminate at the gradient threshold: {report.get('status')}")
        require(report.get("grid") == [16, 12, 8] and report.get("steps") == 960 and
                report.get("dt") == 0.3125 and report.get("times") == [150.0, 300.0],
                "inverse schedule differs from the fixed rotating 960-step setup")
        require(report.get("optimizer_run") is True,
                "report does not attest that the optimizer ran")
        require(report.get("formal_Eg_bound") is False,
                "optimizer receipt must not claim a formal Eg bound")
        require(report.get("gradient_threshold") == y_inverse.GRADIENT_THRESHOLD == 1e-5,
                "declared gradient threshold changed")
        require(report.get("convergence_claim") ==
                "two-control projected gradient below 1e-5; no formal Eg bound",
                "convergence claim is missing or overstates the evidence")
        source_receipt = verify_source(report, source_root)
        input_hashes = report.get("input_sha256", {})
        require(set(input_hashes) == EXPECTED_INPUTS,
                "inverse input pin set is incomplete or unexpected")

        with tempfile.TemporaryDirectory(prefix="pr290-rotating-gate-") as temp_name:
            temp_dir = Path(temp_name)
            input_dir = temp_dir / "inputs"
            input_dir.mkdir()
            input_bytes = {}
            for name, expected in input_hashes.items():
                data = forecast._member(archive, prefix, f"inputs/{name}")
                require(sha_bytes(data) == expected, f"input SHA mismatch: {name}")
                (input_dir / name).write_bytes(data)
                input_bytes[name] = data
            artifact_receipt = {"input_bytes": input_bytes}
            source_data = forecast._source_arrays(
                report, artifact_receipt, prefix, archive, temp_dir)
            require(source_data["is_rotating"], "source loader did not select rotating dynamics")
            require(source_data["basis"].shape == (8480, 2),
                    "archived two-control basis has unexpected dimensions")
            profile = source_data["rotating_profile"]
            require(profile is not None, "rotating descriptor profile is missing")

            call_rows = report.get("calls", [])
            require(report.get("total_native_calls") == len(call_rows),
                    "total_native_calls differs from archived call history")
            labels = [row.get("label") for row in call_rows]
            require(len(labels) == len(set(labels)), "inverse call labels are not unique")
            optimizer_rows = [row for row in call_rows
                              if row.get("kind") in {"gradient", "forward_trial"}]
            by_label = {row["label"]: row for row in optimizer_rows}
            require("gradient_u0" in by_label and
                    by_label["gradient_u0"].get("kind") == "gradient",
                    "initial native gradient call is missing")
            center_arrays = None
            decoded = {}
            gradient_calls = {}
            observations = {}
            for index, row in enumerate(optimizer_rows):
                # The first optimizer call is the anchor gradient. Its own
                # observations become the exact context for every later call.
                if index == 0:
                    m, a, s, t, _ = forecast._call_bundle(archive, prefix, row)
                    center_arrays = a
                    observations = {k: a[k] for k in ("observed_150", "observed_300")}
                call_data = load_call(archive, prefix, row, source_data,
                                      source_data["basis"], center_arrays,
                                      profile, observations)
                decoded[row["label"]] = call_data
                if call_data["gradient"] is not None:
                    gradient_calls[row["label"]] = call_data
            require(len(gradient_calls) >= 1, "no raw native gradient calls were verified")
            expected_gradient_labels = [f"gradient_u{i}" for i in range(len(gradient_calls))]
            require(set(gradient_calls) == set(expected_gradient_labels),
                    "native gradient call labels are not contiguous from gradient_u0")

            initial_gradient = gradient_calls["gradient_u0"]["gradient"]
            require(np.allclose(initial_gradient, report.get("native_gradient_initial"),
                                rtol=2e-13, atol=1e-10),
                    "projected gradient_u0 differs from report native_gradient_initial")

            updates = report.get("updates", [])
            accepted = [u for u in updates if u.get("decision") == "accepted"]
            require(len(accepted) > 0, "no accepted optimizer updates are recorded")
            require(len(accepted) == len(updates),
                    "completed threshold report contains an incomplete optimizer update")
            step_records = []
            current = gradient_calls["gradient_u0"]
            for index, update in enumerate(accepted):
                current_label = f"gradient_u{index}"
                fresh_label = f"gradient_u{index + 1}"
                require(current_label in gradient_calls and fresh_label in gradient_calls,
                        f"update {index + 1} lacks current or fresh native gradient")
                current = gradient_calls[current_label]
                fresh = gradient_calls[fresh_label]
                g = current["gradient"]
                require(np.array_equal(np.asarray(update.get("delta"), dtype=np.float64),
                                       current["delta"]),
                        f"update {index + 1} delta differs from current gradient call")
                require(np.allclose(np.asarray(update.get("gradient"), dtype=np.float64),
                                    g, rtol=2e-13, atol=1e-10),
                        f"update {index + 1} gradient differs from raw B^T pullback")
                require(np.isclose(update.get("objective"), current["objective"],
                                   rtol=2e-12, atol=1e-9),
                        f"update {index + 1} current objective differs from raw gradient call")
                direction = np.asarray(update.get("direction"), dtype=np.float64)
                slope = float(g @ direction)
                require(direction.shape == (2,) and np.isfinite(direction).all() and
                        np.isclose(slope, update.get("gradient_slope"), rtol=2e-12, atol=1e-10) and
                        slope < 0.0,
                        f"update {index + 1} direction/slope receipt is invalid")
                accepted_rows = [r for r in update.get("line_search", []) if r.get("accepted")]
                require(len(accepted_rows) == 1,
                        f"update {index + 1} must have exactly one accepted Armijo record")
                armijo = accepted_rows[0]
                trial_label = armijo.get("call_label")
                require(trial_label in decoded and decoded[trial_label]["row"].get("kind") == "forward_trial",
                        f"update {index + 1} accepted trial CSV/state is missing")
                trial = decoded[trial_label]
                alpha = float(armijo["alpha"])
                expected_delta = current["delta"] + alpha * direction
                require(np.array_equal(trial["delta"], expected_delta) and
                        np.array_equal(np.asarray(update.get("accepted_delta"), dtype=np.float64),
                                       expected_delta),
                        f"update {index + 1} accepted control delta differs from raw trial")
                current_cost = current["objective"]
                trial_cost = trial["objective"]
                bound = current_cost + y_inverse.ARMIJO * alpha * slope
                require(trial_cost < current_cost and trial_cost <= bound and
                        np.isclose(armijo.get("objective"), trial_cost, rtol=2e-12, atol=1e-9) and
                        np.isclose(armijo.get("armijo_bound"), bound, rtol=2e-12, atol=1e-9) and
                        np.isclose(update.get("accepted_objective"), trial_cost,
                                   rtol=2e-12, atol=1e-9) and
                        np.isclose(update.get("alpha"), alpha, rtol=0.0, atol=0.0),
                        f"update {index + 1} fails recomputed strict actual-cost Armijo")
                gradient_point = {"label": fresh_label, "delta": fresh["delta"],
                                  "arrays": fresh["arrays"], "objective": fresh["objective"]}
                trial_point = {"label": trial_label, "delta": trial["delta"],
                               "arrays": trial["arrays"], "objective": trial["objective"]}
                y_inverse.same_trial_and_gradient(trial_point, gradient_point)
                require(np.array_equal(fresh["delta"], trial["delta"]),
                        f"update {index + 1} fresh gradient is not at accepted trial point")
                fresh_cost = fresh["objective"]
                require(fresh_cost < current_cost,
                        f"update {index + 1} fresh gradient endpoint cost did not decrease")
                step_records.append({"update": index + 1, "current_gradient_call": current_label,
                                     "accepted_trial_call": trial_label,
                                     "fresh_gradient_call": fresh_label, "alpha": alpha,
                                     "current_objective_recomputed": current_cost,
                                     "trial_objective_recomputed": trial_cost,
                                     "fresh_gradient_objective_recomputed": fresh_cost,
                                     "strict_cost_decrease": True,
                                     "trial_gradient_endpoint_checkpoint_arrays_equal": True})

            terminal = report.get("terminal_gradient", {})
            terminal_label = terminal.get("call_label")
            require(terminal_label in gradient_calls,
                    "terminal report is not linked to a bundled native gradient call")
            final_call = gradient_calls[terminal_label]
            final_delta = np.asarray(report.get("final_delta"), dtype=np.float64)
            require(terminal.get("reached") is True and terminal.get("threshold") == 1e-5 and
                    float(terminal.get("gradient_l2", float("inf"))) < 1e-5,
                    "fresh terminal projected gradient did not reach the unchanged 1e-5 threshold")
            require(np.array_equal(final_delta, final_call["delta"]) and
                    np.array_equal(np.asarray(terminal.get("delta"), dtype=np.float64), final_delta),
                    "final/terminal controls differ from the terminal gradient call")
            require(terminal_label == f"gradient_u{len(accepted)}",
                    "terminal call is not the last fresh accepted gradient")
            final_gradient = final_call["gradient"]
            require(float(np.linalg.norm(final_gradient)) < 1e-5,
                    "raw terminal projected gradient exceeds the unchanged threshold")
            require(np.allclose(final_gradient, terminal.get("gradient"), rtol=2e-13, atol=1e-10) and
                    np.isclose(np.linalg.norm(final_gradient), terminal["gradient_l2"],
                               rtol=2e-13, atol=1e-10),
                    "terminal projected gradient/norm differs from raw B^T pullback")
            require(np.array_equal(final_delta, np.asarray(accepted[-1]["accepted_delta"], dtype=np.float64)) and
                    final_call["objective"] < decoded[f"gradient_u{len(accepted)-1}"]["objective"],
                    "final controls/objective do not match the last accepted update")
            require(np.isclose(report.get("final_objective"), final_call["objective"],
                               rtol=2e-12, atol=1e-9) and
                    np.isclose(terminal.get("objective"), final_call["objective"],
                               rtol=2e-12, atol=1e-9),
                    "final objective differs from raw terminal gradient call")
            return {"schema": "pr290-rotating-inverse-optimizer-gate-v1",
                    "status": "passed", "artifact_zip_sha256": actual_sha,
                    "zip_crc_passed": True, "inverse_report_sha256": report_sha,
                    "inverse_report_schema": report["schema"],
                    "inverse_status": report["status"],
                    "native_call_count": len(call_rows),
                    "optimizer_call_count": len(optimizer_rows),
                    "gradient_call_count": len(gradient_calls),
                    "accepted_update_count": len(accepted),
                    "chart_reconstruction_by_call": {
                        label: call["chart_reconstruction"]
                        for label, call in decoded.items()},
                    "source": source_receipt,
                    "inputs": {name: input_hashes[name] for name in sorted(input_hashes)},
                    "raw_objective_definition": "0.5 * sum((predicted_W - observed_W)^2) / sigma^2 across 150s and 300s; sigma=3e-4",
                    "gradient_definition": "canonical_basis.T @ raw native initial_pullback",
                    "steps": step_records,
                    "terminal": {"call_label": terminal_label,
                                 "delta": final_delta.tolist(),
                                 "objective": final_call["objective"],
                                 "projected_gradient": final_gradient.tolist(),
                                 "projected_gradient_l2": float(np.linalg.norm(final_gradient)),
                                 "threshold": 1e-5, "reached": True},
                    "formal_Eg_bound": False,
                    "native_executions": 0,
                    "limitations": [
                        "The artifact's executable digest is cross-checked against its source receipt but the executable binary is not part of this archive and is not re-hashed by this offline gate.",
                        "This verifies the bounded two-control optimizer receipt only; it does not establish full-state stationarity or a formal Eg bound."]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--zip", type=Path, required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, default=PRODUCER_ROOT)
    args = parser.parse_args()
    result = {"schema": "pr290-rotating-inverse-optimizer-gate-v1",
              "status": "failed", "artifact": str(args.zip.resolve()),
              "source_root": str(args.source_root.resolve()), "native_executions": 0}
    try:
        if not args.zip.is_file():
            raise ValueError("artifact ZIP does not exist")
        if len(args.sha256) != 64 or any(c not in "0123456789abcdef" for c in args.sha256):
            raise ValueError("--sha256 must be a lowercase 64-character SHA-256")
        if not args.out.parent.exists():
            raise ValueError("output parent directory does not exist")
        verified = verify_archive(args.zip.resolve(), args.sha256, args.source_root.resolve())
        result = {**verified, "artifact": str(args.zip.resolve()),
                  "source_root": str(args.source_root.resolve())}
    except Exception as error:
        result.update(failure_type=type(error).__name__, failure=str(error))
    args.out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result.get("status"), "out": str(args.out.resolve()),
                      "failure": result.get("failure")}, sort_keys=True))
    return 0 if result.get("status") == "passed" else 2


if __name__ == "__main__":
    raise SystemExit(main())
