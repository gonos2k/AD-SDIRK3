#!/usr/bin/env python3
"""Run the fixed ABBA list once; retain any failure and stop without retry."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert sys.argv[1:]==['--go']
    manifest=json.loads((ROOT/'native_abba_manifest.json').read_text());assert manifest['case_order']==['A0','B0','B1','A1']
    out=ROOT/'native_abba_block_receipt.json';assert not out.exists()
    results=[];start=time.monotonic();reason=None
    for key in manifest['case_order']:
        p=subprocess.run([sys.executable,str(ROOT/'execution/run_native_abba.py'),key,'--go'],capture_output=True,text=True)
        row={'case':key,'runner_return_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr};results.append(row)
        print(p.stdout,flush=True)
        if p.returncode:
            reason='native_run_failed';break
        if key!='A0':
            reference=Path(manifest['cases']['A0']['directory']);current=Path(manifest['cases'][key]['directory'])
            row['full_public_output_hashes_match_A0']=all(sha(f)==sha(current/f.name) for f in reference.glob('wrfout_d01_*'))
            if not row['full_public_output_hashes_match_A0']:
                reason='prospective_public_parity_failed';break
    record={'order':manifest['case_order'],'attempts':results,'elapsed_seconds':time.monotonic()-start,'stop_reason':reason,'no_retries':True,'all_four_completed':len(results)==4 and reason is None,'manifest_sha256':sha(ROOT/'native_abba_manifest.json'),'source_sha256':sha(Path(__file__))}
    out.write_text(json.dumps(record,indent=2)+'\n')
    return 0 if record['all_four_completed'] else 2
if __name__=='__main__':raise SystemExit(main())
