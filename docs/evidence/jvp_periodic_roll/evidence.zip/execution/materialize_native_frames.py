#!/usr/bin/env python3
"""Restore the eight immutable frame names from content-addressed archive payloads."""
from pathlib import Path
import hashlib,json,shutil
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    manifest=json.loads((ROOT/'archive_manifest.json').read_text())
    for alias in manifest['native_frame_aliases']:
        rel=Path(alias['path']);source_rel=Path(alias['payload'])
        assert not rel.is_absolute() and '..' not in rel.parts
        assert not source_rel.is_absolute() and '..' not in source_rel.parts
        source=ROOT/source_rel;target=ROOT/rel;assert sha(source)==alias['sha256']
        target.parent.mkdir(parents=True,exist_ok=True)
        if not target.exists():shutil.copyfile(source,target)
        assert sha(target)==alias['sha256']
    print('All native frame aliases materialized and SHA-256 verified.')
if __name__=='__main__':main()
