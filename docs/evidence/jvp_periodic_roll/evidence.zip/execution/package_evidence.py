#!/usr/bin/env python3
"""Freeze this bounded experiment; deduplicate byte-identical native frames."""
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[1]
WORK=Path('/private/tmp/standard-forward-comparison-20261024')
DEST=WORK/'docs/evidence/jvp_periodic_roll'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    DEST.mkdir(parents=True,exist_ok=True)
    for rel in ['external/libtorch_wrf/sdirk3/wrf_sdirk3_phi_horizontal.h','external/libtorch_wrf/sdirk3/tests/test_phi_horizontal_kernel_contract.cpp']:
        p=ROOT/'final_sources'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(WORK/rel,p)
    patch=subprocess.check_output(['git','diff','2ca1704630475b28877b68d9f38ae2e34dc27a5b','--','external/libtorch_wrf/sdirk3/wrf_sdirk3_phi_horizontal.h','external/libtorch_wrf/sdirk3/tests/test_phi_horizontal_kernel_contract.cpp'],cwd=WORK)
    (ROOT/'final_sources/accepted_code.patch').write_bytes(patch)
    for rel in ['analysis/summary.json','analysis/costs.csv','analysis/native_field_parity.csv','protocol.json','resolution_checklist.json']:
        shutil.copyfile(ROOT/rel,DEST/Path(rel).name)
    payloads={};aliases=[]
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(ROOT)
        if any(v in ('objects','archives','tests','__pycache__','initial_views','initial_views_current') for v in rel.parts):continue
        if p.suffix in ('.exe','.a','.o','.d') or p.name in ('wrfinput_d01','report_path.txt','pr_body.md'):continue
        if p.name.startswith('wrfoutReady'):continue
        if p.is_symlink() and p.name!='native_sample.txt':continue
        if p.name.startswith('wrfout_d01_'):
            digest=sha(p);key='native_arrays/'+digest+'.nc';payloads.setdefault(key,p);aliases.append({'path':str(rel),'payload':key,'sha256':digest,'bytes':p.stat().st_size})
        else:payloads[str(rel)]=p
    manifest={'at_local':datetime.datetime.now().astimezone().isoformat(),'base':'2ca1704630475b28877b68d9f38ae2e34dc27a5b','scope':'Four fixed one-step ABBA runs only; all RC0; permutation candidate accepted for declared CPU scope; no5day/RK3newrun','files':[{'path':k,'sha256':sha(p),'bytes':p.stat().st_size} for k,p in sorted(payloads.items())],'native_frame_aliases':aliases}
    target=DEST/'evidence.zip'
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,p in sorted(payloads.items()):z.write(p,name)
        z.writestr('archive_manifest.json',json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        for row in manifest['files']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
        for row in aliases:assert hashlib.sha256(z.read(row['payload'])).hexdigest()==row['sha256']
    verification={'archive':'evidence.zip','sha256':sha(target),'bytes':target.stat().st_size,'items':len(payloads)+1,'native_frame_aliases':len(aliases),'unique_native_netcdf_payloads':len({v['payload'] for v in aliases}),'all_sha256_crc_and_alias_hashes_verified':True,'omitted':'Executable/object/archive binaries and unchanged common input; exact build/source/input hashes and commands retained.'}
    (DEST/'archive_verification.json').write_text(json.dumps(verification,indent=2)+'\n');print(json.dumps(verification,indent=2))
if __name__=='__main__':main()
