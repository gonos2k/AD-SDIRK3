from pathlib import Path
import json,hashlib,subprocess,time,os,datetime
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    d=ROOT/'build/phi_horizontal_roll';old=json.loads((d/'periodic_select_test_plan.json').read_text());spec=old['tests'][0];rename={spec['object']:str(d/'tests/phi_horizontal_kernel_same_primal.o'),spec['executable']:str(d/'tests/test_phi_horizontal_kernel_same_primal.exe')}
    compile_cmd=[rename.get(a,a) for a in spec['compile_argv']];link_cmd=[rename.get(a,a) for a in spec['link_argv']];run_cmd=[rename[spec['executable']]]
    p=d/'same_primal_phi_test_plan.json';p.write_text(json.dumps({'at_local':datetime.datetime.now().astimezone().isoformat(),'source':spec['source'],'source_sha256':sha(spec['source']),'candidate_archive':old['candidate_archive'],'compile':compile_cmd,'link':link_cmd,'run':run_cmd,'change':'Testonly: same primal withtwo distinct tangents; productionheader/binary/work/gatesunchanged; no model/otherregressionsrerun.'},indent=2)+'\n')
    env={k:v for k,v in os.environ.items() if not k.startswith(tuple(old['environment']['cleared_prefixes']))};env.update({k:v for k,v in old['environment'].items() if isinstance(v,str)});rows=[]
    for label,cmd,cwd in [('compile',compile_cmd,spec['compile_cwd']),('link',link_cmd,spec['link_cwd']),('run',run_cmd,str(d))]:
        start=time.monotonic();v=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True,text=True);out=d/'logs'/('same_primal_phi.'+label+'.stdout.log');err=d/'logs'/('same_primal_phi.'+label+'.stderr.log');out.write_text(v.stdout);err.write_text(v.stderr);rows.append({'phase':label,'command':cmd,'return_code':v.returncode,'elapsed_seconds':time.monotonic()-start,'stdout':str(out),'stderr':str(err)})
        if v.returncode:break
    success=len(rows)==3 and all(x['return_code']==0 for x in rows)
    receipt={'plan_sha256':sha(p),'source_sha256':sha(spec['source']),'candidate_header_sha256':sha('/private/tmp/standard-forward-comparison-20261024/external/libtorch_wrf/sdirk3/wrf_sdirk3_phi_horizontal.h'),'status':'passed' if success else 'failed','rows':rows,'no_model_run':True}
    (d/'same_primal_phi_test_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':receipt['status'],'source_sha256':receipt['source_sha256'],'phase_codes':[x['return_code'] for x in rows]},indent=2));assert success
if __name__=='__main__':main()
