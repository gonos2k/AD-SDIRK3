#!/usr/bin/env python3
"""Evaluate the frozen four-run ABBA protocol once; no launches or acceptance tuning."""
from pathlib import Path
import hashlib,json,re,statistics
import numpy as np
from netCDF4 import Dataset
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(key):
    d=ROOT/'native_abba'/key;receipt=json.loads((d/'forecast_receipt.json').read_text())
    assert receipt['status']=='completed' and receipt['return_code']==0
    log=(d/'rsl.error.0000').read_text();rows=[]
    for line in log.splitlines():
        if line.startswith('[SOLVER TELEMETRY]'):
            fields=dict(re.findall(r'(\w+)=([^, ]+)',line))
            rows.append({k:float(fields[k]) for k in ('stage','newton','gmres_iters','gmres_rel','jvp_calls','jvp_ms','jvp_ad_calls','jvp_fd_calls','krylov_tol_final')})
    assert len(rows)==6
    nr=re.findall(r'\[Newton\] CONVERGED stage=(\d+) iters=(\d+) .*?rms=([\deE+.-]+).*?\|\|R\|\|=([\deE+.-]+)',log)
    assert len(nr)==3
    main=(d/'rsl.out.0000').read_text();mt=[float(v) for v in re.findall(r'Timing for main:.*?([\d.]+) elapsed seconds',main)];assert len(mt)==1
    jvp=sum(v['jvp_ms'] for v in rows)/1000;calls=sum(v['jvp_calls'] for v in rows)
    return {'path':str(d),'receipt_sha256':sha(d/'forecast_receipt.json'),'executable_sha256':receipt['executable_sha256'],'elapsed_seconds':receipt['elapsed_seconds'],'rsl_main_seconds':sum(mt),'jvp_seconds':jvp,'jvp_calls':calls,'jvp_seconds_per_call':jvp/calls,'newton_residuals':nr,'krylov_rows':rows,'residual_tolerances_met':all(float(v[2])<=1e-9 for v in nr) and all(v['gmres_rel']<=v['krylov_tol_final'] for v in rows),'sampled_tree_peak_rss':receipt['peak_sampled_tree_rss_bytes']}

def compare(reference,other):
    result={'name':reference.name,'reference_sha256':sha(reference),'other_sha256':sha(other),'whole_file_equal':reference.read_bytes()==other.read_bytes(),'variables':[]}
    with Dataset(reference) as a,Dataset(other) as b:
        assert tuple(a.dimensions)==tuple(b.dimensions) and tuple(a.variables)==tuple(b.variables)
        assert all(len(a.dimensions[n])==len(b.dimensions[n]) for n in a.dimensions)
        for n,v in a.variables.items():
            w=b.variables[n];assert v.dimensions==w.dimensions and v.dtype==w.dtype
            x,y=np.asarray(v[:]),np.asarray(w[:]);row={'name':n,'shape':list(x.shape),'dtype':str(v.dtype),'array_bytes_equal':x.tobytes()==y.tobytes()}
            if np.issubdtype(x.dtype,np.number):
                assert np.isfinite(x).all() and np.isfinite(y).all()
                row['max_abs_difference']=float(np.max(np.abs(x.astype(float)-y.astype(float))))
            result['variables'].append(row)
    return result

def main():
    order=['A0','B0','B1','A1'];rows={k:read(k) for k in order};frames={}
    for key in order[1:]:
        frames[key]=[compare(p,ROOT/'native_abba'/key/p.name) for p in sorted((ROOT/'native_abba/A0').glob('wrfout_d01_*'))]
        assert len(frames[key])==2
    ks=('stage','newton','gmres_iters','gmres_rel','jvp_calls','jvp_ad_calls','jvp_fd_calls','krylov_tol_final')
    work=all(all(all(a[k]==b[k] for k in ks) for a,b in zip(rows['A0']['krylov_rows'],rows[key]['krylov_rows'])) and rows[key]['newton_residuals']==rows['A0']['newton_residuals'] for key in order[1:])
    all_exact=all(f['whole_file_equal'] and all(v['array_bytes_equal'] for v in f['variables']) for fs in frames.values() for f in fs)
    med_a=statistics.median(rows[k]['rsl_main_seconds'] for k in ('A0','A1'));med_b=statistics.median(rows[k]['rsl_main_seconds'] for k in ('B0','B1'))
    ja=statistics.median(rows[k]['jvp_seconds_per_call'] for k in ('A0','A1'));jb=statistics.median(rows[k]['jvp_seconds_per_call'] for k in ('B0','B1'))
    pair=[{'baseline':a,'candidate':b,'rsl_reduction_fraction':1-rows[b]['rsl_main_seconds']/rows[a]['rsl_main_seconds']} for a,b in [('A0','B0'),('A1','B1')]]
    gates={'exact_public_output':all_exact,'exact_reported_residuals_and_fixed_work':work,'configured_residuals_met':all(v['residual_tolerances_met'] for v in rows.values()),'median_rsl_reduction_ge_3pct':med_b<=.97*med_a,'both_paired_rsl_reductions_ge_1pct':all(v['rsl_reduction_fraction']>=.01 for v in pair),'median_jvp_per_call_reduction_ge_5pct':jb<=.95*ja}
    result={'scope':'Exactly one preregistered A-B-B-A block, telemetry-on first-step standard h600. Not quiet6h/five-day/same-accuracy performance. No reruns until pass.','protocol_sha256':sha(ROOT/'protocol.json'),'analysis_sha256':sha(Path(__file__)),'rows':rows,'frames':frames,'paired_results':pair,'median_rsl_baseline_seconds':med_a,'median_rsl_candidate_seconds':med_b,'median_rsl_reduction_fraction':1-med_b/med_a,'median_jvp_per_call_reduction_fraction':1-jb/ja,'gates':gates,'all_gates_pass':all(gates.values())}
    (ROOT/'analysis/native_abba_comparison.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('paired_results','median_rsl_reduction_fraction','median_jvp_per_call_reduction_fraction','gates','all_gates_pass')},indent=2))
    return 0 if result['all_gates_pass'] else 2
if __name__=='__main__':raise SystemExit(main())
