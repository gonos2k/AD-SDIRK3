from pathlib import Path
import json,hashlib
import torch
import torch.utils.benchmark as bench
from torch.autograd import forward_ad

def old(q,offset):
    n=q.size(2)
    idx=torch.remainder(torch.arange(n,device=q.device,dtype=torch.int64)+offset,n)
    return q.index_select(2,idx)
def new(q,offset):return torch.roll(q,shifts=-offset,dims=2)
def evaluate(fn,q):return tuple(fn(q,off) for off in (-3,-2,-1,1,2,3))

def main():
    torch.set_num_threads(1);torch.manual_seed(6320)
    rows=[]
    for dtype in (torch.float32,torch.float64):
        for sliced in (False,True):
            base=torch.randn((81,65,41),dtype=dtype)
            q=base[:80,:,:40] if sliced else base[:80,:,:40].contiguous()
            tangent=torch.randn_like(q)
            with forward_ad.dual_level():
                dual=forward_ad.make_dual(q,tangent)
                expected=evaluate(old,dual);actual=evaluate(new,dual)
                equal=True
                for a,b in zip(expected,actual):
                    av,at=forward_ad.unpack_dual(a);bv,bt=forward_ad.unpack_dual(b)
                    equal &= torch.equal(av,bv) and torch.equal(at,bt)
                oldt=bench.Timer('evaluate(old,dual)',globals=locals()|globals(),num_threads=1).blocked_autorange(min_run_time=.3)
                newt=bench.Timer('evaluate(new,dual)',globals=locals()|globals(),num_threads=1).blocked_autorange(min_run_time=.3)
                assert equal
            q1=q.detach().clone().requires_grad_();q2=q.detach().clone().requires_grad_()
            weights=[torch.randn_like(q) for _ in range(6)]
            g1=torch.autograd.grad(sum((v*w).sum() for v,w in zip(evaluate(old,q1),weights)),q1)[0]
            g2=torch.autograd.grad(sum((v*w).sum() for v,w in zip(evaluate(new,q2),weights)),q2)[0]
            rows.append({'dtype':str(dtype),'sliced':sliced,'shape':list(q.shape),'strides':list(q.stride()),'primal_and_tangent_exact':bool(equal),'reverse_grad_exact':bool(torch.equal(g1,g2)),'reverse_max_abs':float((g1-g2).abs().max()),'old_seconds':oldt.median,'new_seconds':newt.median,'old_over_new':oldt.median/newt.median})
    result={'scope':'Pre-source-edit one-thread installedTorch helper probe at native PH shape, not full-RHS/native performance','torch':torch.__version__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
