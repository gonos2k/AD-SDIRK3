# JVP bucket breakdown — existing one-step stack sample

작성 시각: 2026-10-24 23:08:41 JST (UTC+09:00)

Raw sample SHA-256: `ee13ec642b68970fede46280236a0b6893369b804fe5cbbdc2ff09dec7843ed8`. It contains 9,689 main-thread samples. The one-step ARK run returned RC0 after one accepted outer step and is marked `cost_eligible=false`. Two waiting threads (PMIx in `kevent`, worker in `__workq_kernreturn`) are excluded. The parser uses the existing call-tree indentation, computes each node’s exclusive self count as inclusive count minus direct-child counts, and assigns each self sample by JVP → preconditioner → other FGMRES → stage/RHS precedence.

## Inside the 6,664-sample JVP bucket

- **6,662 self samples** are within the two `solveImplicitStage` RHS callback subtrees (inclusive roots 5,942 and 720); 2 are outside those callback subtrees. The two root counts are distinct call paths; do not sum other inclusive frames.
- **State-value gathers:** `index_select` descendants contribute 334 exclusive samples, including 291 under `periodic_select`; 324 are direct-copy-kernel self samples within the index-select subtree.
- **Fixed-shape index setup:** `arange` 2, `remainder` 2, and Tensor-to conversion 4 exclusive samples in the JVP bucket. The stack does not split every metric/coefficient operation from state-dependent RHS arithmetic.
- Largest JVP exclusive leaf symbols are direct-copy callbacks (1,254), multiply callbacks (1,254), add callbacks (1,087), `Sleef_powd2` (727), and `_platform_memmove` (313). These are stack leaves, not isolated source statements.

## Source hypotheses

1. Most JVP samples occur in the actual RHS callback: Newton calls the JVP helper at `wrf_sdirk3_newton_solver.cpp:6968-6972`; tile RHS routing is at `wrf_sdirk3_tile_unified_impl.cpp:14004-14059`. This includes both state-dependent operator work and fixed metric/coefficient use.
2. A visible named RHS branch is native W-PGF horizontal work: max inclusive counts are 711 in `computeUnifiedRHS`, 678 in `native_w_phi_horizontal`, and 315 in its core. The tile call site is `wrf_sdirk3_tile_unified_impl.cpp:19445-19451`; the state/metric calculation is in `wrf_sdirk3_phi_horizontal.h:64-95`. Inclusive counts overlap.
3. Index-vector construction is small in this JVP sample: `periodic_select` builds `arange/remainder` indices at `wrf_sdirk3_phi_horizontal.h:13-17`, while `centered` applies repeated shifts at lines 29-38. The gathered state-value outputs have larger sample weight than index construction itself.

These are source-mapped stack hypotheses, not a performance attribution. No source, model, build, or test action was taken. The previous MGS candidate is not part of this JVP classification.

Machine output: `analysis/jvp_bucket_summary.json` (SHA-256 `b6603f97d4317335fa5e432cf96c3c8a60097bd4d0ade6298875329c8e9a5f10`). Parser: `analysis/reproduce_sample_accounting.py --jvp-detail` (SHA-256 `3ab3c4e1f91e81aabf231f7151b6db37d9eb9d617ad14a92358b2e9beae2c034`); raw breakdown: `analysis/jvp_bucket_breakdown.json` (SHA-256 `1d15f04efdf17029f7e2ef08547d3fa1591c6fc898b7db78180263303b7f60d3`).
