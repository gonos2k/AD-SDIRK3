#!/usr/bin/env python3
"""Compare literal CMake add_test names with the pinned expected inventory.

Source-level only: this does not configure CMake or discover CTest. It expands
MPI _np loops over 1,2,4, and omits SDIRK3_Tests when its optional executable
source is absent. MPI-conditional registration is assumed enabled because the
pinned expected inventory includes those MPI names.
"""
from __future__ import annotations

import hashlib
import re
from pathlib import Path
import subprocess

ROOT = Path.cwd().resolve()
CMAKE = ROOT / 'external/libtorch_wrf/sdirk3/CMakeLists.txt'
EXPECTED = ROOT / '.github/ci/expected_ctest_names.txt'
OPTIONAL_MAIN = ROOT / 'external/libtorch_wrf/sdirk3/wrf_sdirk3_main.cpp'


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def main() -> int:
    source = CMAKE.read_text()
    expected = EXPECTED.read_text().splitlines()
    literal_names = re.findall(r'add_test\s*\(\s*NAME\s+([^\s)]+)', source, flags=re.I)
    registered = []
    omitted_optional = []
    for name in literal_names:
        if name == 'SDIRK3_Tests' and not OPTIONAL_MAIN.is_file():
            omitted_optional.append(name)
            continue
        if '${_np}' in name:
            registered.extend(name.replace('${_np}', str(np)) for np in (1, 2, 4))
        else:
            if '${' in name:
                raise ValueError(f'unhandled CMake variable in test name: {name}')
            registered.append(name)
    missing = sorted(set(registered) - set(expected))
    expected_without_registration = sorted(set(expected) - set(registered))
    duplicate_registration = sorted(n for n in set(registered) if registered.count(n) > 1)
    duplicate_expected = sorted(n for n in set(expected) if expected.count(n) > 1)
    try:
        head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    except (OSError, subprocess.CalledProcessError):
        head = 'unavailable'
    print('mode=static_source_inventory_only')
    print(f'worktree={ROOT}')
    print(f'head={head}')
    print(f'cmake_sha256={sha(CMAKE)}')
    print(f'expected_sha256={sha(EXPECTED)}')
    print(f'optional_sdirk3_main_exists={str(OPTIONAL_MAIN.is_file()).lower()}')
    print(f'omitted_optional_names={omitted_optional}')
    print('mpi_rank_expansion=1,2,4 (source loop; MPI_FOUND assumed from expected inventory)')
    print(f'registered_expanded={len(registered)} expected={len(expected)}')
    print(f'missing_from_expected={missing}')
    print(f'expected_without_registration={expected_without_registration}')
    print(f'duplicate_registration={duplicate_registration}')
    print(f'duplicate_expected={duplicate_expected}')
    ok = not (missing or expected_without_registration or duplicate_registration or duplicate_expected)
    print(f'status={"PASS" if ok else "FAIL"}')
    print('configured_ctest=not_run')
    print('cmake_configure_build_model_run=not_run')
    return 0 if ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
