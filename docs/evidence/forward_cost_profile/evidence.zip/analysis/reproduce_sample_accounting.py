#!/usr/bin/env python3
"""Reconstruct exclusive main-thread stack buckets from the pinned macOS sample."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path


SAMPLE = Path(__file__).resolve().parent.parent / "native_sample.txt"
EXPECTED_SHA256 = "ee13ec642b68970fede46280236a0b6893369b804fe5cbbdc2ff09dec7843ed8"
EXPECTED_COUNTS = {
    "jvp": 6664,
    "preconditioner": 518,
    "other_fgmres": 2339,
    "stage_rhs_outside": 168,
}
THREAD_RE = re.compile(r"^\s+(\d+)\s+(Thread_\d+)(.*)$")
ROW_RE = re.compile(r"^(?P<prefix>\s*[+!|: -]+?)(?P<count>\d+)\s+(?P<desc>.*)$")


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def category(node: dict) -> str:
    chain = []
    current = node
    while current is not None:
        chain.append(current["name"])
        current = current["parent"]
    if any("compute_jvp_" in name for name in chain):
        return "jvp"
    if any("UnifiedPreconditioner" in name or "apply_raw_principal" in name for name in chain):
        return "preconditioner"
    if any("solve_fgmres" in name or "solve_gmres" in name for name in chain):
        return "other_fgmres"
    return "stage_rhs_outside"


def main() -> None:
    sample_sha = digest(SAMPLE)
    if sample_sha != EXPECTED_SHA256:
        raise SystemExit(f"native_sample.txt SHA-256 mismatch: {sample_sha}")
    lines = SAMPLE.read_text(errors="replace").splitlines()
    thread_headers = [(i, THREAD_RE.match(line)) for i, line in enumerate(lines)
                      if THREAD_RE.match(line)]
    main_header = next(((i, match) for i, match in thread_headers
                        if "com.apple.main-thread" in match.group(3)), None)
    if main_header is None:
        raise SystemExit("main-thread sample tree not found")
    start, match = main_header
    sample_count = int(match.group(1))
    end = next((i for i, _ in thread_headers if i > start), len(lines))

    nodes = []
    for line_number, line in enumerate(lines[start + 1:end], start + 2):
        row = ROW_RE.match(line)
        if row is None:
            continue
        prefix = row.group("prefix")
        if len(prefix) < 6 or (len(prefix) - 6) % 2:
            raise SystemExit(f"unexpected call-graph indentation at line {line_number}")
        desc = row.group("desc")
        name = desc.rsplit(" (in ", 1)[0] if " (in " in desc else desc
        nodes.append({"line": line_number, "depth": (len(prefix) - 6) // 2,
                      "count": int(row.group("count")), "name": name, "children": []})

    roots, stack = [], []
    for node in nodes:
        while stack and stack[-1]["depth"] >= node["depth"]:
            stack.pop()
        node["parent"] = stack[-1] if stack else None
        if stack:
            stack[-1]["children"].append(node)
        else:
            roots.append(node)
        stack.append(node)

    totals = {key: 0 for key in EXPECTED_COUNTS}
    underflows = []
    for node in nodes:
        child_sum = sum(child["count"] for child in node["children"])
        exclusive = node["count"] - child_sum
        if exclusive < 0:
            underflows.append(node["line"])
        totals[category(node)] += exclusive

    root_sum = sum(root["count"] for root in roots)
    exclusive_sum = sum(totals.values())
    if underflows or root_sum != sample_count or exclusive_sum != sample_count:
        raise SystemExit("sample tree count conservation failed")
    if totals != EXPECTED_COUNTS:
        raise SystemExit(f"bucket totals differ from reviewed values: {totals}")

    other_threads = [match.group(2) + match.group(3).strip()
                     for i, match in thread_headers if i != start]
    print(json.dumps({
        "schema": "native_sample_exclusive_accounting_v1",
        "sample_path": str(SAMPLE),
        "sample_sha256": sample_sha,
        "main_thread": match.group(2) + match.group(3).strip(),
        "main_thread_samples": sample_count,
        "call_graph_rows": len(nodes),
        "root_inclusive_sum": root_sum,
        "exclusive_self_sum": exclusive_sum,
        "negative_exclusive_rows": len(underflows),
        "category_precedence": ["JVP", "preconditioner", "other FGMRES", "stage/RHS outside"],
        "exclusive_self_samples": totals,
        "approx_stack_share_percent": {key: round(100 * value / sample_count, 3)
                                        for key, value in totals.items()},
        "excluded_other_threads": other_threads,
        "qualification": "Sampled stack shares; not exclusive wall time or a clean benchmark.",
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
