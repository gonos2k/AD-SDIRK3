#!/usr/bin/env python3
"""Freeze bounded positive/negative evidence; do not include binaries or parent archives."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
WORK = Path('/private/tmp/standard-forward-comparison-20261024')
DEST = WORK/'docs/evidence/forward_cost_profile'
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    DEST.mkdir(parents=True, exist_ok=True)
    sources = ['tools/benchmark_wrf_accuracy_cost.py', 'tools/test_benchmark_wrf_accuracy_cost.py', '.github/ci/expected_ctest_names.txt', 'external/libtorch_wrf/sdirk3/test_fgmres_contract.cpp', 'external/libtorch_wrf/sdirk3/wrf_sdirk3_newton_solver.cpp']
    for rel in sources:
        dst = ROOT/'final_sources'/rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(WORK/rel, dst)
    patch = subprocess.check_output(['git', 'diff', 'fec53e4a8a90d1be8c336d572314d16c2cb71220', '--', *sources], cwd=WORK)
    (ROOT/'final_sources/accepted_code.patch').write_bytes(patch)
    files = []
    for p in ROOT.rglob('*'):
        if not p.is_file() or p.is_symlink() or '__pycache__' in p.parts:
            continue
        rel = p.relative_to(ROOT)
        if rel.parts[0] in ('initial_views', 'initial_views_6h') or any(v in ('objects','archives','tests') for v in rel.parts) or p.suffix in ('.exe','.o','.a','.d'):
            continue
        if p.name == 'wrfinput_d01':
            continue # Shared immutable input already in archived standard-case evidence.
        if p.name.startswith('wrfoutReady'):
            continue
        if rel.parts[0] in ('profile_cases','native_pair'):
            if not (p.suffix in ('.json','.log') or p.name.startswith(('rsl.','wrfout_d01_')) or p.name=='namelist.input'):
                continue
        files.append(p)
    files.sort()
    payload = {'at_local': datetime.datetime.now().astimezone().isoformat(), 'base_revision': 'fec53e4a8a90d1be8c336d572314d16c2cb71220', 'scope': 'Three one-step native attempts, all RC0; one sampled profile and matched old/rejected candidate. No new RK3/6h/5day run. No promoted performance change.', 'files': [{'path':str(p.relative_to(ROOT)), 'bytes':p.stat().st_size, 'sha256':sha(p)} for p in files]}
    zip_path = DEST/'evidence.zip'
    with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:
            z.write(p,str(p.relative_to(ROOT)))
        z.writestr('archive_manifest.json', json.dumps(payload,indent=2)+'\n')
    with zipfile.ZipFile(zip_path) as z:
        assert z.testzip() is None
        for row in payload['files']:
            assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
    receipt={'archive':'evidence.zip','bytes':zip_path.stat().st_size,'sha256':sha(zip_path),'items':len(files)+1,'all_payload_sha256_and_crc_verified':True,'native_netcdf_files':sum(p.name.startswith('wrfout_d01_') for p in files),'not_included':['native executables, objects, static archives; exact hashes and build receipts retained','shared wrfinput and unchanged prior quiet/RK3 evidence; referenced by hash']}
    (DEST/'archive_verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
