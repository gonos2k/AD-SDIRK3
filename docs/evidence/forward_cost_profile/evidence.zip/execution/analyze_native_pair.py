#!/usr/bin/env python3
"""Compare only completed matched one-step runs; no model launch or pass-budget tuning."""
from pathlib import Path
import hashlib
import json
import re
import numpy as np
from netCDF4 import Dataset

ROOT = Path(__file__).resolve().parents[1]
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def read(key):
    d = ROOT / 'native_pair' / key
    receipt = json.loads((d / 'forecast_receipt.json').read_text())
    assert receipt['status'] == 'completed' and receipt['return_code'] == 0
    log = (d / 'rsl.error.0000').read_text()
    rows = []
    for line in log.splitlines():
        if line.startswith('[SOLVER TELEMETRY]'):
            row = dict(re.findall(r'(\w+)=([^, ]+)', line))
            rows.append({k: float(row[k]) for k in ('stage','newton','gmres_iters','gmres_rel','jvp_calls','jvp_ms','jvp_ad_calls','jvp_fd_calls','krylov_tol_final')})
    assert len(rows) == 6
    residuals = re.findall(r'\[Newton\] CONVERGED stage=(\d+) iters=(\d+) .*?rms=([\deE+.-]+).*?\|\|R\|\|=([\deE+.-]+)', log)
    assert len(residuals) == 3
    assert all(float(v[2]) <= 1e-9 for v in residuals)
    assert all(v['gmres_rel'] <= v['krylov_tol_final'] for v in rows)
    main = (d / 'rsl.out.0000').read_text()
    times = [float(v) for v in re.findall(r'Timing for main:.*?([\d.]+) elapsed seconds', main)]
    assert len(times) == 1
    return {'receipt_sha256': sha(d/'forecast_receipt.json'), 'executable_sha256': receipt['executable_sha256'], 'elapsed_seconds': receipt['elapsed_seconds'], 'rsl_main_seconds': sum(times), 'newton_residuals': residuals, 'krylov_rows': rows, 'jvp_calls': sum(v['jvp_calls'] for v in rows), 'jvp_seconds': sum(v['jvp_ms'] for v in rows)/1000, 'jvp_fd_calls': sum(v['jvp_fd_calls'] for v in rows)}, d

def main():
    baseline, bd = read('baseline'); candidate, cd = read('candidate')
    frames = []
    for b in sorted(bd.glob('wrfout_d01_*')):
        c = cd/b.name
        row = {'name': b.name, 'baseline_sha256': sha(b), 'candidate_sha256': sha(c), 'whole_file_equal': b.read_bytes() == c.read_bytes(), 'variables': []}
        with Dataset(b) as db, Dataset(c) as dc:
            assert tuple(db.dimensions) == tuple(dc.dimensions)
            assert all(len(db.dimensions[n]) == len(dc.dimensions[n]) for n in db.dimensions)
            assert tuple(db.variables) == tuple(dc.variables)
            for name, v in db.variables.items():
                w = dc.variables[name]
                assert v.dimensions == w.dimensions and v.dtype == w.dtype
                x, y = np.asarray(v[:]), np.asarray(w[:])
                same = x.tobytes() == y.tobytes()
                item = {'name': name, 'dtype': str(v.dtype), 'shape': list(x.shape), 'array_bytes_equal': same}
                if np.issubdtype(x.dtype, np.number):
                    assert np.isfinite(x).all() and np.isfinite(y).all()
                    item['max_abs_difference'] = float(np.max(np.abs(x.astype(float)-y.astype(float))))
                row['variables'].append(item)
        frames.append(row)
    assert len(frames) == 2
    # The prospective short-map parity condition is exact public-output equality.
    public_parity = all(r['whole_file_equal'] and all(v['array_bytes_equal'] for v in r['variables']) for r in frames)
    parity_keys = ('stage','newton','gmres_iters','gmres_rel','jvp_calls','jvp_ad_calls','jvp_fd_calls','krylov_tol_final')
    matching_work = all(all(b[k] == c[k] for k in parity_keys) for b,c in zip(baseline['krylov_rows'],candidate['krylov_rows']))
    out = {'prospective_exact_public_output_parity': public_parity, 'scope': 'One matched diagnostic-telemetry step per binary without host sampling; not quiet-production or repeated timing, 6h/5day or same-accuracy speedup.', 'baseline': baseline, 'candidate': candidate, 'frames': frames, 'work_and_reported_true_residuals_equal': matching_work, 'newton_reported_residuals_equal': baseline['newton_residuals'] == candidate['newton_residuals'], 'rsl_baseline_over_candidate': baseline['rsl_main_seconds']/candidate['rsl_main_seconds'], 'whole_baseline_over_candidate': baseline['elapsed_seconds']/candidate['elapsed_seconds'], 'analysis_source_sha256': sha(Path(__file__))}
    (ROOT/'analysis/native_pair_comparison.json').write_text(json.dumps(out, indent=2)+'\n')
    print(json.dumps({k:out[k] for k in ('prospective_exact_public_output_parity','work_and_reported_true_residuals_equal','newton_reported_residuals_equal','rsl_baseline_over_candidate','whole_baseline_over_candidate')},indent=2))
    assert public_parity, 'Prospective exact-public-output criterion failed; preserve differences, do not relax.'

if __name__ == '__main__':
    main()
