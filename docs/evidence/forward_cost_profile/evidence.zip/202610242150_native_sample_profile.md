# One-step native ARK stack sample — bounded read-only review

작성 시각: 2026-10-24 21:50:55 JST (UTC+09:00)

## Scope

The input sample SHA-256 is `ee13ec642b68970fede46280236a0b6893369b804fe5cbbdc2ff09dec7843ed8`. It samples PID `63856` for 15 seconds at 1 ms intervals, mapped to executable SHA `ad3abbbfdb41a1285fad2894c117b999e5572bc3b08526646ede2a0653a96bab`. The one-step run completed RC=0 with one accepted outer step and three converged Newton stages; its receipt marks it `cost_eligible=false`. The sample tree has 9,689 main-thread samples. The PMIx thread is blocked in `kevent` and the work-queue thread is blocked in `__workq_kernreturn`; both are excluded.

## Exclusive self-sample buckets

The parser uses each call-graph row's sample count minus the sum of its direct children. Ancestor assignment precedence is JVP, preconditioner, other FGMRES, then stage/RHS outside. The four buckets sum exactly to 9,689 self samples; percentages are approximate stack shares, not exclusive wall time.

| Bucket | Exclusive self samples | Approx. main-thread share |
|---|---:|---:|
| jvp | 6664 | 68.779% |
| preconditioner | 518 | 5.346% |
| other_fgmres | 2339 | 24.141% |
| stage_rhs_outside | 168 | 1.734% |

The call tree's largest inclusive stack nodes include `solve_stage_impl` 9,507, `solve_fgmres` 6,032, `compute_jvp_forward_mode` 5,944, and `compute_jvp_fwad_or_fd` 5,942. These inclusive counts overlap and must not be summed.

## C++ RHS and tensor-copy paths

| Function / kernel | Max inclusive samples on one path | Exclusive self samples |
|---|---:|---:|
| `computeUnifiedRHS` | 711 | 4 |
| `native_w_phi_horizontal` | 678 | 0 |
| `native_w_phi_horizontal_core` | 315 | 0 |
| `centered` | 47 | 0 |
| `periodic_select` | 46 | 0 |
| `index_select` | 46 | 0 |

Copy-named self samples total 1,384, including 1,283 direct-copy-kernel samples. The `index_select` subtree contributes 342 exclusive samples (297 under `periodic_select`). Conversion/helper self samples include `arange` 2, `Tensor::to` 4, `contiguous` 9, `cat` 27, and `memcpy`/`memmove` 326. These categories overlap and must not be summed.
Within the 2,339 exclusive samples assigned to other FGMRES (JVP and preconditioner paths excluded), leaf symbols classify as add-kernel 781 (33.39%), multiply 588 (25.14%), dot 558 (23.86%), norm 201 (8.59%), copy 4 (0.17%), and other 207 (8.85%). These counts sum exactly to the bucket; they do not identify one source statement.

A narrow candidate to evaluate is the modified Gram-Schmidt update in `wrf_sdirk3_newton_solver.cpp` around line 3412: replace `w = w - H[i][j] * V[i]` with out-of-place `torch::addcmul(w, H[i][j], V[i], -1)` to fuse the elementwise multiply/subtract and avoid a product temporary. The aggregate add/mul samples are only suggestive; FMA/rounding can differ, so preserve tolerance, orthogonalization order, and true-residual checks and run parity tests before adopting. No change was made.

## Limits

This is one accepted step sampled under explicit telemetry, not a benchmark and not a forecast-wide cost estimate. It reports approximate stack shares only. No source edits, builds, additional tests, or model runs were performed for this review.

Machine-readable result: `analysis/native_sample_profile_review.json` (SHA-256 `3d4a9a88f6e7fc6c4f383e85fd33c24a7df1c4886711597ffcdcd73619cd2d70`).

Sample-accounting reproduction: `python3 -B analysis/reproduce_sample_accounting.py` reads the pinned raw sample and asserts exact thread-root, exclusive-self, and four-bucket totals. Script SHA-256: `fdf2edf6c35d2e8b142941792bc92dcea40461db60d4950a6fbbe928411d8304`; saved result SHA-256: `56054463978f359a5594af5b511bcac3b1db4c52b2ba54a0373b8ee84de0244d`.
