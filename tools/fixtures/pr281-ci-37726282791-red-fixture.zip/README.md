# PR281 CI h5 precision probe fixture

This fixture contains literal CI descriptors, fixed observation inputs, and the last Armijo-accepted and first full-step-rejected h=5 states/payloads from run 37726282791. `ci_h5_probe_matrices.npz` includes the source projection basis B, CI-geometry H, current H before failed iteration 9, gradients, controls, initial pullbacks, and fine base state. `full_h5_armijo_reconstruction.json` has all 24 h=5 evaluation paths and the reconstructed Armijo sequence.

Probe the two included state files on an isolated Linux build that matches the CI source/compiler context, using the included literal observation file and descriptors. CLI syntax:

```text
test_native_wave_refinement 16 12 8 <out.csv> --physical-wave-inverse <state.txt> fixed_physical_observations.txt 60 5 --newton-tol 1e-13 --krylov-tol 1e-10
```

The current C++ adapter also accepts the default comparison (`--newton-tol 1e-12 --krylov-tol 1e-8`). No probe calls were run. Local Mac descriptor-only checks found a fine-grid PHB difference of 0.0078125 and a base difference of 9.09e-13 versus CI; do not use that Mac executable for a same-context trajectory replay. The CI observation file is authoritative; locally source-regenerated observation values differ by up to 7.8063e-16.
